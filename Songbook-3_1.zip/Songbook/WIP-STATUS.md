# Songbook 3.1 - new header and icon (not yet compiled)

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.
