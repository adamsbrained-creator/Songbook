# zips

Put a Songbook project zip here (GitHub: **Add file ▸ Upload files**, commit to `main`).
The workflow **Signed build from zip** unpacks it, builds it, signs it and publishes the APK under **Releases**.
