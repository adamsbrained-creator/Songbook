package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// The Coral icon: a near-black tile, a coral book with a darker spine and a white eighth note.
// Keep the colors the same as res/drawable/ic_launcher_*.xml.
private val IconBg = Color(0xFF111111)
private val IconTop = Color(0xFFFF8A6B)
private val IconBottom = Color(0xFFF0573A)
private val IconSpine = Color(0xFFC8442A)

// The same outlines as res/drawable/ic_launcher_foreground.xml, on the 108 x 108 grid.
private const val BookPath =
    "M39 28 L69 28 C72.314 28 75 30.686 75 34 L75 74 C75 77.314 72.314 80 69 80 L39 80 C35.686 80 33 77.314 33 74 L33 34 C33 30.686 35.686 28 39 28 Z"
private const val SpinePath =
    "M40 28 L39 28 C35.686 28 33 30.686 33 34 L33 74 C33 77.314 35.686 80 39 80 L40 80 Z"
private const val NotePath =
    "M 54.95 42.72 Q 54.95 41.37 56.31 41.37 L 58.87 41.37 Q 60.22 41.37 60.22 42.72 C 60.22 48.91 71.3 48.62 71.3 57.9 C 71.3 59.34 70.13 60.51 68.68 60.51 C 67.24 60.51 66.07 59.34 66.07 57.9 C 66.07 53.74 64.48 51.33 61.58 49.68 Q 60.22 48.91 60.22 51.52 L 60.22 60.82 C 60.22 63.44 58.22 66.12 55.15 67.6 C 52.09 69.07 48.6 69.04 46.33 67.52 C 44.06 66 43.48 63.29 44.86 60.69 C 46.24 58.08 49.3 56.11 52.59 55.7 Q 54.95 55.41 54.95 53.03 L 54.95 42.72 Z"

/** In-app copy of the Songbook icon: a dark tile with the coral book and the white note. */
@Composable
fun AppIconArt(size: Dp, modifier: Modifier = Modifier) {
    val bookPath = remember { PathParser().parsePathString(BookPath).toPath() }
    val spinePath = remember { PathParser().parsePathString(SpinePath).toPath() }
    val notePath = remember { PathParser().parsePathString(NotePath).toPath() }
    val shape = RoundedCornerShape(size * 0.225f)
    Canvas(
        modifier.size(size)
            .shadow(if (size > 60.dp) 12.dp else 0.dp, shape)
            .clip(shape)
            .border(1.dp, Color(0x14FFFFFF), shape)
    ) {
        val s = this.size.width / 108f
        scale(s, s, pivot = Offset.Zero) {
            drawRect(IconBg, size = Size(108f, 108f))
            // the picture is drawn a little larger than in the launcher icon because the whole tile is visible here
            scale(1.2f, 1.2f, pivot = Offset(54f, 54f)) {
                drawPath(
                    bookPath,
                    Brush.linearGradient(
                        listOf(IconTop, IconBottom),
                        start = Offset(40f, 28f),
                        end = Offset(68f, 80f)
                    )
                )
                drawPath(spinePath, IconSpine)
                drawPath(notePath, Color.White)
            }
        }
    }
}
