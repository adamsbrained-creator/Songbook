package com.songbook.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.songbook.app.data.Keys
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlin.math.roundToInt

/** Pick the key of a song, or leave it on Automatic (worked out from the chords). [onSave] gets "" for Automatic. */
@Composable
fun KeyDialog(manual: String, auto: String?, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val c = Sb.colors
    var minor by remember { mutableStateOf(manual.endsWith("m")) }
    var picked by remember { mutableStateOf(manual) }
    SbDialog("Key", onDismiss, "Save", { onSave(picked) }) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(12.dp)).clickable { picked = "" },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Automatic" + (auto?.let { " ($it)" } ?: " (needs two chords)"),
                    style = sbStyle(15, if (picked.isBlank()) FontWeight.SemiBold else FontWeight.Medium, if (picked.isBlank()) c.ct else c.tx)
                )
                if (picked.isBlank()) StrokeIcon(SbIcons.Check, c.ct, size = 20.dp)
            }
            Segmented(listOf("Major", "Minor"), if (minor) 1 else 0) { i ->
                val toMinor = i == 1
                if (toMinor != minor && picked.isNotBlank()) {
                    // the same tonic in the other mode: C <-> Cm
                    val idx = (if (minor) Keys.minors else Keys.majors).indexOf(picked)
                    if (idx >= 0) picked = (if (toMinor) Keys.minors else Keys.majors)[idx]
                }
                minor = toMinor
            }
            (if (minor) Keys.minors else Keys.majors).chunked(4).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { name ->
                        ChipPill(name, active = picked == name, onClick = { picked = name }, inactiveBg = c.track, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/** Set the tempo of a song with − / +, a slider or by tapping the beat. [onSave] gets 0 for "no BPM". */
@Composable
fun BpmDialog(bpm: Int, onSave: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = Sb.colors
    var value by remember { mutableIntStateOf(if (bpm > 0) bpm else 100) }
    val taps = remember { mutableStateListOf<Long>() }
    SbDialog("Tempo", onDismiss, "Save", { onSave(value.coerceIn(30, 300)) }) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { value = (value - 1).coerceAtLeast(30) }) { Text("−", style = sbStyle(28, FontWeight.Bold, c.ct)) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$value", style = sbStyle(40, FontWeight.Bold, c.tx))
                    Text("BPM", style = sbStyle(12, color = c.mu))
                }
                TextButton(onClick = { value = (value + 1).coerceAtMost(300) }) { Text("+", style = sbStyle(28, FontWeight.Bold, c.ct)) }
            }
            Slider(
                value = value.toFloat(), onValueChange = { value = it.roundToInt() }, valueRange = 30f..300f,
                colors = SliderDefaults.colors(thumbColor = c.ac, activeTrackColor = c.ac, inactiveTrackColor = c.ln)
            )
            ChipPill(
                "Tap tempo", active = true,
                onClick = {
                    val now = System.currentTimeMillis()
                    if (taps.isNotEmpty() && now - taps.last() > 2500) taps.clear()
                    taps.add(now)
                    if (taps.size > 6) taps.removeAt(0)
                    if (taps.size >= 2) {
                        val avg = taps.zipWithNext { a, b -> b - a }.average()
                        if (avg > 0) value = (60000.0 / avg).roundToInt().coerceIn(30, 300)
                    }
                }
            )
            Text(
                "Tap the button on the beat. With a tempo set, the auto scroll runs faster for fast songs and slower for slow ones.",
                style = sbStyle(12, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
            )
            ChipPill("Remove tempo", active = false, inactiveBg = c.track, onClick = { onSave(0) })
        }
    }
}

/** A free comment that is shown under the lyrics of the song. Blank (or Remove) takes it away. */
@Composable
fun CommentDialog(initial: String, onSave: (String) -> Unit, onRemove: (() -> Unit)?, onDismiss: () -> Unit) {
    val c = Sb.colors
    var text by remember { mutableStateOf(initial) }
    SbDialog("Comment", onDismiss, "Save", { onSave(text.trim()) }) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                label = { Text("Write something about this song") },
                textStyle = sbStyle(15, color = c.tx), minLines = 3, maxLines = 8,
                modifier = Modifier.fillMaxWidth()
            )
            if (onRemove != null) ChipPill("Remove comment", active = false, inactiveBg = c.track, onClick = onRemove)
        }
    }
}
