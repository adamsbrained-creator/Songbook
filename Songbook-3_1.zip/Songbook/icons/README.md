# Icon variants

`coral/`, `pink/` and `purple/` each hold the three launcher drawables (`ic_launcher_background.xml`,
`ic_launcher_foreground.xml`, `ic_launcher_monochrome.xml`) plus a PNG preview and a 512 px PNG.

The project uses **coral** (those three files are in `app/src/main/res/drawable/`).

To switch to pink or purple:
1. Copy the three `.xml` files from `icons/purple/` over the ones in `app/src/main/res/drawable/`.
2. The in-app copy of the icon (Settings and the intro) is drawn in `app/src/main/java/com/songbook/app/ui/components/AppIcon.kt`.
   Pink and purple used a gradient guitar pick there (see git history / Songbook-3_0); coral is the current drawing.
