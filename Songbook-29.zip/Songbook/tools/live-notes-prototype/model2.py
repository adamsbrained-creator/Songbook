"""More realistic guitar: body resonance near 100 Hz, level spread between strings (bass louder), room noise, previous chord ringing."""
import numpy as np
from model import *
import model

def string_gain(s):  # strings low->high, bass strings louder in a phone recording
    return [1.0, 0.95, 0.8, 0.6, 0.45, 0.38][s] if s < 6 else 0.6

def strum2(frets, tuning=OPEN, cents=0.0, down=True, dur=2.0, noise=0.004, prev=None, body=None, seed=None):
    r = np.random.default_rng(seed)
    n = int(dur * SR)
    y = np.zeros(n + SR)
    delay = r.uniform(0.008, 0.028)
    idx = [i for i, f in enumerate(frets) if f >= 0]
    if not down: idx = idx[::-1]
    peak = 0.0
    for k, s in enumerate(idx):
        m = tuning[s] + frets[s] + cents / 100.0
        v = string_gain(s if len(tuning) == 6 else 3) * float(np.exp(r.normal(0, 0.35)))
        tone = string_tone(m, dur, vel=v)
        t0 = int(k * delay * SR); y[t0:t0 + len(tone)] += tone[:len(y) - t0]
    peak = np.abs(y).max()
    # body resonance: a ~100 Hz thump that every strum excites (the top plate / air resonance), plus one near 200 Hz
    body = r.uniform(0.25, 0.9) if body is None else body
    t = np.arange(len(y)) / SR
    fr = r.uniform(92, 108)
    y += body * peak * 0.5 * np.sin(2 * np.pi * (fr + 3 * np.exp(-t * 6)) * t + r.uniform(0, 6.28)) * np.exp(-t * r.uniform(2.5, 6)) * (1 - np.exp(-t * 200))
    y += body * peak * 0.25 * np.sin(2 * np.pi * r.uniform(190, 215) * t) * np.exp(-t * r.uniform(3, 7)) * (1 - np.exp(-t * 200))
    # the chord before it still rings for a while
    if prev is not None:
        p = strum2(prev, tuning, 0.0, True, dur + 0.0, noise=0, prev=None, body=0.0, seed=(seed or 0) + 7)
        # shift: the previous chord was struck 'delay0' before; use it attenuated and decaying
        pad = int(0.0 * SR)
        y[:len(p)] += 0.35 * p[:len(y)] * np.exp(-t[:len(p)] * 1.5)[:len(y)] if len(p) >= len(y) else 0
    # room: pink-ish noise
    w = r.normal(0, 1, len(y)); pink = np.cumsum(w) * 0.02; pink -= np.convolve(pink, np.ones(2000) / 2000, mode='same')
    y += noise * peak * (w * 0.6 + pink * 2)
    y = y[:n]
    return y / (np.abs(y).max() + 1e-9) * 0.5
