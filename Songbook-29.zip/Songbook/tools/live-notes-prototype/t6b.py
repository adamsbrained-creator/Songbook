import numpy as np, live_sim, model
from t6 import *
import scenario, t6
def clean_eval(thr):
    live_sim.note_acts = orig if thr is None else with_support(thr, t6.TOP)
    ok = tot = ch = n = 0
    for seed in (3, 4, 5):
        y, marks = scenario.scenario(seed=seed, strum_gap=1.1)
        o, t, c = score(run(y, cfg6()), marks, 1.1); ok += o; tot += t; ch += c; n += len(marks)
    return f"clean Am/F/G {ok}/{tot}={ok/tot:.2f} changes/chord {ch/n:.2f}"
def real_eval(thr, progs):
    live_sim.note_acts = orig if thr is None else with_support(thr, t6.TOP)
    ok = tot = ch = n = 0
    for prog in progs:
        for seed in (1, 2, 3):
            y, marks, gap = make(prog, seed=seed)
            o, t, c = score(run(y, cfg6()), marks, gap); ok += o; tot += t; ch += c; n += len(prog)
    return f"realistic {ok}/{tot}={ok/tot:.2f} changes/chord {ch/n:.2f}"
PROGS = [["Am"]*4 + ["F"]*3 + ["G"]*3, ["C","G","Am","F","Dm","G7","Cmaj7","Em","A","D","E","Am7"]]
import t6
for top in (24, 36):
    for thr in (None, 0.2, 0.3):
        t6.TOP = top
        print(top, thr, "|", clean_eval(thr), "|", real_eval(thr, PROGS))
