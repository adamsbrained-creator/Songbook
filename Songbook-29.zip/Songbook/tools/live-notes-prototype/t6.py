import numpy as np, sys
import model, live_sim
from model import *
from model2 import strum2, string_gain
from scenario import reverb, phone
from live_sim import Cfg, run, nm
EXTRA = {"add9","madd9","add11","madd11","add#11","madd#11","7sus4","9sus4","13sus4","sus2sus4","6sus4","5","maj7sus2","maj7sus4","69","m69","11","m11","13","m13","maj9","m9","9"}
def cfg6():
    c = Cfg(); c.slash_pen = 2.0; c.inv_pen = 1.5; c.ghost = True; c.ghost_maxmidi = 55; c.ghost_k = 3.2; c.ghost_keep = 0.15
    c.extra_pen = 0.6; c.extra_types = EXTRA; c.a12_min = 0.15; return c
SHAPES = {"Am":[-1,0,2,2,1,0],"F":[-1,-1,3,2,1,1],"G":[3,2,0,0,0,3],"C":[-1,3,2,0,1,0],"Em":[0,2,2,0,0,0],"Dm":[-1,-1,0,2,3,1],"E":[0,2,2,1,0,0],"A":[-1,0,2,2,2,0],"D":[-1,-1,0,2,3,2],"G7":[3,2,0,0,0,1],"Am7":[-1,0,2,0,1,0],"Cmaj7":[-1,3,2,0,0,0]}
def make(prog, gap=1.1, seed=1):
    rr = np.random.default_rng(seed)
    total = len(prog) * gap + 2.0
    y = np.zeros(int(total * SR)); marks = []
    prev = None
    for i, nm_ in enumerate(prog):
        t0 = int((0.6 + i * gap) * SR)
        s = strum2(SHAPES[nm_], cents=rr.uniform(-10, 10), down=rr.random() < 0.7, dur=gap + 0.9, seed=seed * 50 + i)
        y[t0:t0 + len(s)] += s[:len(y) - t0]
        marks.append((0.6 + i * gap, nm_))
    y = reverb(y, seed=seed); y = phone(y)
    y += rr.normal(0, 0.002, len(y)); y = y / np.abs(y).max() * 0.5
    return y, marks, gap
def score(out, marks, gap):
    ok = tot = ch = 0; prev = None
    for t, n in out:
        k = int((t - 0.6) // gap)
        if k < 0 or k >= len(marks): continue
        if ((t - 0.6) % gap) > 0.45:
            tot += 1; w = marks[k][1]; ok += (n == w)
        if n != prev: ch += 1; prev = n
    return ok, tot, ch
# support suppression hook
def grid_s(mag, tuning=0.0):
    s = np.zeros(NN_G)
    for g in range(NN_G):
        c = NN_M0 - 0.5 + g / NN_SUB + tuning
        flo = 440 * 2 ** ((c - 0.5 / NN_SUB - 69) / 12); fhi = 440 * 2 ** ((c + 0.5 / NN_SUB - 69) / 12)
        k0 = max(1, int(np.floor(flo * len(mag) * 2 / SR))); k1 = min(len(mag) - 1, int(np.ceil(fhi * len(mag) * 2 / SR)))
        s[g] = np.sqrt(mag[k0:max(k0, k1) + 1].max())
    return np.maximum(0, s - 0.5 * np.sort(s)[NN_G // 2])
def gv(s, midi):
    gi = int(round((midi - NN_M0 + 0.5) * NN_SUB))
    if gi - 1 >= NN_G: return None
    return float(s[max(0, gi - 1):min(NN_G, gi + 2)].max())
orig = model.note_acts
def with_support(thr, top=36):
    def f(mag, tuning=0.0, iters=40, dict_=None, dtd=None):
        a = orig(mag, tuning)
        s = grid_s(mag)
        b = a.copy()
        for j in range(min(top, len(a))):
            m = NN_M0 + j; s1 = gv(s, m) + 1e-9
            parts = [v for v in (gv(s, m + 12), gv(s, m + 19.02)) if v is not None]
            if not parts: continue
            sup = min(parts) / s1
            if sup < thr: b[j] = a[j] * (sup / thr) ** 2
        return b
    return f
if __name__ == '__main__':
    PROGS = [["Am"]*4 + ["F"]*3 + ["G"]*3, ["C","G","Am","F","Dm","G7","Cmaj7","Em","A","D","E","Am7"]]
    for label, thr in (("6.0 as is", None), ("6.0 + support .25", 0.25), ("6.0 + support .4", 0.4)):
        live_sim.note_acts = orig if thr is None else with_support(thr)
        ok = tot = ch = n = 0
        for pi, prog in enumerate(PROGS):
            for seed in (1, 2, 3):
                y, marks, gap = make(prog, seed=seed)
                o, t, c = score(run(y, cfg6()), marks, gap); ok += o; tot += t; ch += c; n += len(prog)
        print(f"{label}: right {ok}/{tot} = {ok/tot:.2f}, label changes per chord {ch/n:.2f}")
