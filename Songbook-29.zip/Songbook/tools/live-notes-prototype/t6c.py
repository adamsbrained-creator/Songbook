import numpy as np, live_sim, collections
from t6 import *
live_sim.note_acts = with_support(0.2)
conf = collections.defaultdict(collections.Counter)
for prog in (["C","G","Am","F","Dm","G7","Cmaj7","Em","A","D","E","Am7"],):
    for seed in (1,2,3,4):
        y, marks, gap = make(prog, seed=seed)
        out = run(y, cfg6())
        for t, n in out:
            k = int((t - 0.6) // gap)
            if k < 0 or k >= len(marks) or ((t - 0.6) % gap) <= 0.45: continue
            conf[marks[k][1]][n] += 1
for w, c in conf.items():
    tot = sum(c.values()); print(f"{w:6s} right {c[w]/tot:.2f}  top: {c.most_common(4)}")
