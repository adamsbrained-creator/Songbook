package com.songbook.app.analysis

/** How well one chord candidate fits what was heard. Filled in by [ChordId.evaluate], reused for every candidate. */
class ChordFit {
    /** The score the candidates are ranked by (higher is better). */
    var score = 0.0
    var explained = 0.0
    var extra = 0.0
    var missing = 0.0

    /** Bit p is set for a pitch class that was heard but is not in the chord. */
    var extraMask = 0

    /** Bit p is set for a note the chord needs (its 3rd, its 7th ...) that was not heard. */
    var missingMask = 0

    /** The lowest note when it is not the root (a slash chord: C/E), else -1. */
    var bass = -1

    /** 0..1: how much of what was heard belongs to the chord, 1 = every note, and nothing the chord needs is missing. */
    val fit: Double get() = explained / (explained + ChordId.KX * extra + ChordId.KM * missing + 1e-9)
}

/**
 * Names a chord from the notes heard. Every root and every chord type is scored against the 12 pitch classes
 * (0..1 each, how strongly they sound) and the lowest note:
 *
 *  + the notes of the chord that were heard (each by its weight: the root and the 3rd count most),
 *  - notes that were heard but are not in the chord,
 *  - notes the chord needs (3rd, 7th ...) that were not heard (the 5th is never needed),
 *  - a little for complicated chords, so Cmaj7 beats Cmaj13 when the notes fit both,
 *  + a bonus when the lowest note is the root; a slash chord (C/E) when it is another note of the chord.
 *
 * Plain Kotlin, no Android.
 */
object ChordId {
    const val KX = 1.0
    const val KM = 1.2
    const val KP = 3.0
    const val ROOT_BONUS = 0.35
    const val SLASH_PEN = 2.0

    /** An inversion (C/E) has to be clearly there: the lowest note of a short, blurry reading is often a neighbour of the real root. */
    const val INV_PEN = 1.5

    /**
     * Types that a ghost note or a ringing string turns a plain chord into (Am heard as Amadd9, D as Dadd11, Asus4 as A7sus4).
     * They need clearer evidence than the plain triads and 7ths (maj7, 7, m7, sus2, sus4, 6, m6, dim, aug are not in it).
     */
    const val EXTRA_PEN = 0.6
    private val EXTRA = setOf(
        "add9", "madd9", "add11", "madd11", "add#11", "madd#11", "7sus4", "9sus4", "13sus4", "sus2sus4", "6sus4", "5",
        "maj7sus2", "maj7sus4", "69", "m69", "11", "m11", "13", "m13", "maj9", "m9", "9"
    )

    /**
     * Scores chord [t] on [root] against the pitch classes [a] (each 0..1, [total] is their sum) and the lowest note
     * [bassPc] (-1 = not known). The details go into [out]; the score is returned.
     */
    fun evaluate(a: DoubleArray, total: Double, bassPc: Int, root: Int, t: ChordType, out: ChordFit): Double {
        var expl = 0.0
        var miss = 0.0
        var inChord = 0.0
        var tones = 0
        var missMask = 0
        for (i in t.intervals.indices) {
            val pc = (root + t.intervals[i]) % 12
            val v = a[pc]
            tones = tones or (1 shl pc)
            expl += t.weights[i] * v
            inChord += v
            if (t.required[i]) {
                val lack = 1.0 - v / 0.5
                if (lack > 0.0) {
                    miss += t.weights[i] * lack
                    if (v < 0.25) missMask = missMask or (1 shl pc)
                }
            }
        }
        var extra = total - inChord
        if (extra < 0.0) extra = 0.0
        var extraMask = 0
        for (p in 0 until 12) if ((tones shr p) and 1 == 0 && a[p] >= 0.25) extraMask = extraMask or (1 shl p)
        var score = expl - KX * extra - KM * miss - KP * t.penalty
        if (t.id in EXTRA) score -= EXTRA_PEN
        var bass = -1
        if (bassPc >= 0) {
            if (bassPc == root) {
                score += ROOT_BONUS
            } else if ((tones shr bassPc) and 1 != 0) {
                bass = bassPc                                  // an inversion: C/E
                score -= INV_PEN
            } else {
                // the lowest note is not in the chord: C over a D. It is named, so it does not count as a wrong note
                score += KX * a[bassPc] - SLASH_PEN
                extra -= a[bassPc]
                if (extra < 0.0) extra = 0.0
                extraMask = extraMask and (1 shl bassPc).inv()
                bass = bassPc
            }
        }
        out.score = score
        out.explained = expl
        out.extra = extra
        out.missing = miss
        out.extraMask = extraMask
        out.missingMask = missMask
        out.bass = bass
        return score
    }

    /** The name of a note interval above the root, for "missing: the 3rd" and the like. */
    fun intervalName(iv: Int): String = when (Math.floorMod(iv, 12)) {
        0 -> "root"
        1 -> "b9"
        2 -> "9th"
        3 -> "minor 3rd"
        4 -> "3rd"
        5 -> "4th"
        6 -> "b5"
        7 -> "5th"
        8 -> "#5"
        9 -> "6th"
        10 -> "b7"
        else -> "7th"
    }
}
