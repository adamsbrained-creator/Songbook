package com.songbook.app.analysis

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** One note that was heard: its MIDI number (C4 = 60) and how strongly it sounds (0..1, the loudest note = 1). */
class HeardNote(val midi: Int, val strength: Float)

/** A chord that fits the sound too: root (C = 0), type (one of [ChordTypes]) and the bass note when it is not the root (-1 = none). */
class ChordGuess(val root: Int, val type: String, val bass: Int)

/** What Live mode hears at one moment. */
class LiveReading(
    /** The chord now (0..11, C = 0), or -1 when nothing is playing or nothing is clear yet. */
    val root: Int,
    val type: String,
    /** 0..1, how well the sound fits the chord. */
    val fit: Float,
    /** 0..1, the loudness for a meter. */
    val level: Float,
    /** The 12 notes (C first) as they sound now, the loudest = 1. */
    val notes: FloatArray,
    /** The key heard so far, or -1 while there is not enough to say. */
    val keyTonic: Int,
    val keyMinor: Boolean,
    /** True while it is too quiet to hear a chord. */
    val quiet: Boolean,
    /** 0..1, where the "someone is playing" gate sits on the same scale as [level]. */
    val gate: Float = 0f,
    /** True while it is learning the noise of the room ([LiveChords.calibrate]). */
    val calibrating: Boolean = false,
    /** The lowest note when it is not the root of the chord (the E in C/E), else -1. */
    val bass: Int = -1,
    /** The notes that were heard, lowest first: the exact notes, with their octave. */
    val heard: List<HeardNote> = emptyList(),
    /** How those notes are played on the strings ([LiveChords.strings]), or null for other instruments or when nothing playable fits. */
    val voicing: GuitarShape? = null,
    /** True when the chord named has every note that was heard and nothing it needs is missing; false = the closest chord. */
    val exact: Boolean = true,
    /** Notes heard that are not in the chord named (bit p = pitch class p), and notes the chord needs that were not heard. */
    val extraMask: Int = 0,
    val missingMask: Int = 0,
    /** Other chords that fit nearly as well (the same notes read another way: Am7 and C6). */
    val alts: List<ChordGuess> = emptyList()
)

/**
 * Finds the chord that is playing right now, from the microphone, a bit more than twenty times a second.
 *
 * The last 0.37 s is split into single notes (see "separating the notes"), the notes are fitted to the strings of the
 * instrument ([Voicing]: the exact way they are played) and the chord is named from them ([ChordId], about 60 types,
 * slash chords, and the closest chord with the notes that do not belong when it is not a standard one). There is no
 * look-ahead, so a new chord has to fit clearly better than the one that is playing, for a few readings in a row.
 * The tuning is followed while it plays (a guitar a few cents flat still gives the right chords) and the key is guessed
 * from the chords of the last minute or so.
 *
 * Plain Kotlin: [feed] takes mono samples at the microphone's rate (44.1 or 48 kHz).
 */
class LiveChords(private val inRate: Int) {
    @Volatile var precise = false

    /** 0 low (loud rooms), 1 normal, 2 high (quiet playing). */
    @Volatile var sensitivity = 1

    /** The chords of the song that is being followed (set from outside), or null. They get a bonus when a chord is picked. */
    @Volatile var song: List<SongChord>? = null

    /**
     * The strings the notes are fitted to: the open strings as MIDI notes, with a capo already added. Null = no strings
     * (piano, other instruments): the notes are only listed. Set from outside, like [precise].
     */
    @Volatile var strings: IntArray? = OpenStrings.GUITAR

    private val basicTypes: List<ChordType> = ChordEngine.LIVE_BASIC.mapNotNull { ChordTypes.get(it) }
    private val allTypes: List<ChordType> = ChordTypes.ALL

    // what is made from [song] on the microphone thread: the chords of the song as "root:type", and Basic plus the types the song uses
    private var songBuiltFor: List<SongChord>? = null
    private var songRoots: Map<String, Int> = emptyMap()       // type -> the roots (bit r) it is written on in the song
    private var songTypes: List<ChordType>? = null

    private fun rebuildSong(sc: List<SongChord>?) {
        songBuiltFor = sc
        if (sc == null || sc.isEmpty()) {
            songRoots = emptyMap()
            songTypes = null
            return
        }
        val roots = HashMap<String, Int>()
        for (c in sc) roots[c.type] = (roots[c.type] ?: 0) or (1 shl c.root)
        songRoots = roots
        val used = sc.map { it.type }.toSet()
        songTypes = ChordTypes.ALL.filter { it.id in ChordEngine.LIVE_BASIC || it.id in used }
    }

    // ---------------------------------------------------------------- down to about 11 kHz

    private val dec = max(1, Math.round(inRate / 11025.0).toInt())
    private val sr = inRate.toDouble() / dec
    private val taps = 8 * dec + 1
    private val lp = FloatArray(taps)
    private val hist = FloatArray(taps)
    private var hp = 0
    private var phase = 0

    init {
        if (dec > 1) {
            val fc = 0.45 / dec
            val mid = (taps - 1) / 2.0
            var sum = 0.0
            for (i in 0 until taps) {
                val x = i - mid
                val sinc = if (x == 0.0) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
                val w = 0.54 - 0.46 * cos(2 * PI * i / (taps - 1))
                lp[i] = (sinc * w).toFloat()
                sum += lp[i]
            }
            for (i in 0 until taps) lp[i] = (lp[i] / sum).toFloat()
        }
    }

    // ---------------------------------------------------------------- the window

    private val n = ChordEngine.N
    private val nb = ChordEngine.NB
    private val ring = FloatArray(n)
    private var rp = 0
    private var filled = 0
    private var since = 0
    private val fft = ChordEngine.Fft(n)
    private val re = DoubleArray(n)
    private val im = DoubleArray(n)
    private val mag = DoubleArray(nb)

    private val kLo = ceil(ChordEngine.FMIN * n / sr).toInt()
    private val kHi = min(nb - 1, (ChordEngine.FMAX * n / sr).toInt())
    private val kBassLo = ceil(ChordEngine.BASS_MIN * n / sr).toInt()
    private val kBassHi = min(nb - 1, (ChordEngine.BASS_MAX * n / sr).toInt())
    private val tuneLo = (100 * n / sr).toInt()
    private val tuneHi = min(nb - 2, (1500 * n / sr).toInt())
    private val midiBase = DoubleArray(nb) { k -> if (k == 0) 0.0 else 69.0 + 12.0 * log2(k * sr / n / 440.0) }
    private val weight = DoubleArray(nb) { k ->
        val d = (midiBase[k] - 57.0) / 14.0
        exp(-0.5 * d * d)
    }

    // ---------------------------------------------------------------- separating the notes
    // The partials of a low note fall on the notes of the chord (the 5th partial of an E is a G#, a major third), which
    // made power chords, add9, 6 and the like look like plain major chords. So the spectrum is split into notes instead:
    // every note 36..88 (C2..E6) is a comb of its first 8 partials (each 0.6 times the one before: tried in the Python model on
    // bright, normal and dull simulated guitars, 0.6 is the best single value, 0.7 let octave doublings vanish into the lower note), and the loudness of
    // each note is found so that the combs together match what is heard (non-negative least squares, 40 steps).

    private val nnG = NN_NOTES * NN_SUB
    private val nnDict = Array(nnG) { DoubleArray(NN_NOTES) }
    private val nnDtD = Array(NN_NOTES) { DoubleArray(NN_NOTES) }
    private val nnS = DoubleArray(nnG)
    private val nnSort = DoubleArray(nnG)
    private val nnDtS = DoubleArray(NN_NOTES)
    private val nnA = DoubleArray(NN_NOTES)
    private val nnNew = DoubleArray(NN_NOTES)

    init {
        for (j in 0 until NN_NOTES) {
            val m = NN_M0 + j
            var amp = 1.0
            for (h in 1..8) {
                val mh = m + 12.0 * log2(h.toDouble())
                for (g in 0 until nnG) {
                    val d = (NN_M0 - 0.5 + g.toDouble() / NN_SUB - mh) / 0.3
                    nnDict[g][j] += amp * exp(-0.5 * d * d)
                }
                amp *= PARTIAL_DECAY
            }
        }
        for (i in 0 until NN_NOTES) for (j in 0 until NN_NOTES) {
            var s = 0.0
            for (g in 0 until nnG) s += nnDict[g][i] * nnDict[g][j]
            nnDtD[i][j] = s
        }
    }

    /** Fills [cur] (how much each of the 12 notes sounds) and [bass] (the low notes only) from [mag]. */
    private fun noteChroma(cur: DoubleArray, bass: DoubleArray, windowSec: Double) {
        val kmax = nb - 1
        for (g in 0 until nnG) {
            val c = NN_M0 - 0.5 + g.toDouble() / NN_SUB + tuning
            val flo = 440.0 * 2.0.pow((c - 0.5 / NN_SUB - 69.0) / 12.0)
            val fhi = 440.0 * 2.0.pow((c + 0.5 / NN_SUB - 69.0) / 12.0)
            val k0 = max(1, floor(flo * n / sr).toInt())
            val k1 = min(kmax, ceil(fhi * n / sr).toInt())
            var mx = 0.0
            for (k in k0..k1) if (mag[k] > mx) mx = mag[k]
            nnS[g] = sqrt(mx)
        }
        System.arraycopy(nnS, 0, nnSort, 0, nnG)
        java.util.Arrays.sort(nnSort)
        val sortFloor = 0.5 * nnSort[nnG / 2]
        for (g in 0 until nnG) nnS[g] = max(0.0, nnS[g] - sortFloor)

        for (j in 0 until NN_NOTES) {
            var s = 0.0
            for (g in 0 until nnG) s += nnDict[g][j] * nnS[g]
            nnDtS[j] = s
            nnA[j] = 0.1
        }
        repeat(40) {
            for (j in 0 until NN_NOTES) {
                var d = 0.0
                for (i in 0 until NN_NOTES) d += nnDtD[j][i] * nnA[i]
                nnNew[j] = nnA[j] * nnDtS[j] / (d + 1e-9)
            }
            System.arraycopy(nnNew, 0, nnA, 0, NN_NOTES)
        }
        // Low notes a semitone apart cannot be told apart by a short window (A2 110 Hz and G#2 104 Hz are 6 Hz apart, a window of
        // 0.14 s resolves about 14 Hz): the weaker of the two is a ghost of the louder one (right after a strum Am showed as
        // AmMaj7/G#). Real chords almost never hold two low neighbours, so the weaker one is turned down. Only the low notes:
        // up high a weak note next to a loud one is often real (the F of a G7).
        System.arraycopy(nnA, 0, nnNew, 0, NN_NOTES)
        for (j in 0 until NN_NOTES) {
            val m = NN_M0 + j
            if (m > GHOST_MAX_MIDI) break
            val df = 440.0 * 2.0.pow((m - 69.0) / 12.0) * 0.0595
            if (df >= GHOST_K / windowSec) continue
            val nbr = max(if (j > 0) nnNew[j - 1] else 0.0, if (j + 1 < NN_NOTES) nnNew[j + 1] else 0.0)
            if (nbr >= nnNew[j]) nnA[j] = nnNew[j] * GHOST_KEEP
        }
        for (j in 0 until NN_NOTES) {
            val m = NN_M0 + j
            val p = m % 12
            cur[p] += nnA[j]
            if (m <= 55 && nnA[j] > bass[p]) bass[p] = nnA[j]
        }
    }

    // ---------------------------------------------------------------- what it remembers

    private var sx = 0.0
    private var sy = 0.0
    private var tuning = 0.0
    private val chromaS = DoubleArray(12)
    private val bassS = DoubleArray(12)
    private var wasLoud = false
    private var quietFrames = 0

    // the room: how loud it is when nobody plays, and the spectrum of that noise (learned while it is quiet)
    private val noiseMag = DoubleArray(nb)
    private var noiseRms = -1.0
    @Volatile private var calibRequest = false
    private var calib = 0

    // strum detection: hops since the sound last jumped up (99 = none lately), and the fit of the last reading
    private var sinceOnset = 99
    private var lastFit = 0f

    private var curRoot = -1
    private var curType = ""
    private var pendRoot = -1
    private var pendType = ""
    private var pendCount = 0

    // the notes heard now, and what is made from them
    private val actS = DoubleArray(NN_NOTES)          // how strongly each note 36..88 sounds, smoothed like chromaS
    private val an = DoubleArray(NN_NOTES)            // the same, the loudest = 1
    private val a12 = DoubleArray(12)                 // the notes by pitch class (0..1) for naming the chord
    private var bassPc = -1                           // the pitch class of the lowest note heard
    private var heardNotes: List<HeardNote> = emptyList()
    private var heardShape: GuitarShape? = null
    private var lastMask = -1L                        // which notes counted when the strings were last fitted
    private var lastTuning: IntArray? = null
    private var lastSolved: VoicingResult? = null
    private var lastShape: GuitarShape? = null
    private val fitTmp = ChordFit()
    private val fitBest = ChordFit()
    private val fitCur = ChordFit()
    private var curBass = -1
    private var curExact = true
    private var curExtra = 0
    private var curMissing = 0
    private var curAlts: List<ChordGuess> = emptyList()

    private val hopSec = HOP.toDouble() / sr
    private val keyDecay = exp(-ln(2.0) * hopSec / 60.0)
    private val keyProf = DoubleArray(12)
    private val chordTime = DoubleArray(24)
    private var keyTotal = 0.0
    private var keyTonic = -1
    private var keyMinor = false
    private var keyTick = 0

    private fun clearHeard() {
        heardNotes = emptyList()
        heardShape = null
        lastMask = -1L
        lastSolved = null
        lastShape = null
        curBass = -1
        curExact = true
        curExtra = 0
        curMissing = 0
        curAlts = emptyList()
    }

    fun reset() {
        java.util.Arrays.fill(ring, 0f)
        java.util.Arrays.fill(hist, 0f)
        rp = 0; filled = 0; since = 0; hp = 0; phase = 0
        sx = 0.0; sy = 0.0; tuning = 0.0
        java.util.Arrays.fill(chromaS, 0.0)
        java.util.Arrays.fill(bassS, 0.0)
        java.util.Arrays.fill(actS, 0.0)
        clearHeard()
        wasLoud = false; quietFrames = 0
        noiseRms = -1.0
        java.util.Arrays.fill(noiseMag, 0.0)
        calibRequest = false; calib = 0; sinceOnset = 99; lastFit = 0f
        curRoot = -1; curType = ""; pendRoot = -1; pendType = ""; pendCount = 0
        java.util.Arrays.fill(keyProf, 0.0)
        java.util.Arrays.fill(chordTime, 0.0)
        keyTotal = 0.0; keyTonic = -1; keyMinor = false; keyTick = 0
    }

    // ---------------------------------------------------------------- input

    /** Takes [count] microphone samples. Returns a reading when a new one is due (about every 46 ms), else null. */
    fun feed(x: FloatArray, count: Int): LiveReading? {
        var out: LiveReading? = null
        for (i in 0 until count) {
            val s = x[i]
            if (dec == 1) {
                push(s)
            } else {
                hist[hp] = s
                hp = if (hp + 1 == taps) 0 else hp + 1
                phase++
                if (phase == dec) {
                    phase = 0
                    var idx = hp - 1
                    if (idx < 0) idx += taps
                    var acc = 0f
                    for (t in 0 until taps) {
                        acc += lp[t] * hist[idx]
                        idx--
                        if (idx < 0) idx = taps - 1
                    }
                    push(acc)
                }
            }
            if (filled >= n && since >= HOP) {
                since = 0
                out = process()
            }
        }
        return out
    }

    private fun push(v: Float) {
        ring[rp] = v
        rp = if (rp + 1 == n) 0 else rp + 1
        if (filled < n) filled++
        since++
    }

    // ---------------------------------------------------------------- one reading

    /** Learns the noise of the room again for about two seconds: the sound heard meanwhile counts as noise, so stay quiet. */
    fun calibrate() {
        calibRequest = true
    }

    /** How far above the room's own noise the sound has to be (in RMS) before it counts as playing. */
    private fun gateRatio(): Double = when (sensitivity) {
        0 -> 2.5
        2 -> 1.35
        else -> 1.8
    }

    /** The lowest level that can ever count, for a very quiet room. */
    private fun gateFloor(): Double = when (sensitivity) {
        0 -> 0.003
        2 -> 0.0005
        else -> 0.0012
    }

    /** How much of the sound has to belong to a chord (0..1, [ChordFit.fit]) for it to be named. High accepts weaker, quieter matches. */
    private fun minFit(): Double = when (sensitivity) {
        0 -> 0.50
        2 -> 0.35
        else -> 0.42
    }

    private fun currentGate(): Double = max(gateFloor(), gateRatio() * max(noiseRms, 0.0))

    /** Learns the room: the level and the spectrum of what is heard when nobody plays. It falls fast, rises slowly. */
    private fun trackNoise(rms: Double, quietNow: Boolean) {
        if (noiseRms < 0) {
            noiseRms = rms
            for (k in 0 until nb) noiseMag[k] = mag[k]
            return
        }
        noiseRms = when {
            rms < noiseRms -> noiseRms + 0.3 * (rms - noiseRms)
            quietNow -> noiseRms + 0.1 * (rms - noiseRms)
            else -> min(rms, noiseRms * 1.002)
        }
        for (k in 0 until nb) {
            val m = mag[k]
            val z = noiseMag[k]
            noiseMag[k] = when {
                m < z -> z + 0.2 * (m - z)
                quietNow -> z + 0.1 * (m - z)
                else -> min(m, z * 1.003)
            }
        }
    }

    private fun process(): LiveReading {
        var sumSq = 0.0
        for (i in 0 until n) {
            val v = ring[(rp + i) % n].toDouble()
            sumSq += v * v
            re[i] = v * ChordEngine.window[i]
            im[i] = 0.0
        }
        val rms = sqrt(sumSq / n)
        val level = ((20.0 * log10(max(rms, 1e-6)) + 60.0) / 50.0).coerceIn(0.0, 1.0).toFloat()

        // the newest hop against the one before it: a jump up is a strum
        var newSq = 0.0
        var oldSq = 0.0
        for (i in 0 until HOP) {
            val a = ring[(rp + n - HOP + i) % n].toDouble()
            val b = ring[(rp + n - 2 * HOP + i) % n].toDouble()
            newSq += a * a
            oldSq += b * b
        }
        val newRms = sqrt(newSq / HOP)
        val oldRms = sqrt(oldSq / HOP)

        fft.transform(re, im)
        val norm = 4.0 / n
        for (k in 0 until nb) mag[k] = hypot(re[k], im[k]) * norm

        if (calibRequest) {
            calibRequest = false
            calib = CALIB_FRAMES
            noiseRms = -1.0
        }
        val calibrating = calib > 0
        if (calibrating) calib--
        val quietNow = calibrating || noiseRms < 0 || rms < currentGate()
        trackNoise(rms, quietNow)

        if (calibrating || rms < currentGate()) {
            // quiet: the sound dies away, the chord is cleared after about half a second
            wasLoud = false
            sinceOnset = 99
            quietFrames++
            for (p in 0 until 12) chromaS[p] *= 0.8
            for (j in 0 until NN_NOTES) actS[j] *= 0.8
            if (quietFrames >= 11) {
                curRoot = -1
                curType = ""
                pendRoot = -1
                pendCount = 0
                clearHeard()
            }
            return reading(level, 0f, quiet = true, calibrating = calibrating)
        }
        quietFrames = 0

        // A strum: the sound jumps up. The old chord is still in the window, so for the next few readings only the sound
        // since the strum is looked at (a shorter window, a bit less sharp) and the new chord may win at once.
        if (newRms > ONSET_RATIO * oldRms + 1e-9 && newRms > ONSET_GATES * currentGate()) sinceOnset = 0
        else if (sinceOnset < 99) sinceOnset++
        if (sinceOnset < 2) return reading(level, lastFit, quiet = false)       // too early to tell: keep what was shown
        val fast = sinceOnset <= FAST_UNTIL
        val eager = sinceOnset <= EAGER_UNTIL
        var cut = NOISE_CUT
        var winSec = n / sr
        if (fast) {
            val len = min(n, (sinceOnset + 1) * HOP)
            for (i in 0 until n) {
                if (i < len) {
                    val w = 0.5 - 0.5 * cos(2.0 * PI * i / (len - 1))
                    re[i] = ring[(rp + n - len + i) % n].toDouble() * w
                } else {
                    re[i] = 0.0
                }
                im[i] = 0.0
            }
            fft.transform(re, im)
            val nrm = 4.0 / len
            for (k in 0 until nb) mag[k] = hypot(re[k], im[k]) * nrm
            winSec = len / sr
            cut = NOISE_CUT * sqrt(n.toDouble() / len)      // a shorter window sees more of the noise
        }

        // take the room's noise out of the spectrum, so that a soft chord is not drowned in it
        for (k in 0 until nb) mag[k] = max(0.0, mag[k] - cut * noiseMag[k])

        followTuning()

        val cur = DoubleArray(12)
        val bass = DoubleArray(12)
        noteChroma(cur, bass, winSec)
        if (!wasLoud || fast) {
            for (p in 0 until 12) {
                chromaS[p] = cur[p]
                bassS[p] = bass[p]
            }
            for (j in 0 until NN_NOTES) actS[j] = nnA[j]
        } else {
            for (p in 0 until 12) {
                chromaS[p] = SMOOTH * chromaS[p] + (1 - SMOOTH) * cur[p]
                bassS[p] = SMOOTH * bassS[p] + (1 - SMOOTH) * bass[p]
            }
            for (j in 0 until NN_NOTES) actS[j] = SMOOTH * actS[j] + (1 - SMOOTH) * nnA[j]
        }
        wasLoud = true

        val fit = decide(eager)
        lastFit = fit
        listen()
        return reading(level, fit, quiet = false)
    }

    /** Follows how far the instrument is tuned from A = 440 Hz: the loud partials vote, with the recent past counting most. */
    private fun followTuning() {
        var mx = 0.0
        for (k in tuneLo until tuneHi) if (mag[k] > mx) mx = mag[k]
        if (mx <= 0.0) return
        sx *= TUNE_KEEP
        sy *= TUNE_KEEP
        for (k in tuneLo + 1 until tuneHi - 1) {
            val v = mag[k]
            if (v > mag[k - 1] && v >= mag[k + 1] && v > 0.1 * mx) {
                val a = mag[k - 1]
                val c = mag[k + 1]
                val d = 0.5 * (a - c) / (a - 2 * v + c + 1e-12)
                val fr = (k + d) * sr / n
                val midi = 69 + 12 * log2(fr / 440.0)
                val dev = midi - Math.rint(midi)
                sx += v * cos(2 * PI * dev)
                sy += v * sin(2 * PI * dev)
            }
        }
        if (sx != 0.0 || sy != 0.0) tuning = atan2(sy, sx) / (2 * PI)
    }

    /**
     * Works out which notes are heard: when there are strings to fit them to, the playable voicing that explains the sound
     * best (the notes are then the ones that voicing plays), else the notes that clearly stand out. Fills [heardNotes],
     * [heardShape], [a12] (the notes by pitch class, for naming) and [bassPc]. False when fewer than two different notes
     * are heard, so there is no chord to name.
     */
    private fun hearNotes(): Boolean {
        var mx = 1e-9
        for (j in 0 until NN_NOTES) if (actS[j] > mx) mx = actS[j]
        for (j in 0 until NN_NOTES) an[j] = actS[j] / mx

        val st = strings
        var midis: List<Int>? = null
        var fromStrings = false
        if (st != null) {
            // fit the strings again only when the set of notes that count has changed: the search is the costly part
            var mask = 0L
            for (j in 0 until NN_NOTES) if (an[j] >= MASK_MIN) mask = mask or (1L shl j)
            if (mask != lastMask || lastTuning !== st) {
                lastMask = mask
                lastTuning = st
                val v = Voicing.solve(an, st)
                lastSolved = v
                lastShape = v?.let { Voicing.toShape(it.frets) }
            }
            val v = lastSolved
            if (v != null) {
                midis = v.notes.toList()
                fromStrings = true
            }
        }
        if (midis == null) {
            val l = ArrayList<Int>()
            for (j in 0 until NN_NOTES) {
                val v = an[j]
                if (v < NOTE_MIN) continue
                val lo = if (j > 0) an[j - 1] else 0.0
                val hi = if (j + 1 < NN_NOTES) an[j + 1] else 0.0
                if (max(lo, hi) > 2.0 * v) continue                                  // leakage of a louder neighbour
                if (j + 12 < NN_NOTES && an[j + 12] > 2.5 * v && v < 0.4) continue    // the ghost an octave below a note
                l.add(NN_M0 + j)
            }
            midis = l
        }
        heardShape = if (fromStrings) lastShape else null
        val notes = ArrayList<HeardNote>()
        java.util.Arrays.fill(a12, 0.0)
        var low = Int.MAX_VALUE
        for (m in midis) {
            val strength = (if (m - NN_M0 in 0 until NN_NOTES) an[m - NN_M0] else 0.0).coerceIn(0.0, 1.0)
            notes.add(HeardNote(m, strength.toFloat()))
            if (fromStrings && strength < A12_MIN) continue     // a string the fit added that hardly sounds is not a note heard
            val v = if (fromStrings) 0.4 + 0.6 * strength else strength
            val pc = m % 12
            if (v > a12[pc]) a12[pc] = v
            if (strength >= BASS_MIN_STRENGTH && m < low) low = m     // the lowest note has to be a clear one: a guitar body hums at about 100 Hz
        }
        heardNotes = notes
        bassPc = if (low == Int.MAX_VALUE) -1 else low % 12
        var distinct = 0
        for (p in 0 until 12) if (a12[p] > 0.0) distinct++
        return distinct >= 2
    }

    /** Picks the chord. Returns how well the chord that is playing fits (0..1). */
    private fun decide(eager: Boolean): Float {
        val sc = song
        if (sc !== songBuiltFor) rebuildSong(sc)
        if (!hearNotes()) {
            // a single note, or nothing clear: there is no chord. The one that played stays until the sound dies away
            pendCount = 0
            return if (curRoot >= 0) lastFit else 0f
        }
        val types = if (precise) allTypes else (songTypes ?: basicTypes)
        var total = 0.0
        for (p in 0 until 12) total += a12[p]
        val inSong = songRoots
        val dia = if (keyTonic >= 0) ChordEngine.diatonic(keyTonic, keyMinor) else emptySet()

        var bestE = -1e9
        var bestRoot = -1
        var bestType: ChordType? = null
        var curE = -1e9
        var haveCur = false
        // the best few: score, root, type, bass (kept sorted, best first)
        val altE = DoubleArray(ALTS + 1) { -1e9 }
        val altRoot = IntArray(ALTS + 1)
        val altType = arrayOfNulls<ChordType>(ALTS + 1)
        val altBass = IntArray(ALTS + 1)
        for (r in 0 until 12) {
            for (t in types) {
                var e = ChordId.evaluate(a12, total, bassPc, r, t, fitTmp)
                if (t.id in DIA_TYPES && dia.contains(r * 2 + (if (ChordEngine.isMinorType(t.id)) 1 else 0))) e += DIA_BONUS
                if (inSong.isNotEmpty()) {
                    val m = inSong[t.id]
                    if (m != null && ((m shr r) and 1) != 0) e += SONG_BONUS
                }
                if (r == curRoot && t.id == curType) {
                    curE = e
                    haveCur = true
                    copyFit(fitTmp, fitCur)
                }
                if (e > bestE) {
                    bestE = e
                    bestRoot = r
                    bestType = t
                    copyFit(fitTmp, fitBest)
                }
                if (e > altE[ALTS]) {
                    var k = ALTS
                    while (k > 0 && altE[k - 1] < e) {
                        altE[k] = altE[k - 1]; altRoot[k] = altRoot[k - 1]; altType[k] = altType[k - 1]; altBass[k] = altBass[k - 1]
                        k--
                    }
                    altE[k] = e; altRoot[k] = r; altType[k] = t; altBass[k] = fitTmp.bass
                }
            }
        }
        // a chord of the other vocabulary (the extra types after switching to Basic) cannot stay
        if (curRoot >= 0 && !haveCur) {
            curRoot = -1
            curType = ""
        }
        val best = bestType
        if (best == null || fitBest.fit < minFit()) {
            pendCount = 0
            return if (curRoot >= 0) fitCur.fit.toFloat() else 0f
        }
        if (best.id == curType && bestRoot == curRoot) {
            pendCount = 0
        } else if (curRoot < 0 || bestE - curE > (if (eager) MARGIN * 0.4 else MARGIN)) {
            if (bestRoot == pendRoot && best.id == pendType) pendCount++ else {
                pendRoot = bestRoot
                pendType = best.id
                pendCount = 1
            }
            if (pendCount >= (if (eager) 1 else CONFIRM)) {
                curRoot = bestRoot
                curType = best.id
                copyFit(fitBest, fitCur)
                curE = bestE
                pendCount = 0
            }
        } else {
            pendCount = 0
        }
        if (curRoot < 0) return 0f

        // the details of the chord that is shown
        curBass = fitCur.bass
        curExtra = fitCur.extraMask
        curMissing = fitCur.missingMask
        curExact = fitCur.extraMask == 0 && fitCur.missingMask == 0
        val alts = ArrayList<ChordGuess>()
        for (k in 0 until ALTS) {
            val t = altType[k] ?: continue
            if (altRoot[k] == curRoot && t.id == curType) continue
            if (curE - altE[k] > ALT_WITHIN) continue
            alts.add(ChordGuess(altRoot[k], t.id, altBass[k]))
            if (alts.size >= 2) break
        }
        curAlts = alts
        return fitCur.fit.toFloat()
    }

    private fun copyFit(a: ChordFit, b: ChordFit) {
        b.score = a.score
        b.explained = a.explained
        b.extra = a.extra
        b.missing = a.missing
        b.extraMask = a.extraMask
        b.missingMask = a.missingMask
        b.bass = a.bass
    }

    /** Adds the chord that plays to the picture of the key, and reads the key from it now and then. */
    private fun listen() {
        for (i in 0 until 12) keyProf[i] *= keyDecay
        for (i in 0 until 24) chordTime[i] *= keyDecay
        keyTotal *= keyDecay
        if (curRoot < 0) return
        for ((iv, w) in ChordEngine.TYPE_NOTES.getValue(curType)) keyProf[(curRoot + iv) % 12] += hopSec * w
        chordTime[curRoot * 2 + (if (ChordEngine.isMinorType(curType)) 1 else 0)] += hopSec
        keyTotal += hopSec
        keyTick++
        if (keyTotal < KEY_AFTER || keyTick % 10 != 0) return
        var best = -1e9
        var bt = 0
        var bm = false
        for (minor in listOf(false, true)) {
            val kk = if (minor) ChordEngine.KK_MIN else ChordEngine.KK_MAJ
            for (t in 0 until 12) {
                var sc = ChordEngine.pearson(keyProf, ChordEngine.rolled(kk, t))
                sc += 0.25 * chordTime[t * 2 + (if (minor) 1 else 0)] / keyTotal
                if (sc > best) {
                    best = sc
                    bt = t
                    bm = minor
                }
            }
        }
        keyTonic = bt
        keyMinor = bm
    }

    private fun reading(level: Float, fit: Float, quiet: Boolean, calibrating: Boolean = false): LiveReading {
        var top = 1e-9
        for (p in 0 until 12) if (chromaS[p] > top) top = chromaS[p]
        val notes = FloatArray(12) { (chromaS[it] / top).toFloat() }
        val gateLevel = ((20.0 * log10(max(currentGate(), 1e-6)) + 60.0) / 50.0).coerceIn(0.0, 1.0).toFloat()
        val named = curRoot >= 0
        return LiveReading(
            curRoot, curType, fit, level, notes, keyTonic, keyMinor, quiet, gateLevel, calibrating,
            bass = if (named) curBass else -1, heard = heardNotes, voicing = heardShape,
            exact = curExact, extraMask = if (named) curExtra else 0, missingMask = if (named) curMissing else 0,
            alts = if (named) curAlts else emptyList()
        )
    }

    private companion object {
        /** New samples (at about 11 kHz) between two readings: 46 ms. */
        const val HOP = 512
        const val SMOOTH = 0.5
        const val TUNE_KEEP = 0.97
        /** How many times the learned room noise is taken off each bin of the spectrum. */
        const val NOISE_CUT = 1.5
        /** The bonus for a chord that is written in the song being followed (about as much as the margin a new chord needs). */
        const val SONG_BONUS = 0.5
        /** The bonus for a chord that belongs to the key heard so far, and the types it is given to (not the exotic ones). */
        const val DIA_BONUS = 0.12
        val DIA_TYPES = setOf("", "m", "7", "m7", "maj7", "6", "m6", "add9", "9", "sus4", "sus2")
        /** A note counts as heard from this strength (0..1) up, when no strings are known. */
        const val NOTE_MIN = 0.25
        /** The strings are fitted again when the set of notes at least this strong changes. */
        const val MASK_MIN = 0.15
        /** Other readings of the notes: how many are kept, and how close to the chord shown (score) they have to be. */
        const val ALTS = 3
        const val ALT_WITHIN = 0.6
        /** How much weaker each partial of a note is than the one before, in the sqrt-magnitude the notes are fitted in. */
        const val PARTIAL_DECAY = 0.6
        /** Ghost notes: the low notes (up to G3) whose neighbour is louder are turned down to this share, when the window cannot separate them (GHOST_K / window length in Hz). */
        const val GHOST_MAX_MIDI = 55
        const val GHOST_K = 3.2
        const val GHOST_KEEP = 0.15
        /** A note the string fit plays counts for naming the chord only from this strength (0..1) up. */
        const val A12_MIN = 0.15
        /** The lowest note only gives the bass (C/E) and the root bonus from this strength (0..1) up. */
        const val BASS_MIN_STRENGTH = 0.4
        /** A strum has to be this many times louder than the gate: a tiny blip over the gate is not a new chord (and the short window it starts is the blurry one). */
        const val ONSET_GATES = 4.0
        const val NN_M0 = 36
        const val NN_NOTES = 53
        const val NN_SUB = 3
        /** The newest 46 ms has to be this many times louder than the 46 ms before to count as a strum. */
        const val ONSET_RATIO = 2.2
        /** After a strum, readings up to this many hops later use only the sound since the strum. */
        const val FAST_UNTIL = 7
        /** ... and up to this many hops later the new chord may win at once. */
        const val EAGER_UNTIL = 4
        /** Readings (46 ms each) of "Listen to the room": about two seconds. */
        const val CALIB_FRAMES = 44
        /** A new chord has to beat the one playing by this much (in [ChordId] score units: about the weight of one chord note). */
        const val MARGIN = 0.6
        /** Readings in a row it has to win. */
        const val CONFIRM = 3
        /** Seconds of chords needed before a key is named. */
        const val KEY_AFTER = 8.0
    }
}
