import numpy as np
from model import *
import model
from scipy.signal import fftconvolve, butter, lfilter
def reverb(y, rt=0.25, seed=1):
    r=np.random.default_rng(seed); n=int(rt*SR)
    ir=r.normal(0,1,n)*np.exp(-np.arange(n)/SR*6.9/rt); ir[0]=1.5
    return fftconvolve(y,ir)[:len(y)]
def phone(y):
    b,a=butter(2,90/(SR/2),btype='high'); y=lfilter(b,a,y)
    return y
def scenario(seed=3, strum_gap=0.9, prog=None, mic=True, noise=0.002):
    model.rng=np.random.default_rng(seed)
    rr=np.random.default_rng(seed+100)
    AM=[-1,0,2,2,1,0]; F=[-1,-1,3,2,1,1]; G=[3,2,0,0,0,3]
    # beginner-style open chords: Am x4 strums, F x3, G x3  (F as easy 4-string F)
    prog = prog or [("Am",AM)]*5+[("F",F)]*3+[("G",G)]*3
    total=len(prog)*strum_gap+2.0
    y=np.zeros(int(total*SR))
    marks=[]
    for i,(nm_,fr) in enumerate(prog):
        t0=int((0.6+i*strum_gap)*SR)
        s=strum(fr,dur=strum_gap+1.0,cents=rr.uniform(-10,10),down=rr.random()<0.7,noise=0.0,mic=False,delay=rr.uniform(0.008,0.02))
        # sloppy: occasionally ring open low E / extra string muffled leakage
        y[t0:t0+len(s)]+=s[:len(y)-t0]
        marks.append((0.6+i*strum_gap,nm_))
    y=reverb(y)
    if mic: y=phone(y)
    y+=rr.normal(0,noise,len(y))
    y=y/np.abs(y).max()*0.5
    return y,marks
def score(out,marks,gap):
    ok=tot=0; changes=0; prev=None; names=[]
    for t,n in out:
        k=int((t-0.6)//gap)
        if k<0 or k>=len(marks): continue
        if ((t-0.6)%gap)>0.35:
            tot+=1; w=marks[k][1]
            ok+= (n==w) or (n is not None and n.split('/')[0]==w)
        if n!=prev: changes+=1; prev=n
    return ok,tot,changes
