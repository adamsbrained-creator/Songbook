"""Bin-domain NNLS with the Hann window's own main lobe as the note shape (variant B/C)."""
import numpy as np
from model import *

def hann_kernel(x):
    # |W(x)| of a Hann window, x in bins (fractional offset from the peak), normalised to 1 at 0
    x = np.asarray(x, float)
    out = np.empty_like(x)
    small = np.abs(x) < 1e-9
    xs = np.where(small, 1.0, x)
    # Hann = 0.5 D(x) + 0.25 D(x-1) + 0.25 D(x+1) with D(x)=sinc(x) (periodic-sinc approx)
    s = lambda v: np.sinc(v)
    val = 0.5 * s(xs) + 0.25 * s(xs - 1) + 0.25 * s(xs + 1)
    out = np.where(small, 1.0, val)
    return np.abs(out)

def build_bin_dict(decay=0.7, nh=8, power=False, kmin=None, kmax=None, notes=(36, 89)):
    kmin = int(55 * N / SR) if kmin is None else kmin
    kmax = int(4200 * N / SR) if kmax is None else kmax
    ks = np.arange(kmin, kmax + 1)
    D = np.zeros((len(ks), notes[1] - notes[0]))
    for j in range(D.shape[1]):
        f0 = float(hz(notes[0] + j)); amp = 1.0
        for h in range(1, nh + 1):
            f = f0 * h
            if f < SR / 2 - 100:
                kern = hann_kernel(ks - f * N / SR)
                D[:, j] += (amp ** (2 if power else 1)) * (kern ** (2 if power else 1))
            amp *= decay
    return ks, D

def nnls_bins(mag, ks, D, DtD, power=False, comp=1.0, iters=60, floor=True):
    s = mag[ks] ** (2 if power else 1) if comp == 1.0 else mag[ks] ** comp
    if floor:
        s = np.maximum(0, s - 0.0 * np.median(s))
    dts = D.T @ s
    a = np.full(D.shape[1], 0.1 * (s.max() + 1e-12) / (D.sum(0).mean() + 1e-12))
    for _ in range(iters):
        a = a * dts / (DtD @ a + 1e-12)
    return a
