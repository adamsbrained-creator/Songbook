import numpy as np, model
from model import *
from evalnotes import build_cases
from voicing import solve
orig = model.string_tone
DECAYS = (0.4, 0.55, 0.7)
DICTS = {d: (build_dict(d, 8, 0.3),) for d in DECAYS}
for d in DECAYS: DICTS[d] = (DICTS[d][0], DICTS[d][0].T @ DICTS[d][0])

def sgrid(mag, tuning):
    s = np.zeros(NN_G)
    for g in range(NN_G):
        c = NN_M0 - 0.5 + g / NN_SUB + tuning
        flo = 440 * 2 ** ((c - 0.5 / NN_SUB - 69) / 12); fhi = 440 * 2 ** ((c + 0.5 / NN_SUB - 69) / 12)
        k0 = max(1, int(np.floor(flo * N / SR))); k1 = min(NB - 1, int(np.ceil(fhi * N / SR)))
        s[g] = np.sqrt(mag[k0:k1 + 1].max())
    return np.maximum(0, s - 0.5 * np.sort(s)[NN_G // 2])
def nn(s, D, DD):
    dts = D.T @ s; a = np.full(NN_NOTES, 0.1)
    for _ in range(40): a = a * dts / (DD @ a + 1e-9)
    return a
def hear_multi(y, te, tuning, mode):
    n = int(te * SR); seg = y[max(0, n - N):n]
    if len(seg) < N: seg = np.concatenate([np.zeros(N - len(seg)), seg])
    s = sgrid(spectrum(seg), tuning)
    best = None
    for d in DECAYS:
        D, DD = DICTS[d]; a = nn(s, D, DD)
        res = np.sum((s - D @ a) ** 2)
        if mode == 'fixed' and d != 0.55: continue
        if best is None or res < best[0]: best = (res, d, a)
    return best[2], best[1]
def run(name, alpha_rng, d0_rng):
    model.string_tone = lambda m, dur, B=None, d0=None, alpha=None, vel=1.0: orig(m, dur, B, rng.uniform(*d0_rng), rng.uniform(*alpha_rng), vel)
    cases = build_cases(40, seed=33)
    ys = [strum(c['frets'], cents=c['cents'], down=c['down'], mic=c['mic']) for c in cases]
    truths = [{OPEN[i]+f for i,f in enumerate(c['frets']) if f>=0} for c in cases]
    for mode in ('fixed', 'auto'):
        tp=fp=fn=ex=pc=tot=0; picks = {}
        for c,y,tr in zip(cases,ys,truths):
            for te in (0.45,0.9):
                a, d = hear_multi(y, te, c['cents']/100, mode); picks[d] = picks.get(d,0)+1
                an=a/a.max(); fr,_ = solve(an, theta=0.25, lam=0.6, opt_min=0.12)
                got = {OPEN[i]+f for i,f in enumerate(fr) if f>=0} if fr else set()
                tp+=len(got&tr); fp+=len(got-tr); fn+=len(tr-got); ex+=got==tr; pc+={m%12 for m in got}=={m%12 for m in tr}; tot+=1
        print(f"{name:7s} {mode:5s}: P={tp/(tp+fp):.3f} R={tp/(tp+fn):.3f} exact={ex/tot:.2f} pc={pc/tot:.2f} picks={picks}")
run("bright", (0.4, 0.8), (0.6, 1.2)); run("normal", (0.9, 1.5), (1.0, 2.2)); run("dull", (1.6, 2.4), (1.5, 2.8))
