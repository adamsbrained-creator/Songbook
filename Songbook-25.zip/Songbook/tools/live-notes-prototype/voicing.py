import numpy as np
from model import OPEN, NN_M0, NN_NOTES

def solve(a, tuning=OPEN, theta=0.3, lam=0.4, maxfret=15, span_max=4, peaks_tau=0.25, theta_oct=None, opt_min=0.07, nms=True, nms_ratio=2.0, nms_keep=0.25):
    """a: activations for midi 36.. (normalised max=1). Returns (frets, score) or (None, 0)."""
    a = np.asarray(a, float)
    if nms:
        b = a.copy()
        for j in range(len(a)):
            nb = max(a[j - 1] if j > 0 else 0.0, a[j + 1] if j + 1 < len(a) else 0.0)
            if nb > nms_ratio * a[j]: b[j] = a[j] * nms_keep
        a = b
    S = len(tuning)
    def act(p): return a[p - NN_M0] if NN_M0 <= p < NN_M0 + NN_NOTES else 0.0
    # peaks that deserve explaining: local maxima >= peaks_tau, not smaller than half of a semitone neighbour
    peaks = []
    for j in range(NN_NOTES):
        v = a[j]
        if v < peaks_tau: continue
        nb = max(a[j - 1] if j > 0 else 0, a[j + 1] if j + 1 < NN_NOTES else 0)
        if v >= 0.5 * nb: peaks.append(NN_M0 + j)
    opts = []
    for s in range(S):
        o = [-1]
        for f in range(0, maxfret + 1):
            p = tuning[s] + f
            if act(p) >= opt_min: o.append(f)
        opts.append(o)
    best = [None, -1e9]
    cur = [-1] * S
    def rec(s):
        if s == S:
            fr = cur
            sounding = [i for i in range(S) if fr[i] >= 0]
            if len(sounding) < 2: return
            fretted = [f for f in fr if f > 0]
            if fretted:
                span = max(fretted) - min(fretted)
                if span > span_max: return
            pitches = [tuning[i] + fr[i] for i in sounding]
            sc = 0.0
            seen = set()
            pset = set(pitches)
            for p in pitches:
                if p in seen: sc -= 0.35; continue
                seen.add(p)
                th = theta
                if theta_oct is not None and ((p - 12) in pset or (p + 12) in pset): th = theta_oct
                sc += (act(p) - th) / (1 - th) * 1.0
            for p in peaks:
                if p not in seen: sc -= lam * (act(p) - 0.15)
            first, last = sounding[0], sounding[-1]
            sc -= 0.12 * sum(1 for i in range(first, last + 1) if fr[i] < 0)
            sc -= 0.012 * (min(fretted) if fretted else 0)
            sc -= 0.01 * (span if fretted else 0)
            sc += 0.015 * sum(1 for i in sounding if fr[i] == 0)
            if sc > best[1]: best[0] = list(fr); best[1] = sc
            return
        for f in opts[s]:
            cur[s] = f
            rec(s + 1)
        cur[s] = -1
    rec(0)
    return best[0], best[1]
