"""Port of LiveChords.process/decide flow, for replaying simulated playing."""
import numpy as np, random, sys
from model import *
from voicing import solve
from ctypes_py import T
NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
HOP = 512
BASIC = {"", "m", "7", "m7"}

class Cfg:
    margin=0.6; confirm=3; margin_sus=0.6; confirm_sus=3
    smooth=0.5; smooth_sus=0.5
    kx=1.0; km=1.2; kp=3.0; root_bonus=0.35; slash_pen=0.5; inv_pen=0.0
    flat_a12=False   # False = 0.4+0.6*strength (current)
    a12_min=0.0
    min_pen=0.0      # extra flat penalty for non-basic
    vocab=None       # None = all
    min_fit=0.42
    eager_until=4; fast_until=7
    sustain_lock=False
    ghost=False; extra_pen=0.0; extra_types=(); ghost_maxmidi=127; ghost_k=2.4; ghost_keep=0.15
    hold_basic_fast=False

def evaluate(a, total, bass, r, t, cfg):
    suf, tones, pen = t
    expl=0; miss=0; inchord=0; tmask=0
    for iv,w,req in tones:
        pc=(r+iv)%12; v=a[pc]; tmask|=1<<pc
        expl+=w*v; inchord+=v
        if req:
            lack=1-v/0.5
            if lack>0: miss+=w*lack
    extra=max(0,total-inchord)
    sc=expl-cfg.kx*extra-cfg.km*miss-cfg.kp*pen
    if suf not in BASIC: sc-=cfg.min_pen
    if suf in cfg.extra_types: sc-=cfg.extra_pen
    b=-1
    if bass>=0:
        if bass==r: sc+=cfg.root_bonus
        elif (tmask>>bass)&1: b=bass; sc-=cfg.inv_pen
        else:
            sc+=cfg.kx*a[bass]-cfg.slash_pen; extra=max(0,extra-a[bass]); b=bass
    expl_=expl
    fit=expl_/(expl_+cfg.kx*extra+cfg.km*miss+1e-9)
    return sc,fit,b

class Live:
    def __init__(s,cfg): 
        s.cfg=cfg; s.actS=np.zeros(NN_NOTES); s.cur=None; s.pend=None; s.pc=0
        s.wasLoud=False; s.sinceOnset=99; s.lastfit=0; s.quiet=0
    def decide(s, an, eager, sus):
        cfg=s.cfg
        v,_=solve(an,opt_min=0.12)
        if v is None: return
        got=[OPEN[i]+f for i,f in enumerate(v) if f>=0]
        a12=np.zeros(12); low=1e9
        for m in got:
            st=min(1.0,max(0.0,an[m-36]))
            if st<cfg.a12_min: continue
            val = st if cfg.flat_a12 else 0.4+0.6*st
            a12[m%12]=max(a12[m%12],val); low=min(low,m)
        if (a12>0).sum()<2: return
        bass=int(low%12) if low<1e9 else -1
        total=a12.sum()
        best=None; curE=None
        for r in range(12):
            for t in T:
                if cfg.vocab is not None and t[0] not in cfg.vocab: continue
                sc,fit,b=evaluate(a12,total,bass,r,t,cfg)
                key=(r,t[0],b)
                if s.cur is not None and key[:2]==s.cur[:2]: curE=sc
                if best is None or sc>best[0]: best=(sc,key,fit)
        if best[2]<cfg.min_fit: return
        bkey=best[1]
        if s.cur is not None and curE is None: s.cur=None
        mg = cfg.margin_sus if sus else cfg.margin
        cf = cfg.confirm_sus if sus else cfg.confirm
        if s.cur is not None and bkey[:2]==s.cur[:2]:
            s.cur=bkey; s.pc=0   # bass may change
        elif s.cur is None or best[0]-curE > (mg*0.4 if eager else mg):
            if s.pend is not None and s.pend[:2]==bkey[:2]: s.pc+=1
            else: s.pend=bkey; s.pc=1
            if s.pc >= (1 if eager else cf): s.cur=bkey; s.pc=0
        else: s.pc=0

def nm(key):
    if key is None: return None
    r,suf,b=key
    return NAMES[r]+suf+(("/"+NAMES[b]) if b>=0 else "")

def suppress(a, L, k, keep, maxm=127):
    a=a.copy(); out=a.copy()
    for j in range(len(a)):
        if 36+j>maxm: continue
        f=440*2**((36+j-69)/12); df=f*0.0595
        if df>=k/L: continue
        nb=max(a[j-1] if j>0 else 0, a[j+1] if j+1<len(a) else 0)
        if nb>=a[j]: out[j]=a[j]*keep
    return out
def run(y, cfg, noise_floor=None):
    L=Live(cfg); out=[]; t=N
    hist_rms=[]
    while t < len(y):
        seg=y[t-N:t]
        rms=np.sqrt((seg**2).mean())
        new=y[t-HOP:t]; old=y[t-2*HOP:t-HOP]
        newr=np.sqrt((new**2).mean()); oldr=np.sqrt((old**2).mean())
        gate=0.004
        if rms<gate:
            L.quiet+=1; L.actS*=0.8; L.wasLoud=False; L.sinceOnset=99
            if L.quiet>=11: L.cur=None; L.pend=None
            out.append((t/SR,nm(L.cur))); t+=HOP; continue
        L.quiet=0
        if newr>2.2*oldr+1e-9 and newr>gate: L.sinceOnset=0
        elif L.sinceOnset<99: L.sinceOnset+=1
        if L.sinceOnset<2: out.append((t/SR,nm(L.cur))); t+=HOP; continue
        fast=L.sinceOnset<=cfg.fast_until; eager=L.sinceOnset<=cfg.eager_until
        ln=N
        if fast:
            ln=min(N,(L.sinceOnset+1)*HOP)
            w=0.5-0.5*np.cos(2*np.pi*np.arange(ln)/(ln-1))
            x=np.zeros(N); x[:ln]=y[t-ln:t]*w
            mag=np.abs(np.fft.rfft(x))*4.0/ln
        else:
            mag=spectrum(seg)
        a=note_acts(mag)
        if cfg.ghost: a=suppress(a, (ln if fast else N)/SR, cfg.ghost_k, cfg.ghost_keep, cfg.ghost_maxmidi)
        sm = cfg.smooth if fast or not cfg.sustain_lock else cfg.smooth_sus
        if (not L.wasLoud) or fast: L.actS=a.copy()
        else: L.actS=sm*L.actS+(1-sm)*a
        L.wasLoud=True
        an=L.actS/(L.actS.max()+1e-12)
        L.decide(an,eager, not eager)
        out.append((t/SR,nm(L.cur))); t+=HOP
    return out
