import numpy as np, random
from model import *
from voicing import solve
from ident import *
OPENS = {
 "0:":"x32010","0:maj7":"x32000","0:7":"x32310","0:sus2":"x30010","0:sus4":"x33011",
 "2:":"xx0232","2:m":"xx0231","2:7":"xx0212","2:maj7":"xx0222","2:m7":"xx0211","2:sus4":"xx0233","2:sus2":"xx0230",
 "4:":"022100","4:m":"022000","4:7":"020100","4:maj7":"021100","4:m7":"020000","4:sus4":"022200","4:sus2":"024400",
 "5:maj7":"xx3210","7:":"320003","7:7":"320001","7:maj7":"320002","7:sus4":"330013",
 "9:":"x02220","9:m":"x02210","9:7":"x02020","9:maj7":"x02120","9:m7":"x02010","9:sus4":"x02230","9:sus2":"x02200","11:7":"x21202",
 "0:add9":"x32030","4:add9":"022102","7:add9":"320203","9:add9":"x02420","0:6":"x32210","2:6":"xx0202","7:6":"320000","2:m6":"xx0201",
 "2:5":"xx023x","4:5":"022xxx","9:5":"x022xx","2:7sus4":"xx0213","7:7sus4":"330011"}
E = {"":[0,2,2,1,0,0],"m":[0,2,2,0,0,0],"7":[0,2,0,1,0,0],"m7":[0,2,0,0,0,0],"maj7":[0,2,1,1,0,0],"sus4":[0,2,2,2,0,0],"6":[0,2,2,1,2,0],"m6":[0,2,2,0,2,0],"9":[0,2,0,1,0,2],"add9":[0,2,2,1,0,2],"7sus4":[0,2,0,2,0,0]}
A = {"":[-1,0,2,2,2,0],"m":[-1,0,2,2,1,0],"7":[-1,0,2,0,2,0],"m7":[-1,0,2,0,1,0],"maj7":[-1,0,2,1,2,0],"sus4":[-1,0,2,2,3,0],"sus2":[-1,0,2,2,0,0],"6":[-1,0,2,2,2,2],"m6":[-1,0,2,2,1,2],"9":[-1,0,2,4,2,3],"add9":[-1,0,2,4,2,0],"7sus4":[-1,0,2,0,3,0],
     "dim":[-1,0,1,2,1,-1],"m7b5":[-1,0,1,0,1,-1],"dim7":[-1,0,1,2,1,2],"maj9":[-1,0,2,1,0,0],"m9":[-1,0,2,1,0,0],"7b9":[-1,0,1,0,2,-1],"7#9":[-1,0,-1,0,2,3],"13":[-1,0,2,0,2,2],"aug":[-1,0,3,2,2,1],"mMaj7":[-1,0,2,1,1,0],"6/9":[-1,0,2,2,2,2]}
def shapes():
    out = {}
    for k, v in OPENS.items():
        r, t = k.split(":"); out[(int(r), t)] = [-1 if ch == 'x' else int(ch) for ch in v]
    for tab, openpc in ((E, 4), (A, 9)):
        for t, rel in tab.items():
            for f in range(1, 9):
                r = (openpc + f) % 12
                if (r, t) in out: continue
                out[(r, t)] = [(-1 if x < 0 else x + f) for x in rel]
    return out
S = shapes()
# fix: A-shape m9 mistaken (same as maj9) -> drop doubtful ones
for bad in ("maj9", "m9"):
    for k in [k for k in S if k[1] == bad]: del S[k]
def run(seed=2, per=1):
    rnd = random.Random(seed)
    items = list(S.items()); rnd.shuffle(items)
    ok = tot = 0; bad = []
    for (r, t), fr in items:
        fr = [x for x in fr]
        for k in range(per):
            y = strum(fr, cents=rnd.uniform(-12, 12), down=rnd.random() < .7, mic=rnd.random() < .5)
            for te in (0.45, 0.9):
                a = hear(y, te); an = a / a.max()
                v, sc = solve(an, opt_min=0.12)
                tot += 1
                if v is None: bad.append((NAMES[r] + t, None)); continue
                got = [OPEN[s] + f for s, f in enumerate(v) if f >= 0]
                a12 = np.zeros(12)
                for m in got: a12[m % 12] = min(1, 0.4 + 0.6 * an[m - 36])
                res = identify(a12, min(got) % 12)
                g = name(res[0]); want = NAMES[r] + t
                if g == want: ok += 1
                else: bad.append((want, g, [NAMES[m % 12] for m in sorted(got)], fr, v))
    print(f"standard shapes: {ok}/{tot} = {ok/tot:.2f}")
    return bad
bad = run()
for b in bad[:40]: print(b)
