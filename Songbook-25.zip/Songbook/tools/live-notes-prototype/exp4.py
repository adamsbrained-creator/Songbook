import numpy as np, model, itertools
from model import *
from evalnotes import build_cases
from voicing import solve
orig = model.string_tone
D = build_dict(0.6, 8, 0.3); DD = D.T @ D
sets = []
for name, ar, dr in (("bright",(0.4,0.8),(0.6,1.2)),("normal",(0.9,1.5),(1.0,2.2)),("dull",(1.6,2.4),(1.5,2.8))):
    model.string_tone = lambda m, dur, B=None, d0=None, alpha=None, vel=1.0, ar=ar, dr=dr: orig(m, dur, B, rng.uniform(*dr), rng.uniform(*ar), vel)
    cases = build_cases(30, seed=44)
    for c in cases:
        y = strum(c['frets'], cents=c['cents'], down=c['down'], mic=c['mic'])
        tr = {OPEN[i]+f for i,f in enumerate(c['frets']) if f>=0}
        for te in (0.45, 0.9):
            a = hear(y, te, tuning=c['cents']/100, dict_=D, dtd=DD); sets.append((a/a.max(), tr))
def ev(**kw):
    tp=fp=fn=ex=pc=0
    for an,tr in sets:
        fr,_ = solve(an, **kw)
        got = {OPEN[i]+f for i,f in enumerate(fr) if f>=0} if fr else set()
        tp+=len(got&tr); fp+=len(got-tr); fn+=len(tr-got); ex+=got==tr; pc+={m%12 for m in got}=={m%12 for m in tr}
    t=len(sets); return f"{kw}: P={tp/(tp+fp):.3f} R={tp/(tp+fn):.3f} exact={ex/t:.3f} pc={pc/t:.3f}"
print(ev(theta=0.25, lam=0.6, opt_min=0.12))
for th in (0.15, 0.2, 0.3): print(ev(theta=th, lam=0.6, opt_min=0.12))
for lam in (0.3, 1.0): print(ev(theta=0.25, lam=lam, opt_min=0.12))
for nr in (1.3, 2.0): print(ev(theta=0.25, lam=0.6, opt_min=0.12, nms_ratio=nr))
for nk in (0.1, 0.4): print(ev(theta=0.25, lam=0.6, opt_min=0.12, nms_keep=nk))
print("--- combos")
print(ev(theta=0.3, lam=0.4, opt_min=0.12, nms_ratio=2.0))
print(ev(theta=0.35, lam=0.4, opt_min=0.12, nms_ratio=2.0))
print(ev(theta=0.3, lam=0.4, opt_min=0.12, nms_ratio=2.5))
