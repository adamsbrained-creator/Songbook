import numpy as np, random, sys
from model import *
from voicing import solve
from ident import *
HOP = 512
def simulate(prog, margin, confirm, seed=4, dur=2.0, vocab=None, smooth=0.5):
    r = random.Random(seed)
    y = np.zeros(int(len(prog) * dur * SR) + SR)
    for i, (nm, fr) in enumerate(prog):
        s = strum(fr, dur=dur + 0.2, cents=r.uniform(-8, 8), mic=r.random() < .5, down=r.random() < .7)
        i0 = int(i * dur * SR); y[i0:i0 + len(s)] += s[:len(y) - i0]
        if i < len(prog): pass
    y /= np.abs(y).max()
    cur = None; pend = None; pc = 0; shown = []; actS = None
    t = N
    flick = 0; lastname = None
    while t < len(y) - 1:
        a = note_acts(spectrum(y[t - N:t]))
        actS = a if actS is None else smooth * actS + (1 - smooth) * a
        an = actS / (actS.max() + 1e-12)
        v, sc = solve(an, opt_min=0.12)
        if v is not None:
            got = [OPEN[s] + f for s, f in enumerate(v) if f >= 0]
            a12 = np.zeros(12)
            for m in got: a12[m % 12] = max(a12[m % 12], min(1, 0.4 + 0.6 * an[m - 36]))
            res = identify(a12, min(got) % 12, types=vocab, top=60)
            best = res[0]
            curs = None
            if cur is not None:
                for c in res:
                    if (c[1], c[2], c[3]) == cur: curs = c; break
            if cur is None or curs is None or best[0] - curs[0] > margin:
                key = (best[1], best[2], best[3])
                if key != cur:
                    if pend is not None and pend[0] == key: pend = (key, pend[1] + 1)
                    else: pend = (key, 1)
                    if pend[1] >= confirm: cur = key; pend = None
            else: pend = None
        shown.append((t / SR, name((0, cur[0], cur[1], cur[2], 0, 0)) if cur else None))
        t += HOP
    return shown
def summarize(shown, prog, dur=2.0):
    # expected name per time window (skip first 0.5 s after each change), count mismatches and changes
    ok = tot = 0; changes = 0; prev = None; lat = []
    for ti, nm in shown:
        k = int(ti // dur)
        if k >= len(prog): break
        want = prog[k][0]
        if (ti % dur) > 0.7:
            tot += 1; ok += (nm == want)
        if nm != prev: changes += 1; prev = nm
    return ok, tot, changes
if __name__ == '__main__':
    P = [("C",[-1,3,2,0,1,0]),("G",[3,2,0,0,0,3]),("Am",[-1,0,2,2,1,0]),("F",[1,3,3,2,1,1]),("Dm7",[-1,-1,0,2,1,1]),("G7",[3,2,0,0,0,1]),("Cmaj7",[-1,3,2,0,0,0]),("Em",[0,2,2,0,0,0]),("Asus4",[-1,0,2,2,3,0]),("A",[-1,0,2,2,2,0])]
    for margin in (0.3, 0.5, 0.8):
        for conf in (2, 3):
            sh = simulate(P, margin, conf)
            ok, tot, ch = summarize(sh, P)
            print(f"margin={margin} confirm={conf}: steady-state correct {ok}/{tot}={ok/tot:.2f}, label changes {ch} (ideal {len(P)})")
