from ctypes_py import T
from model import OPEN
NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
def standard(root, suf, tuning=OPEN, maxfret=12):
    tones = next(t for s, t, p in T if s == suf)
    pcs = {(root + iv) % 12 for iv, _, _ in tones}
    req = [(root + iv) % 12 for iv, _, rq in tones if rq]
    fifth = (root + 7) % 12
    S = len(tuning)
    opts = []
    for s in range(S):
        o = [-1] + [f for f in range(0, maxfret + 1) if (tuning[s] + f) % 12 in pcs]
        opts.append(o)
    best = [None, 1e9]; cur = [-1] * S
    min_snd = 2 if len(tones) <= 2 else 3
    def rec(s, lo, hi):
        if s == S:
            snd = [i for i in range(S) if cur[i] >= 0]
            if len(snd) < min_snd: return
            ps = [(tuning[i] + cur[i]) for i in snd]
            if min(ps) % 12 != root: return
            have = {p % 12 for p in ps}
            if not all(r in have for r in req): return
            inner = sum(1 for i in range(snd[0], snd[-1] + 1) if cur[i] < 0)
            if inner > 1: return
            fretted = [f for f in cur if f > 0]
            span = (max(fretted) - min(fretted)) if fretted else 0
            cost = (min(fretted) if fretted else 0) * 0.5 + span * 0.8 + inner * 1.2 + (S - len(snd)) * 0.25 + (0.4 if fifth not in have and 7 in [iv for iv,_,_ in tones] else 0)
            cost += 0.05 * (len(ps) - len(have))
            if cost < best[1]: best[0] = list(cur); best[1] = cost
            return
        for f in opts[s]:
            nlo, nhi = lo, hi
            if f > 0:
                nlo = min(lo, f); nhi = max(hi, f)
                if nhi - nlo > 3: continue
            cur[s] = f
            rec(s + 1, nlo, nhi)
        cur[s] = -1
    rec(0, 99, 0)
    return best[0]
if __name__ == '__main__':
    for r, s in [(0,'maj9'),(9,'m7b5'),(7,'13'),(2,'7#9'),(11,'dim7'),(0,'6/9'),(4,'m9'),(5,'maj7#11'),(9,'7b9'),(0,'mMaj7'),(7,'9'),(2,'m11'),(0,'aug'),(0,'7sus4'),(0,'13sus4'),(6,'m7b5'),(0,'7alt' if False else '9')]:
        print(NAMES[r]+s, standard(r, s))
