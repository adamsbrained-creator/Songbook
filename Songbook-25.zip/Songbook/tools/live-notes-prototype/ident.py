import numpy as np
from ctypes_py import T
NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
KX, KM, KP = 1.0, 1.2, 3.0
def identify(a12, bass, types=None, top=5, root_bonus=0.35, slash_pen=0.5):
    """a12: strength per pitch class (0..1+), bass: pitch class of the lowest note (or -1)."""
    a = np.minimum(1.0, np.asarray(a12, float))
    total = a.sum()
    cands = []
    for r in range(12):
        for (suf, tones, pen) in T:
            if types is not None and suf not in types: continue
            tp = {(r + iv) % 12 for iv, _, _ in tones}
            expl = sum(w * a[(r + iv) % 12] for iv, w, _ in tones)
            miss = sum(w * max(0.0, 1.0 - a[(r + iv) % 12] / 0.5) for iv, w, req in tones if req)
            extra = sum(a[p] for p in range(12) if p not in tp)
            sc = expl - KX * extra - KM * miss - KP * pen
            b = -1
            if bass >= 0:
                if bass == r: sc += root_bonus
                elif bass in tp: b = bass
                else:
                    # slash chord over a note that is not in the chord: the bass note is not 'extra'
                    sc += KX * a[bass] - slash_pen; b = bass
            cands.append((sc, r, suf, b, extra, miss))
    cands.sort(key=lambda c: -c[0])
    return cands[:top]
def name(c):
    sc, r, suf, b, ex, mi = c
    return NAMES[r] + suf + (("/" + NAMES[b]) if b >= 0 else "")
