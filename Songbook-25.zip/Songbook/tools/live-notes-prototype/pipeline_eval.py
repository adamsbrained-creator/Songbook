import numpy as np, random, sys
from model import *
from voicing import solve
from ident import *
from ctypes_py import T
rnd = random.Random(8)
def gen_voicing(root, tones, tries=400):
    req = [iv for iv, w, rq in tones if rq]
    allt = [iv for iv, w, rq in tones]
    for _ in range(tries):
        base = rnd.randrange(0, 10); span = rnd.randint(2, 4)
        fr = []
        for s in range(6):
            opts = [-1]
            for f in list(range(0, 1)) + list(range(base, base + span + 1)):
                p = OPEN[s] + f
                if (p - root) % 12 in allt: opts.append(f)
            fr.append(rnd.choice(opts) if rnd.random() > 0.15 else (opts[1] if len(opts) > 1 else -1))
        pcs = {(OPEN[s] + f) % 12 for s, f in enumerate(fr) if f >= 0}
        if sum(1 for f in fr if f >= 0) < 3: continue
        if not all((root + iv) % 12 in pcs for iv in req): continue
        fretted = [f for f in fr if f > 0]
        if fretted and max(fretted) - min(fretted) > 4: continue
        low = min(OPEN[s] + f for s, f in enumerate(fr) if f >= 0)
        if low % 12 != root and rnd.random() < 0.7: continue
        return fr
    return None

def run(n_per_type=2, flat=False, seed=1):
    global rnd; rnd = random.Random(seed)
    ok_truth = ok_intended = tot = 0; fails = []
    for suf, tones, pen in T:
        for k in range(n_per_type):
            root = rnd.randrange(12)
            fr = gen_voicing(root, tones)
            if fr is None: continue
            truth = [OPEN[s] + f for s, f in enumerate(fr) if f >= 0]
            a12t = np.zeros(12)
            for m in truth: a12t[m % 12] = 1
            tr = identify(a12t, min(truth) % 12)
            truth_name = name(tr[0])
            y = strum(fr, cents=rnd.uniform(-12, 12), down=rnd.random() < .7, mic=rnd.random() < .5)
            for te in (0.45, 0.9):
                a = hear(y, te); an = a / a.max()
                v, sc = solve(an, opt_min=0.12)
                tot += 1
                if v is None: fails.append((NAMES[root] + suf, 'no voicing')); continue
                got = [OPEN[s] + f for s, f in enumerate(v) if f >= 0]
                a12 = np.zeros(12)
                for m in got: a12[m % 12] = 1.0 if flat else min(1, 0.4 + 0.6 * an[m - 36])
                res = identify(a12, min(got) % 12)
                gname = name(res[0])
                ok_truth += gname == truth_name; ok_intended += gname == NAMES[root] + suf
                if gname != truth_name: fails.append((NAMES[root] + suf, truth_name, gname, [NAMES[m % 12] for m in sorted(truth)], [NAMES[m % 12] for m in sorted(got)]))
    print(f"flat={flat}: matches name-from-true-notes {ok_truth}/{tot} = {ok_truth/tot:.2f}; matches intended {ok_intended}/{tot} = {ok_intended/tot:.2f}")
    return fails
f = run(2, flat=False)
for x in f[:25]: print(x)
