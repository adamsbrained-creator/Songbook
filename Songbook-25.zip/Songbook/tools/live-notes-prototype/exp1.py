import pickle, sys
import numpy as np
import model
from model import *
from evalnotes import build_cases
from voicing import solve
cases = build_cases(60, seed=21)
ys = [strum(c['frets'], cents=c['cents'], down=c['down'], mic=c['mic']) for c in cases]
truths = [{OPEN[i]+f for i,f in enumerate(c['frets']) if f>=0} for c in cases]
def run(decay, nh, sigma, t_ends=(0.45,0.9)):
    D = build_dict(decay, nh, sigma); DD = D.T @ D
    tp=fp=fn=ex=pc=tot=0
    for c,y,tr in zip(cases,ys,truths):
        for te in t_ends:
            a = hear(y, te, tuning=c['cents']/100, dict_=D, dtd=DD); an=a/a.max()
            fr,_ = solve(an, theta=0.25, lam=0.6, opt_min=0.12)
            got = {OPEN[i]+f for i,f in enumerate(fr) if f>=0} if fr else set()
            tp+=len(got&tr); fp+=len(got-tr); fn+=len(tr-got); ex+=got==tr; pc+={m%12 for m in got}=={m%12 for m in tr}; tot+=1
    return f"decay={decay} nh={nh} sigma={sigma}: P={tp/(tp+fp):.3f} R={tp/(tp+fn):.3f} exact={ex/tot:.2f} pc={pc/tot:.2f}"
for d in (0.5, 0.6, 0.7, 0.8):
    print(run(d, 8, 0.3))
print(run(0.7, 8, 0.4)); print(run(0.7, 8, 0.25)); print(run(0.7, 12, 0.3))
