import numpy as np, model
from model import *
from evalnotes import build_cases
from voicing import solve
orig = model.string_tone
def run_variant(name, alpha_rng, d0_rng, decays):
    model.string_tone = lambda m, dur, B=None, d0=None, alpha=None, vel=1.0: orig(m, dur, B, rng.uniform(*d0_rng), rng.uniform(*alpha_rng), vel)
    cases = build_cases(40, seed=33)
    ys = [strum(c['frets'], cents=c['cents'], down=c['down'], mic=c['mic']) for c in cases]
    truths = [{OPEN[i]+f for i,f in enumerate(c['frets']) if f>=0} for c in cases]
    for d in decays:
        D = build_dict(d, 8, 0.3); DD = D.T @ D
        tp=fp=fn=ex=pc=tot=0
        for c,y,tr in zip(cases,ys,truths):
            for te in (0.45,0.9):
                a = hear(y, te, tuning=c['cents']/100, dict_=D, dtd=DD); an=a/a.max()
                fr,_ = solve(an, theta=0.25, lam=0.6, opt_min=0.12)
                got = {OPEN[i]+f for i,f in enumerate(fr) if f>=0} if fr else set()
                tp+=len(got&tr); fp+=len(got-tr); fn+=len(tr-got); ex+=got==tr; pc+={m%12 for m in got}=={m%12 for m in tr}; tot+=1
        print(f"{name:7s} decay={d}: P={tp/(tp+fp):.3f} R={tp/(tp+fn):.3f} exact={ex/tot:.2f} pc={pc/tot:.2f}")
run_variant("bright", (0.4, 0.8), (0.6, 1.2), (0.5, 0.6, 0.7))
run_variant("dull", (1.6, 2.4), (1.5, 2.8), (0.4, 0.5, 0.6, 0.7))
run_variant("normal", (0.9, 1.5), (1.0, 2.2), (0.5, 0.55, 0.6))
