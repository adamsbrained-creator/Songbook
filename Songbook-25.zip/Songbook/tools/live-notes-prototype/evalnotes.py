import sys, itertools
from model import *
from kern import *
names = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
def nn(m): return names[m%12]+str(m//12-1)

def random_voicing(r):
    while True:
        base = r.integers(0, 9)
        span = r.integers(2, 5)
        fr = []
        for s in range(6):
            if r.random() < 0.18: fr.append(-1)
            else:
                f = int(r.integers(0, span + 1)) + base if r.random() > 0.2 else 0
                fr.append(f)
        # need >= 3 sounding strings and distinct pitch classes >= 2
        notes = [OPEN[i] + f for i, f in enumerate(fr) if f >= 0]
        if len(notes) >= 3 and len(set(n % 12 for n in notes)) >= 3 and sum(1 for f in fr if f > 0 and f - base > span) == 0:
            # contiguous: no gap of muted inner strings bigger than 1
            return fr

def build_cases(n, seed=5):
    r = np.random.default_rng(seed)
    cases = []
    for i in range(n):
        fr = random_voicing(r)
        cases.append(dict(frets=fr, cents=float(r.uniform(-18, 18)), down=bool(r.random() < 0.7), mic=bool(r.random() < 0.5)))
    return cases

def detect_simple(a, base_midi=36, tau=0.2, nms=True, octghost=True):
    a = a / (a.max() + 1e-12)
    keep = a.copy()
    if nms:
        for j in range(len(a)):
            for d in (-1, 1):
                k = j + d
                if 0 <= k < len(a) and a[k] > 2.0 * a[j]: keep[j] = 0
    if octghost:
        for j in range(len(a) - 12):
            if keep[j] > 0 and a[j + 12] > 2.5 * a[j] and a[j] < 0.4: keep[j] = 0
    return {base_midi + j for j in range(len(a)) if keep[j] >= tau}

def score(cases, method, tau=0.2, t_ends=(0.45, 0.9), **kw):
    tp = fp = fn = 0; exact = 0; pcexact = 0; basseq = 0; tot = 0
    for c in cases:
        y = strum(c['frets'], cents=c['cents'], down=c['down'], mic=c['mic'])
        truth = {OPEN[i] + f for i, f in enumerate(c['frets']) if f >= 0}
        for te in t_ends:
            a = method(y, te, c['cents'])
            got = detect_simple(a, tau=tau, **kw)
            tp += len(got & truth); fp += len(got - truth); fn += len(truth - got)
            exact += got == truth
            pcexact += {m % 12 for m in got} == {m % 12 for m in truth}
            if got: basseq += (min(got) % 12) == (min(truth) % 12)
            tot += 1
    p = tp / max(1, tp + fp); rc = tp / max(1, tp + fn)
    return dict(prec=round(p, 3), rec=round(rc, 3), f1=round(2 * p * rc / (p + rc + 1e-9), 3), exact=round(exact / tot, 3), pcexact=round(pcexact / tot, 3), bass=round(basseq / tot, 3))

if __name__ == '__main__':
    cases = build_cases(60)
    base = lambda y, te, cents: hear(y, te, tuning=cents / 100.0)
    print("grid baseline", score(cases, base))
    ks, D = build_bin_dict(); DtD = D.T @ D
    def binm(y, te, cents, power=False, comp=1.0):
        n = int(te * SR); seg = y[max(0, n - N):n]
        if len(seg) < N: seg = np.concatenate([np.zeros(N - len(seg)), seg])
        return nnls_bins(spectrum(seg), ks, D, DtD)
    print("bin-domain linear", score(cases, binm))
