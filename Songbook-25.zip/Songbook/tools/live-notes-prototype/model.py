"""Python model of Live mode's note-level hearing (mirrors LiveChords.noteChroma) + guitar synth for testing."""
import numpy as np
SR = 11025
N = 4096
NB = N // 2 + 1
NN_M0, NN_NOTES, NN_SUB = 36, 53, 3
NN_G = NN_NOTES * NN_SUB
OPEN = [40, 45, 50, 55, 59, 64]
rng = np.random.default_rng(11)

def hz(m): return 440.0 * 2 ** ((np.asarray(m, float) - 69) / 12)

# ---- dictionary (same as Kotlin)
def build_dict(decay=0.6, nh=8, sigma=0.3):
    D = np.zeros((NN_G, NN_NOTES))
    g = np.arange(NN_G)
    for j in range(NN_NOTES):
        m = NN_M0 + j; amp = 1.0
        for h in range(1, nh + 1):
            mh = m + 12 * np.log2(h)
            d = (NN_M0 - 0.5 + g / NN_SUB - mh) / sigma
            D[:, j] += amp * np.exp(-0.5 * d * d)
            amp *= decay
    return D
DICT = build_dict()
DTD = DICT.T @ DICT

def spectrum(x):
    w = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(N) / (N - 1))
    z = np.fft.rfft(x[-N:] * w)
    return np.abs(z) * 4.0 / N

def note_acts(mag, tuning=0.0, iters=40, dict_=None, dtd=None):
    D = DICT if dict_ is None else dict_
    DD = DTD if dtd is None else dtd
    s = np.zeros(NN_G)
    for g in range(NN_G):
        c = NN_M0 - 0.5 + g / NN_SUB + tuning
        flo = 440 * 2 ** ((c - 0.5 / NN_SUB - 69) / 12)
        fhi = 440 * 2 ** ((c + 0.5 / NN_SUB - 69) / 12)
        k0 = max(1, int(np.floor(flo * N / SR))); k1 = min(NB - 1, int(np.ceil(fhi * N / SR)))
        s[g] = np.sqrt(mag[k0:k1 + 1].max())
    s = np.maximum(0, s - 0.5 * np.sort(s)[NN_G // 2])
    dts = D.T @ s
    a = np.full(NN_NOTES, 0.1)
    for _ in range(iters):
        a = a * dts / (DD @ a + 1e-9)
    return a  # index j -> midi 36+j

# ---- synth
def string_tone(m, dur, B=None, d0=None, alpha=None, vel=1.0):
    f0 = float(hz(m))
    B = rng.uniform(0.5e-4, 3e-4) if B is None else B
    d0 = rng.uniform(1.0, 2.2) if d0 is None else d0
    alpha = rng.uniform(0.9, 1.5) if alpha is None else alpha
    t = np.arange(int(dur * SR)) / SR
    out = np.zeros_like(t)
    for h in range(1, 14):
        f = f0 * h * np.sqrt(1 + B * h * h)
        if f > SR / 2 - 300: break
        amp = 1.0 / h ** alpha
        out += amp * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.283)) * np.exp(-t * (d0 + 0.35 * h))
    return out * vel * (1 - np.exp(-t * 300))

def lowcut(y, fc=100.0, order=1):
    # simple one-pole highpass-ish phone mic droop for low end
    a = np.exp(-2 * np.pi * fc / SR); out = np.zeros_like(y); prev_x = 0; prev_y = 0
    for i, v in enumerate(y):
        prev_y = a * (prev_y + v - prev_x); prev_x = v; out[i] = prev_y
    return out

def strum(frets, tuning=OPEN, cents=0.0, delay=None, down=True, dur=1.6, noise=0.003, mic=False, vels=None):
    delay = rng.uniform(0.006, 0.022) if delay is None else delay
    y = np.zeros(int(dur * SR) + SR)
    idx = [i for i, f in enumerate(frets) if f >= 0]
    if not down: idx = idx[::-1]
    for k, s in enumerate(idx):
        m = tuning[s] + frets[s] + cents / 100.0
        v = (vels[s] if vels else rng.uniform(0.7, 1.15))
        tone = string_tone(m, dur, vel=v)
        t0 = int(k * delay * SR)
        y[t0:t0 + len(tone)] += tone[:len(y) - t0]
    y = y[:int(dur * SR)]
    y += rng.normal(0, noise, len(y))
    if mic: y = lowcut(y, 110.0)
    return y / (np.abs(y).max() + 1e-9) * 0.5

def hear(y, t_end=0.45, tuning=0.0, dict_=None, dtd=None):
    n = int(t_end * SR)
    seg = y[max(0, n - N):n]
    if len(seg) < N: seg = np.concatenate([np.zeros(N - len(seg)), seg])
    mag = spectrum(seg)
    return note_acts(mag, tuning, dict_=dict_, dtd=dtd)
