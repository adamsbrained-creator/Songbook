package com.songbook.app.analysis

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** One tuning: the open strings from the lowest to the highest as MIDI note numbers (C4 = 60, A4 = 69). No strings = chromatic. */
class Tuning(val name: String, val strings: IntArray, val bass: Boolean = false) {
    val chromatic: Boolean get() = strings.isEmpty()

    /** "E A D G B E": the notes of the strings, as the tuning is listed in the picker. */
    fun notes(): String = strings.joinToString(" ") { Pitch.name(it) }
}

object Tunings {
    val ALL = listOf(
        Tuning("Standard", intArrayOf(40, 45, 50, 55, 59, 64)),
        Tuning("Drop D", intArrayOf(38, 45, 50, 55, 59, 64)),
        Tuning("Half step down", intArrayOf(39, 44, 49, 54, 58, 63)),
        Tuning("Full step down", intArrayOf(38, 43, 48, 53, 57, 62)),
        Tuning("DADGAD", intArrayOf(38, 45, 50, 55, 57, 62)),
        Tuning("Open G", intArrayOf(38, 43, 50, 55, 59, 62)),
        Tuning("Open D", intArrayOf(38, 45, 50, 54, 57, 62)),
        Tuning("Ukulele", intArrayOf(67, 60, 64, 69)),
        Tuning("Bass", intArrayOf(28, 33, 38, 43), bass = true),
        Tuning("Chromatic", IntArray(0))
    )

    fun get(i: Int): Tuning = ALL[i.coerceIn(0, ALL.size - 1)]
}

/** Notes and frequencies. [ref] is the pitch of A4 in Hz (440 normally). */
object Pitch {
    fun midiOf(freq: Double, ref: Double): Double = 69.0 + 12.0 * log2(freq / ref)
    fun freqOf(midi: Int, ref: Double): Double = ref * 2.0.pow((midi - 69) / 12.0)
    fun name(midi: Int): String = ChordNames.note(Math.floorMod(midi, 12), false)
    fun octave(midi: Int): Int = Math.floorDiv(midi, 12) - 1
}

/**
 * Finds the pitch of one note with the YIN method: how well the sound matches itself when it is shifted by a
 * number of samples, the first good match is the period. [buf] given to [detect] holds [needed] samples.
 */
class PitchDetector(private val rate: Int, minFreq: Double, private val window: Int) {
    private val maxLag = (rate / minFreq).toInt()
    private val minLag = max(2, rate / 1500)
    private val diff = FloatArray(maxLag + 2)
    private val cmnd = FloatArray(maxLag + 2)

    /** How many samples [detect] reads. */
    val needed: Int = window + maxLag + 2

    /** 0..1, how clean the last note was (1 = a pure tone). */
    var clarity = 0f
        private set

    /** The loudness (RMS) of the last block, 0..1. */
    var level = 0f
        private set

    /** The frequency in Hz, or -1 when there is no clear note (silence, noise, several notes at once). */
    fun detect(x: FloatArray): Double {
        clarity = 0f
        var energy = 0.0
        for (i in 0 until window) energy += x[i] * x[i]
        val rms = sqrt(energy / window).toFloat()
        level = rms
        if (rms < QUIET) return -1.0

        for (tau in 1..maxLag) {
            var s = 0.0
            for (j in 0 until window) {
                val d = x[j] - x[j + tau]
                s += d * d
            }
            diff[tau] = s.toFloat()
        }
        cmnd[0] = 1f
        var sum = 0.0
        for (tau in 1..maxLag) {
            sum += diff[tau]
            cmnd[tau] = if (sum > 0.0) (diff[tau] * tau / sum).toFloat() else 1f
        }

        // the first dip under the threshold, followed down to its bottom
        var found = -1
        var tau = minLag
        while (tau < maxLag) {
            if (cmnd[tau] < THRESHOLD) {
                while (tau + 1 < maxLag && cmnd[tau + 1] < cmnd[tau]) tau++
                found = tau
                break
            }
            tau++
        }
        if (found < 0) {
            var best = minLag
            var bv = cmnd[minLag]
            for (t in minLag until maxLag) if (cmnd[t] < bv) {
                bv = cmnd[t]
                best = t
            }
            if (bv > 0.35f) return -1.0
            found = best
        }
        clarity = (1f - cmnd[found]).coerceIn(0f, 1f)

        val better: Double = if (found > 1 && found < maxLag - 1) {
            val a = cmnd[found - 1].toDouble()
            val b = cmnd[found].toDouble()
            val c = cmnd[found + 1].toDouble()
            val den = a - 2 * b + c
            if (abs(den) > 1e-9) found + 0.5 * (a - c) / den else found.toDouble()
        } else found.toDouble()
        return rate / better
    }

    private companion object {
        const val THRESHOLD = 0.15f
        const val QUIET = 0.004f
    }
}

/** What the tuner hears now. [freq] is -1 when no note is clear. */
class PitchReading(val freq: Double, val clarity: Float, val level: Float)

/** Feeds microphone blocks to a [PitchDetector] and gives a reading about every 46 ms. */
class TunerEngine(rate: Int, bass: Boolean) {
    private val det = PitchDetector(rate, if (bass) 35.0 else 55.0, if (bass) 3072 else 2048)
    private val buf = FloatArray(det.needed)
    private var filled = 0
    private var since = 0

    fun feed(x: FloatArray, n: Int): PitchReading? {
        val k = min(n, buf.size)
        val keep = buf.size - k
        System.arraycopy(buf, k, buf, 0, keep)
        System.arraycopy(x, 0, buf, keep, k)
        filled = min(buf.size, filled + k)
        since += k
        if (filled < buf.size || since < HOP) return null
        since = 0
        val f = det.detect(buf)
        return PitchReading(f, det.clarity, det.level)
    }

    private companion object {
        const val HOP = 2048
    }
}

/** Plays a plucked-string note to tune by ear. Additive: exact pitch, a soft attack and a decay that is faster for the high partials. */
class RefTone {
    private var track: AudioTrack? = null

    fun play(freq: Double) {
        stop()
        val rate = 44_100
        val seconds = 2.6
        val n = (rate * seconds).toInt()
        val data = ShortArray(n)
        val partials = 7
        var peak = 1e-9
        val raw = DoubleArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            var v = 0.0
            for (h in 1..partials) {
                val f = freq * h
                if (f > rate / 2.2) break
                val amp = 1.0 / h.toDouble().pow(1.15)
                v += amp * exp(-t * (0.9 + 0.8 * h)) * sin(2.0 * PI * f * t)
            }
            val attack = min(1.0, t / 0.006)
            val tail = min(1.0, (seconds - t) / 0.15)
            v *= attack * tail
            raw[i] = v
            if (abs(v) > peak) peak = abs(v)
        }
        for (i in 0 until n) data[i] = (raw[i] / peak * 0.8 * 32767).toInt().toShort()
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, n)
            track = t
            t.play()
        } catch (e: Exception) {
            track = null
        }
    }

    fun stop() {
        track?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        track = null
    }
}

/** A short rising "ding" for a string that is in tune; with [all] a rising three-note one for the last string. */
class Chime {
    private var track: AudioTrack? = null

    /** How long the sound lasts, so the tuner can ignore the microphone meanwhile. */
    fun lengthMs(all: Boolean): Long = ((if (all) 0.14 * 2 + 0.55 else 0.11 + 0.45) * 1000).toLong()

    fun play(all: Boolean) {
        stop()
        val rate = 44_100
        val notes = if (all) doubleArrayOf(784.0, 1046.5, 1318.5) else doubleArrayOf(987.8, 1318.5)
        val gap = if (all) 0.14 else 0.11
        val seconds = lengthMs(all) / 1000.0
        val n = (rate * seconds).toInt()
        val raw = DoubleArray(n)
        for ((idx, f) in notes.withIndex()) {
            val start = (idx * gap * rate).toInt()
            for (i in start until n) {
                val t = (i - start).toDouble() / rate
                val env = min(1.0, t / 0.004) * exp(-t * 6.5)
                raw[i] += env * (sin(2.0 * PI * f * t) + 0.3 * exp(-t * 10.0) * sin(2.0 * PI * 2.0 * f * t))
            }
        }
        var peak = 1e-9
        for (v in raw) if (abs(v) > peak) peak = abs(v)
        val data = ShortArray(n) { i ->
            val tail = min(1.0, (n - i).toDouble() / (rate * 0.05))
            (raw[i] / peak * 0.7 * tail * 32767).toInt().toShort()
        }
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, n)
            track = t
            t.play()
        } catch (e: Exception) {
            track = null
        }
    }

    fun stop() {
        track?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        track = null
    }
}
