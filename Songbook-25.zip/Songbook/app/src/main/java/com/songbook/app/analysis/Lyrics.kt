package com.songbook.app.analysis

import com.songbook.app.data.ChordMark
import com.songbook.app.data.SongLine
import com.songbook.app.data.SongParser
import com.songbook.app.data.serialize
import com.songbook.app.data.wordAt
import kotlin.math.max
import kotlin.math.min

/** One line of lyrics for the chord analyzer. [start] is when it is sung (seconds), or -1 while it has no time yet. A section is a heading like "Verse". */
class LyricLine(val text: String, val section: Boolean = false, val start: Double = -1.0) {
    val synced: Boolean get() = !section && start >= 0
    fun at(t: Double) = LyricLine(text, section, t)
    fun untimed() = LyricLine(text, section)
}

/**
 * Lyrics next to the chords: the lines come from a song (or are typed), get a time each (tapped while the recording
 * plays, or spread evenly) and the chords that sound during a line are put over its words. The result is written as
 * Songbook song text: `[G]words [D]more words`.
 */
object Lyrics {
    /** Lines from song text or typed text. Chords in [brackets], tab lines and empty lines are dropped; "# Verse" is a section. */
    fun parse(raw: String): List<LyricLine> {
        val out = ArrayList<LyricLine>()
        for (l in SongParser.parse(raw)) {
            when (l) {
                is SongLine.Section -> out.add(LyricLine(l.label, section = true))
                is SongLine.Lyric -> {
                    val t = l.text.trim()
                    if (t.isNotEmpty()) out.add(LyricLine(t))
                }
                else -> {}
            }
        }
        // a heading with nothing under it says nothing
        return out.filterIndexed { i, ln -> !ln.section || (i + 1 < out.size && !out[i + 1].section) }
    }

    /** The lines as text to edit: "# Verse" for sections. */
    fun toEditText(lines: List<LyricLine>): String = lines.joinToString("\n") { if (it.section) "# " + it.text else it.text }

    fun hasLines(lines: List<LyricLine>) = lines.any { !it.section }
    fun syncedCount(lines: List<LyricLine>) = lines.count { it.synced }

    /** Gives every line a time between [from] and [to], longer lines getting more of it. A start to fine-tune by tapping. */
    fun spread(lines: List<LyricLine>, from: Double, to: Double): List<LyricLine> {
        val weight = lines.filter { !it.section }.sumOf { it.text.length + 8 }
        if (weight == 0 || to <= from) return lines
        var acc = 0
        return lines.map {
            if (it.section) it else {
                val t = from + (to - from) * acc / weight
                acc += it.text.length + 8
                it.at(t)
            }
        }
    }

    /** The line that is sung at [t]: the last timed line that has started. -1 before the first one. */
    fun currentIndex(lines: List<LyricLine>, t: Double): Int = lines.indexOfLast { it.synced && it.start <= t }

    /** Where the line [idx] ends: when the next timed line starts, or a few seconds after it. */
    private fun endOf(lines: List<LyricLine>, idx: Int, endSec: Double): Double {
        val start = lines[idx].start
        val next = lines.drop(idx + 1).firstOrNull { it.synced }?.start
        return next ?: max(start + 1.0, min(endSec, start + 6.0))
    }

    /** The chords of line [idx], each on the word that is being sung when the chord starts. */
    fun marksFor(lines: List<LyricLine>, idx: Int, segs: List<ChordSeg>, names: List<String>, endSec: Double): List<ChordMark> {
        val ln = lines[idx]
        if (!ln.synced || ln.text.isEmpty()) return emptyList()
        val end = endOf(lines, idx, endSec)
        val span = max(0.5, end - ln.start)
        val marks = ArrayList<ChordMark>()
        var last = ""
        // the chord that is already playing when the line starts
        for (i in segs.indices) {
            val s = segs[i]
            if (s.isChord && s.start < ln.start - TOL && s.end > ln.start + TOL) {
                marks.add(ChordMark(0, names[i]))
                last = names[i]
            }
        }
        for (i in segs.indices) {
            val s = segs[i]
            if (!s.isChord || s.start < ln.start - TOL || s.start >= end - TOL) continue
            if (names[i] == last) continue
            last = names[i]
            val f = ((s.start - ln.start) / span).coerceIn(0.0, 1.0)
            val at = (f * ln.text.length).toInt().coerceIn(0, ln.text.length - 1)
            val off = SongParser.wordAt(ln.text, at)?.first ?: 0
            marks.add(ChordMark(off, names[i]))
        }
        return marks
    }

    /** Song text with the chords over the words. Lines without a time come out plain, chords before the first line as a line of their own. */
    fun toSongText(lines: List<LyricLine>, segs: List<ChordSeg>, names: List<String>, endSec: Double): String {
        val sb = StringBuilder()
        val first = lines.firstOrNull { it.synced }?.start
        if (first != null) {
            val intro = ArrayList<String>()
            for (i in segs.indices) {
                if (segs[i].isChord && segs[i].start < first - 0.3 && (intro.isEmpty() || intro.last() != names[i])) intro.add(names[i])
            }
            if (intro.isNotEmpty()) sb.append('[').append(intro.joinToString(" ")).append("]\n")
        }
        for (i in lines.indices) {
            val ln = lines[i]
            when {
                ln.section -> sb.append("# ").append(ln.text).append('\n')
                !ln.synced -> sb.append(ln.text).append('\n')
                else -> sb.append(SongParser.serialize(SongLine.Lyric(ln.text, marksFor(lines, i, segs, names, endSec)))).append('\n')
            }
        }
        return sb.toString().trimEnd()
    }

    private const val TOL = 0.15
}
