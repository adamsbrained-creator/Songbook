package com.songbook.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

/** A block of a page: its id and whether it is shown. The list order is the order on the page. */
typealias BlockList = List<Pair<String, Boolean>>

/** The blocks of the main page and the Albums page with their default order. */
object Blocks {
    /** The shortcut tiles that can sit on the main page (the "tools" block), with the standard ones on. */
    fun tiles(): BlockList = listOf(
        "t_analyzer" to true, "t_record" to true, "t_workflow" to true, "t_stats" to true,
        "t_live" to true, "t_tuner" to true,
        "t_new" to false, "t_albums" to false, "t_favorites" to false, "t_settings" to false, "t_random" to false
    )

    /**
     * The blocks of the main page. For the Coral look [coralMode] says which main page: 0 Classic, 1 Glassy, 2 Tools;
     * the Coral pages can also show the tiles, the favorites and the progress card.
     */
    fun home(style: Int, coralMode: Int = -1): BlockList {
        if (style == UiStyle.CORAL && coralMode >= 0) {
            // everything the app can put on its main page: every page and tool has a block, off unless a page shows it by default
            val extras = listOf(
                "tools" to false, "favorites" to false, "groups" to false, "stats" to false,
                "analyzer" to false, "live" to false, "tuner" to false, "record" to false,
                "newsong" to false, "random" to false, "quick" to false, "albumgrid" to false
            )
            return when (coralMode) {
                1 -> listOf("filters" to true, "search" to true, "albums" to true, "workflow" to true, "recent" to true, "songs" to true) + extras
                2 -> listOf(
                    "tools" to true, "search" to false, "filters" to false, "albums" to true, "favorites" to false,
                    "stats" to false, "workflow" to false, "recent" to false, "songs" to true,
                    "groups" to false, "analyzer" to false, "live" to false, "tuner" to false, "record" to false,
                    "newsong" to false, "random" to false, "quick" to false, "albumgrid" to false
                )
                else -> listOf("filters" to true, "albums" to true, "workflow" to true, "recent" to false, "songs" to true) + extras
            }
        }
        return home(style)
    }

    fun home(style: Int): BlockList = when (style) {
        UiStyle.CORAL -> listOf("filters" to true, "albums" to true, "workflow" to true, "recent" to false, "songs" to true)
        else -> listOf("filters" to true, "search" to true, "albums" to true, "workflow" to true, "recent" to true, "songs" to true)
    }

    fun albums(style: Int): BlockList = when (style) {
        UiStyle.CORAL -> listOf("groups" to true, "albums" to true)
        else -> listOf("groups" to true, "albums" to true)
    }

    val labels = mapOf(
        "search" to "Search box",
        "filters" to "Filters (All, Lyrics, Chords, Tabs)",
        "albums" to "Albums",
        "workflow" to "Workflow",
        "recent" to "Recently edited",
        "songs" to "All songs",
        "groups" to "Groups (trilogies...)",
        "tools" to "Tiles (shortcuts)",
        "favorites" to "Favorite songs",
        "stats" to "Progress card",
        "analyzer" to "Chord analyzer card",
        "live" to "Live chords card",
        "tuner" to "Guitar tuner card",
        "record" to "Record a demo card",
        "newsong" to "New song card",
        "random" to "Surprise me card",
        "groups" to "Groups (trilogies, box sets)",
        "quick" to "Quick settings",
        "albumgrid" to "Albums (grid)",
        "t_settings" to "Settings",
        "t_random" to "Surprise me (random song)",
        "t_analyzer" to "Chord analyzer",
        "t_live" to "Live chords",
        "t_tuner" to "Guitar tuner",
        "t_record" to "Record a demo",
        "t_workflow" to "Workflow",
        "t_stats" to "Statistics",
        "t_new" to "New song",
        "t_albums" to "Albums",
        "t_favorites" to "Favorites"
    )

    /** Merges what was saved with the defaults: unknown blocks are dropped, new blocks are added at the end. */
    fun resolve(raw: String, defaults: BlockList): BlockList {
        val known = defaults.map { it.first }
        val saved = raw.split(',').mapNotNull { part ->
            val bits = part.split(':')
            val id = bits.getOrNull(0)?.trim()
            if (id != null && id in known) id to (bits.getOrNull(1) != "0") else null
        }.distinctBy { it.first }
        return saved + defaults.filter { d -> saved.none { it.first == d.first } }
    }

    fun encode(list: BlockList): String = list.joinToString(",") { it.first + ":" + (if (it.second) "1" else "0") }

    /** True when [id] should be drawn in [list]. */
    fun shows(list: BlockList, id: String): Boolean = list.firstOrNull { it.first == id }?.second ?: false
}

/**
 * Drag the blocks of a page into the order you want and switch the ones you do not need off.
 * [onSave] gets the new list, [onReset] goes back to the standard layout.
 */
@Composable
fun BlocksDialog(
    title: String,
    start: BlockList,
    onSave: (BlockList) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val c = Sb.colors
    val list = remember { mutableStateListOf<Pair<String, Boolean>>().also { it.addAll(start) } }
    SbDialog(title, onDismiss, "Save", { onSave(list.toList()) }) {
        androidx.compose.foundation.layout.Column {
            Text("Drag the handle to move a block. The switch shows or hides it.", style = sbStyle(12, color = c.mu), modifier = Modifier.padding(bottom = 8.dp))
            Box(Modifier.fillMaxWidth().height((list.size * 56).coerceAtMost(392).dp)) {
                ReorderList(
                    items = list,
                    key = { it.first.hashCode().toLong() },
                    onMove = { from, to -> if (from in list.indices && to in list.indices) list.add(to, list.removeAt(from)) }
                ) { item, dragging, handle ->
                    Row(
                        Modifier.fillMaxWidth().height(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (dragging) c.track else androidx.compose.ui.graphics.Color.Transparent),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            Blocks.labels[item.first] ?: item.first,
                            style = sbStyle(14, FontWeight.Medium, if (item.second) c.tx else c.mu),
                            modifier = Modifier.weight(1f)
                        )
                        SbSwitch(item.second) { on ->
                            val i = list.indexOfFirst { it.first == item.first }
                            if (i >= 0) list[i] = list[i].copy(second = on)
                        }
                        Box(handle.padding(6.dp)) { StrokeIcon(SbIcons.Drag, c.mu, size = 22.dp) }
                    }
                }
            }
            ChipPill("Reset to standard", active = false, onClick = onReset, inactiveBg = c.track, modifier = Modifier.padding(top = 10.dp))
        }
    }
}
