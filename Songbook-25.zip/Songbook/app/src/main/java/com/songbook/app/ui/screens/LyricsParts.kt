package com.songbook.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.songbook.app.analysis.ChordSeg
import com.songbook.app.analysis.LyricLine
import com.songbook.app.analysis.Lyrics
import com.songbook.app.data.ChordMark
import com.songbook.app.ui.components.SbDialog
import com.songbook.app.ui.components.SbField
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlin.math.max
import kotlin.math.roundToInt

// Lyrics in the chord analyzer: the lyrics view (the chords over the words, the line that is sung lit), the bar for
// tapping the lines in time, the Lyrics sheet and the dialog to type or paste lyrics. The model is in analysis/Lyrics.kt.

/** One line of lyrics with its chords above the words they start on. */
@Composable
private fun ChordedLine(text: String, marks: List<ChordMark>, size: Int, textColor: Color, chordColor: Color) {
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val density = LocalDensity.current
    Column {
        if (marks.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().height((size + 10).dp)) {
                val l = layout
                if (l != null) {
                    var lastEnd = -1000f
                    val gap = with(density) { 8.dp.toPx() }
                    for (m in marks) {
                        val off = m.offset.coerceIn(0, text.length)
                        if (l.getLineForOffset(off) > 0) continue            // a chord on a wrapped line cannot be placed from here
                        val x = max(l.getHorizontalPosition(off, true), lastEnd + gap)
                        Text(
                            m.name, style = sbStyle(size - 2, FontWeight.SemiBold, chordColor), maxLines = 1, softWrap = false,
                            modifier = Modifier.offset { IntOffset(x.roundToInt(), 0) }
                        )
                        lastEnd = x + with(density) { (m.name.length * (size - 2) * 0.62f).sp.toPx() }
                    }
                }
            }
        }
        Text(text, style = sbStyle(size, FontWeight.Medium, textColor), onTextLayout = { layout = it })
    }
}

/** The lyrics with the chords over the words; the line that is sung now is big and the view follows it. */
@Composable
internal fun LyricsView(
    lines: List<LyricLine>, segs: List<ChordSeg>, names: List<String>, posSec: Double, endSec: Double,
    bottom: Int, onSeek: (Double) -> Unit, onOpenLyrics: () -> Unit
) {
    val c = Sb.colors
    val cur = Lyrics.currentIndex(lines, posSec)
    val marks = remember(lines.toList(), segs, names, endSec) { lines.indices.map { Lyrics.marksFor(lines, it, segs, names, endSec) } }
    val anySynced = Lyrics.syncedCount(lines) > 0
    val state = rememberLazyListState()
    LaunchedEffect(cur) { if (cur >= 0) state.animateScrollToItem(max(0, cur - 1) + 1) }
    LazyColumn(Modifier.fillMaxWidth(), state = state, contentPadding = PaddingValues(top = 12.dp, bottom = bottom.dp)) {
        item {
            if (!anySynced) {
                Column(
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().sbCard(24.dp).clip(RoundedCornerShape(24.dp)).clickable(onClick = onOpenLyrics).padding(16.dp)
                ) {
                    Text("Put the chords over the words", style = sbStyle(16, FontWeight.SemiBold, c.tx))
                    Text("Give the lines their time: tap them while the song plays, or spread them evenly. Tap here.", style = sbStyle(13, color = c.mu), modifier = Modifier.padding(top = 4.dp))
                }
            } else Box(Modifier.height(1.dp))
        }
        itemsIndexed(lines) { i, ln ->
            if (ln.section) {
                Text(ln.text.uppercase(), style = sbStyle(12, FontWeight.Medium, c.mu), modifier = Modifier.padding(start = 24.dp, top = 18.dp, bottom = 4.dp))
            } else {
                val now = i == cur
                val alpha = if (!ln.synced) 0.85f else if (now) 1f else if (i < cur) 0.4f else 0.75f
                Box(
                    Modifier.fillMaxWidth().clickable(enabled = ln.synced) { onSeek(ln.start) }.padding(horizontal = 24.dp, vertical = if (now) 8.dp else 5.dp)
                ) {
                    ChordedLine(ln.text, marks[i], if (now) 26 else 19, c.tx.copy(alpha = alpha), c.ac.copy(alpha = if (now) 1f else alpha))
                }
            }
        }
    }
}

/** While the lines are being timed: the next line and a big button to tap the moment it is sung. */
@Composable
internal fun SyncBar(next: LyricLine?, left: Int, onTap: () -> Unit, onUndo: () -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier.padding(horizontal = 12.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).padding(16.dp)) {
        Text(if (next != null) "Next line · $left to go" else "All lines are timed", style = sbStyle(12, FontWeight.Medium, c.mu))
        Text(
            next?.text ?: "Play it through to check, then Done.", style = sbStyle(18, FontWeight.SemiBold, c.tx), maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        if (next != null) PillButton("Tap when it is sung", true, Modifier.fillMaxWidth(), onTap)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Undo", false, Modifier.weight(1f), onUndo)
            PillButton("Done", false, Modifier.weight(1f), onDone)
        }
    }
}

/** Everything to do with the lyrics: where they come from, timing them, editing, removing. */
@Composable
internal fun LyricsSheet(
    lines: List<LyricLine>, onType: () -> Unit, onFromSong: (() -> Unit)?, onSync: () -> Unit, onSpread: () -> Unit,
    onClearTimes: () -> Unit, onRemove: () -> Unit, onClose: () -> Unit
) {
    val c = Sb.colors
    val has = Lyrics.hasLines(lines)
    val total = lines.count { !it.section }
    val timed = Lyrics.syncedCount(lines)
    AnalyzerSheet("Lyrics", if (has) "$total lines · $timed timed" else "Not added yet", onClose) {
        if (!has) {
            Text(
                "Add the words of the song. Then give the lines their time and the chords go over the words.",
                style = sbStyle(14, color = c.mu), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)
            )
            ActionRow(SbIcons.Edit, "Type or paste the lyrics", "One line per row, \"# Verse\" starts a section", onType)
            if (onFromSong != null) ActionRow(SbIcons.Music, "Take them from a song", "Use the lyrics of one of your songs", onFromSong)
        } else {
            ActionRow(SbIcons.Play, "Tap to time the lines", "Play the song and tap when each line is sung", onSync)
            ActionRow(SbIcons.Sliders, "Spread the lines evenly", "A quick start you can fix by tapping", onSpread)
            ActionRow(SbIcons.Edit, "Edit the lyrics", "Change words, lines and sections", onType)
            if (timed > 0) ActionRow(SbIcons.Close, "Clear the times", "Keep the words, start timing again", onClearTimes)
            if (onFromSong != null) ActionRow(SbIcons.Music, "Take them from another song", "Replaces these lyrics", onFromSong)
            ActionRow(SbIcons.Close, "Remove the lyrics", "The chords stay", onRemove)
        }
    }
}

/** Type or paste the lyrics. */
@Composable
internal fun LyricsDialog(initial: String, onUse: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    SbDialog("Lyrics", onDismiss, "Use these lyrics", { onUse(text) }) {
        SbField(
            text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 220.dp),
            label = { Text("One line per row") }, minLines = 8
        )
    }
}
