package com.songbook.app.analysis

/** What the chord shapes are drawn for. [OFF] shows no shapes. */
enum class Instrument(val label: String) { GUITAR("Guitar"), UKULELE("Ukulele"), PIANO("Piano"), OFF("Off") }

/** Shapes for the instruments other than the guitar. */
object Instruments {
    private val TONES = mapOf(
        "" to intArrayOf(0, 4, 7), "m" to intArrayOf(0, 3, 7), "7" to intArrayOf(0, 4, 7, 10), "maj7" to intArrayOf(0, 4, 7, 11),
        "m7" to intArrayOf(0, 3, 7, 10), "sus4" to intArrayOf(0, 5, 7), "sus2" to intArrayOf(0, 2, 7),
        "add9" to intArrayOf(0, 4, 7, 2), "6" to intArrayOf(0, 4, 7, 9), "m6" to intArrayOf(0, 3, 7, 9), "5" to intArrayOf(0, 7),
        "dim" to intArrayOf(0, 3, 6), "aug" to intArrayOf(0, 4, 8), "7sus4" to intArrayOf(0, 5, 7, 10), "9" to intArrayOf(0, 4, 7, 10, 2)
    )
    private val UKE_OPEN = intArrayOf(7, 0, 4, 9)          // G C E A
    private val cache = HashMap<String, GuitarShape?>()

    /** The notes of a chord as pitch classes (C = 0). */
    fun tones(root: Int, type: String): List<Int> = intervalsOf(type).map { Math.floorMod(root + it, 12) }

    private fun intervalsOf(type: String): IntArray = TONES[type] ?: ChordTypes.get(type)?.intervals ?: TONES.getValue("")

    /** The keys that sound on a two-octave keyboard starting at C: 0..23. */
    fun pianoKeys(root: Int, type: String): List<Int> = intervalsOf(type).map { Math.floorMod(root, 12) + it }

    /**
     * A ukulele shape (GCEA, all four strings played): every string plays a note of the chord, the root and the
     * note that makes it major or minor (or sus, or the 7th) are there, and the shape stays low and compact.
     */
    fun ukulele(root: Int, type: String): GuitarShape? = synchronized(cache) {
        cache.getOrPut("$root:$type") { searchUke(Math.floorMod(root, 12), type) }
    }

    private fun searchUke(root: Int, type: String): GuitarShape? {
        val iv = TONES[type] ?: ChordTypes.get(type)?.intervals ?: return null
        val tones = iv.map { (root + it) % 12 }.toSet()
        val required = iv.filter { it != 7 }.map { (root + it) % 12 }.toSet()
        val fifth = (root + 7) % 12
        var best = Double.MAX_VALUE
        var bestFrets: IntArray? = null
        val f = IntArray(4)
        for (a in 0..9) for (b in 0..9) for (c in 0..9) for (d in 0..9) {
            f[0] = a; f[1] = b; f[2] = c; f[3] = d
            val pcs = IntArray(4) { (UKE_OPEN[it] + f[it]) % 12 }
            if (pcs.any { it !in tones }) continue
            if (!pcs.toSet().containsAll(required)) continue
            var maxF = 0
            var minUsed = 99
            var maxUsed = 0
            var opens = 0
            for (x in f) {
                if (x > maxF) maxF = x
                if (x == 0) opens++ else {
                    if (x < minUsed) minUsed = x
                    if (x > maxUsed) maxUsed = x
                }
            }
            val span = if (maxUsed == 0) 0 else maxUsed - minUsed
            if (span > 3) continue
            val cost = maxF * 2.0 + span * 3.0 + (if (pcs.contains(fifth)) 0.0 else 2.0) - opens * 0.5
            if (cost < best) {
                best = cost
                bestFrets = f.copyOf()
            }
        }
        return bestFrets?.let { GuitarShape(it) }
    }
}
