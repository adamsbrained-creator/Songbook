package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.ui.theme.Sb
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.songbook.app.ui.theme.sbStyle

/**
 * Ring with a rounded coral arc, used for "Songs finished" on the Settings and Statistics pages.
 * [fraction] is 0..1, [label] is written in the middle ("79%").
 */
@Composable
fun ProgressRing(
    fraction: Float,
    size: Dp,
    stroke: Dp,
    track: Color,
    color: Color,
    label: String,
    labelColor: Color,
    labelSize: Int,
    modifier: Modifier = Modifier
) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val topLeft = Offset(w / 2f, w / 2f)
            val arc = Size(this.size.width - w, this.size.height - w)
            drawArc(track, 0f, 360f, false, topLeft = topLeft, size = arc, style = Stroke(width = w))
            val sweep = 360f * fraction.coerceIn(0f, 1f)
            if (sweep > 0f) drawArc(color, -90f, sweep, false, topLeft = topLeft, size = arc, style = Stroke(width = w, cap = StrokeCap.Round))
        }
        Text(label, style = sbStyle(labelSize, FontWeight.SemiBold, labelColor))
    }
}

/**
 * The big summary card of the Settings page, reused on Favorites: a ring, a title with a line under it and a
 * pill button on the right. White in dark mode, black in light mode ([com.songbook.app.ui.theme.SbColors.pill]).
 */
@Composable
fun SummaryCard(
    fraction: Float,
    ringLabel: String,
    title: String,
    subtitle: String,
    button: String,
    onButton: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Sb.colors
    Row(
        modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(c.pill)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ProgressRing(fraction, 52.dp, 7.dp, c.onPill.copy(alpha = 0.2f), c.ac, ringLabel, c.onPill, 12)
        Column(Modifier.weight(1f)) {
            Text(title, style = sbStyle(19, FontWeight.SemiBold, c.onPill), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = sbStyle(14, color = c.onPill.copy(alpha = 0.7f)), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.height(46.dp).clip(RoundedCornerShape(23.dp)).background(c.onPill).clickable(onClick = onButton).padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) { Text(button, style = sbStyle(15, FontWeight.SemiBold, c.pill), maxLines = 1) }
    }
}
