package com.songbook.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.lerp
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.theme.LocalSb
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.SbColors
import com.songbook.app.ui.theme.SongGradients

// A page that takes its colors from the album cover, like the album pages of Apple Music: the main color of
// the picture, toned down so that the normal text stays readable (deep and dark in dark mode, a soft pastel in
// light mode).

/** The most "colorful" color of the picture; the average color when the picture is nearly gray. */
private fun dominantColor(img: ImageBitmap): Color? {
    val w = img.width
    val h = img.height
    if (w <= 0 || h <= 0) return null
    val px = IntArray(w * h)
    img.readPixels(px, 0, 0, w, h)
    val hueW = FloatArray(12)
    val hueR = FloatArray(12)
    val hueG = FloatArray(12)
    val hueB = FloatArray(12)
    var sumR = 0f
    var sumG = 0f
    var sumB = 0f
    var sumSat = 0f
    var n = 0
    val hsv = FloatArray(3)
    for (p in px) {
        if (((p ushr 24) and 0xFF) < 128) continue
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        android.graphics.Color.RGBToHSV(r, g, b, hsv)
        sumR += r; sumG += g; sumB += b; sumSat += hsv[1]; n++
        // bright, saturated pixels count more than dull ones
        val weight = hsv[1] * hsv[2] + 0.02f
        val bucket = (hsv[0] / 30f).toInt().coerceIn(0, 11)
        hueW[bucket] += weight
        hueR[bucket] += r * weight
        hueG[bucket] += g * weight
        hueB[bucket] += b * weight
    }
    if (n == 0) return null
    val average = Color(sumR / n / 255f, sumG / n / 255f, sumB / n / 255f)
    if (sumSat / n < 0.12f) return average          // a black and white cover: stay neutral
    var best = 0
    for (i in 1 until 12) if (hueW[i] > hueW[best]) best = i
    if (hueW[best] <= 0f) return average
    return Color(hueR[best] / hueW[best] / 255f, hueG[best] / hueW[best] / 255f, hueB[best] / hueW[best] / 255f)
}

/** Turns a cover color into a page color: dark and deep in dark mode, a light tint in light mode. */
private fun pageTint(color: Color, dark: Boolean): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(
        (color.red * 255f).toInt().coerceIn(0, 255),
        (color.green * 255f).toInt().coerceIn(0, 255),
        (color.blue * 255f).toInt().coerceIn(0, 255),
        hsv
    )
    if (dark) {
        hsv[1] = hsv[1].coerceAtMost(0.72f)
        hsv[2] = (hsv[2] * 0.42f).coerceIn(0.12f, 0.30f)
    } else {
        hsv[1] = (hsv[1] * 0.30f).coerceAtMost(0.26f)
        hsv[2] = 0.97f
    }
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** The page color for a cover (its picture, or its gradient when it has none). */
@Composable
fun rememberCoverTint(image: String?, gradient: Int, dark: Boolean): Color {
    val cover = rememberCover(image, 48)
    val base = remember(cover, gradient) {
        (cover?.let { runCatching { dominantColor(it) }.getOrNull() })
            ?: SongGradients[((gradient % SongGradients.size) + SongGradients.size) % SongGradients.size].first()
    }
    return remember(base, dark) { pageTint(base, dark) }
}

/**
 * Wraps a page of the Coral look so that it takes its colors from a cover ([mode] 0) or keeps the normal
 * dark or white page ([mode] 1). Cards, tracks and lines inside use the tinted colors too.
 */
@Composable
fun CoverBackdrop(image: String?, gradient: Int, mode: Int, content: @Composable () -> Unit) {
    val base = Sb.colors
    if (mode != 0 || base.style != UiStyle.CORAL) {
        content()
        return
    }
    val tint = rememberCoverTint(image, gradient, base.isDark)
    val adapted = remember(base, tint) {
        SbColors(
            bg = tint, tx = base.tx, mu = base.mu, ac = base.ac,
            cd = lerp(tint, base.tx, if (base.isDark) 0.10f else 0.07f),
            ln = lerp(tint, base.tx, 0.16f),
            isDark = base.isDark, sheet = base.sheet,
            track = lerp(tint, base.tx, 0.13f),
            style = base.style, pill = base.pill, onPill = base.onPill, onAc = base.onAc, ct = base.ct
        )
    }
    CompositionLocalProvider(LocalSb provides adapted) { content() }
}
