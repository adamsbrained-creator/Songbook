package com.songbook.app.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.songbook.app.SongbookApp
import com.songbook.app.data.*
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

// SONGBOOK <-> SCRAPBOOK, the screens and the sending. The rules and message formats are in data/ScrapbookLink.kt. The rest of the app touches this from
// marked hook lines ("[scrapbook hook N]"):
//
//   1. AndroidManifest.xml: ScrapbookReceiverActivity (the door Scrapbook knocks on, and songbook:// links)
//   2. ui/components/SongMenu.kt: the "Edit in Scrapbook" row of the song menu
//   3. ui/SongbookRoot.kt: ScrapbookOpenSongEffect(nav), which opens a song asked for by a songbook:// link
//   4. ui/screens/SongScreen.kt: the "Scrapbook" chip (IfLinkedToScrapbook) and the Keep / Undo card (ScrapbookUpdateBanner)

/** A song a songbook://song/<id> link asked for; the root opens it (see ScrapbookOpenSongEffect). */
object SongLinkRequests { val open = MutableStateFlow<Long?>(null) }

/**
 * "Edit in Scrapbook": sends the song's text (and its desk tasks) to Scrapbook, which opens the scrap tied to the song or makes one. Says so plainly when
 * Scrapbook is not installed.
 */
fun editSongInScrapbook(ctx: Context, song: SongEntity) {
    val st = song.textForScrapbook()
    val i = Intent(ACTION_SCRAPBOOK_EDIT_SONG).setClassName(SCRAPBOOK_PACKAGE, SCRAPBOOK_ACTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).apply {
        putExtra("title", song.title); putExtra("body", st.text)
        putStringArrayListExtra("tasks", ArrayList(st.tasks.map { it.first })); putExtra("done", st.tasks.map { it.second }.toBooleanArray())
        putExtra("song", song.id); putExtra("uid", ScrapbookLinks.uidOf(ctx, song.id))
    }
    try { ctx.startActivity(i); ScrapbookLinks.markLinked(ctx, song.id) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Scrapbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/** Opens the song a songbook:// link asked for. Goes in the root, next to the navigation controller. */
@Composable
fun ScrapbookOpenSongEffect(nav: NavHostController) {
    LaunchedEffect(Unit) {
        SongLinkRequests.open.collect { id ->
            if (id != null) {
                var tries = 0
                while (tries < 20) {   // the screens may still be starting
                    if (runCatching { nav.navigate("song/$id") }.isSuccess) { SongLinkRequests.open.value = null; break }
                    tries++; delay(100)
                }
            }
        }
    }
}

/** Shows [content] (a chip; its argument opens the song in Scrapbook) only for a song that is tied to a scrap. */
@Composable
fun IfLinkedToScrapbook(song: SongEntity, content: @Composable (open: () -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val tick by ScrapbookLinks.changes.collectAsState()
    val linked = remember(tick, song.id) { ScrapbookLinks.isLinked(ctx, song.id) }
    if (linked) content { editSongInScrapbook(ctx, song) }
}

/**
 * The card on a song that Scrapbook has just changed: what changed, and Keep or Undo (which puts back what the song said before). It goes away by itself
 * once the song is edited, because Undo would then throw those edits away.
 */
@Composable
fun ScrapbookUpdateBanner(song: SongEntity) {
    val ctx = LocalContext.current
    val tick by ScrapbookLinks.changes.collectAsState()
    val pending = remember(tick, song.id) { ScrapbookLinks.pending(ctx, song.id) } ?: return
    if (song.body != pending.nowBody || song.idea != pending.nowIdea) {
        LaunchedEffect(song.id, song.body, song.idea) { delay(300); ScrapbookLinks.clearPending(ctx, song.id) }
        return
    }
    val c = Sb.colors
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 96.dp), contentAlignment = Alignment.BottomCenter) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.sheet).padding(14.dp)) {
            Text("Updated from Scrapbook", style = sbStyle(14, FontWeight.Medium, c.tx))
            Text(pending.note, style = sbStyle(12, color = c.mu), modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Keep", style = sbStyle(13, FontWeight.Medium, c.onPill),
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(c.pill).clickable { ScrapbookLinks.clearPending(ctx, song.id) }.padding(horizontal = 18.dp, vertical = 8.dp))
                Text("Undo", style = sbStyle(13, FontWeight.Medium, c.tx),
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(c.track).clickable {
                        scope.launch {
                            val repo = (ctx.applicationContext as SongbookApp).repo
                            repo.song(song.id)?.let { repo.saveSong(it.copy(body = pending.prevBody, idea = pending.prevIdea)) }
                            ScrapbookLinks.clearPending(ctx, song.id)
                        }
                    }.padding(horizontal = 18.dp, vertical = 8.dp))
            }
        }
    }
}
