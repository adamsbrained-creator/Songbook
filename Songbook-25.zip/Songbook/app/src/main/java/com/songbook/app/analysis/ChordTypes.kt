package com.songbook.app.analysis

/**
 * One kind of chord. [id] is what is written after the root ("m7b5", "13sus4"; "" is a plain major chord).
 * [intervals] are the notes as semitones above the root, [weights] how much each counts when a chord is matched,
 * [required] whether the chord is not that chord without the note (the 5th is almost never required: guitarists
 * leave it out) and [penalty] how much the chord is disliked against a simpler one that fits about as well.
 */
class ChordType(
    val id: String,
    val intervals: IntArray,
    val weights: DoubleArray,
    val required: BooleanArray,
    val penalty: Double
) {
    /** True when the chord has a minor third (and no major one): Am, Am7, Adim ... */
    val minorThird: Boolean = intervals.contains(3) && !intervals.contains(4)
}

private class Tn(val iv: Int, val w: Double, val req: Boolean)

private val ROOT = Tn(0, 1.0, true)
private fun q(iv: Int, w: Double = 0.9) = Tn(iv, w, true)          // the note that makes the chord major, minor, sus ...
private fun fifth(iv: Int = 7, w: Double = 0.7) = Tn(iv, w, false)  // the 5th: counts when it is there, is not missed when it is not
private fun x(iv: Int, w: Double = 0.6, req: Boolean = true) = Tn(iv, w, req)

private fun def(id: String, penalty: Double, vararg t: Tn) = ChordType(
    id, IntArray(t.size) { t[it].iv }, DoubleArray(t.size) { t[it].w }, BooleanArray(t.size) { t[it].req }, penalty
)

/** Every chord type Songbook can name. Live mode's Precise setting uses all of them. */
object ChordTypes {
    val ALL: List<ChordType> = listOf(
        // triads
        def("", 0.0, ROOT, q(4), fifth()),
        def("m", 0.0, ROOT, q(3), fifth()),
        def("5", 0.10, ROOT, Tn(7, 0.9, true)),
        def("sus4", 0.05, ROOT, q(5), fifth()),
        def("sus2", 0.05, ROOT, q(2), fifth()),
        def("dim", 0.06, ROOT, q(3), Tn(6, 0.8, true)),
        def("aug", 0.06, ROOT, q(4), Tn(8, 0.8, true)),
        // sixths
        def("6", 0.05, ROOT, q(4), x(9), fifth()),
        def("m6", 0.05, ROOT, q(3), x(9), fifth()),
        def("69", 0.10, ROOT, q(4), x(9), x(2), fifth()),
        def("m69", 0.12, ROOT, q(3), x(9), x(2), fifth()),
        // sevenths
        def("7", 0.04, ROOT, q(4), x(10), fifth()),
        def("maj7", 0.05, ROOT, q(4), x(11), fifth()),
        def("m7", 0.04, ROOT, q(3), x(10), fifth()),
        def("mMaj7", 0.09, ROOT, q(3), x(11), fifth()),
        def("m7b5", 0.07, ROOT, q(3), Tn(6, 0.8, true), x(10)),
        def("dim7", 0.07, ROOT, q(3), Tn(6, 0.8, true), x(9)),
        def("7sus4", 0.07, ROOT, q(5), x(10), fifth()),
        def("7b5", 0.10, ROOT, q(4), Tn(6, 0.8, true), x(10)),
        def("7#5", 0.09, ROOT, q(4), Tn(8, 0.8, true), x(10)),
        def("maj7#5", 0.12, ROOT, q(4), Tn(8, 0.8, true), x(11)),
        def("maj7b5", 0.13, ROOT, q(4), Tn(6, 0.8, true), x(11)),
        def("maj7sus2", 0.12, ROOT, q(2), x(11), fifth()),
        def("maj7sus4", 0.12, ROOT, q(5), x(11), fifth()),
        // added notes
        def("add9", 0.07, ROOT, q(4), x(2), fifth()),
        def("madd9", 0.08, ROOT, q(3), x(2), fifth()),
        def("add11", 0.12, ROOT, q(4), x(5, 0.55), fifth()),
        def("madd11", 0.14, ROOT, q(3), x(5, 0.55), fifth()),
        def("add#11", 0.14, ROOT, q(4), x(6), fifth()),
        def("madd#11", 0.18, ROOT, q(3), x(6), fifth()),
        def("sus2sus4", 0.14, ROOT, Tn(2, 0.8, true), Tn(5, 0.8, true), fifth()),
        def("6sus4", 0.12, ROOT, q(5), x(9), fifth()),
        // ninths
        def("9", 0.09, ROOT, q(4), x(10), x(2), fifth()),
        def("maj9", 0.10, ROOT, q(4), x(11), x(2), fifth()),
        def("m9", 0.09, ROOT, q(3), x(10), x(2), fifth()),
        def("mMaj9", 0.15, ROOT, q(3), x(11), x(2), fifth()),
        def("9sus4", 0.12, ROOT, q(5), x(10), x(2), fifth()),
        // altered dominants
        def("7b9", 0.11, ROOT, q(4), x(10), x(1), fifth()),
        def("7#9", 0.11, ROOT, q(4), x(10), x(3), fifth()),
        def("m7b9", 0.16, ROOT, q(3), x(10), x(1), fifth()),
        def("9b5", 0.16, ROOT, q(4), Tn(6, 0.8, true), x(10), x(2)),
        def("9#5", 0.16, ROOT, q(4), Tn(8, 0.8, true), x(10), x(2)),
        def("7b9#5", 0.19, ROOT, q(4), Tn(8, 0.8, true), x(10), x(1)),
        def("7#9#5", 0.19, ROOT, q(4), Tn(8, 0.8, true), x(10), x(3)),
        def("7b9b5", 0.19, ROOT, q(4), Tn(6, 0.8, true), x(10), x(1)),
        def("7#9b5", 0.19, ROOT, q(4), Tn(6, 0.8, true), x(10), x(3)),
        def("7#11", 0.12, ROOT, q(4), x(10), x(6), fifth()),
        def("maj7#11", 0.12, ROOT, q(4), x(11), x(6), fifth()),
        def("m7#11", 0.16, ROOT, q(3), x(10), x(6), fifth()),
        def("7b13", 0.16, ROOT, q(4), x(10), x(8), fifth()),
        // elevenths and thirteenths
        def("11", 0.14, ROOT, x(10), x(5, 0.65), x(2, 0.5, false), fifth(), Tn(4, 0.6, false)),
        def("m11", 0.12, ROOT, q(3), x(10), x(5, 0.65), x(2, 0.5, false), fifth()),
        def("maj11", 0.18, ROOT, q(4), x(11), x(5, 0.65), x(2, 0.5, false), fifth()),
        def("13", 0.12, ROOT, q(4), x(10), x(9, 0.65), fifth()),
        def("maj13", 0.13, ROOT, q(4), x(11), x(9, 0.65), fifth()),
        def("m13", 0.14, ROOT, q(3), x(10), x(9, 0.65), fifth()),
        def("13sus4", 0.15, ROOT, q(5), x(10), x(9, 0.65), fifth()),
        def("13b9", 0.20, ROOT, q(4), x(10), x(9, 0.65), x(1))
    )

    private val BY_ID: Map<String, ChordType> = ALL.associateBy { it.id }
    private val IDS_LONGEST_FIRST: List<String> = ALL.map { it.id }.filter { it.isNotEmpty() }.sortedByDescending { it.length }

    /** The type with this id, or null. */
    fun get(id: String): ChordType? = BY_ID[id]

    /** The notes of a type as semitones above the root (a major triad for an id that is not known). */
    fun intervals(id: String): IntArray = (BY_ID[id] ?: BY_ID.getValue("")).intervals

    /** True for the types that count as minor chords (Am, Am7, Am9 ...). Diminished chords do not. */
    fun isMinor(id: String): Boolean = id.startsWith("m") && !id.startsWith("maj")

    /**
     * The kind of chord, for telling whether two names are about the same chord: 0 major-ish (also 7, maj7, 9 ...),
     * 1 minor, 2 diminished, 3 augmented, 4 suspended.
     */
    fun family(id: String): Int {
        val t = BY_ID[id]
        return when {
            id.contains("sus") -> 4
            t != null && t.intervals.contains(3) && t.intervals.contains(6) -> 2
            t != null && t.intervals.contains(4) && t.intervals.contains(8) && !t.intervals.contains(7) -> 3
            isMinor(id) -> 1
            else -> 0
        }
    }

    private val ALIASES = mapOf(
        "maj" to "", "major" to "", "M" to "", "min" to "m", "minor" to "m", "mi" to "m",
        "2" to "sus2", "sus" to "sus4", "4" to "sus4", "7sus" to "7sus4", "9sus" to "9sus4", "13sus" to "13sus4",
        "add2" to "add9", "add4" to "add11", "madd2" to "madd9", "madd4" to "madd11",
        "6/9" to "69", "m6/9" to "m69", "maj6" to "6", "min6" to "m6",
        "7+" to "7#5", "aug7" to "7#5", "7aug" to "7#5", "+7" to "7#5", "maj7+" to "maj7#5", "maj7aug" to "maj7#5",
        "m7-5" to "m7b5", "min7b5" to "m7b5", "m7(b5)" to "m7b5", "7-5" to "7b5", "7-9" to "7b9", "7+9" to "7#9",
        "mM7" to "mMaj7", "mmaj7" to "mMaj7", "minmaj7" to "mMaj7", "m(maj7)" to "mMaj7", "mM9" to "mMaj9",
        "maj7#4" to "maj7#11", "7#4" to "7#11", "m7#4" to "m7#11",
        "M7" to "maj7", "Maj7" to "maj7", "M9" to "maj9", "Maj9" to "maj9", "M13" to "maj13", "M11" to "maj11"
    )

    /**
     * The chord type for what is written after the root of a chord name (m9, 7#9, maj7, +, ø). A name that is not
     * known exactly gets the longest known type it starts with (m7b5add11 gives m7b5), else the plain major or minor.
     */
    fun parse(raw: String): String {
        var s = raw.trim().replace("(", "").replace(")", "").replace(" ", "")
        s = s.replace("°", "dim").replace("ø", "m7b5").replace("Δ", "maj7")
        if (s.startsWith("-")) s = "m" + s.substring(1)
        else if (s.startsWith("+")) s = if (s == "+") "aug" else if (s == "+7") "7#5" else "aug" + s.substring(1)
        ALIASES[s]?.let { return it }
        if (BY_ID.containsKey(s)) return s
        for (id in IDS_LONGEST_FIRST) if (s.startsWith(id)) return id
        return if (isMinor(s)) "m" else ""
    }
}
