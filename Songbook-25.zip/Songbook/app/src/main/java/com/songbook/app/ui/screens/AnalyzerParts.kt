package com.songbook.app.ui.screens

import com.songbook.app.ui.components.IconSpec
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.activity.compose.BackHandler
import com.songbook.app.analysis.Instruments
import com.songbook.app.analysis.Instrument
import com.songbook.app.data.AudioStore
import androidx.compose.runtime.rememberUpdatedState
import android.content.Context
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.em
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.analysis.AnalysisResult
import com.songbook.app.analysis.AudioDecoder
import com.songbook.app.analysis.ChordEngine
import com.songbook.app.analysis.ChordNames
import com.songbook.app.analysis.ChordSeg
import com.songbook.app.analysis.GuitarShape
import com.songbook.app.analysis.GuitarShapes
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.components.CoralEmptyCard
import com.songbook.app.ui.components.CoralTopBar
import com.songbook.app.ui.components.SbIconButton
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.roundToInt

// The chord analyzer: pick a recording, Songbook listens to it on the phone and shows the chords with their
// times, the key, the tempo and how to play each chord on a guitar. The work is in analysis/ChordEngine.kt.

// Shared pieces of the chord analyzer's pages (AnalyzerScreen.kt): the player, the chart, the timelines, the shapes and the sheets.

internal val RootColors = listOf(
    Color(0xFFE4572E), Color(0xFFF08A24), Color(0xFFD9A400), Color(0xFF8AB531), Color(0xFF2FA84F), Color(0xFF1AA39A),
    Color(0xFF1D8FD6), Color(0xFF3F6FE0), Color(0xFF6C5CE7), Color(0xFF9B4DCA), Color(0xFFD6459D), Color(0xFFE0436B)
)

internal fun fmtTime(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

// ------------------------------------------------------------------ playback

internal class AnalyzerPlayer(file: File) {
    private var mp: MediaPlayer? = null
    var playing by mutableStateOf(false)
    var posMs by mutableStateOf(0)
    var speed by mutableStateOf(1f)
    var durationMs = 0

    init {
        runCatching {
            val m = MediaPlayer()
            m.setDataSource(file.path)
            m.prepare()
            m.setOnCompletionListener {
                playing = false
                posMs = 0
                runCatching { it.seekTo(0) }
            }
            durationMs = m.duration
            mp = m
        }
    }

    val ready: Boolean get() = mp != null

    internal fun applySpeed() {
        val m = mp ?: return
        runCatching { m.playbackParams = PlaybackParams().setSpeed(speed) }
    }

    fun toggle() {
        val m = mp ?: return
        if (playing) {
            m.pause()
            playing = false
        } else {
            m.start()
            playing = true
            if (speed != 1f) applySpeed()
        }
    }

    fun setSpeedTo(s: Float) {
        speed = s
        if (playing) applySpeed()
    }

    fun seekTo(ms: Int) {
        val m = mp ?: return
        val t = ms.coerceIn(0, max(0, durationMs))
        runCatching { m.seekTo(t) }
        posMs = t
    }

    fun seekSec(sec: Double) = seekTo((sec * 1000).toInt())

    fun tick() {
        val m = mp ?: return
        if (playing) posMs = runCatching { m.currentPosition }.getOrDefault(posMs)
    }

    fun release() {
        playing = false
        runCatching { mp?.release() }
        mp = null
    }
}

// ------------------------------------------------------------------ the chord chart

internal class BarGrid(val cells: List<String?>, val pad: Int, val perBar: Int) {
    val bars: List<List<String?>> get() = cells.chunked(perBar)
}

/** Lays the chords out in bars: a cell shows the chord only on the beat where it changes. */
internal fun buildBars(beats: DoubleArray, segs: List<ChordSeg>, names: List<String>, perBar: Int): BarGrid {
    if (beats.isEmpty() || segs.isEmpty()) return BarGrid(emptyList(), 0, perBar)
    fun idxAt(t: Double) = segs.indexOfLast { it.start <= t }.coerceAtLeast(0)
    val at = IntArray(beats.size) { idxAt(beats[it] + 0.08) }
    val changes = BooleanArray(beats.size) { i -> i == 0 || at[i] != at[i - 1] }
    // chords usually change on the first beat of a bar: pick the beat that most changes fall on
    var bestPhase = 0
    var bestCount = -1
    for (ph in 0 until perBar) {
        var cnt = 0
        for (i in beats.indices) if (changes[i] && segs[at[i]].isChord && i % perBar == ph) cnt++
        if (cnt > bestCount) {
            bestCount = cnt
            bestPhase = ph
        }
    }
    val cells = ArrayList<String?>()
    val pad = (perBar - bestPhase) % perBar
    repeat(pad) { cells.add(null) }
    for (i in beats.indices) cells.add(if (changes[i] && segs[at[i]].isChord) names[at[i]] else null)
    while (cells.size % perBar != 0) cells.add(null)
    return BarGrid(cells, pad, perBar)
}

/** Song text for the library: four bars to a line, every chord in square brackets as Songbook writes them. */
internal fun songBody(grid: BarGrid): String {
    val sb = StringBuilder("# Chords\n")
    var last = ""
    val perBar = ArrayList<String>()
    for (bar in grid.bars) {
        val tokens = ArrayList<String>()
        for (cell in bar) if (cell != null) {
            tokens.add(cell)
            last = cell
        }
        if (tokens.isEmpty() && last.isNotEmpty()) tokens.add(last)
        perBar.add(tokens.joinToString(" "))
    }
    for (line in perBar.chunked(4)) {
        val chords = line.filter { it.isNotEmpty() }.joinToString(" ")
        if (chords.isNotEmpty()) sb.append('[').append(chords).append("]\n")
    }
    return sb.toString().trimEnd()
}

/** A close-up of the 12 seconds around the playhead: it scrolls as the song plays, drag it to move through the song. */
@Composable
internal fun ZoomTimeline(
    result: AnalysisResult,
    segs: List<ChordSeg>,
    names: List<String>,
    posSec: Double,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 120.dp
) {
    val c = Sb.colors
    val window = 12.0
    val accent = c.ac
    val muted = c.mu.copy(alpha = 0.45f)
    val tick = c.mu.copy(alpha = 0.7f)
    val ink = c.tx
    val pos by rememberUpdatedState(posSec)
    val dur = result.durationSec
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(24.dp))
            .background(c.cd)
            .pointerInput(dur) {
                detectHorizontalDragGestures { change, dx ->
                    change.consume()
                    onSeek((pos - dx / (size.width / window)).coerceIn(0.0, dur))
                }
            }
    ) {
        val w = maxWidth
        val t0 = posSec - window / 2
        Canvas(Modifier.fillMaxSize()) {
            val pw = size.width
            val ph = size.height
            fun xOf(t: Double) = ((t - t0) / window * pw).toFloat()
            // loudness
            val first = kotlin.math.floor(t0 / AnalysisResult.PEAK_STEP).toInt().coerceAtLeast(0)
            val last = kotlin.math.ceil((t0 + window) / AnalysisResult.PEAK_STEP).toInt().coerceAtMost(result.peaks.size - 1)
            val barW = (pw / (window / AnalysisResult.PEAK_STEP)).toFloat()
            for (i in first..last) {
                val t = i * AnalysisResult.PEAK_STEP
                val h = (result.peaks[i] * ph * 0.26f).coerceAtLeast(1.5f)
                val x = xOf(t) + barW / 2
                drawLine(if (t <= posSec) accent else muted, Offset(x, ph * 0.66f - h), Offset(x, ph * 0.66f + h), strokeWidth = max(1f, barW * 0.7f), cap = StrokeCap.Round)
            }
            // chords
            for (s in segs) {
                if (!s.isChord || s.end < t0 || s.start > t0 + window) continue
                val x0 = max(0f, xOf(s.start))
                val x1 = kotlin.math.min(pw, xOf(s.end))
                if (x1 - x0 < 2f) continue
                drawRoundRect(RootColors[s.root % 12], Offset(x0 + 0.5.dp.toPx(), 8.dp.toPx()), Size(x1 - x0 - 1.dp.toPx(), 34.dp.toPx()), CornerRadius(9.dp.toPx()))
            }
            // beats
            for (b in result.beats) {
                if (b < t0 || b > t0 + window) continue
                drawLine(tick, Offset(xOf(b), ph - 12.dp.toPx()), Offset(xOf(b), ph - 4.dp.toPx()), strokeWidth = 1.5.dp.toPx())
            }
            drawLine(ink, Offset(pw / 2, 0f), Offset(pw / 2, ph), strokeWidth = 2.dp.toPx())
        }
        segs.forEachIndexed { i, s ->
            if (s.isChord && s.end >= t0 && s.start <= t0 + window) {
                val a = kotlin.math.max(s.start, t0)
                val b = kotlin.math.min(s.end, t0 + window)
                val sw = w * ((b - a) / window).toFloat()
                if (sw >= 34.dp) {
                    Text(
                        names[i], maxLines = 1, textAlign = TextAlign.Center,
                        style = sbStyle(16, FontWeight.SemiBold, Color.White),
                        modifier = Modifier.offset(x = w * ((a - t0) / window).toFloat(), y = 15.dp).width(sw)
                    )
                }
            }
        }
    }
}

/** A guitar chord box: six strings, five frets, dots for the fingers, x and o above the strings. */
@Composable
internal fun GuitarDiagram(shape: GuitarShape, modifier: Modifier = Modifier, labels: List<String>? = null) {
    val c = Sb.colors
    val ink = c.tx
    val dot = c.ac
    val soft = c.mu.copy(alpha = 0.55f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val left = w * 0.20f
        val right = w * 0.92f
        val top = h * 0.20f
        val bottom = h * (if (labels != null) 0.86f else 0.97f)
        val n = shape.frets.size
        val sx = (right - left) / (n - 1)
        val fy = (bottom - top) / 5f
        val base = shape.baseFret
        val line = 1.2.dp.toPx()
        // frets
        for (f in 0..5) {
            val y = top + fy * f
            val nut = f == 0 && base == 1
            drawLine(if (nut) ink else soft, Offset(left, y), Offset(right, y), strokeWidth = if (nut) 3.dp.toPx() else line)
        }
        // strings
        for (s in 0 until n) drawLine(soft, Offset(left + sx * s, top), Offset(left + sx * s, bottom), strokeWidth = line)
        // barre
        if (shape.barre > 0) {
            val row = shape.barre - base
            if (row in 0..4) {
                val y = top + fy * (row + 0.5f)
                drawLine(dot, Offset(left + sx * shape.barreFrom, y), Offset(right, y), strokeWidth = fy * 0.62f, cap = StrokeCap.Round)
            }
        }
        // fingers, muted and open strings
        val r = kotlin.math.min(sx, fy) * 0.34f
        for (s in 0 until n) {
            val f = shape.frets[s]
            val x = left + sx * s
            if (f < 0) drawCross(x, top - fy * 0.45f, r * 0.7f, ink, line)
            else if (f == 0) drawCircle(ink, r * 0.7f, Offset(x, top - fy * 0.45f), style = androidx.compose.ui.graphics.drawscope.Stroke(line))
            else {
                val row = f - base
                if (row in 0..4 && !(shape.barre == f && s >= shape.barreFrom)) drawCircle(dot, r, Offset(x, top + fy * (row + 0.5f)))
            }
        }
        // the note each string sounds, under the string
        if (labels != null) {
            val paint = android.graphics.Paint().apply {
                color = ink.toArgb(); textSize = h * 0.075f; isAntiAlias = true; textAlign = android.graphics.Paint.Align.CENTER
            }
            for (s in 0 until n) {
                val t = labels.getOrNull(s) ?: ""
                if (t.isNotEmpty()) drawContext.canvas.nativeCanvas.drawText(t, left + sx * s, h * 0.985f, paint)
            }
        }
        // the fret number when the chord is up the neck
        if (base > 1) {
            drawContext.canvas.nativeCanvas.drawText(
                "$base", 1.dp.toPx(), top + fy * 0.7f,
                android.graphics.Paint().apply { color = ink.toArgb(); textSize = fy * 0.6f; isAntiAlias = true }
            )
        }
    }
}


internal fun DrawScope.drawCross(x: Float, y: Float, r: Float, color: Color, width: Float) {
    drawLine(color, Offset(x - r, y - r), Offset(x + r, y + r), strokeWidth = width)
    drawLine(color, Offset(x - r, y + r), Offset(x + r, y - r), strokeWidth = width)
}


@Composable
internal fun StepButton(text: String, onClick: () -> Unit) {
    val c = Sb.colors
    Box(Modifier.size(40.dp).clip(CircleShape).background(c.track).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, style = sbStyle(20, FontWeight.SemiBold, c.tx))
    }
}

@Composable
internal fun PillButton(text: String, solid: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = Sb.colors
    Box(
        modifier.height(54.dp).clip(RoundedCornerShape(27.dp)).background(if (solid) c.pill else c.cd).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, style = sbStyle(15, FontWeight.SemiBold, if (solid) c.onPill else c.tx), maxLines = 1) }
}


// ------------------------------------------------------------------ shapes for every instrument

internal fun shapeFor(instrument: Instrument, root: Int, type: String): GuitarShape? = when (instrument) {
    Instrument.GUITAR -> GuitarShapes.shape(Math.floorMod(root, 12), type)
    Instrument.UKULELE -> Instruments.ukulele(root, type)
    else -> null
}

/** The shape of a chord for the chosen instrument: strings and frets, a keyboard, or nothing. */
@Composable
internal fun ChordShapeView(instrument: Instrument, root: Int, type: String, modifier: Modifier = Modifier) {
    when (instrument) {
        Instrument.PIANO -> PianoDiagram(root, type, modifier.aspectRatio(1.9f))
        Instrument.OFF -> {}
        else -> shapeFor(instrument, root, type)?.let { GuitarDiagram(it, modifier.aspectRatio(0.85f)) }
    }
}

/** Two octaves of keys from C, the notes of the chord in the accent colour. */
@Composable
internal fun PianoDiagram(root: Int, type: String, modifier: Modifier = Modifier, lit: Set<Int>? = null) {
    val c = Sb.colors
    val accent = c.ac
    val whiteFill = if (c.isDark) Color(0xFFE9E9E9) else Color.White
    val edge = Color(0xFF555555)
    val keys = lit ?: Instruments.pianoKeys(root, type).toSet()
    val whiteSem = intArrayOf(0, 2, 4, 5, 7, 9, 11)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val ww = w / 14f
        for (wi in 0 until 14) {
            val sem = (wi / 7) * 12 + whiteSem[wi % 7]
            drawRoundRect(if (sem in keys) accent else whiteFill, Offset(wi * ww + 1f, 0f), Size(ww - 2f, h), CornerRadius(4.dp.toPx()))
            drawRoundRect(edge, Offset(wi * ww + 1f, 0f), Size(ww - 2f, h), CornerRadius(4.dp.toPx()), style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        }
        val bw = ww * 0.6f
        for (wi in 0 until 13) {
            if (wi % 7 in intArrayOf(0, 1, 3, 4, 5)) {
                val sem = (wi / 7) * 12 + whiteSem[wi % 7] + 1
                drawRoundRect(if (sem in keys) accent else Color(0xFF1A1A1A), Offset((wi + 1) * ww - bw / 2, 0f), Size(bw, h * 0.62f), CornerRadius(3.dp.toPx()))
            }
        }
    }
}

// ------------------------------------------------------------------ players

@Composable
internal fun RoundBtn(icon: IconSpec, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier.size(44.dp).clip(CircleShape).background(c.cd).clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, c.tx, size = 22.dp) }
}

private fun nextSpeed(s: Float) = when (s) { 1f -> 0.75f; 0.75f -> 0.5f; else -> 1f }
private fun speedLabel(s: Float) = when (s) { 0.5f -> "0.5×"; 0.75f -> "0.75×"; else -> "1×" }

/** The small player at the bottom of the Chords, Chart and Follow views. */
@Composable
internal fun MiniPlayer(player: AnalyzerPlayer, duration: Double, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp).fillMaxWidth().height(72.dp)
            .clip(RoundedCornerShape(36.dp)).background(c.pill).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(c.onPill).clickable { player.toggle() }
                .semantics { contentDescription = if (player.playing) "Pause" else "Play" },
            contentAlignment = Alignment.Center
        ) { StrokeIcon(if (player.playing) SbIcons.Pause else SbIcons.Play, c.pill, size = 22.dp, filled = true) }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(c.onPill.copy(alpha = 0.2f))) {
                Box(Modifier.fillMaxWidth((player.posMs / 1000.0 / max(1.0, duration)).toFloat().coerceIn(0.01f, 1f)).height(4.dp).background(c.ac))
            }
            Text("${fmtTime(player.posMs / 1000.0)} / ${fmtTime(duration)}", style = sbStyle(12, FontWeight.Medium, c.onPill.copy(alpha = 0.7f)), modifier = Modifier.padding(top = 6.dp))
        }
        Box(
            Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).clickable { player.setSpeedTo(nextSpeed(player.speed)) }.padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) { Text(speedLabel(player.speed), style = sbStyle(14, FontWeight.SemiBold, c.onPill)) }
    }
}

/** The big controls of the Play view: a bar to jump with, minus five seconds, play, plus five, the speed. */
@Composable
internal fun BigControls(player: AnalyzerPlayer, duration: Double, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier.navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 22.dp)) {
        Box(
            Modifier.fillMaxWidth().height(28.dp).pointerInput(duration) {
                detectTapGestures { o -> player.seekTo((o.x / size.width * duration * 1000).toInt()) }
            }.pointerInput(duration) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    player.seekTo((change.position.x / size.width * duration * 1000).toInt())
                }
            },
            contentAlignment = Alignment.CenterStart
        ) {
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(c.track)) {
                Box(Modifier.fillMaxWidth((player.posMs / 1000.0 / max(1.0, duration)).toFloat().coerceIn(0.01f, 1f)).height(4.dp).background(c.ac))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmtTime(player.posMs / 1000.0), style = sbStyle(13, color = c.mu))
            Text(fmtTime(duration), style = sbStyle(13, color = c.mu))
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.width(64.dp).height(40.dp).clip(RoundedCornerShape(20.dp)).background(c.cd).clickable { player.setSpeedTo(nextSpeed(player.speed)) }, contentAlignment = Alignment.Center) {
                Text(speedLabel(player.speed), style = sbStyle(14, FontWeight.SemiBold, c.tx))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(c.cd).clickable { player.seekTo(player.posMs - 5000) }, contentAlignment = Alignment.Center) {
                    Text("−5", style = sbStyle(15, FontWeight.SemiBold, c.tx))
                }
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(c.pill).clickable { player.toggle() }
                        .semantics { contentDescription = if (player.playing) "Pause" else "Play" },
                    contentAlignment = Alignment.Center
                ) { StrokeIcon(if (player.playing) SbIcons.Pause else SbIcons.Play, c.onPill, size = 30.dp, filled = true) }
                Box(Modifier.size(52.dp).clip(CircleShape).background(c.cd).clickable { player.seekTo(player.posMs + 5000) }, contentAlignment = Alignment.Center) {
                    Text("+5", style = sbStyle(15, FontWeight.SemiBold, c.tx))
                }
            }
            Spacer(Modifier.width(64.dp))
        }
    }
}

// ------------------------------------------------------------------ sheets and rows

/** A sheet from the bottom with a title and a Done button, over a dimmed page. */
@Composable
internal fun AnalyzerSheet(title: String, subtitle: String? = null, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Sb.colors
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(Color(0x9E000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
        )
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth().heightIn(max = maxHeight * 0.88f)
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(c.sheet)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .navigationBarsPadding().padding(start = 20.dp, end = 20.dp, top = 10.dp)
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(5.dp).clip(CircleShape).background(Color(0x66808080)))
                Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, style = sbStyle(22, FontWeight.SemiBold, c.tx))
                        if (subtitle != null) Text(subtitle, style = sbStyle(13, color = c.mu))
                    }
                    Box(Modifier.height(40.dp).clip(RoundedCornerShape(20.dp)).background(c.pill).clickable(onClick = onClose).padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                        Text("Done", style = sbStyle(15, FontWeight.SemiBold, c.onPill))
                    }
                }
                Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp), content = content)
            }
        }
    }
}

@Composable
internal fun AnaLabel(text: String, modifier: Modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) {
    val c = Sb.colors
    Text(text.uppercase(), style = sbStyle(12, FontWeight.Medium, c.mu).copy(letterSpacing = 0.14.em), modifier = modifier)
}

@Composable
internal fun AnaRow(label: String, sub: String? = null, content: @Composable () -> Unit) {
    val c = Sb.colors
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(label, style = sbStyle(15, FontWeight.Medium, c.tx))
            if (sub != null) Text(sub, style = sbStyle(12, color = c.mu))
        }
        content()
    }
}

/** A row of the Save sheet: an icon tile, a title and a line under it. */
@Composable
internal fun ActionRow(icon: IconSpec, title: String, sub: String, onClick: () -> Unit) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).heightIn(min = 60.dp).padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).background(c.cd, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { StrokeIcon(icon, c.tx, size = 22.dp) }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, style = sbStyle(16, FontWeight.SemiBold, c.tx))
            Text(sub, style = sbStyle(13, color = c.mu))
        }
        StrokeIcon(SbIcons.ChevronRight, c.mu, size = 18.dp)
    }
}
