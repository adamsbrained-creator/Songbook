package com.songbook.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.data.SongEntity
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

/**
 * Square song tile for the grid layouts (2, 3 or 4 columns). The heart and the menu sit on top of the
 * artwork; in the 4 column layout they are smaller so the tile stays readable.
 */
@Composable
fun SongGridCell(
    song: SongEntity,
    subtitle: String,
    columns: Int,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Sb.colors
    val small = columns >= 4
    val compact = columns >= 3
    Column(modifier.clickable(onClick = onClick)) {
        Artwork(
            song.gradient,
            RoundedCornerShape(if (small) 14.dp else if (compact) 18.dp else 22.dp),
            Modifier.fillMaxWidth().aspectRatio(1f),
            image = song.image
        ) {
            if (song.badge.isNotBlank() && !small) {
                Box(Modifier.matchParentSize().padding(8.dp), contentAlignment = Alignment.TopStart) {
                    BadgePill(song.badge, song.badgeColor, solid = true)
                }
            }
            val pad = if (small) 3.dp else 6.dp
            Box(Modifier.matchParentSize().padding(pad), contentAlignment = Alignment.BottomStart) {
                MiniButton(SbIcons.Heart, if (song.favorite) c.ac else Color.White, song.favorite, onFavorite, small)
            }
            Box(Modifier.matchParentSize().padding(pad), contentAlignment = Alignment.BottomEnd) {
                MiniButton(SbIcons.More, Color.White, false, onMore, small)
            }
        }
        Text(
            song.title,
            style = sbStyle(if (small) 11 else if (compact) 13 else 14, FontWeight.SemiBold, c.tx),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = if (small) 5.dp else 8.dp)
        )
        if (!small) {
            Text(subtitle, style = sbStyle(12, color = c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis)
            RatingTag(song.rating)
        }
    }
}

@Composable
fun MiniButton(icon: IconSpec, tint: Color, filled: Boolean, onClick: () -> Unit, small: Boolean = false) {
    Box(
        Modifier.size(if (small) 24.dp else 32.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.30f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, tint, size = if (small) 14.dp else 18.dp, filled = filled) }
}

/**
 * The "Simple list" layout, in the style of a record player's track list: no lines and no cards. A small
 * number, the title, and the little things on the right (heart, stars, album) in quiet colors. Tap opens the
 * song, a long press (or the dots) opens its menu. [number] is the track number ("01", "A1"); leave it out
 * for a list without numbers.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun SimpleSongRow(
    title: String,
    subtitle: String,
    favorite: Boolean,
    rating: Float,
    onClick: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier,
    number: String? = null
) {
    val c = Sb.colors
    androidx.compose.foundation.layout.Row(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .combinedClickable(onClick = onClick, onLongClick = onMore)
            .padding(start = 24.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
    ) {
        if (number != null) {
            Text(number, style = sbStyle(14, color = c.mu), maxLines = 1, modifier = Modifier.width(30.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = sbStyle(16, FontWeight.Medium, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = sbStyle(12, color = c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (favorite) StrokeIcon(SbIcons.Heart, c.ac, size = 14.dp, filled = true)
        RatingTag(rating)
        SbIconButton(SbIcons.More, "More", onMore, tint = c.mu, size = 20.dp)
    }
}

/**
 * A group heading for the Simple list, like the "Side A" bar of a record player: a soft rounded bar with a
 * disc icon, the name and a note on the right ("5 songs").
 */
@Composable
fun SimpleSectionHeader(title: String, note: String, modifier: Modifier = Modifier) {
    val c = Sb.colors
    androidx.compose.foundation.layout.Row(
        modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(c.cd)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
    ) {
        StrokeIcon(SbIcons.Disc, c.tx, size = 22.dp)
        Text(title, style = sbStyle(16, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(note, style = sbStyle(13, color = c.mu), maxLines = 1)
    }
}
