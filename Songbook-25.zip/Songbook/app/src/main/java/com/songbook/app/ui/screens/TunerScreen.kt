package com.songbook.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.provider.Settings
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.songbook.app.analysis.Chime
import com.songbook.app.analysis.MicStream
import com.songbook.app.analysis.Pitch
import com.songbook.app.analysis.RefTone
import com.songbook.app.analysis.TunerEngine
import com.songbook.app.analysis.Tuning
import com.songbook.app.analysis.Tunings
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.rememberMicRequest
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

// The tuner: it listens to the microphone, finds the pitch of the string (analysis/Tuner.kt), shows the note and how
// many cents it is off on a meter, and can play the note of a string to tune by ear.

private val InTuneColor = Color(0xFF2FA84F)

/** The median of the last few readings, so one wrong reading (the pluck itself, a harmonic) does not move the meter. */
private class Smoother {
    private val v = DoubleArray(5)
    private var n = 0
    private var i = 0

    @Synchronized
    fun add(x: Double): Double {
        v[i] = x
        i = (i + 1) % v.size
        if (n < v.size) n++
        val s = v.copyOf(n)
        s.sort()
        return s[n / 2]
    }

    @Synchronized
    fun clear() {
        n = 0
        i = 0
    }
}

/** Times shared between the microphone thread and the screen. */
private class TunerClock {
    @Volatile var toneUntil = 0L
    @Volatile var lastHeard = 0L
    @Volatile var octaveRuns = 0
}

@Composable
fun TunerScreen(
    onBack: () -> Unit,
    tuningIndex: Int,
    refHz: Int,
    onTuning: (Int) -> Unit,
    onRef: (Int) -> Unit,
    advance: Boolean,
    chime: Boolean,
    onAdvance: (Boolean) -> Unit,
    onChime: (Boolean) -> Unit
) {
    val c = Sb.colors
    val context = LocalContext.current
    val view = LocalView.current
    val tuning = Tunings.get(tuningIndex)
    val ref = refHz.coerceIn(430, 450)
    val refNow by rememberUpdatedState(ref)

    var access by remember { mutableIntStateOf(0) }         // 0 asking, 1 listening, 2 no permission, 3 the microphone is busy
    var hasNote by remember { mutableStateOf(false) }
    var midi by remember { mutableDoubleStateOf(0.0) }
    var target by remember { mutableIntStateOf(-1) }         // the string that is locked, -1 = automatic
    var sheet by remember { mutableStateOf(false) }
    var playing by remember { mutableIntStateOf(-1) }        // the note of the reference tone that sounds, -1 = none
    var playKey by remember { mutableIntStateOf(0) }
    val tuned = remember { mutableStateListOf<Int>() }
    var lastIdx by remember { mutableIntStateOf(-1) }        // the string that was tuned last: the next one is suggested after it

    val mic = remember { MicStream(context) }
    val tone = remember { RefTone() }
    val chimePlayer = remember { Chime() }
    val smoother = remember { Smoother() }
    val clock = remember { TunerClock() }

    val request = rememberMicRequest { ok -> access = if (ok) 1 else 2 }
    LaunchedEffect(Unit) { request() }

    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) { onDispose { tone.stop(); chimePlayer.stop() } }

    DisposableEffect(access, tuning.bass) {
        if (access == 1) {
            var engine: TunerEngine? = null
            val ok = mic.start(autoGain = true) { buf, n ->
                val e = engine ?: TunerEngine(mic.rate, tuning.bass).also { engine = it }
                val r = e.feed(buf, n)
                if (r != null) {
                    val now = System.currentTimeMillis()
                    if (now < clock.toneUntil) {
                        hasNote = false
                        smoother.clear()
                    } else if (r.freq > 0.0 && r.clarity > 0.8f) {
                        val m = Pitch.midiOf(r.freq, refNow.toDouble())
                        // a reading an octave away from the one before is usually the detector's mistake: it counts only when it lasts
                        val octaveJump = hasNote && now - clock.lastHeard < 400 && abs(abs(m - midi) - 12.0) < 0.8
                        if (octaveJump && clock.octaveRuns < 4) {
                            clock.octaveRuns++
                            clock.lastHeard = now
                        } else {
                            clock.octaveRuns = 0
                            if (octaveJump) smoother.clear()
                            midi = smoother.add(m)
                            hasNote = true
                            clock.lastHeard = now
                        }
                    } else if (now - clock.lastHeard > 700) {
                        hasNote = false
                        smoother.clear()
                    }
                }
            }
            if (!ok) access = 3
        }
        onDispose { mic.stop() }
    }

    LaunchedEffect(tuningIndex) {
        tuned.clear()
        lastIdx = -1
        target = -1
    }
    LaunchedEffect(playKey) {
        if (playing >= 0) {
            delay(2700)
            playing = -1
        }
    }

    val strings = tuning.strings
    // the string to tune next: the first one after the last tuned that is not in tune yet (none when every string is)
    val suggest = if (!advance || strings.isEmpty()) -1 else {
        var s = -1
        for (k in 1..strings.size) {
            val i = (lastIdx + k) % strings.size
            if (strings[i] !in tuned) {
                s = i
                break
            }
        }
        s
    }
    val allDone = strings.isNotEmpty() && strings.all { it in tuned }
    val auto = when {
        !hasNote -> -1
        strings.isEmpty() -> Math.round(midi).toInt()
        // a string that is far out of tune still counts as the suggested one, as long as it is nearer to it than to the others
        suggest >= 0 && abs(strings[suggest] - midi) < 2.5 -> strings[suggest]
        else -> strings.minByOrNull { abs(it - midi) } ?: -1
    }
    val locked = target in strings.indices
    val tgt = if (locked) strings[target] else auto
    val cents = if (hasNote && tgt >= 0) ((midi - tgt) * 100.0).toFloat() else 0f
    val inTune = hasNote && tgt >= 0 && abs(cents) <= 5f

    // held in tune for a moment: the string is done, a chime plays and the next string is suggested
    LaunchedEffect(inTune, tgt, chime) {
        if (inTune && strings.isNotEmpty()) {
            delay(600)
            if (tgt !in tuned) {
                tuned.add(tgt)
                lastIdx = strings.indexOf(tgt)
                if (chime) {
                    val all = strings.all { it in tuned }
                    clock.toneUntil = System.currentTimeMillis() + chimePlayer.lengthMs(all) + 250
                    hasNote = false
                    smoother.clear()
                    chimePlayer.play(all)
                    view.performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                    )
                }
            }
        }
    }
    // a string that was in tune and has gone out of tune again can be tuned (and chime) once more
    val farOut = hasNote && tgt >= 0 && abs(cents) > 15f
    LaunchedEffect(farOut, tgt) {
        if (farOut && tgt in tuned) {
            delay(800)
            tuned.remove(tgt)
        }
    }

    fun playString(i: Int) {
        val note = strings[i]
        clock.toneUntil = System.currentTimeMillis() + 2800
        hasNote = false
        smoother.clear()
        tone.play(Pitch.freqOf(note, ref.toDouble()))
        playing = note
        playKey++
    }

    Box(Modifier.fillMaxSize().screenBg().statusBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            AnaHeader("Tuner", "${tuning.name} · A = $ref Hz", { RoundBtn(SbIcons.Back, "Back", onBack) }) {
                RoundBtn(SbIcons.Sliders, "Tuning", { sheet = true })
            }
            if (access >= 2) {
                MicProblem(busy = access == 3, onRetry = { access = 0; request() }, onSettings = {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            } else {
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(20.dp))
                    val shownNote = if (playing >= 0) playing else if (tgt >= 0) tgt else -1
                    val live = hasNote && playing < 0
                    val noteColor = if (inTune) InTuneColor else if (live || playing >= 0) c.tx else c.mu
                    Row(verticalAlignment = Alignment.Top) {
                        Text(if (shownNote >= 0) Pitch.name(shownNote) else "–", style = sbStyle(120, FontWeight.SemiBold, noteColor), maxLines = 1)
                        if (shownNote >= 0) {
                            Text(Pitch.octave(shownNote).toString(), style = sbStyle(28, FontWeight.Medium, c.mu), modifier = Modifier.padding(top = 26.dp, start = 2.dp))
                        }
                    }
                    val hz = if (live) ref * Math.pow(2.0, (midi - 69.0) / 12.0) else 0.0
                    Text(
                        if (live) String.format("%.1f Hz", hz) else " ",
                        style = sbStyle(15, color = c.mu), modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(18.dp))
                    CentMeter(cents, live, inTune, Modifier.padding(horizontal = 16.dp))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp)) {
                        Text("Flat", style = sbStyle(13, color = c.mu), modifier = Modifier.weight(1f))
                        Text("Sharp", style = sbStyle(13, color = c.mu))
                    }
                    val noteName = if (tgt >= 0) Pitch.name(tgt) else ""
                    val how = if (tuning.chromatic) "" else if (cents < 0) " · tighten the string" else " · loosen the string"
                    val hint = when {
                        playing >= 0 -> "Playing ${Pitch.name(playing)}${Pitch.octave(playing)}"
                        !hasNote -> when {
                            locked -> "Play the $noteName string"
                            allDone -> "All strings are in tune"
                            suggest >= 0 -> "Play the ${Pitch.name(strings[suggest])}${Pitch.octave(strings[suggest])} string"
                            else -> "Play a string"
                        }
                        inTune -> if (!locked && suggest >= 0 && tgt in tuned) "In tune · next: ${Pitch.name(strings[suggest])}${Pitch.octave(strings[suggest])}" else "In tune"
                        cents < 0 -> "${(-cents).roundToInt()} cents flat$how"
                        else -> "${cents.roundToInt()} cents sharp$how"
                    }
                    Text(
                        hint, style = sbStyle(18, FontWeight.SemiBold, if (inTune) InTuneColor else c.tx), textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 18.dp, start = 24.dp, end = 24.dp)
                    )
                    if (!tuning.chromatic) {
                        Spacer(Modifier.height(28.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            strings.forEachIndexed { i, note ->
                                StringChip(
                                    note, selected = tgt == note && (locked || hasNote), locked = locked && target == i, done = note in tuned,
                                    next = !locked && i == suggest
                                ) {
                                    if (target == i) target = -1 else {
                                        target = i
                                        playString(i)
                                    }
                                }
                            }
                        }
                        Text(
                            when {
                                locked -> "Staying on this string. Tap it again to go back to Auto."
                                advance -> "Auto: it finds the string you play and moves on when one is in tune. Tap a string to hear it and stay on it."
                                else -> "Auto: it finds the string you play. Tap a string to hear it and stay on it."
                            },
                            style = sbStyle(13, color = c.mu), textAlign = TextAlign.Center,
                            modifier = Modifier.padding(start = 32.dp, end = 32.dp, top = 14.dp)
                        )
                        if (tuned.isNotEmpty()) {
                            Text(
                                "Start over", style = sbStyle(14, FontWeight.Medium, c.ac),
                                modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(14.dp)).clickable {
                                    tuned.clear()
                                    lastIdx = -1
                                }.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(32.dp))
                }
            }
        }
        if (sheet) TunerSheet(tuningIndex, onTuning, ref, onRef, advance, chime, onAdvance, onChime) { sheet = false }
    }
}

// ------------------------------------------------------------------ pieces

/** The meter: -50 to +50 cents, the zone of 5 cents either side of the note in green, the needle moves softly. */
@Composable
private fun CentMeter(cents: Float, active: Boolean, inTune: Boolean, modifier: Modifier = Modifier) {
    val c = Sb.colors
    val pos by animateFloatAsState(if (active) cents.coerceIn(-50f, 50f) else 0f, spring(stiffness = Spring.StiffnessMediumLow), label = "cents")
    val needle = if (!active) c.mu else if (inTune) InTuneColor else c.ac
    val strong = c.tx
    val soft = c.mu
    Canvas(modifier.fillMaxWidth().height(96.dp)) {
        val w = size.width
        val pad = 20.dp.toPx()
        val half = (w - 2 * pad) / 2f
        val cx = w / 2f
        val mid = size.height / 2f
        drawRoundRect(
            InTuneColor.copy(alpha = if (inTune) 0.32f else 0.14f),
            Offset(cx - half * 5f / 50f, 6.dp.toPx()), Size(half * 10f / 50f, size.height - 12.dp.toPx()), CornerRadius(10.dp.toPx())
        )
        for (i in -50..50 step 5) {
            val x = cx + half * i / 50f
            val len = when {
                i == 0 -> 30.dp.toPx()
                i % 25 == 0 -> 22.dp.toPx()
                i % 10 == 0 -> 16.dp.toPx()
                else -> 9.dp.toPx()
            }
            drawLine(if (i == 0) strong else soft, Offset(x, mid - len), Offset(x, mid + len), strokeWidth = if (i == 0) 2.5.dp.toPx() else 1.5.dp.toPx(), cap = StrokeCap.Round)
        }
        val nx = cx + half * pos / 50f
        drawRoundRect(needle, Offset(nx - 3.dp.toPx(), 2.dp.toPx()), Size(6.dp.toPx(), size.height - 4.dp.toPx()), CornerRadius(3.dp.toPx()))
    }
}

/** A string of the tuning: its note and octave. Coral while it is the one being tuned, a green dot when it was in tune. */
@Composable
private fun StringChip(note: Int, selected: Boolean, locked: Boolean, done: Boolean, next: Boolean, onClick: () -> Unit) {
    val c = Sb.colors
    Box(contentAlignment = Alignment.TopEnd) {
        Column(
            Modifier.size(50.dp).clip(CircleShape).background(if (selected) c.ac else c.cd)
                .then(if (next && !selected) Modifier.border(2.dp, c.ac, CircleShape) else Modifier)
                .clickable(onClick = onClick),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Text(Pitch.name(note), style = sbStyle(17, FontWeight.SemiBold, if (selected) c.onAc else c.tx), maxLines = 1)
                Text(Pitch.octave(note).toString(), style = sbStyle(10, FontWeight.Medium, if (selected) c.onAc else c.mu), modifier = Modifier.padding(top = 2.dp))
            }
        }
        if (done) Box(Modifier.size(14.dp).clip(CircleShape).background(InTuneColor))
        else if (locked) Box(Modifier.size(8.dp).clip(CircleShape).background(c.tx))
    }
}

@Composable
internal fun MicProblem(busy: Boolean, onRetry: () -> Unit, onSettings: () -> Unit) {
    val c = Sb.colors
    Column(Modifier.padding(16.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).padding(24.dp)) {
        Text(if (busy) "The microphone is busy" else "The microphone is off", style = sbStyle(20, FontWeight.SemiBold, c.tx))
        Text(
            if (busy) "Another app is using the microphone. Close it and try again."
            else "Songbook needs the microphone to hear your instrument. Nothing is recorded or uploaded.",
            style = sbStyle(15, color = c.mu), modifier = Modifier.padding(top = 8.dp, bottom = 18.dp)
        )
        PillButton(if (busy) "Try again" else "Allow the microphone", true, Modifier.fillMaxWidth(), onRetry)
        if (!busy) {
            Spacer(Modifier.height(10.dp))
            PillButton("Open the app's settings", false, Modifier.fillMaxWidth(), onSettings)
        }
    }
}

@Composable
private fun TunerSheet(
    tuningIndex: Int, onTuning: (Int) -> Unit, ref: Int, onRef: (Int) -> Unit,
    advance: Boolean, chime: Boolean, onAdvance: (Boolean) -> Unit, onChime: (Boolean) -> Unit, onClose: () -> Unit
) {
    val c = Sb.colors
    AnalyzerSheet("Tuner", null, onClose) {
        AnaLabel("Tuning")
        Tunings.ALL.forEachIndexed { i, t -> TuningRow(t, i == tuningIndex) { onTuning(i) } }
        AnaLabel("When a string is in tune")
        AnaRow("Chime", "A short sound and a buzz") {
            Segmented(listOf("On", "Off"), if (chime) 0 else 1) { onChime(it == 0) }
        }
        AnaRow("Next string", "Move on to the next string by itself, or stay on the one you play") {
            Segmented(listOf("Move on", "Stay"), if (advance) 0 else 1) { onAdvance(it == 0) }
        }
        AnaLabel("Reference pitch")
        AnaRow("A = $ref Hz", "Most music is at 440") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StepButton("−") { onRef((ref - 1).coerceAtLeast(430)) }
                Text("$ref", style = sbStyle(16, FontWeight.SemiBold, c.tx), textAlign = TextAlign.Center, modifier = Modifier.width(52.dp))
                StepButton("+") { onRef((ref + 1).coerceAtMost(450)) }
            }
        }
    }
}

@Composable
private fun TuningRow(t: Tuning, selected: Boolean, onClick: () -> Unit) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).heightIn(min = 56.dp).padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(t.name, style = sbStyle(16, FontWeight.SemiBold, c.tx))
            Text(if (t.chromatic) "Any note" else t.notes(), style = sbStyle(13, color = c.mu))
        }
        if (selected) StrokeIcon(SbIcons.Check, c.ac, size = 22.dp)
    }
}
