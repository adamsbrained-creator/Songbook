package com.songbook.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.data.SongEntity
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

/** Pick one of the songs by name (with a search box); used to say which song a new demo belongs to. */
@Composable
fun SongPickDialog(title: String, songs: List<SongEntity>, onPick: (Long) -> Unit, onDismiss: () -> Unit) {
    val c = Sb.colors
    var query by remember { mutableStateOf("") }
    val list = remember(songs, query) { songs.filter { query.isBlank() || it.title.contains(query, ignoreCase = true) }.take(80) }
    SbDialog(title, onDismiss, null, null) {
        Column {
            SbField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Search songs") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 320.dp)) {
                items(list, key = { it.id }) { s ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onPick(s.id) }.padding(horizontal = 12.dp, vertical = 14.dp)) {
                        Text(s.title, style = sbStyle(15, FontWeight.Medium, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
