package com.songbook.app.analysis

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** One stretch of the recording with one chord. [root] is 0..11 (C = 0), or -1 for "no chord" (silence). */
class ChordSeg(val start: Double, val end: Double, val root: Int, val type: String) {
    val isChord: Boolean get() = root >= 0
}

class AnalysisResult(
    val durationSec: Double,
    val bpm: Double,
    /** Times of the beats in seconds. */
    val beats: DoubleArray,
    val keyTonic: Int,
    val keyMinor: Boolean,
    /** How far the recording is tuned from A = 440 Hz, in cents (-50..50). */
    val tuningCents: Int,
    /** Only major and minor chords. */
    val basic: List<ChordSeg>,
    /** Also 7th, maj7, m7, sus4 and sus2 chords. */
    val precise: List<ChordSeg>,
    /** How loud the recording is every [PEAK_STEP] seconds, 0..1, for drawing it. */
    val peaks: FloatArray
) {
    companion object {
        const val PEAK_STEP = 0.1
    }
}

/**
 * Works out the chords of a recording on the phone: a chromagram (how much of each of the 12 notes sounds),
 * matched against chord templates, smoothed with a Viterbi search so the chord does not flicker, with the tempo
 * and beats found from the onsets and the chord changes snapped to the beats. The key comes from the chords.
 *
 * Plain Kotlin, no Android classes: it takes mono samples at [SR] Hz. The constants were tuned on test songs
 * played by a guitar synthesizer; real recordings with drums, vocals and distortion are harder, so the result is
 * a good first draft, not a transcription.
 */
object ChordEngine {
    const val SR = 11025
    internal const val N = 4096
    private const val HOP = 512
    internal const val NB = N / 2 + 1
    private const val BLOCK = 4
    internal const val FMIN = 60.0
    internal const val FMAX = 1800.0
    internal const val BASS_MIN = 40.0
    internal const val BASS_MAX = 250.0

    internal const val SCALE = 8.0
    private const val SWITCH_PEN = 1.2
    internal const val BASS_W = 0.08
    internal const val DIA_W = 0.06
    internal const val TYPE_PEN = 1.5
    private const val QUIET = 0.10
    private const val SNAP = 0.30

    internal val KK_MAJ = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    internal val KK_MIN = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    /** Chord types: the notes (semitones above the root) and how strongly each counts. */
    private val CORE_NOTES: Map<String, List<Pair<Int, Double>>> = mapOf(
        "" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8),
        "m" to listOf(0 to 1.0, 3 to 0.9, 7 to 0.8),
        "7" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8, 10 to 0.7),
        "maj7" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8, 11 to 0.7),
        "m7" to listOf(0 to 1.0, 3 to 0.9, 7 to 0.8, 10 to 0.7),
        "sus4" to listOf(0 to 1.0, 5 to 0.9, 7 to 0.8),
        "sus2" to listOf(0 to 1.0, 2 to 0.9, 7 to 0.8),
        // the extra chords of Live mode (see [LIVE_FULL]); the offline analyzer does not use them
        "add9" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8, 2 to 0.6),
        "6" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8, 9 to 0.6),
        "m6" to listOf(0 to 1.0, 3 to 0.9, 7 to 0.8, 9 to 0.6),
        "5" to listOf(0 to 1.0, 7 to 0.9),
        "dim" to listOf(0 to 1.0, 3 to 0.9, 6 to 0.8),
        "aug" to listOf(0 to 1.0, 4 to 0.9, 8 to 0.8),
        "7sus4" to listOf(0 to 1.0, 5 to 0.9, 7 to 0.8, 10 to 0.7),
        "9" to listOf(0 to 1.0, 4 to 0.9, 7 to 0.8, 10 to 0.7, 2 to 0.5)
    )
    private val CORE_PENALTY: Map<String, Double> = mapOf(
        "" to 0.0, "m" to 0.0, "7" to 0.035, "maj7" to 0.045, "m7" to 0.035, "sus4" to 0.06, "sus2" to 0.06,
        "add9" to 0.035, "6" to 0.035, "m6" to 0.035, "5" to 0.05, "dim" to 0.045, "aug" to 0.045, "7sus4" to 0.04, "9" to 0.04
    )

    /** Every chord type: the tuned ones above as they are (the offline analyzer depends on them), the others from [ChordTypes]. */
    internal val TYPE_NOTES: Map<String, List<Pair<Int, Double>>> = CORE_NOTES + ChordTypes.ALL.filter { it.id !in CORE_NOTES }
        .associate { t -> t.id to t.intervals.indices.map { t.intervals[it] to t.weights[it] } }
    internal val TYPE_PENALTY: Map<String, Double> = CORE_PENALTY + ChordTypes.ALL.filter { it.id !in CORE_PENALTY }
        .associate { t -> t.id to t.penalty * 0.4 }
    internal val BASIC = listOf("", "m")
    internal val PRECISE = listOf("", "m", "7", "maj7", "m7", "sus4", "sus2")

    /** The chords Live mode can name: Basic (four), and Precise (every type of [ChordTypes]). */
    internal val LIVE_BASIC = listOf("", "m", "7", "m7")
    internal val LIVE_FULL: List<String> = ChordTypes.ALL.map { it.id }

    // ---------------------------------------------------------------- FFT

    internal class Fft(private val n: Int) {
        private val cosT = DoubleArray(n / 2)
        private val sinT = DoubleArray(n / 2)
        private val rev = IntArray(n)

        init {
            for (i in 0 until n / 2) {
                val a = -2.0 * PI * i / n
                cosT[i] = cos(a)
                sinT[i] = sin(a)
            }
            val bits = Integer.numberOfTrailingZeros(n)
            for (i in 0 until n) rev[i] = Integer.reverse(i) ushr (32 - bits)
        }

        fun transform(re: DoubleArray, im: DoubleArray) {
            for (i in 0 until n) {
                val j = rev[i]
                if (j > i) {
                    val tr = re[i]; re[i] = re[j]; re[j] = tr
                    val ti = im[i]; im[i] = im[j]; im[j] = ti
                }
            }
            var size = 2
            while (size <= n) {
                val half = size / 2
                val step = n / size
                var i = 0
                while (i < n) {
                    var k = 0
                    for (j in i until i + half) {
                        val wr = cosT[k]
                        val wi = sinT[k]
                        val xr = re[j + half]
                        val xi = im[j + half]
                        val tr = xr * wr - xi * wi
                        val ti = xr * wi + xi * wr
                        re[j + half] = re[j] - tr
                        im[j + half] = im[j] - ti
                        re[j] += tr
                        im[j] += ti
                        k += step
                    }
                    i += size
                }
                size = size shl 1
            }
        }
    }

    internal val window = DoubleArray(N) { 0.5 - 0.5 * cos(2.0 * PI * it / (N - 1)) }

    /**
     * The magnitude spectra of frames [fa] and [fb] with one FFT: the first goes in the real part, the second in
     * the imaginary part, and the two are told apart afterwards. [fb] may be past the end (then it is silence).
     */
    private fun spectrumPair(
        pcm: FloatArray, fa: Int, fb: Int, nFrames: Int, fft: Fft,
        re: DoubleArray, im: DoubleArray, outA: FloatArray, outB: FloatArray
    ) {
        val a0 = fa * HOP
        val b0 = fb * HOP
        val hasB = fb < nFrames
        for (i in 0 until N) {
            re[i] = pcm[a0 + i] * window[i]
            im[i] = if (hasB) pcm[b0 + i] * window[i] else 0.0
        }
        fft.transform(re, im)
        val norm = 4.0 / N
        for (k in 0 until NB) {
            val nk = (N - k) and (N - 1)
            val zr = re[k]; val zi = im[k]
            val zr2 = re[nk]; val zi2 = im[nk]
            outA[k] = (0.5 * hypot(zr + zr2, zi - zi2) * norm).toFloat()
            outB[k] = (0.5 * hypot(zi + zi2, zr - zr2) * norm).toFloat()
        }
    }

    // ---------------------------------------------------------------- the analysis

    /**
     * [pcm] is mono at [SR] Hz. [progress] gets 0..1 now and then; [cancelled] is polled and makes the call
     * return null. Throws IllegalArgumentException when the recording is too short to analyse.
     */
    fun analyze(pcm: FloatArray, progress: (Float) -> Unit, cancelled: () -> Boolean): AnalysisResult? {
        require(pcm.size >= SR * 4) { "The recording is too short (under 4 seconds)." }
        val nFrames = 1 + (pcm.size - N) / HOP
        val fft = Fft(N)
        val re = DoubleArray(N)
        val im = DoubleArray(N)
        val magA = FloatArray(NB)
        val magB = FloatArray(NB)

        // 1. tuning: look at every 8th frame
        var sx = 0.0
        var sy = 0.0
        val lo = (100 * N / SR)
        val hi = (1500 * N / SR)
        var f = 0
        while (f < nFrames) {
            val f2 = f + 8
            spectrumPair(pcm, f, f2, nFrames, fft, re, im, magA, magB)
            for (pass in 0..1) {
                if (pass == 1 && f2 >= nFrames) break
                val m = if (pass == 0) magA else magB
                var mx = 0f
                for (k in lo until hi) if (m[k] > mx) mx = m[k]
                if (mx <= 0f) continue
                for (k in lo + 1 until hi - 1) {
                    val v = m[k]
                    if (v > m[k - 1] && v >= m[k + 1] && v > 0.1f * mx) {
                        val a = m[k - 1].toDouble()
                        val b = v.toDouble()
                        val c = m[k + 1].toDouble()
                        val d = 0.5 * (a - c) / (a - 2 * b + c + 1e-12)
                        val fr = (k + d) * SR / N
                        val midi = 69 + 12 * log2(fr / 440.0)
                        val dev = midi - Math.rint(midi)
                        sx += b * cos(2 * PI * dev)
                        sy += b * sin(2 * PI * dev)
                    }
                }
            }
            f += 16
            if (cancelled()) return null
        }
        val tuning = if (sx == 0.0 && sy == 0.0) 0.0 else atan2(sy, sx) / (2 * PI)
        progress(0.05f)

        // pitch class of every FFT bin
        val pcOf = IntArray(NB) { -1 }
        val wOf = FloatArray(NB)
        val bassOf = IntArray(NB) { -1 }
        for (k in 1 until NB) {
            val fr = k * SR.toDouble() / N
            val midi = 69 + 12 * log2(fr / 440.0) - tuning
            if (fr in FMIN..FMAX) {
                pcOf[k] = Math.floorMod(Math.rint(midi).toInt(), 12)
                wOf[k] = exp(-0.5 * ((midi - 57) / 14.0) * ((midi - 57) / 14.0)).toFloat()
            }
            if (fr in BASS_MIN..BASS_MAX) bassOf[k] = Math.floorMod(Math.rint(midi).toInt(), 12)
        }

        // 2. every frame: chroma, bass chroma and the onset flux
        val chroma = FloatArray(nFrames * 12)
        val bass = FloatArray(nFrames * 12)
        val flux = DoubleArray(nFrames)
        val fLo = (50 * N / SR)
        val fHi = (4000 * N / SR)
        val prevLog = DoubleArray(NB)
        var frame = 0
        while (frame < nFrames) {
            val second = frame + 1
            spectrumPair(pcm, frame, second, nFrames, fft, re, im, magA, magB)
            for (pass in 0..1) {
                val idx = frame + pass
                if (idx >= nFrames) break
                val m = if (pass == 0) magA else magB
                val base = idx * 12
                for (k in 1 until NB) {
                    val p = pcOf[k]
                    if (p >= 0) chroma[base + p] += sqrt(m[k]) * wOf[k]
                    val bp = bassOf[k]
                    if (bp >= 0 && m[k] > bass[base + bp]) bass[base + bp] = m[k]
                }
                var fl = 0.0
                for (k in fLo until fHi) {
                    val l = ln(1.0 + 100.0 * m[k])
                    if (idx > 0) {
                        val d = l - prevLog[k]
                        if (d > 0) fl += d
                    }
                    prevLog[k] = l
                }
                flux[idx] = fl
            }
            frame += 2
            if ((frame and 63) == 0) {
                if (cancelled()) return null
                progress(0.05f + 0.8f * frame / nFrames)
            }
        }
        progress(0.86f)

        // 3. tempo and beats
        val env = onsetEnvelope(flux)
        var bpm = estimateTempo(env)
        bpm = refineTempo(env, bpm)
        val beats = beatGrid(env, bpm)
        if (cancelled()) return null
        progress(0.9f)

        // 4. the chords, in both vocabularies
        val nb = nFrames / BLOCK
        val cb = Array(nb) { DoubleArray(12) }
        val bb = Array(nb) { DoubleArray(12) }
        for (b in 0 until nb) {
            for (h in 0 until BLOCK) {
                val base = (b * BLOCK + h) * 12
                for (p in 0 until 12) {
                    cb[b][p] += chroma[base + p] / BLOCK.toDouble()
                    bb[b][p] += bass[base + p] / BLOCK.toDouble()
                }
            }
        }
        val mean = DoubleArray(12)
        for (i in 0 until nFrames) for (p in 0 until 12) mean[p] += chroma[i * 12 + p].toDouble() / nFrames
        val (tonic0, minor0) = keyFromChroma(mean)

        val basic = decode(cb, bb, beats, BASIC, tonic0, minor0)
        val precise = decode(cb, bb, beats, PRECISE, tonic0, minor0)
        progress(0.97f)

        val real = basic.filter { it.isChord }
        val key = if (real.isNotEmpty()) keyFromSegments(real) else (tonic0 to (minor0))

        // 5. the loudness curve for drawing
        val step = (SR * AnalysisResult.PEAK_STEP).toInt()
        val nPeaks = pcm.size / step
        val peaks = FloatArray(nPeaks)
        var top = 1e-6f
        for (i in 0 until nPeaks) {
            var m = 0f
            for (j in i * step until (i + 1) * step) {
                val a = abs(pcm[j])
                if (a > m) m = a
            }
            peaks[i] = m
            if (m > top) top = m
        }
        for (i in 0 until nPeaks) peaks[i] = peaks[i] / top
        progress(1f)

        return AnalysisResult(
            durationSec = pcm.size.toDouble() / SR,
            bpm = bpm,
            beats = beats,
            keyTonic = key.first,
            keyMinor = key.second,
            tuningCents = (tuning * 100).roundToInt(),
            basic = basic,
            precise = precise,
            peaks = peaks
        )
    }

    // ---------------------------------------------------------------- onsets and tempo

    private fun onsetEnvelope(flux: DoubleArray): DoubleArray {
        val n = flux.size
        val out = DoubleArray(n)
        for (i in 0 until n) {
            var s = 0.0
            for (j in max(0, i - 10)..min(n - 1, i + 10)) s += flux[j]
            out[i] = max(0.0, flux[i] - s / 21.0)
        }
        return out
    }

    private fun estimateTempo(env: DoubleArray): Double {
        val n = env.size
        val hopSec = HOP.toDouble() / SR
        var mean = 0.0
        for (v in env) mean += v
        mean /= n
        val e = DoubleArray(n) { env[it] - mean }
        val maxLag = min(n - 1, 100)
        val acf = DoubleArray(maxLag + 1)
        for (lag in 0..maxLag) {
            var s = 0.0
            for (i in 0 until n - lag) s += e[i] * e[i + lag]
            acf[lag] = s
        }
        if (acf[0] < 1e-9) return 100.0
        for (lag in 0..maxLag) acf[lag] = acf[lag] / acf[0]
        fun at(lag: Double): Double {
            val i = lag.toInt()
            val fr = lag - i
            if (i + 1 > maxLag) return 0.0
            return acf[i] * (1 - fr) + acf[i + 1] * fr
        }
        var best = -1e9
        var bestB = 100.0
        var b10 = 650
        while (b10 <= 1800) {
            val b = b10 / 10.0
            val lag = 60.0 / b / hopSec
            val s = at(lag) + 0.5 * at(2 * lag) + 0.25 * at(4 * lag)
            val z = log2(b / 100.0) / 0.6
            val sc = s * exp(-0.5 * z * z)
            if (sc > best) {
                best = sc
                bestB = b
            }
            b10 += 5
        }
        return bestB
    }

    /** The mean onset strength on a beat grid of this tempo, with the best phase (in frames). */
    private fun gridScore(env: DoubleArray, bpm: Double, phaseStep: Double): Pair<Double, Double> {
        val hopSec = HOP.toDouble() / SR
        val period = 60.0 / bpm / hopSec
        val n = env.size
        var best = -1.0
        var bestPhase = 0.0
        var p = 0.0
        while (p < period) {
            var sum = 0.0
            var cnt = 0
            var x = p
            while (x < n - 1) {
                sum += env[Math.rint(x).toInt()]
                cnt++
                x += period
            }
            val v = if (cnt > 0) sum / cnt else 0.0
            if (v > best) {
                best = v
                bestPhase = p
            }
            p += phaseStep
        }
        return best to bestPhase
    }

    private fun refineTempo(env: DoubleArray, bpm: Double): Double {
        var best = -1.0
        var bb = bpm
        var d = -3.0
        while (d <= 3.0001) {
            val b = bpm + d
            val v = gridScore(env, b, 0.5).first
            if (v > best + 1e-9) {
                best = v
                bb = b
            }
            d += 0.25
        }
        return bb
    }

    private fun beatGrid(env: DoubleArray, bpm: Double): DoubleArray {
        val hopSec = HOP.toDouble() / SR
        val period = 60.0 / bpm / hopSec
        val phase = gridScore(env, bpm, 0.25).second
        val out = ArrayList<Double>()
        var x = phase
        // an onset shows up in the flux when it reaches the middle of the analysis window
        while (x < env.size - 1) {
            out.add(x * hopSec + N / 2.0 / SR)
            x += period
        }
        return out.toDoubleArray()
    }

    // ---------------------------------------------------------------- key

    internal fun pearson(a: DoubleArray, b: DoubleArray): Double {
        var ma = 0.0
        var mb = 0.0
        for (i in a.indices) {
            ma += a[i]
            mb += b[i]
        }
        ma /= a.size
        mb /= b.size
        var cov = 0.0
        var va = 0.0
        var vb = 0.0
        for (i in a.indices) {
            cov += (a[i] - ma) * (b[i] - mb)
            va += (a[i] - ma) * (a[i] - ma)
            vb += (b[i] - mb) * (b[i] - mb)
        }
        if (va <= 1e-12 || vb <= 1e-12) return -1.0
        return cov / sqrt(va * vb)
    }

    internal fun rolled(profile: DoubleArray, t: Int) = DoubleArray(12) { profile[Math.floorMod(it - t, 12)] }

    private fun keyFromChroma(mean: DoubleArray): Pair<Int, Boolean> {
        var best = -1e9
        var bt = 0
        var bm = false
        for (minor in listOf(false, true)) {
            val prof = if (minor) KK_MIN else KK_MAJ
            for (t in 0 until 12) {
                val r = pearson(mean, rolled(prof, t))
                if (r > best) {
                    best = r
                    bt = t
                    bm = minor
                }
            }
        }
        return bt to bm
    }

    internal fun isMinorType(t: String) = t.startsWith("m") && !t.startsWith("maj")

    /** The key from the chords found: their notes weighted by how long they sound, against the key profiles. */
    private fun keyFromSegments(segs: List<ChordSeg>): Pair<Int, Boolean> {
        val prof = DoubleArray(12)
        var total = 0.0
        for (s in segs) {
            val d = s.end - s.start
            total += d
            for ((iv, w) in TYPE_NOTES.getValue(s.type)) prof[(s.root + iv) % 12] += d * w
        }
        var best = -1e9
        var bt = 0
        var bm = false
        val first = segs.first()
        val last = segs.last()
        for (minor in listOf(false, true)) {
            val kk = if (minor) KK_MIN else KK_MAJ
            for (t in 0 until 12) {
                var sc = pearson(prof, rolled(kk, t))
                var tonicTime = 0.0
                for (s in segs) if (s.root == t && isMinorType(s.type) == minor) tonicTime += s.end - s.start
                sc += 0.25 * tonicTime / total
                if (first.root == t && isMinorType(first.type) == minor) sc += 0.03
                if (last.root == t && isMinorType(last.type) == minor) sc += 0.06
                if (sc > best) {
                    best = sc
                    bt = t
                    bm = minor
                }
            }
        }
        return bt to bm
    }

    // ---------------------------------------------------------------- chords

    internal fun diatonic(tonic: Int, minor: Boolean): Set<Int> {
        // encoded as root * 2 + (1 when the chord is minor)
        val pairs = if (!minor) listOf(0 to 0, 2 to 1, 4 to 1, 5 to 0, 7 to 0, 9 to 1, 10 to 0)
        else listOf(0 to 1, 3 to 0, 5 to 1, 7 to 1, 7 to 0, 8 to 0, 10 to 0)
        return pairs.map { ((tonic + it.first) % 12) * 2 + it.second }.toSet()
    }

    private fun decode(
        cb: Array<DoubleArray>, bb: Array<DoubleArray>, beats: DoubleArray,
        types: List<String>, tonic: Int, minorKey: Boolean
    ): List<ChordSeg> {
        val nb = cb.size
        if (nb == 0) return emptyList()
        val nTypes = types.size
        val nChords = 12 * nTypes
        val nStates = nChords + 1                    // the last state is "no chord"
        val templates = Array(nChords) { DoubleArray(12) }
        for (r in 0 until 12) {
            for ((ti, t) in types.withIndex()) {
                val v = templates[r * nTypes + ti]
                for ((iv, w) in TYPE_NOTES.getValue(t)) v[(r + iv) % 12] = w
                var norm = 0.0
                for (x in v) norm += x * x
                norm = sqrt(norm)
                for (i in 0 until 12) v[i] = v[i] / norm
            }
        }
        val dia = diatonic(tonic, minorKey)

        // how loud each block is, to find the quiet ones
        val energy = DoubleArray(nb) { b -> cb[b].sum() }
        val sorted = energy.sortedArray()
        val pos = 0.9 * (nb - 1)
        val i0 = pos.toInt()
        val ref = (if (i0 + 1 < nb) sorted[i0] + (sorted[i0 + 1] - sorted[i0]) * (pos - i0) else sorted[i0]) + 1e-9

        val emission = Array(nb) { DoubleArray(nStates) }
        for (b in 0 until nb) {
            var norm = 0.0
            for (x in cb[b]) norm += x * x
            norm = sqrt(norm) + 1e-9
            var bmax = 0.0
            for (x in bb[b]) if (x > bmax) bmax = x
            bmax += 1e-9
            for (r in 0 until 12) {
                for ((ti, t) in types.withIndex()) {
                    val j = r * nTypes + ti
                    var dot = 0.0
                    for (p in 0 until 12) dot += cb[b][p] / norm * templates[j][p]
                    var e = SCALE * dot
                    e += BASS_W * SCALE * (bb[b][r] / bmax)
                    e -= TYPE_PEN * TYPE_PENALTY.getValue(t) * SCALE
                    val minorBase = t == "m" || t == "m7"
                    if (dia.contains(r * 2 + (if (minorBase) 1 else 0))) e += DIA_W * SCALE
                    emission[b][j] = e
                }
            }
            emission[b][nChords] = if (energy[b] / ref < QUIET) 0.9 * SCALE else -SCALE
        }

        // Viterbi with one cost for any change of chord
        val switchPen = SWITCH_PEN * SCALE / 6.0
        var delta = emission[0].copyOf()
        val back = Array(nb) { IntArray(nStates) }
        for (t in 1 until nb) {
            var bi = 0
            for (s in 1 until nStates) if (delta[s] > delta[bi]) bi = s
            val bv = delta[bi] - switchPen
            val next = DoubleArray(nStates)
            for (s in 0 until nStates) {
                if (bv > delta[s]) {
                    back[t][s] = bi
                    next[s] = bv + emission[t][s]
                } else {
                    back[t][s] = s
                    next[s] = delta[s] + emission[t][s]
                }
            }
            delta = next
        }
        val path = IntArray(nb)
        var last = 0
        for (s in 1 until nStates) if (delta[s] > delta[last]) last = s
        path[nb - 1] = last
        for (t in nb - 1 downTo 1) path[t - 1] = back[t][path[t]]

        // times: a block's frames are centred later than their first sample
        val blk = BLOCK.toDouble() * HOP / SR
        val off = (N / 2.0 - BLOCK * HOP / 2.0) / SR
        val starts = ArrayList<Int>()
        starts.add(0)
        for (i in 1 until nb) if (path[i] != path[i - 1]) starts.add(i)
        val snapped = ArrayList<Double>()
        snapped.add(0.0)
        for (k in 1 until starts.size) {
            val t = starts[k] * blk + off
            var bestBeat = -1
            var bestD = Double.MAX_VALUE
            for (j in beats.indices) {
                val d = abs(beats[j] - t)
                if (d < bestD) {
                    bestD = d
                    bestBeat = j
                }
            }
            val t2 = if (bestBeat >= 0 && bestD <= SNAP) beats[bestBeat] else t + 0.08
            snapped.add(max(t2, snapped.last() + 1e-3))
        }
        val total = nb * blk + off
        val out = ArrayList<ChordSeg>()
        for (k in starts.indices) {
            val s = path[starts[k]]
            val end = if (k + 1 < starts.size) snapped[k + 1] else total
            if (end > snapped[k]) {
                if (s == nChords) out.add(ChordSeg(snapped[k], end, -1, ""))
                else out.add(ChordSeg(snapped[k], end, s / nTypes, types[s % nTypes]))
            }
        }
        return out
    }
}

