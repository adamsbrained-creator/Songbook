package com.songbook.app.analysis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** One kept analysis, as the Recent list shows it. [audio] is "copy" (a copy kept with the analysis) or "rec:<file>" (a demo of a song). */
class AnaMeta(
    val id: String,
    val title: String,
    val key: String,
    val bpm: Int,
    val seconds: Int,
    val created: Long,
    /** The roots of the first chords, for the colour strip in the list. */
    val strip: List<Int>,
    val audio: String
)

/** Analyses the user chose to keep: a small index, one JSON file for each result and, for files picked from outside the app, a copy of the audio. */
object AnalysisStore {
    private fun dir(context: Context): File = File(context.filesDir, "analyses").also { it.mkdirs() }
    private fun index(context: Context) = File(dir(context), "index.json")

    fun list(context: Context): List<AnaMeta> = runCatching {
        val arr = JSONArray(index(context).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getJSONArray("strip")
            AnaMeta(
                o.getString("id"), o.getString("title"), o.getString("key"), o.getInt("bpm"), o.getInt("seconds"),
                o.getLong("created"), (0 until s.length()).map { s.getInt(it) }, o.getString("audio")
            )
        }.sortedByDescending { it.created }
    }.getOrDefault(emptyList())

    private fun writeIndex(context: Context, items: List<AnaMeta>) {
        val arr = JSONArray()
        for (m in items) {
            arr.put(
                JSONObject().put("id", m.id).put("title", m.title).put("key", m.key).put("bpm", m.bpm).put("seconds", m.seconds)
                    .put("created", m.created).put("strip", JSONArray(m.strip)).put("audio", m.audio)
            )
        }
        index(context).writeText(arr.toString())
    }

    private fun segs(list: List<ChordSeg>): JSONArray {
        val a = JSONArray()
        for (s in list) a.put(JSONArray().put(s.start).put(s.end).put(s.root).put(s.type))
        return a
    }

    private fun readSegs(a: JSONArray): List<ChordSeg> =
        (0 until a.length()).map { val s = a.getJSONArray(it); ChordSeg(s.getDouble(0), s.getDouble(1), s.getInt(2), s.getString(3)) }

    /**
     * Keeps an analysis. [audioFile] is copied unless it is a demo ([demoName] is its name in the audio folder).
     * Returns the entry for the list.
     */
    fun save(context: Context, title: String, audioFile: File, demoName: String?, keyName: String, r: AnalysisResult): AnaMeta {
        val id = UUID.randomUUID().toString()
        val d = dir(context)
        val audio = if (demoName != null) "rec:$demoName" else {
            audioFile.copyTo(File(d, "$id.audio"), overwrite = true)
            "copy"
        }
        val peaks = JSONArray()
        for (p in r.peaks) peaks.put((p * 100).toInt())
        val json = JSONObject()
            .put("duration", r.durationSec).put("bpm", r.bpm).put("beats", JSONArray(r.beats.toList()))
            .put("tonic", r.keyTonic).put("minor", r.keyMinor).put("tuning", r.tuningCents)
            .put("basic", segs(r.basic)).put("precise", segs(r.precise)).put("peaks", peaks)
        File(d, "$id.json").writeText(json.toString())
        val strip = r.basic.filter { it.isChord }.take(8).map { it.root }
        val meta = AnaMeta(id, title, keyName, r.bpm.toInt(), r.durationSec.toInt(), System.currentTimeMillis(), strip, audio)
        writeIndex(context, listOf(meta) + list(context))
        return meta
    }

    /** The audio file and the result of a kept analysis, or null when something is missing. */
    fun load(context: Context, meta: AnaMeta, demoFile: (String) -> File): Pair<File, AnalysisResult>? = runCatching {
        val o = JSONObject(File(dir(context), "${meta.id}.json").readText())
        val b = o.getJSONArray("beats")
        val p = o.getJSONArray("peaks")
        val audio = if (meta.audio.startsWith("rec:")) demoFile(meta.audio.removePrefix("rec:")) else File(dir(context), "${meta.id}.audio")
        if (!audio.exists()) return null
        audio to AnalysisResult(
            durationSec = o.getDouble("duration"), bpm = o.getDouble("bpm"),
            beats = DoubleArray(b.length()) { b.getDouble(it) },
            keyTonic = o.getInt("tonic"), keyMinor = o.getBoolean("minor"), tuningCents = o.getInt("tuning"),
            basic = readSegs(o.getJSONArray("basic")), precise = readSegs(o.getJSONArray("precise")),
            peaks = FloatArray(p.length()) { p.getInt(it) / 100f }
        )
    }.getOrNull()

    fun delete(context: Context, id: String) {
        runCatching {
            File(dir(context), "$id.json").delete()
            File(dir(context), "$id.audio").delete()
            writeIndex(context, list(context).filter { it.id != id })
        }
    }
}
