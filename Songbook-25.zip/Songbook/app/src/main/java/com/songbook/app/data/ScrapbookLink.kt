package com.songbook.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

// WORKING TOGETHER WITH SCRAPBOOK
//
// Scrapbook (package app.scrapbook) is the notes app of the same family, and a good place to write and polish lyrics. The two apps keep their own data and
// talk through links and explicit intents, so each one works alone and the other is simply absent when it is not installed. The rules, the same in both apps
// (the Scrapbook copy is Songbook.kt there):
//
//   songbook://song/<id>                              opens a song (ScrapbookReceiverActivity)
//   action com.songbook.app.action.RECEIVE            Scrapbook -> Songbook: mode ("idea", "song" or "update"), title, body (song text), tasks + done,
//                                                     scrap (the scrap's uid), song (the song's id, for "update"). Handled without opening Songbook.
//   action app.scrapbook.action.SONG_LINKED           Songbook -> Scrapbook after it received: uid, song, title, what (the mode)
//   action app.scrapbook.action.EDIT_SONG             Songbook -> Scrapbook, "Edit in Scrapbook": title, body (song text), tasks + done, song, uid (a hint)
//
// The scrap holds the tie (a "Songbook: [name](songbook://song/<id>)" line at its end), so Songbook only remembers which songs are tied (for the chip) and,
// after an update from Scrapbook, what the song said before (for Keep / Undo). That is kept in the phone's small settings storage: no database change.

const val SCRAPBOOK_PACKAGE = "app.scrapbook"
const val SCRAPBOOK_ACTIVITY = "app.scrapbook.MainActivity"
const val ACTION_SONGBOOK_RECEIVE = "com.songbook.app.action.RECEIVE"
const val ACTION_SCRAPBOOK_EDIT_SONG = "app.scrapbook.action.EDIT_SONG"
const val ACTION_SCRAPBOOK_SONG_LINKED = "app.scrapbook.action.SONG_LINKED"

object ScrapbookMode { const val IDEA = "idea"; const val SONG = "song"; const val UPDATE = "update" }

/** The text of a song as Scrapbook sees it, and its tasks as (text, ticked). */
class SongText(val text: String, val tasks: List<Pair<String, Boolean>>)

/** True while the song's words live on the writing desk as lines (an idea with no lyrics yet) instead of in [SongEntity.body]. */
fun SongEntity.isDeskSong(): Boolean = stage == Stage.IDEA && body.isBlank()

/** The desk lines as text: a "# Tag" line whenever the tag changes, then the lines. (The same as the desk's "Turn lines into lyrics".) */
fun ideaLinesToText(lines: List<IdeaLine>): String {
    val sb = StringBuilder(); var current = ""
    for (l in lines) {
        val text = l.text.trim()
        if (text.isEmpty()) continue
        if (l.tag.isNotBlank() && l.tag != current) {
            if (sb.isNotEmpty()) sb.append("\n")
            sb.append("# ").append(l.tag).append("\n"); current = l.tag
        }
        sb.append(text).append("\n")
    }
    return sb.toString().trimEnd()
}

/** Text as desk lines: every non-blank line is a line, and a "# Heading" line is the tag of the lines after it. */
fun textToIdeaLines(text: String): List<IdeaLine> {
    var tag = ""; val out = ArrayList<IdeaLine>()
    for (raw in text.lines()) {
        val t = raw.trim()
        if (t.isEmpty()) continue
        if (t.startsWith("#")) { tag = t.trimStart('#').trim(); continue }
        out += IdeaLine(t, tag)
    }
    return out
}

/** What goes to Scrapbook for "Edit in Scrapbook": the song's words (the desk lines for an idea) and its desk tasks. */
fun SongEntity.textForScrapbook(): SongText {
    val idea = ideaData
    return SongText((if (isDeskSong()) ideaLinesToText(idea.lines) else body).trim(), idea.tasks.map { it.text to it.done })
}

/** The song with the text Scrapbook sent back: the body (the desk lines when the song is an idea with no lyrics) and the tasks are replaced; the rest is kept. */
fun SongEntity.withScrapText(text: String, tasks: List<Pair<String, Boolean>>): SongEntity {
    val idea = ideaData
    val desk = isDeskSong()
    val next = idea.copy(lines = if (desk) textToIdeaLines(text) else idea.lines, tasks = tasks.map { IdeaTask(it.first, it.second) })
    return copy(body = if (desk) body else text.trim(), idea = next.toJson())
}

/** A short sentence about what changed between two texts, by whole lines: "3 lines added · 1 removed". */
fun describeChange(old: String, new: String): String {
    val gone = old.lines().map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    var added = 0
    for (l in new.lines().map { it.trim() }.filter { it.isNotEmpty() }) if (!gone.remove(l)) added++
    val parts = listOfNotNull(
        if (added > 0) "$added line${if (added == 1) "" else "s"} added" else null,
        if (gone.isNotEmpty()) "${gone.size} removed" else null
    )
    return if (parts.isEmpty()) "Tasks or order changed" else parts.joinToString(" · ")
}

/** What Songbook remembers about songs tied to Scrapbook scraps. */
object ScrapbookLinks {
    /** Counts up on every change, so screens that show a chip or the Keep / Undo card redraw. */
    val changes = MutableStateFlow(0)

    /** A song changed by Scrapbook: what it said before, what it says now (Undo is only offered while the song still says that), and what changed. */
    class Pending(val prevBody: String, val prevIdea: String, val nowBody: String, val nowIdea: String, val note: String, val at: Long)

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("scrapbook_link", Context.MODE_PRIVATE)
    private fun bump() { changes.value = changes.value + 1 }

    fun isLinked(ctx: Context, songId: Long): Boolean = prefs(ctx).getBoolean("linked_$songId", false)
    fun uidOf(ctx: Context, songId: Long): String = prefs(ctx).getString("uid_$songId", "").orEmpty()

    fun markLinked(ctx: Context, songId: Long, uid: String = "") {
        prefs(ctx).edit().putBoolean("linked_$songId", true).apply { if (uid.isNotBlank()) putString("uid_$songId", uid) }.apply()
        bump()
    }

    fun pending(ctx: Context, songId: Long): Pending? {
        val raw = prefs(ctx).getString("pending_$songId", null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            Pending(o.getString("pb"), o.getString("pi"), o.getString("nb"), o.getString("ni"), o.getString("n"), o.getLong("t"))
        }.getOrNull()
    }

    fun setPending(ctx: Context, songId: Long, p: Pending) {
        val o = JSONObject().put("pb", p.prevBody).put("pi", p.prevIdea).put("nb", p.nowBody).put("ni", p.nowIdea).put("n", p.note).put("t", p.at)
        prefs(ctx).edit().putString("pending_$songId", o.toString()).apply()
        bump()
    }

    fun clearPending(ctx: Context, songId: Long) {
        if (prefs(ctx).contains("pending_$songId")) { prefs(ctx).edit().remove("pending_$songId").apply(); bump() }
    }
}
