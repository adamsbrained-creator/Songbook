package com.songbook.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.songbook.app.data.*
import com.songbook.app.ui.components.SongLinkRequests
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * The door Scrapbook knocks on (rules in data/ScrapbookLink.kt). It has no screen: a scrap sent from Scrapbook is turned into an idea or a song (or
 * replaces a song's text) and Scrapbook is told which song it became, so the person never leaves Scrapbook. A songbook://song/<id> link opens that song.
 */
class ScrapbookReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i == null) { finish(); return }
        when (i.action) {
            ACTION_SONGBOOK_RECEIVE -> receive(i)
            Intent.ACTION_VIEW -> openSong(i.data)
            else -> finish()
        }
    }

    private fun openSong(uri: Uri?) {
        val id = uri?.pathSegments?.firstOrNull()?.toLongOrNull()
        if (id != null) {
            SongLinkRequests.open.value = id
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        finish()
    }

    private fun receive(i: Intent) {
        val mode = i.getStringExtra("mode").orEmpty()
        val title = i.getStringExtra("title").orEmpty().trim().ifBlank { "Untitled" }
        val text = i.getStringExtra("body").orEmpty()
        val names = i.getStringArrayListExtra("tasks").orEmpty()
        val ticks = i.getBooleanArrayExtra("done") ?: BooleanArray(0)
        val tasks = names.mapIndexed { n, t -> t to ticks.getOrElse(n) { false } }
        val scrapUid = i.getStringExtra("scrap").orEmpty()
        val songId = i.getLongExtra("song", -1L)
        val repo = (application as SongbookApp).repo
        CoroutineScope(Dispatchers.IO).launch {
            val id = runCatching { take(repo, mode, title, text, tasks, songId, scrapUid) }.getOrNull()
            runOnUiThread {
                if (id == null) Toast.makeText(this, "Songbook could not take that", Toast.LENGTH_LONG).show()
                else replyToScrapbook(scrapUid, id, title, mode)
                finish()
            }
        }
    }

    /** Makes the idea or song, or updates the song. Returns the song's id. */
    private suspend fun take(repo: SongbookRepository, mode: String, title: String, text: String, tasks: List<Pair<String, Boolean>>, songId: Long, scrapUid: String): Long {
        val ideaTasks = tasks.map { IdeaTask(it.first, it.second) }
        if (mode == ScrapbookMode.UPDATE) {
            val cur = if (songId >= 0) repo.song(songId) else null
            if (cur != null) {
                val next = cur.withScrapText(text, tasks)
                if (next.body != cur.body || next.idea != cur.idea) {
                    repo.saveSong(next)
                    // after the save, so the song page never sees "changed since" before the card is there
                    val note = describeChange(cur.textForScrapbook().text, next.textForScrapbook().text)
                    ScrapbookLinks.setPending(this, cur.id, ScrapbookLinks.Pending(cur.body, cur.idea, next.body, next.idea, note, System.currentTimeMillis()))
                }
                ScrapbookLinks.markLinked(this, cur.id, scrapUid)
                return cur.id
            }
        }
        // a new idea (its lines go on the writing desk), or a new song starting at Lyrics; a song that is gone also comes back as a new song
        val song = if (mode == ScrapbookMode.IDEA) SongEntity(title = title, stage = Stage.IDEA, idea = IdeaData(lines = textToIdeaLines(text), tasks = ideaTasks).toJson())
                   else SongEntity(title = title, body = text.trim(), stage = 1, idea = IdeaData(tasks = ideaTasks).toJson())
        val id = repo.createSong(song)
        ScrapbookLinks.markLinked(this, id, scrapUid)
        return id
    }

    private fun replyToScrapbook(uid: String, songId: Long, title: String, mode: String) {
        if (uid.isBlank()) return
        val back = Intent(ACTION_SCRAPBOOK_SONG_LINKED).setClassName(SCRAPBOOK_PACKAGE, SCRAPBOOK_ACTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("uid", uid).putExtra("song", songId).putExtra("title", title).putExtra("what", mode)
        try { startActivity(back) } catch (e: ActivityNotFoundException) { /* Scrapbook is gone: the song is made all the same */ }
    }
}
