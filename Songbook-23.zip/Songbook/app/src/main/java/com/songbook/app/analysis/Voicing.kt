package com.songbook.app.analysis

import kotlin.math.max
import kotlin.math.min

/** The strings of an instrument as MIDI notes, from the lowest-sounding string to the highest-sounding one (E2 = 40, C4 = 60, A4 = 69). */
object Tunings {
    val GUITAR = intArrayOf(40, 45, 50, 55, 59, 64)
    val UKULELE = intArrayOf(67, 60, 64, 69)          // G C E A, the G is the high one
}

/** A way to play the notes that were heard. [frets] per string (-1 = not played) and the note each string sounds. */
class VoicingResult(val frets: IntArray, val midi: IntArray) {
    /** The notes that sound, lowest first. */
    val notes: IntArray = midi.filter { it >= 0 }.sorted().toIntArray()
}

/**
 * Works out how a set of notes is played on strings, and the other way round: a standard shape for any chord.
 * Plain Kotlin, no Android.
 *
 * [solve] is given how strongly each note from C2 (MIDI 36) up sounds, and looks for the playable way of holding strings
 * and frets (all fingers within four frets, no more notes than strings) that explains the sound best: a string that
 * plays a note that is heard adds to the score, a string that plays a note that is not heard takes away from it, and a
 * loud note that no string plays takes away too. Notes that cannot be played at all (below the lowest string, a long
 * way up the neck) can never win, which throws out most of the ghost notes the sound analysis makes.
 * Which string plays a note is a guess when several can (the same E sounds on three strings): the most natural,
 * lowest, most compact way wins.
 */
object Voicing {
    const val NOTE0 = 36

    private const val THETA = 0.3         // a note has to sound this strongly (0..1) before a string playing it adds to the score
    private const val LAM = 0.4           // how much a loud note that no string plays counts against a voicing
    private const val PEAK_MIN = 0.25     // what counts as a loud note
    private const val OPT_MIN = 0.12      // a string only tries frets whose note is at least this strong
    private const val NMS_RATIO = 2.0     // a note next to one that is this much louder is mostly leakage ...
    private const val NMS_KEEP = 0.25     // ... and only this much of it counts
    private const val SPAN = 4            // the fingers stay within this many frets
    private const val MAX_OPTIONS = 6

    /**
     * [act] is how strongly each note sounds, index 0 = MIDI 36, the loudest = 1. [tuning] gives the open strings (with a
     * capo: the notes at the capo). Null when no playable voicing explains the sound.
     */
    fun solve(act: DoubleArray, tuning: IntArray, maxFret: Int = 15): VoicingResult? {
        val n = act.size
        val ev = DoubleArray(n)
        for (j in 0 until n) {
            val lo = if (j > 0) act[j - 1] else 0.0
            val hi = if (j + 1 < n) act[j + 1] else 0.0
            ev[j] = if (max(lo, hi) > NMS_RATIO * act[j]) act[j] * NMS_KEEP else act[j]
        }
        val peaks = ArrayList<Int>()
        for (j in 0 until n) {
            if (ev[j] < PEAK_MIN) continue
            val nb = max(if (j > 0) ev[j - 1] else 0.0, if (j + 1 < n) ev[j + 1] else 0.0)
            if (ev[j] >= 0.5 * nb) peaks.add(NOTE0 + j)
        }
        return Search(ev, tuning, maxFret, peaks).run()
    }

    private class Search(val ev: DoubleArray, val tuning: IntArray, maxFret: Int, val peaks: List<Int>) {
        val s = tuning.size
        val opts: Array<IntArray>
        val cur = IntArray(s) { -1 }
        var best: IntArray? = null
        var bestScore = -1e9

        init {
            opts = Array(s) { i ->
                val cands = ArrayList<Int>()
                for (f in 0..maxFret) if (at(tuning[i] + f) >= OPT_MIN) cands.add(f)
                // the strongest few only: the search is small and stays small on a noisy reading
                cands.sortByDescending { at(tuning[i] + it) }
                val keep = cands.take(MAX_OPTIONS)
                IntArray(keep.size + 1) { if (it == 0) -1 else keep[it - 1] }
            }
        }

        fun at(midi: Int): Double {
            val j = midi - NOTE0
            return if (j >= 0 && j < ev.size) ev[j] else 0.0
        }

        fun run(): VoicingResult? {
            rec(0, 99, 0)
            val b = best ?: return null
            return VoicingResult(b, IntArray(s) { if (b[it] < 0) -1 else tuning[it] + b[it] })
        }

        fun rec(i: Int, lo: Int, hi: Int) {
            if (i == s) {
                leaf(lo, hi)
                return
            }
            for (f in opts[i]) {
                var nlo = lo
                var nhi = hi
                if (f > 0) {
                    nlo = min(lo, f)
                    nhi = max(hi, f)
                    if (nhi - nlo > SPAN) continue
                }
                cur[i] = f
                rec(i + 1, nlo, nhi)
            }
            cur[i] = -1
        }

        fun leaf(lo: Int, hi: Int) {
            var sounding = 0
            var first = -1
            var last = -1
            var opens = 0
            for (i in 0 until s) {
                if (cur[i] >= 0) {
                    sounding++
                    if (first < 0) first = i
                    last = i
                    if (cur[i] == 0) opens++
                }
            }
            if (sounding < 2) return
            val fretted = hi > 0
            var sc = 0.0
            for (i in 0 until s) {
                if (cur[i] < 0) continue
                val p = tuning[i] + cur[i]
                var dup = false
                for (k in 0 until i) if (cur[k] >= 0 && tuning[k] + cur[k] == p) dup = true
                if (dup) {
                    sc -= 0.35
                } else {
                    sc += (at(p) - THETA) / (1 - THETA)
                }
            }
            for (m in peaks) {
                var played = false
                for (i in 0 until s) if (cur[i] >= 0 && tuning[i] + cur[i] == m) played = true
                if (!played) sc -= LAM * (at(m) - 0.15)
            }
            var inner = 0
            for (i in first..last) if (cur[i] < 0) inner++
            sc -= 0.12 * inner
            sc -= 0.012 * (if (fretted) lo else 0)
            sc -= 0.01 * (if (fretted) hi - lo else 0)
            sc += 0.015 * opens
            if (sc > bestScore) {
                bestScore = sc
                best = cur.copyOf()
            }
        }
    }

    // ---------------------------------------------------------------- drawing

    /** A shape for drawing: the frets, and a barre line when the lowest fret is pressed on two or more strings up to the highest string. */
    fun toShape(frets: IntArray): GuitarShape {
        var m = 99
        for (f in frets) if (f > 0 && f < m) m = f
        if (m == 99) return GuitarShape(frets)
        var first = -1
        var count = 0
        for (i in frets.indices) {
            if (frets[i] == m) {
                if (first < 0) first = i
                count++
            }
        }
        var barre = count >= 2 && frets[frets.size - 1] == m
        if (barre) for (i in first until frets.size) if (frets[i] == 0) barre = false     // an open string cannot ring behind a barre
        return GuitarShape(frets, if (barre) m else 0, if (barre) first else 0)
    }

    /** The frets as tab text: "x32010", or with spaces when a fret has two digits ("x 10 12 12 11 10"). */
    fun tabText(frets: IntArray): String {
        val parts = frets.map { if (it < 0) "x" else it.toString() }
        return if (parts.all { it.length == 1 }) parts.joinToString("") else parts.joinToString(" ")
    }

    // ---------------------------------------------------------------- a standard shape for any chord

    private val cache = HashMap<String, GuitarShape?>()

    /**
     * A usual way to play chord [id] on [root]: the root is the lowest note, every note the chord needs is there, the
     * fingers stay within four frets and near the nut. For the chords that have no shape in the tables.
     */
    fun standard(root: Int, id: String, tuning: IntArray = Tunings.GUITAR): GuitarShape? {
        val t = ChordTypes.get(id) ?: return null
        val r = Math.floorMod(root, 12)
        val key = "$r:$id:${tuning.joinToString(",")}"
        synchronized(cache) {
            if (cache.containsKey(key)) return cache[key]
        }
        val shape = searchStandard(r, t, tuning, if (tuning.size <= 4) 9 else 12)
        synchronized(cache) { cache[key] = shape }
        return shape
    }

    private fun searchStandard(root: Int, t: ChordType, tuning: IntArray, maxFret: Int): GuitarShape? {
        val s = tuning.size
        var toneMask = 0
        var reqMask = 0
        for (i in t.intervals.indices) {
            val bit = 1 shl ((root + t.intervals[i]) % 12)
            toneMask = toneMask or bit
            if (t.required[i]) reqMask = reqMask or bit
        }
        val fifthBit = 1 shl ((root + 7) % 12)
        val wantsFifth = t.intervals.contains(7)
        val minSounding = if (t.intervals.size <= 2) 2 else 3
        val opts = Array(s) { i ->
            val l = ArrayList<Int>()
            l.add(-1)
            for (f in 0..maxFret) if ((toneMask shr ((tuning[i] + f) % 12)) and 1 != 0) l.add(f)
            l.toIntArray()
        }
        val cur = IntArray(s) { -1 }
        var best: IntArray? = null
        var bestCost = Double.MAX_VALUE

        fun rec(i: Int, lo: Int, hi: Int) {
            if (i == s) {
                var cnt = 0
                var first = -1
                var last = -1
                var lowest = Int.MAX_VALUE
                var have = 0
                for (k in 0 until s) {
                    if (cur[k] < 0) continue
                    cnt++
                    if (first < 0) first = k
                    last = k
                    val p = tuning[k] + cur[k]
                    if (p < lowest) lowest = p
                    have = have or (1 shl (p % 12))
                }
                if (cnt < minSounding) return
                if (lowest % 12 != root) return
                if ((have and reqMask) != reqMask) return
                var inner = 0
                for (k in first..last) if (cur[k] < 0) inner++
                if (inner > 1) return
                val fretted = hi > 0
                val span = if (fretted) hi - lo else 0
                var cost = (if (fretted) lo else 0) * 0.5 + span * 0.8 + inner * 1.2 + (s - cnt) * 0.25
                if (wantsFifth && (have and fifthBit) == 0) cost += 0.4
                cost += 0.05 * (cnt - Integer.bitCount(have))
                if (cost < bestCost) {
                    bestCost = cost
                    best = cur.copyOf()
                }
                return
            }
            for (f in opts[i]) {
                var nlo = lo
                var nhi = hi
                if (f > 0) {
                    nlo = min(lo, f)
                    nhi = max(hi, f)
                    if (nhi - nlo > 3) continue
                }
                cur[i] = f
                rec(i + 1, nlo, nhi)
            }
            cur[i] = -1
        }
        rec(0, 99, 0)
        return best?.let { toShape(it) }
    }
}
