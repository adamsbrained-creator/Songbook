# Songbook 5.5 - Follow a song in Live mode, tuner octave guard (not yet compiled)

## 5.5 changes
- Live mode > "Follow a song" (link under the level bar, or Live settings > Song): pick a song of the library that has chords. Its chords get a bonus when Live picks a chord (`LiveChords.song`, `SONG_W` 0.12 = about the margin a new chord needs) and Basic also learns the types the song uses (a maj7 in the song is heard even on Basic). A strip "In the song" shows the chord that sounds now (filled), the next one (ring) and the ones after; "Next: Em" below; "That chord is not in this song" when you play something else. Where you are is found by looking at the next 6 chords first (songs repeat, so round the end too), then 3 back, then everywhere (`analysis/SongFollow.kt`). Chords are read as written (`Keys.chordsOf`), extensions are mapped to the nearest type Live knows (m9 -> m7, 7#9 -> 7, m7b5 -> dim); a slash chord counts as its root chord. Shown with the capo like the rest. Clear restarts from the first chord
- Tuner: a reading an octave away from the one before (the usual YIN mistake) is ignored unless it lasts for 4 readings
- Version 5.5

# Songbook 5.4 - Live chords and the tuner, better (not yet compiled)

## 5.4 changes
- Live chords hear more: the notes are now separated before the chords are matched (non-negative least squares over 53 notes, each a comb of 8 partials, `LiveChords.noteChroma`). The partials of low notes no longer make power chords, add9, 6 and the like look like plain major chords. Checked in a Python model of the engine with simulated guitar chords (about 94% of 49 shapes right over 15 chord types, against about 82% for the old chroma; the noise-removal step is not in that model)
- Chords: Basic = major, minor, 7, m7. Precise adds maj7, sus4, sus2, add9, 6, m6, 5 (power), dim, aug, 7sus4 and 9 (`ChordEngine.LIVE_BASIC` / `LIVE_FULL`, the offline analyzer still uses `BASIC` / `PRECISE`). Precise is now the default for new installs. Guitar shapes (E, A and D barre shapes, a few open ones), piano keys and ukulele shapes know the new types
- Live strum detection: when the sound jumps up (newest 46 ms more than 2.2 times the one before) the next readings use only the sound since the strum and the new chord may win at once, so a chord change shows in about 0.15 s instead of about 0.5 s
- Live level bar has a tick for the gate (the sound has to reach it to count as playing); Live settings > Room noise > Listen learns the noise of the room for 2 seconds
- Tuner: when a string is held in tune (0.6 s) a short chime plays with a buzz, the string gets its green dot and the next string is suggested (ring around its chip, "Play the A2 string"); after the last one a three-note chime and "All strings are in tune". Tap a string to stay on it (no moving on); "Start over" clears the dots. A string that goes out of tune again can chime again. Tuner sheet: Chime On/Off, Next string Move on/Stay. New settings `tunerAdvance`, `tunerChime` (in backups)
- Version 5.4

# Songbook 5.3 - Fit fixes, new home blocks, Needle list, Apple Music album page, Scrapbook settings (not yet compiled)

## 5.3 changes
- Fit: album/group tiles no longer clip their text to a rounded corner (that cut the "T" of "Trilogy" and the star rating). Badge and type label share one row and shrink; the type label is darker and hidden on 3-4 column tiles. Pinned albums grid fixed the same way
- Favorites (Coral): the same card as the top of Settings (`SummaryCard` in CoralBits.kt): ring, numbers, Shuffle button; white in dark mode, black in light mode
- Main page blocks: every tool now has a block (Live chords, Guitar tuner, Record a demo, New song, Surprise me, Groups row) besides tiles, favorites, progress, analyzer, quick settings, albums grid. Settings > Home and lists > Main page blocks
- Simple list: no lines, track numbers on album pages, "Side A" style header bar (`SimpleSectionHeader`), long press opens the menu
- Album and group pages (Coral): Apple Music style header, `CoverHeader(coralHeader)`: 0 full width cover fading into the page, 1 framed cover. `CoverBackdrop` (CoverTint.kt) tints the whole page from the cover's main color or keeps the plain page. Settings `albumHeader`, `albumBg` (in backups); also switchable from the three dots
- Settings (Coral): Scrapbook layout: summary card, sections Appearance / Your music / Safety and data, each line with icon, title and summary opens its own page. Other looks keep the old long list
- Version 5.3

# Songbook 5.2 - Lyrics in the chord analyzer (not yet compiled)

## 5.2 changes
- Lyrics button in the analyzer's result header. A demo of a song that has lyrics loads them by itself (chords in the song text are ignored); otherwise type/paste them or take them from another song (`ui/screens/LyricsParts.kt`, model in `analysis/Lyrics.kt`)
- Timing: "Tap to time the lines" (plays the song; a sync bar asks for a tap when each line is sung, Undo, Done) or "Spread the lines evenly" as a starting point. The Follow view then shows the lyrics with the chords over the words and the sung line lit; tap a line to jump to it
- Save sheet: "Save chords and lyrics to this song" (replaces the song's text, asks first) and "...as a new song", written as `[G]word [D]word` (`Lyrics.toSongText`). Chords go on the word sung when they start; the chord already playing at a line's start goes on its first word
- Not done: lyrics are not kept in "Recent" analyses; Live mode has no lyrics yet; word-level placement is by line time, fix single words in the song editor
- Version 5.2

# Songbook 5.1 - Guitar tuner and Live chords (not yet compiled)

## 5.1 changes
- Tuner (menu > Tuner, Settings > Library > Guitar Tuner, home tile "Tuner"): listens to the microphone, finds the pitch with YIN (`analysis/Tuner.kt`), shows the note, Hz and a cents meter (green within 5 cents). Tunings: Standard, Drop D, Half/Full step down, DADGAD, Open G, Open D, Ukulele, Bass, Chromatic. Auto finds the string you play; tap a string to hear it (additive pluck tone) and lock it; a green dot marks strings held in tune. Reference pitch A = 430-450 Hz. Settings `tunerTuning`, `tunerRef` (in backups)
- Live mode of the chord analyzer (start page > "Live mode", home tile "Live chords"): `analysis/LiveChords.kt` is the engine's chroma/template idea on a 0.37 s moving window with hysteresis (a new chord must win clearly twice in a row), live tuning follow and a key guess. Shows the chord with its shape, the last chords, the 12 notes heard, level bar, capo, Basic/Precise, sensitivity. Save as song / copy / share. Settings `liveSens`, `livePrecise` (in backups). Nothing is recorded
- Sensitivity fix (Live + Tuner, not yet compiled): Live mode now learns the room's noise (level and spectrum) while it is quiet, gates relative to it (Sensitivity sets the ratio, the lowest level and the minimum chord fit) and subtracts the noise spectrum before matching chords. `MicStream.start(autoGain = true)` raises quiet microphones up to 24x for the tuner (Live uses the true level). The "Not sure yet" grey-out follows the Sensitivity setting
- `analysis/MicStream.kt` (shared microphone reader, unprocessed source where available), `ui/components/MicPermission.kt`
- `ChordEngine` tables and FFT are now `internal` so Live mode reuses them (offline behavior unchanged)
- Version 5.1

# Songbook 5.0 - The chord analyzer, redesigned (not yet compiled)

## 5.0 changes
- Start page: a card with "Choose audio file" and "Record now" (asks which song, then records a demo), "From your songs" (the demos, one tap), "Recent" (kept analyses; press and hold removes one)
- While it listens: a progress ring with the three steps; the cross stops it
- Result: a header with the title, "E major · 99 BPM", and the Tune and Save buttons; a switch for four views: Play (the chord now with its shape, the next chord, a zoomed timeline, big player), Chords (the chords used, most played first, tap to jump), Chart (bar grid, bar numbers), Follow along (the chords scroll by, the current one big with its shape and beat dots). Small player on the other views
- Sheets: Views (which view, open on last used or this view, tabs on or off, player on every view), Tune (Basic/Precise, beats in a bar, tempo x2 / half, transpose, capo, instrument), Save (add to a song, save as a new song, keep this analysis, copy, share as text)
- Shapes for Guitar, Ukulele (searched, see `analysis/Instruments.kt`), Piano (two octaves, notes lit) or none. With a capo the shapes shown are lower; saved chords are the sounding ones
- Kept analyses: `analysis/AnalysisStore.kt` (index.json, one json per result, a copy of the audio for files from outside the app; demos are referenced, not copied). Not in backups yet
- Code: `ui/screens/AnalyzerScreen.kt` (flow and pages), `ui/screens/AnalyzerParts.kt` (player, chart, timeline, shapes, sheets). New settings `anaDefault`, `anaLast`, `anaOpenLast`, `anaTabs`, `anaPlayer`, `anaInstrument`
- Not done: the PDF chord sheet (text sharing only)
- Version 5.0

# Songbook 4.3 - Greeting size

## 4.3 changes
- Settings > Profile > Greeting Size: Hide / Small (22 sp) / Medium (26 sp, new standard) / Large (32 sp, what it was). It sets the size of "Hi, John" and the line under it on the Glassy and Tools main pages of the Coral look; Hide leaves only a small gap. New setting `greetingSize` (saved in backups). Version 4.3

# Songbook 4.2 - More home sections

## 4.2 changes (Coral look only)
- Every section of the main page can be hidden, moved or added: a "Customize this page" button now ends the page (it was only in the menu before). It opens the same list as before, with a switch for each of: Tiles, Filters, Search, Pinned albums, Favorite songs, Progress card, Chord analyzer card, Quick settings, Albums (grid), Workflow, Recent songs, All songs
- New sections: Chord analyzer card (dark card with "Analyze audio" and "Record a demo"), Quick settings (theme, bottom bar, "All settings"), Albums as a grid; the Progress card now also shows the numbers of songs, albums, favorites and songs in progress
- New tiles for the Tools section: Settings, and "Surprise me" (opens a random song)
- If everything is hidden the page says so, with the Customize button
- Version 4.2

# Songbook 4.1 - Tools home page, customizable home, hide the bottom bar

## 4.1 changes (Coral look only)
- Settings > Look > Home Layout now has a third choice, Tools: the Glassy main page with shortcut tiles under the greeting (mockup "A" from the design canvas): Chord analyzer, Record a demo, Workflow, Statistics, then the pinned albums and the songs. Tiles are two to a row, the first is coral. "Edit" next to Tools (or Settings > Look > Home Tiles) chooses and orders the tiles: also New song, Albums, Favorites
- "Record a demo" asks which song (`ui/components/SongPickDialog.kt`), then opens the recorder for it
- New blocks for every Coral main page (off by default except on Tools): Tiles, Favorite songs, Progress card. "Customize this page" (and Settings > Pages) orders and hides all of the blocks; the Tools page keeps its own order (`homeLayoutTools`) so it does not disturb the Classic and Glassy pages
- Settings > Look > Bottom Navigation: Show / Hide. Hidden: no bottom bar, the plus button drops down, and the swipes between Songs, Albums, Favorites and Settings are always on whatever "Swipe Between Pages" says; the menu button still opens everything
- New settings (saved in backups): `hideNav`, `homeTiles`, `homeLayoutTools`; `coralHome` can be 0, 1 or 2
- Version 4.1

# Songbook 4.0 - Better recordings, more formats

## 4.0 changes
- Demos are recorded by reading the microphone directly (AudioRecord) instead of the phone's ready-made recorder (`recording/AudioRecorder.kt`). With "Raw Microphone" on it asks for the unprocessed signal (no automatic volume, no noise or echo clean-up, which are made for calls); where the phone has none it uses the normal microphone. 16-bit samples at 48 kHz, in stereo where the phone allows it
- Formats (Settings > Recording > Format): AAC (.m4a), WAV (.wav, exact copy), FLAC (.flac, exact copy, about 60% of WAV; written by the app itself in `recording/Sinks.kt`, checked bit for bit against ffmpeg in `tools/flac-reference`), Opus (.ogg, only on phones with an Opus encoder, Android 10 and up)
- Quality: Good (44.1 kHz mono, AAC 128 kbps), High (48 kHz stereo, AAC 256), Studio (48 kHz stereo, AAC 320). Opus 96 / 160 / 256 kbps. WAV and FLAC are exact copies, so only the rate and the channels change
- The recording dialog shows what is really being recorded ("48 kHz · stereo · FLAC"); file names keep their format, also when restored from a backup; the chord analyzer reads all of them
- Old demos (.m4a) are untouched. New settings: `recFormat`, `recQuality`, `recRaw` (saved in backups)
- Version 4.0

# Songbook 3.9 - Analyze a song's demos, zoomed timeline

## 3.9 changes
- A demo recorded in a song has "Find chords" in its menu: the analyzer opens on it and starts at once (no copy is made, the demo is never deleted). Then "Add the chords to this song" adds the chord chart to the end of the song's text; "Save as song" still makes a new one. Route: `analyzer?file=&title=&song=` in `SongbookRoot.kt`
- The analyzer has a second, zoomed timeline: the 12 seconds around the playhead scroll by as the song plays, with the chords as blocks, the loudness, the beats and a fixed playhead in the middle; drag it to move through the song (`ZoomTimeline` in `AnalyzerScreen.kt`)
- Version 3.9

# Songbook 3.8 - Chord analyzer

## 3.8 changes
- New: Chord analyzer (menu > Chord analyzer, or Settings > Library > Chord Analyzer). Pick an audio file; it is decoded and analysed on the phone (nothing is uploaded) and shows the key, the tempo, the length, a timeline with the chords over the loudness curve, the chord now playing and the next one with guitar chord diagrams, the chords used, and a bar-by-bar chord chart. Play / pause, +-5 s, 1x / 0.75x / 0.5x, tap the timeline or a chart cell to jump. Basic (major and minor) or Precise (also 7, maj7, m7, sus4, sus2), 3 or 4 beats to a bar, tempo as found / x2 / half, transpose. "Save as song" makes a song with the chords, key and BPM; "Copy chords" puts the chart on the clipboard
- Code: `analysis/ChordEngine.kt` (chroma, tempo, key, templates, Viterbi), `analysis/AudioDecoder.kt` (MediaCodec to 11025 Hz mono), `analysis/GuitarShapes.kt`, `analysis/ChordNames.kt`, `ui/screens/AnalyzerScreen.kt`
- `tools/chord-engine-prototype/` is the Python version the engine was tuned in (10 synthetic test songs: about 95% Basic, 89% Precise, tempo 10/10, key 8/10). Real recordings will be harder
- The menu card scrolls on small screens; Version 3.8

# Songbook 3.7 - Outfit weights and more pages

## 3.7 changes
- Outfit now has all four weights: Regular and Bold are the original files, Medium (500) and SemiBold (600) are blended from them (`res/font/outfit_medium.ttf`, `outfit_semibold.ttf`, made by `tools/make_outfit_weights.py`). Before, Medium used the Regular file and SemiBold the Bold file. Drop the official Outfit Medium and SemiBold files over the two new ones (same names) to replace the blend
- Coral: the songwriting desk and the song editor get round header buttons, a plain title, and a gray "Edit text" pill / black "Done" pill
- Version 3.7

# Songbook 3.6 - Glassy home layout for Coral

## 3.6 changes
- New option Settings > Look > Home Layout (Coral only): Classic (default, unchanged) or Glassy. Glassy gives the Coral look the Glass look's main page: a big greeting with the tagline, the search box always shown, the pinned albums and recent songs as horizontal rows of plain tiles, then the songs. The Coral top bar, bottom bar and menu stay. Stored as `coralHome` (0 or 1); `Blocks.home(Glass)` supplies the default block order, so "Customize this page" works for it too (`CoralLibrary` in `LibraryScreen.kt`)
- Version 3.6

# Songbook 3.5 - Settings pages and empty states

## 3.5 changes (Coral look only)
- Settings is a short list of groups (Look, Library, Profile, Appearance, Layout, Sorting, Pages, Reading, Song Display, Data, About), each opening as its own page; Back or the arrow returns to the list (`SettingsGroup` + `SettingsNav` in `Common.kt`, state in `SettingsScreen.kt`)
- An empty library shows Paperback's empty card with a "New song" button (`CoralEmptyCard`)
- The Workflow page has the same header as the other pages, with "+ Idea" next to its title
- Version 3.5

# Songbook 3.4 - Paperback navigation and gestures

## 3.4 changes (Coral look only)
- Navigation like Paperback: the header's menu button opens a card of pages above a round close button; "More" opens a sheet with this page's actions and every page (`components/NavMenu.kt`, wired in `SongbookRoot.kt`)
- The plus button stays on Songs and Albums; "New song" is also the first row of the menu
- Gestures from Paperback 34 (`components/SwipeHost.kt`): swipe right to go back, swipe left or right on a main page to move between Songs, Albums, Favorites and Settings. Off in the reader and the editors. Two switches in Settings: "Swipe to Go Back", "Swipe Between Pages"
- Long press on a song row opens its menu
- Selected chips use the accent color; search is a big filled pill; "Sort: ..." and "View: ..." pills replace the two icon buttons; Albums and Favorites get the count pill
- Album tiles are a cover with the name under it, no card; album, group and reader pages use the wordmark with a small label under it
- Version 3.4

# Songbook 3.3 - closer to Paperback

## 3.3 changes (Coral look only)
- Paperback's palette: white page with soft gray (#F3F3F3) cards; black page and #161616 cards in dark (`theme/Theme.kt`)
- Bottom bar like Paperback's, with a soft pill on the current page, the plus button above it (`CoralBottomBar` in `Chrome.kt`)
- Header: lighter wordmark, the page name as a 16 sp label with a pill on the right ("24 songs" on the main page), rounded menu with icons
- Settings rows: an icon tile, the label, the value and a chevron, with the line starting under the label (`SettingsRow` in `Common.kt`)
- Main page: the pinned albums are a plain two-column grid, cover with the name and song count under it, no card (`albumsGrid` in `LibraryScreen.kt`)
- Version 3.3

# Songbook 3.2 - Paperback polish

## Build
One workflow now, like Eon: key in the repo (`app/debug.keystore`), builds loose files or a zip, APK in the run's Artifacts. See SIGNING.md.

## 3.2 changes (Coral look only; Old and Glass are untouched)
- Dialogs copy Paperback's PbDialog: big rounded card, serif title, Cancel pill + solid confirm pill (`CoralDialog` in `Dialogs.kt`)
- Text fields are filled and outline-free (`SbField` in `Fields.kt`, drop-in for OutlinedTextField)
- Segmented control is a soft track with a raised white thumb; switch has a lifted thumb on a softer off track
- Cards are flat with no hairline; settings dividers stop short of the card edges; section labels use Paperback's spacing
- Top bar: lighter wordmark, page name is a small label under it, 22dp icons

First `./gradlew assembleDebug` may still show small errors (nothing could be compiled here). Likeliest spots: `Dialogs.kt` imports, `Fields.kt`.

# Songbook 3.1 - new header and icon

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.

## Scrapbook link
Songs can go to Scrapbook and back (the Scrapbook app of the same family). Rules and message formats: data/ScrapbookLink.kt. Screens and sending: ui/components/ScrapbookBridge.kt.
The door Scrapbook knocks on: ScrapbookReceiverActivity (no screen; also opens songbook://song/<id> links). Hooks are marked "[scrapbook hook N]":
manifest (1), song menu "Edit in Scrapbook" (2), SongbookRoot (3), SongScreen chip + Keep/Undo card (4).
Try: in Scrapbook, a scrap's menu ▸ Send to Songbook as an idea / as a song. Open the song here: its menu has Edit in Scrapbook, and a "Scrapbook" chip shows. Edit it in Scrapbook, Send back,
and the song shows "Updated from Scrapbook" with Keep / Undo.
