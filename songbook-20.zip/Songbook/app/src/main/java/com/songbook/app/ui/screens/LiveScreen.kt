package com.songbook.app.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.songbook.app.analysis.ChordNames
import com.songbook.app.analysis.Instrument
import com.songbook.app.analysis.Instruments
import com.songbook.app.analysis.LiveChords
import com.songbook.app.analysis.LiveReading
import com.songbook.app.analysis.MicStream
import com.songbook.app.analysis.SongChord
import com.songbook.app.analysis.SongFollow
import com.songbook.app.data.Keys
import com.songbook.app.data.SongEntity
import com.songbook.app.data.Transposer
import com.songbook.app.data.hasChords
import com.songbook.app.ui.components.SongPickDialog
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.rememberMicRequest
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

// Live mode of the chord analyzer: Songbook listens through the microphone and shows the chord you play, with its
// shape, the notes it hears, the chords you played just before and the key so far. The detection is in
// analysis/LiveChords.kt. Nothing is recorded: the sound is analysed as it comes and thrown away.

/** One chord of the session: when it started (the next one's start, or now, is when it ended). */
private class LiveEntry(val root: Int, val type: String, val atMs: Long)

private class LiveHolder {
    var det: LiveChords? = null
    @Volatile var song: List<SongChord>? = null
}

/** The chords of the session that lasted long enough to be real, without the same chord twice in a row. */
private fun keptChords(history: List<LiveEntry>, now: Long): List<LiveEntry> {
    val out = ArrayList<LiveEntry>()
    for (i in history.indices) {
        val end = if (i + 1 < history.size) history[i + 1].atMs else now
        if (end - history[i].atMs < 400) continue
        val e = history[i]
        val last = out.lastOrNull()
        if (last == null || last.root != e.root || last.type != e.type) out.add(e)
    }
    return out
}

/** Song text for the library: four chords to a line, in square brackets, like the analyzer writes it. */
private fun liveBody(chords: List<LiveEntry>, flats: Boolean): String {
    val sb = StringBuilder("# Chords\n")
    for (line in chords.chunked(4)) {
        sb.append('[').append(line.joinToString(" ") { ChordNames.chord(it.root, it.type, 0, flats) }).append("]\n")
    }
    return sb.toString().trimEnd()
}

@Composable
internal fun LivePage(
    prefs: AnalyzerPrefs,
    onPrefs: (AnalyzerPrefs) -> Unit,
    onBack: () -> Unit,
    onSave: (title: String, body: String, key: String, bpm: Int, comment: String) -> Unit,
    songs: List<SongEntity> = emptyList()
) {
    val c = Sb.colors
    val context = LocalContext.current
    val view = LocalView.current
    val clipboard = LocalClipboardManager.current
    val prefsNow by rememberUpdatedState(prefs)

    var access by remember { mutableIntStateOf(0) }          // 0 asking, 1 listening, 2 no permission, 3 the microphone is busy
    var paused by remember { mutableStateOf(false) }
    var reading by remember { mutableStateOf<LiveReading?>(null) }
    var capo by rememberSaveable { mutableStateOf(0) }
    var sheet by remember { mutableIntStateOf(0) }           // 1 settings, 2 save
    val history = remember { mutableStateListOf<LiveEntry>() }
    val holder = remember { LiveHolder() }

    // follow a song: its chords help the detection and show where in the song you are
    var followId by rememberSaveable { mutableStateOf(0L) }
    var showPick by remember { mutableStateOf(false) }
    val followSong = songs.firstOrNull { it.id == followId }
    val followChords = remember(followSong?.id, followSong?.body) {
        if (followSong == null) emptyList() else SongFollow.parse(Keys.chordsOf(followSong.body))
    }
    val followNow by rememberUpdatedState(followChords)
    var followPos by remember { mutableIntStateOf(-1) }       // the chord of the song that sounds now, -1 = not known yet
    var offSong by remember { mutableStateOf(false) }         // the last chord is not in the song
    holder.song = followChords.ifEmpty { null }
    LaunchedEffect(followId) {
        followPos = -1
        offSong = false
    }
    val mic = remember { MicStream(context) }
    val instrument = Instrument.values()[prefs.instrument.coerceIn(0, 3)]

    val request = rememberMicRequest { ok -> access = if (ok) 1 else 2 }
    LaunchedEffect(Unit) { request() }
    BackHandler(onBack = onBack)

    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    DisposableEffect(access, paused) {
        if (access == 1 && !paused) {
            holder.det?.reset()
            val ok = mic.start { buf, n ->
                val d = holder.det ?: LiveChords(mic.rate).also { holder.det = it }
                d.precise = prefsNow.livePrecise
                d.sensitivity = prefsNow.liveSens
                d.song = holder.song
                val r = d.feed(buf, n)
                if (r != null) reading = r
            }
            if (!ok) access = 3
        }
        onDispose { mic.stop() }
    }

    // the chords played, one entry each time the chord changes (or the same chord comes back after a silence)
    LaunchedEffect(Unit) {
        var gap = true
        snapshotFlow { reading }.collect { r ->
            if (r != null) {
                if (r.root < 0) gap = true else {
                    val last = history.lastOrNull()
                    if (last == null || gap || last.root != r.root || last.type != r.type) {
                        history.add(LiveEntry(r.root, r.type, System.currentTimeMillis()))
                        if (history.size > 400) history.removeAt(0)
                        val fc = followNow
                        if (fc.isNotEmpty()) {
                            val j = SongFollow.advance(fc, followPos, r.root, r.type)
                            if (j >= 0) {
                                followPos = j
                                offSong = false
                            } else {
                                offSong = true
                            }
                        }
                    }
                    gap = false
                }
            }
        }
    }

    val r = reading
    val showShift = -capo                                    // with a capo the shapes are lower than the sound
    val flatsShown = if (r != null && r.keyTonic >= 0) ChordNames.preferFlats(r.keyTonic + showShift, r.keyMinor) else false
    val flatsSound = if (r != null && r.keyTonic >= 0) ChordNames.preferFlats(r.keyTonic, r.keyMinor) else false
    val chordName = if (r != null && r.root >= 0) ChordNames.chord(r.root, r.type, showShift, flatsShown) else ""
    val subtitle: String? = when {
        access != 1 -> null
        paused -> "Paused"
        r != null && r.keyTonic >= 0 -> "Key so far: " + ChordNames.keyLong(r.keyTonic, r.keyMinor, 0) + (if (capo > 0) " · Capo $capo" else "")
        capo > 0 -> "Listening · Capo $capo"
        else -> "Listening"
    }

    Box(Modifier.fillMaxSize().screenBg()) {
        Column(Modifier.fillMaxSize()) {
            AnaHeader("Live", subtitle, { RoundBtn(SbIcons.Back, "Back", onBack) }) {
                RoundBtn(SbIcons.Sliders, "Settings", { sheet = 1 })
                RoundBtn(SbIcons.Download, "Save", { sheet = 2 })
            }
            if (access >= 2) {
                MicProblem(busy = access == 3, onRetry = { access = 0; request() }, onSettings = {
                    val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}"))
                    context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            } else {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                    LevelBar(r?.level ?: 0f, r?.gate ?: 0f, !paused && r != null, Modifier.padding(start = 28.dp, end = 28.dp, top = 18.dp))
                    Text(
                        if (followSong == null) "Follow a song" else "Following: ${followSong.title}  ✕",
                        style = sbStyle(14, FontWeight.Medium, c.ac), maxLines = 1,
                        modifier = Modifier.padding(top = 8.dp, start = 24.dp, end = 24.dp).clip(RoundedCornerShape(14.dp))
                            .clickable { if (followSong == null) showPick = true else followId = 0L }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    AnaLabel(if (paused) "Paused" else "Now", Modifier)
                    val big = if (chordName.isEmpty()) "–" else chordName
                    val unsureBelow = when (prefs.liveSens) { 0 -> 0.72f; 2 -> 0.60f; else -> 0.68f }
                    val unsure = r != null && r.root >= 0 && r.fit < unsureBelow
                    Text(
                        big,
                        style = sbStyle(if (big.length > 4) 80 else 104, FontWeight.SemiBold, if (chordName.isEmpty() || unsure) c.mu else c.tx),
                        maxLines = 1
                    )
                    val status = when {
                        paused -> "Tap Resume to listen again."
                        r != null && r.calibrating -> "Learning the room… stay quiet for a moment."
                        r == null -> "Play a chord on your instrument. The sound is analysed as it comes and never stored."
                        chordName.isEmpty() -> if (r.quiet) "Play a chord." else "Listening…"
                        unsure -> "Not sure yet…"
                        else -> ""
                    }
                    if (status.isNotEmpty()) {
                        Text(status, style = sbStyle(14, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 36.dp))
                    }
                    if (r != null && r.root >= 0) {
                        ChordShapeView(
                            instrument, Math.floorMod(r.root + showShift, 12), r.type,
                            Modifier.fillMaxWidth(if (instrument == Instrument.PIANO) 0.7f else 0.42f)
                        )
                    }

                    // the song: where you are in it and what comes next
                    if (followSong != null && followChords.isNotEmpty()) {
                        val from = maxOf(0, followPos - 1)
                        val to = minOf(followChords.size - 1, from + 6)
                        AnaLabel("In the song", Modifier.padding(top = 22.dp, bottom = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (i in from..to) {
                                val now = i == followPos
                                val next = followPos >= 0 && i == (followPos + 1).coerceAtMost(followChords.size - 1) && i != followPos
                                Box(
                                    Modifier.clip(RoundedCornerShape(18.dp))
                                        .background(if (now) c.ac else c.cd)
                                        .then(if (next) Modifier.border(2.dp, c.ac, RoundedCornerShape(18.dp)) else Modifier)
                                        .padding(horizontal = 11.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        Transposer.chord(followChords[i].name, showShift),
                                        style = sbStyle(15, FontWeight.SemiBold, if (now) c.onAc else if (i < followPos) c.mu else c.tx), maxLines = 1
                                    )
                                }
                            }
                        }
                        val upNext = followChords[(followPos + 1).let { if (followPos < 0) 0 else it % followChords.size }]
                        Text(
                            when {
                                followPos < 0 -> "Play the first chord: ${Transposer.chord(upNext.name, showShift)}"
                                offSong -> "That chord is not in this song. Next: ${Transposer.chord(upNext.name, showShift)}"
                                else -> "Next: ${Transposer.chord(upNext.name, showShift)}"
                            },
                            style = sbStyle(14, color = c.mu), textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 10.dp, start = 24.dp, end = 24.dp)
                        )
                    }

                    // the chords just before
                    val recent = history.takeLast(5)
                    if (recent.size > 1) {
                        AnaLabel("Last chords", Modifier.padding(top = 22.dp, bottom = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            recent.forEachIndexed { i, e ->
                                val now = i == recent.size - 1 && r != null && r.root >= 0
                                Box(
                                    Modifier.clip(RoundedCornerShape(18.dp)).background(if (now) c.ac else c.cd).padding(horizontal = 11.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        ChordNames.chord(e.root, e.type, showShift, flatsShown),
                                        style = sbStyle(15, FontWeight.SemiBold, if (now) c.onAc else c.tx), maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    // the notes it hears
                    AnaLabel("Notes you play", Modifier.padding(top = 24.dp))
                    val quiet = r == null || r.quiet || paused
                    val inChord = if (r != null && r.root >= 0) Instruments.tones(r.root, r.type).toSet() else emptySet()
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 10.dp),
                        verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        for (p in 0 until 12) {
                            NoteBar(ChordNames.note(p, flatsSound), if (quiet || r == null) 0f else r.notes[p], p in inChord, Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PillButton(if (paused) "Resume" else "Pause", true, Modifier.weight(1f)) { paused = !paused }
                    PillButton("Clear", false, Modifier.weight(1f)) {
                        history.clear()
                        holder.det?.reset()
                        followPos = -1
                        offSong = false
                        reading = null
                    }
                }
            }
        }

        if (showPick) {
            SongPickDialog("Follow a song", songs.filter { it.hasChords() }, { id ->
                followId = id
                showPick = false
            }, { showPick = false })
        }
        if (sheet == 1) AnalyzerSheet("Live", null, onClose = { sheet = 0 }) {
            AnaLabel("Chords")
            AnaRow("Detail", "Basic: major, minor, 7 and m7. Precise adds maj7, sus, add9, 6, power, dim, aug, 7sus4 and 9") {
                Segmented(listOf("Basic", "Precise"), if (prefs.livePrecise) 1 else 0) { onPrefs(prefs.copy(livePrecise = it == 1)) }
            }
            AnaRow("Sensitivity", "Higher for quiet playing, lower in a noisy room") {
                Segmented(listOf("Low", "Normal", "High"), prefs.liveSens.coerceIn(0, 2)) { onPrefs(prefs.copy(liveSens = it)) }
            }
            AnaRow("Room noise", "Stay quiet for two seconds so it can learn the room. The tick on the level bar is the gate") {
                PillButton("Listen", false, Modifier.width(110.dp)) {
                    holder.det?.calibrate()
                    sheet = 0
                }
            }
            AnaLabel("Song")
            AnaRow("Follow a song", followSong?.title ?: "Pick a song to see its chords as you play, and to hear them better") {
                PillButton(if (followSong == null) "Choose" else "Change", false, Modifier.width(110.dp)) {
                    sheet = 0
                    showPick = true
                }
            }
            if (followSong != null) {
                AnaRow("Stop following") {
                    PillButton("Stop", false, Modifier.width(110.dp)) {
                        followId = 0L
                        sheet = 0
                    }
                }
            }
            AnaLabel("Shapes")
            AnaRow("Capo", "Chords are shown as the shapes you play") {
                Segmented(listOf("None", "1", "2", "3", "4"), capo.coerceIn(0, 4)) { capo = it }
            }
            AnaRow("Instrument") {
                Segmented(Instrument.values().map { it.label }, prefs.instrument.coerceIn(0, 3)) { onPrefs(prefs.copy(instrument = it)) }
            }
            Text(
                "Live mode is about a third of a second behind the playing. Chords are an estimate: check them by ear.",
                style = sbStyle(13, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
            )
        }
        if (sheet == 2) {
            val chords = keptChords(history.toList(), System.currentTimeMillis())
            val body = liveBody(chords, flatsSound)
            AnalyzerSheet("Save", if (chords.isEmpty()) null else "${chords.size} chords played", onClose = { sheet = 0 }) {
                if (chords.isEmpty()) {
                    Text(
                        "Play some chords first. Then you can save them here as a song.",
                        style = sbStyle(14, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp)
                    )
                } else {
                    val key = if (r != null && r.keyTonic >= 0) ChordNames.key(r.keyTonic, r.keyMinor, 0) else ""
                    val keyText = if (r != null && r.keyTonic >= 0) ": " + ChordNames.keyLong(r.keyTonic, r.keyMinor, 0) else ""
                    val comment = "Chords heard by Songbook's Live mode$keyText. It is an estimate, check it by ear."
                    ActionRow(SbIcons.Music, "Save as a new song", "The chords in the order you played them") { onSave("Live chords", body, key, 0, comment) }
                    ActionRow(SbIcons.Copy, "Copy the chords", "As text") { clipboard.setText(AnnotatedString(body)); sheet = 0 }
                    ActionRow(SbIcons.Share, "Share the chords", "As text") {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Live chords")
                            putExtra(Intent.EXTRA_TEXT, "Live chords" + keyText + "\n\n" + body.removePrefix("# Chords").trim())
                        }
                        context.startActivity(Intent.createChooser(i, "Share chords").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        sheet = 0
                    }
                    Text("Chords that sounded for less than half a second are left out.", style = sbStyle(13, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 14.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ pieces

/** How loud it is: a thin bar. */
@Composable
private fun LevelBar(level: Float, gate: Float, active: Boolean, modifier: Modifier = Modifier) {
    val c = Sb.colors
    val v by animateFloatAsState(if (active) level.coerceIn(0f, 1f) else 0f, tween(90), label = "level")
    val g by animateFloatAsState(gate.coerceIn(0f, 1f), tween(250), label = "gate")
    Box(modifier.fillMaxWidth().height(12.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(c.track)) {
            Box(Modifier.fillMaxWidth(v.coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape).background(c.ac))
        }
        // the tick: the sound has to reach it to count as playing
        if (active && g > 0.02f) {
            Box(Modifier.fillMaxWidth(g).fillMaxHeight(), contentAlignment = Alignment.CenterEnd) {
                Box(Modifier.width(2.dp).fillMaxHeight().background(c.mu))
            }
        }
    }
}

/** One of the twelve notes: a bar as high as it sounds, in the accent colour when the chord that plays contains it. */
@Composable
private fun NoteBar(name: String, value: Float, inChord: Boolean, modifier: Modifier = Modifier) {
    val c = Sb.colors
    val v by animateFloatAsState(value.coerceIn(0f, 1f), tween(110), label = "note")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
        Box(
            Modifier.fillMaxWidth().height((52f * v + 3f).dp).clip(RoundedCornerShape(6.dp))
                .background(if (inChord && value > 0.05f) c.ac else c.mu.copy(alpha = 0.35f))
        )
        Text(name, style = sbStyle(11, FontWeight.Medium, if (inChord) c.tx else c.mu), maxLines = 1, modifier = Modifier.padding(top = 4.dp))
    }
}
