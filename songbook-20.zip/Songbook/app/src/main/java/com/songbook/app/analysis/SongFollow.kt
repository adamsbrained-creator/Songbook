package com.songbook.app.analysis

/** One chord of a song as Live mode knows it: how it is written, its root (C = 0) and its type (one of [ChordEngine.LIVE_FULL]). */
class SongChord(val name: String, val root: Int, val type: String)

/**
 * "Follow a song": the chords written in a song help Live mode (they get a bonus when it picks a chord) and show where
 * in the song you are. Plain Kotlin, no Android.
 */
object SongFollow {
    private val rx = Regex("""^([A-G])([#b]?)([^/]*)(?:/.*)?$""")
    private val natural = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)

    /** The chords of a song in order, as written ("Am7", "G/B", "Cadd9"). Things that are not chords ("N.C.", "x2") are left out. */
    fun parse(names: List<String>): List<SongChord> {
        val out = ArrayList<SongChord>()
        for (raw in names) {
            val m = rx.matchEntire(raw.trim()) ?: continue
            var root = natural.getValue(m.groupValues[1][0])
            if (m.groupValues[2] == "#") root++ else if (m.groupValues[2] == "b") root--
            out.add(SongChord(raw.trim(), Math.floorMod(root, 12), liveType(m.groupValues[3].trim())))
        }
        return out
    }

    /** The closest type Live mode can name for what is written after the root ("m9" -> "m7", "7#9" -> "7", "m7b5" -> "dim"). */
    fun liveType(q: String): String = when {
        q.isEmpty() || q == "maj" || q == "M" -> ""
        q == "5" -> "5"
        q == "6" || q == "maj6" -> "6"
        q == "m6" || q == "min6" -> "m6"
        q.startsWith("7sus") -> "7sus4"
        q.startsWith("sus2") -> "sus2"
        q.startsWith("sus") -> "sus4"
        q.startsWith("add9") || q.startsWith("add2") || q == "(add9)" -> "add9"
        q.startsWith("aug") || q.startsWith("+") -> "aug"
        q.startsWith("dim") || q.startsWith("m7b5") || q.startsWith("°") || q.startsWith("ø") -> "dim"
        q.startsWith("maj") || q.startsWith("M7") || q.startsWith("M9") || q.startsWith("Δ") -> "maj7"
        q.startsWith("m") || q.startsWith("-") ->
            if (q.contains('7') || q.contains('9') || q.contains("11") || q.contains("13")) "m7" else "m"
        q.startsWith("9") -> "9"
        q.startsWith("7") || q.startsWith("11") || q.startsWith("13") -> "7"
        else -> ""
    }

    private fun family(t: String): Int = when (t) {
        "m", "m7", "m6" -> 1
        "dim" -> 2
        "aug" -> 3
        "sus4", "sus2", "7sus4" -> 4
        else -> 0
    }

    /** True when the chord that was heard is this chord of the song (the same root, the same kind of chord; a power chord fits any). */
    fun matches(c: SongChord, root: Int, type: String): Boolean =
        c.root == root && (c.type == type || c.type == "5" || type == "5" || family(c.type) == family(type))

    /**
     * Where in the song the chord that was just heard is, given where it was before ([pos], -1 = not yet known).
     * Looks first at the next chords (also round the end: songs repeat), then a little back, then everywhere.
     * Returns -1 when the chord is not in the song at all (the position stays where it was).
     */
    fun advance(chords: List<SongChord>, pos: Int, root: Int, type: String): Int {
        val n = chords.size
        if (n == 0) return -1
        if (pos < 0) {
            for (j in 0 until n) if (matches(chords[j], root, type)) return j
            return -1
        }
        for (step in 1..minOf(6, n)) {
            val j = (pos + step) % n
            if (matches(chords[j], root, type)) return j
        }
        for (step in 0..3) {
            val j = pos - step
            if (j >= 0 && matches(chords[j], root, type)) return j
        }
        for (step in 7 until n) {
            val j = (pos + step) % n
            if (matches(chords[j], root, type)) return j
        }
        return -1
    }
}
