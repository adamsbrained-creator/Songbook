"""
Makes outfit_medium.ttf (500) and outfit_semibold.ttf (600) from the bundled Regular (400) and Bold (700) by blending
the two outlines (a third of the way and two thirds of the way). Needs: pip install fonttools
Run from the project root: python tools/make_outfit_weights.py
Replace the results with the official Outfit Medium and SemiBold files (same names) any time you like.
"""
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables import ttProgram
from fontTools.ttLib.tables._g_l_y_f import GlyphCoordinates

D = "app/src/main/res/font/"


def build(t, style, weight, out):
    R = TTFont(D + "outfit_regular.ttf")
    B = TTFont(D + "outfit_bold.ttf")
    gr, gb = R["glyf"], B["glyf"]
    names = R.getGlyphOrder()
    for n in names:  # simple glyphs first, composites after
        a, b = gr[n], gb[n]
        if a.numberOfContours > 0:
            a.coordinates = GlyphCoordinates(
                [(round(x + t * (xb - x)), round(y + t * (yb - y))) for (x, y), (xb, yb) in zip(a.coordinates, b.coordinates)]
            )
    for n in names:
        a, b = gr[n], gb[n]
        if a.numberOfContours < 0:
            for ca, cb in zip(a.components, b.components):
                ca.x = round(ca.x + t * (cb.x - ca.x))
                ca.y = round(ca.y + t * (cb.y - ca.y))
    for n in names:
        a = gr[n]
        if a.numberOfContours != 0:
            a.recalcBounds(gr)
            p = ttProgram.Program()
            p.fromBytecode(b"")
            a.program = p
    hm, hb = R["hmtx"], B["hmtx"]
    for n in names:
        adv, lsb = hm[n]
        hm[n] = (round(adv + t * (hb[n][0] - adv)), gr[n].xMin if gr[n].numberOfContours != 0 else lsb)
    R["OS/2"].usWeightClass = weight
    fam = "Outfit " + style
    for rec in R["name"].names:
        if rec.nameID in (1, 4):
            rec.string = fam
        elif rec.nameID == 2:
            rec.string = "Regular"
        elif rec.nameID == 3:
            rec.string = "Outfit-" + style + " blended from Regular and Bold"
        elif rec.nameID == 6:
            rec.string = "Outfit-" + style
        elif rec.nameID == 16:
            rec.string = "Outfit"
        elif rec.nameID == 17:
            rec.string = style
    R.save(out)


build(1 / 3, "Medium", 500, D + "outfit_medium.ttf")
build(2 / 3, "SemiBold", 600, D + "outfit_semibold.ttf")
