# Chord engine prototype

The chord analyzer in the app (`app/src/main/java/com/songbook/app/analysis/ChordEngine.kt`) is a Kotlin port of
`engine.py` here. This folder is where to try ideas quickly: change a number or a step in Python, run the test
songs, and only port it when it helps. Needs `numpy`.

* `synth.py` makes guitar-like test songs with known chords (strummed chords, a click, a melody, noise, detuning).
* `engine.py` is the analysis: chroma, tempo and beats, key, chord templates, Viterbi.
* `suite.py` runs ten test songs and prints the chord accuracy, the tempo and the key for each (`python suite.py`).

Last results on the ten songs: about 95% of the time the right chord with triads only (Basic), about 89% with
7th and sus chords as well (Precise), the tempo right on all ten, the key right on eight.
These are synthetic songs. Real recordings (vocals, drums, distortion) will do worse.
