"""Prototype of the on-device chord engine. Every constant here is mirrored in the Kotlin port."""
import numpy as np, math

SR = 11025
N = 4096
HOP = 512
NB = N // 2 + 1
BLOCK = 4                # hops per analysis block (~186 ms)
FMIN, FMAX = 60.0, 1800.0
BASS_MIN, BASS_MAX = 40.0, 250.0

NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
# interval sets: name, intervals, weights per interval
TYPES = {
    "":     [(0, 1.0), (4, 0.9), (7, 0.8)],
    "m":    [(0, 1.0), (3, 0.9), (7, 0.8)],
    "7":    [(0, 1.0), (4, 0.9), (7, 0.8), (10, 0.7)],
    "maj7": [(0, 1.0), (4, 0.9), (7, 0.8), (11, 0.7)],
    "m7":   [(0, 1.0), (3, 0.9), (7, 0.8), (10, 0.7)],
    "sus4": [(0, 1.0), (5, 0.9), (7, 0.8)],
    "sus2": [(0, 1.0), (2, 0.9), (7, 0.8)],
}
SNAP = 0.30
BASIC = ["", "m"]
PRECISE = ["", "m", "7", "maj7", "m7", "sus4", "sus2"]
TYPE_PENALTY = {"": 0.0, "m": 0.0, "7": 0.035, "maj7": 0.045, "m7": 0.035, "sus4": 0.06, "sus2": 0.06}

KK_MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
KK_MIN = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

WIN = np.hanning(N).astype(np.float32)
FREQS = np.arange(NB) * SR / N

def frames(y):
    n = 1 + max(0, (len(y) - N) // HOP)
    idx = np.arange(N)[None, :] + HOP * np.arange(n)[:, None]
    return y[idx] * WIN  # (n, N)

def spectra(y):
    f = frames(y)
    return np.abs(np.fft.rfft(f, axis=1)).astype(np.float32) / (N / 4)

def estimate_tuning(S):
    """circular mean of how far spectral peaks sit from the nearest semitone; returns semitones in (-0.5, 0.5)."""
    sel = S[::8]
    sx = sy = 0.0
    lo, hi = int(100 * N / SR), int(1500 * N / SR)
    for fr in sel:
        seg = fr[lo:hi]
        mx = seg.max()
        if mx <= 0: continue
        for k in range(1, len(seg) - 1):
            v = seg[k]
            if v > seg[k - 1] and v >= seg[k + 1] and v > 0.1 * mx:
                # parabolic interpolation of the peak position
                a, b, c = seg[k - 1], v, seg[k + 1]
                d = 0.5 * (a - c) / (a - 2 * b + c + 1e-12)
                f = (k + lo + d) * SR / N
                midi = 69 + 12 * math.log2(f / 440)
                dev = midi - round(midi)
                sx += v * math.cos(2 * math.pi * dev); sy += v * math.sin(2 * math.pi * dev)
    if sx == 0 and sy == 0: return 0.0
    return math.atan2(sy, sx) / (2 * math.pi)

def chroma_maps(tuning):
    """per-bin pitch class + weight for the chroma, and for the bass chroma."""
    pc = np.full(NB, -1, int); w = np.zeros(NB, np.float32)
    bpc = np.full(NB, -1, int)
    for k in range(1, NB):
        f = FREQS[k]
        if FMIN <= f <= FMAX:
            midi = 69 + 12 * math.log2(f / 440) - tuning
            pc[k] = int(round(midi)) % 12
            w[k] = math.exp(-0.5 * ((midi - 57) / 14.0) ** 2)
        if BASS_MIN <= f <= BASS_MAX:
            midi = 69 + 12 * math.log2(f / 440) - tuning
            bpc[k] = int(round(midi)) % 12
    return pc, w, bpc

def chromagram(S, tuning):
    pc, w, bpc = chroma_maps(tuning)
    n = len(S)
    C = np.zeros((n, 12), np.float32); B = np.zeros((n, 12), np.float32)
    comp = np.sqrt(S)  # compress
    for k in range(1, NB):
        if pc[k] >= 0: C[:, pc[k]] += comp[:, k] * w[k]
        if bpc[k] >= 0: B[:, bpc[k]] = np.maximum(B[:, bpc[k]], S[:, k])
    return C, B

def onset_env(S):
    lo, hi = int(50 * N / SR), int(4000 * N / SR)
    L = np.log1p(100.0 * S[:, lo:hi])
    d = np.maximum(0, L[1:] - L[:-1]).sum(axis=1)
    d = np.concatenate([[0], d])
    # remove slow trend
    k = 21
    ker = np.ones(k) / k
    d = d - np.convolve(d, ker, mode="same")
    return np.maximum(d, 0)

def estimate_tempo(env):
    hopsec = HOP / SR
    env = env - env.mean()
    n = len(env)
    f = np.fft.rfft(env, 2 * n)
    acf = np.fft.irfft(f * np.conj(f))[:n]
    acf /= acf[0] + 1e-12
    def at(lag):
        i = int(lag); fr = lag - i
        if i + 1 >= n: return 0.0
        return acf[i] * (1 - fr) + acf[i + 1] * fr
    best, bestb = -1e9, 100.0
    for b10 in range(650, 1801, 5):  # 65.0 .. 180.0 BPM, step 0.5
        b = b10 / 10.0
        lag = 60.0 / b / hopsec
        s = at(lag) + 0.5 * at(2 * lag) + 0.25 * at(4 * lag)
        prior = math.exp(-0.5 * (math.log2(b / 100.0) / 0.6) ** 2)
        sc = s * prior
        if sc > best: best, bestb = sc, b
    return bestb, best

def grid_score(env, bpm):
    hopsec = HOP / SR
    period = 60.0 / bpm / hopsec
    n = len(env)
    best, bp = -1.0, 0.0
    for p in np.arange(0, period, 0.5):
        idx = np.arange(p, n - 1, period)
        v = env[np.round(idx).astype(int)].mean() if len(idx) else 0.0
        if v > best: best, bp = v, p
    return best, bp

def refine_tempo(env, bpm):
    best, bb = -1.0, bpm
    for d in np.arange(-3.0, 3.01, 0.25):
        b = bpm + d
        v, _ = grid_score(env, b)
        if v > best + 1e-9: best, bb = v, b
    return bb

def beat_grid(env, bpm):
    hopsec = HOP / SR
    period = 60.0 / bpm / hopsec  # frames per beat
    n = len(env)
    best, bp = -1, 0.0
    for p in np.arange(0, period, 0.25):
        idx = np.arange(p, n - 1, period)
        v = env[np.round(idx).astype(int)].sum() / max(1, len(idx))
        if v > best: best, bp = v, p
    # an onset shows up in the flux when it reaches the middle of the analysis window
    beats = np.arange(bp, n - 1, period) * hopsec + N / 2 / SR
    return beats

def key_from_chroma(Cmean):
    best, bk = -1e9, (0, 0)
    for mode, prof in ((0, KK_MAJ), (1, KK_MIN)):
        for t in range(12):
            p = np.roll(prof, t)
            r = np.corrcoef(Cmean, p)[0, 1]
            if r > best: best, bk = r, (t, mode)
    return bk, best

def diatonic(tonic, mode):
    """set of (root, type) that get a bonus."""
    s = set()
    if mode == 0:
        for d, q in ((0, ""), (2, "m"), (4, "m"), (5, ""), (7, ""), (9, "m"), (10, "")):
            s.add(((tonic + d) % 12, q))
    else:
        for d, q in ((0, "m"), (3, ""), (5, "m"), (7, "m"), (7, ""), (8, ""), (10, "")):
            s.add(((tonic + d) % 12, q))
    return s

def templates(types):
    T = []; names = []
    for r in range(12):
        for t in types:
            v = np.zeros(12)
            for iv, w in TYPES[t]: v[(r + iv) % 12] = w
            T.append(v / np.linalg.norm(v)); names.append((r, t))
    return np.array(T), names

def viterbi(E, switch_pen):
    """E: (T, S) emission scores (higher = better). Uniform switching cost. Returns best state path."""
    T, S = E.shape
    delta = E[0].copy(); back = np.zeros((T, S), np.int32)
    for t in range(1, T):
        bi = int(np.argmax(delta)); bv = delta[bi] - switch_pen
        stay = delta
        use_sw = bv > stay
        back[t] = np.where(use_sw, bi, np.arange(S))
        delta = np.where(use_sw, bv, stay) + E[t]
    path = np.zeros(T, np.int32); path[-1] = int(np.argmax(delta))
    for t in range(T - 1, 0, -1): path[t - 1] = back[t][path[t]]
    return path

def features(y):
    S = spectra(y)
    tuning = estimate_tuning(S)
    C, B = chromagram(S, tuning)
    env = onset_env(S)
    bpm, conf = estimate_tempo(env)
    bpm = refine_tempo(env, bpm)
    beats = beat_grid(env, bpm)
    return dict(C=C, B=B, env=env, bpm=bpm, conf=conf, beats=beats, tuning=tuning, n=len(y))

PARAMS = dict(switch_pen=1.2, scale=8.0, bass_w=0.08, dia_w=0.06, pen=1.5, quiet=0.10)

def decode(F, precise=True, **kw):
    P = dict(PARAMS); P.update(kw)
    C, B, beats = F["C"], F["B"], F["beats"]
    nb = len(C) // BLOCK
    Cb = C[: nb * BLOCK].reshape(nb, BLOCK, 12).mean(axis=1)
    Bb = B[: nb * BLOCK].reshape(nb, BLOCK, 12).mean(axis=1)
    Cn = Cb / (np.linalg.norm(Cb, axis=1, keepdims=True) + 1e-9)
    Bn = Bb / (Bb.max(axis=1, keepdims=True) + 1e-9)
    (tonic, mode), kconf = key_from_chroma(C.mean(axis=0))
    dia = diatonic(tonic, mode)
    types = PRECISE if precise else BASIC
    T, names = templates(types)
    E = P["scale"] * (Cn @ T.T)
    for j, (r, t) in enumerate(names):
        E[:, j] += P["bass_w"] * P["scale"] * Bn[:, r]
        E[:, j] -= P["pen"] * TYPE_PENALTY[t] * P["scale"]
        base = t if t in ("", "m") else ("m" if t == "m7" else "")
        if (r, base) in dia: E[:, j] += P["dia_w"] * P["scale"]
    # a quiet block (silence, a gap, an intro) is "no chord": an extra state that only quiet blocks like
    energy = Cb.sum(axis=1)
    ref = np.percentile(energy, 90) + 1e-9
    quiet = energy / ref < P["quiet"]
    En = np.where(quiet, 0.9 * P["scale"], -P["scale"])
    E = np.concatenate([E, En[:, None]], axis=1)
    names = names + [(-1, "")]
    path = viterbi(E, P["switch_pen"] * P["scale"] / 6.0)
    blk = BLOCK * HOP / SR
    off = (N / 2 - BLOCK * HOP / 2) / SR
    starts = [0] + [i for i in range(1, nb) if path[i] != path[i - 1]]
    bt = [i * blk + off for i in starts]; bt[0] = 0.0
    snapped = [0.0]
    for t in bt[1:]:
        j = int(np.argmin(np.abs(beats - t))) if len(beats) else -1
        t2 = float(beats[j]) if j >= 0 and abs(beats[j] - t) <= SNAP else t + 0.08
        snapped.append(max(t2, snapped[-1] + 1e-3))
    total = nb * blk + off
    segs = []
    for n_, i in enumerate(starts):
        r, t = names[path[i]]
        end = snapped[n_ + 1] if n_ + 1 < len(starts) else total
        if end > snapped[n_]: segs.append((snapped[n_], end, "N" if r < 0 else NOTE[r] + t, r, t))
    real = [sg for sg in segs if sg[3] >= 0]
    key = key_from_segments([(sg[1] - sg[0], sg[3], sg[4]) for sg in real]) if real else (tonic, mode)
    return dict(bpm=F["bpm"], conf=F["conf"], tuning=F["tuning"], key=key, kk=(tonic, mode), segs=[(a_, b_, c_) for a_, b_, c_, _, _ in segs], beats=beats)

def analyze(y, precise=True, **kw):
    return decode(features(y), precise, **kw)

def key_from_chords(names):
    """names: list of (root, type). Mirrors Keys.detect in the app. Returns (tonic, mode) or None."""
    lst = [(r, 1 if (t.startswith("m") and not t.startswith("maj")) else 0) for r, t in names]
    if len(set(lst)) < 2: return None
    best, bk = -1e9, None
    for tonic in range(12):
        for minor in (0, 1):
            score = 0.0
            for r, m in lst:
                d = (r - tonic) % 12
                if not minor:
                    fits = (d in (0, 5, 7) and not m) or (d in (2, 4, 9, 11) and m)
                else:
                    fits = (d in (0, 5, 2) and m) or (d == 7) or (d in (3, 8, 10) and not m)
                score += (1.6 if d == 0 else 1.0) if fits else -0.8
            if lst[0] == (tonic, minor): score += 1.5
            if lst[-1] == (tonic, minor): score += 2.0
            if score > best: best, bk = score, (tonic, minor)
    return bk


def key_from_segments(segs_rt):
    """segs_rt: list of (dur, root, type) -> (tonic, mode). Chord-tone profile vs Krumhansl profiles + tonic evidence."""
    prof = np.zeros(12)
    for d, r, t in segs_rt:
        for iv, w in TYPES[t]: prof[(r + iv) % 12] += d * w
    best, bk = -1e9, (0, 0)
    first = segs_rt[0]; last = segs_rt[-1]
    tot = sum(d for d, _, _ in segs_rt)
    for mode, kk in ((0, KK_MAJ), (1, KK_MIN)):
        for tonic in range(12):
            sc = np.corrcoef(prof, np.roll(kk, tonic))[0, 1]
            tonic_t = "m" if mode else ""
            tonic_time = sum(d for d, r, t in segs_rt if r == tonic and (t.startswith("m") and not t.startswith("maj")) == bool(mode))
            sc += 0.25 * tonic_time / tot
            if first[1] == tonic and (first[2].startswith("m") and not first[2].startswith("maj")) == bool(mode): sc += 0.03
            if last[1] == tonic and (last[2].startswith("m") and not last[2].startswith("maj")) == bool(mode): sc += 0.06
            if sc > best: best, bk = sc, (tonic, mode)
    return bk
