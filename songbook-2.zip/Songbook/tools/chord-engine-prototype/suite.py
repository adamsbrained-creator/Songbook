import numpy as np, synth, engine, time, itertools, sys
SUITE = [
    (["F#m", "D", "D", "F#m", "F#m", "G", "A", "D"], 112, 4, 0, False, "F#m"),
    (["C", "G", "Am", "F"] * 2, 96, 4, 0, False, "C"),
    (["Cmaj7", "Am7", "Dm", "G7"] * 2, 84, 4, 0, False, "C"),
    (["Em", "C", "G", "D"] * 2, 120, 4, 30, False, "G"),
    (["Am", "F", "C", "G"] * 3, 100, 2, 0, False, "C"),
    (["G", "D", "Em", "C"] * 2, 76, 4, -25, True, "G"),
    (["A", "E", "F#m" if False else "Bm", "D"] * 2, 132, 4, 0, True, "A"),
    (["Am", "G", "F", "E"] * 2, 90, 4, 0, True, "Am"),
    (["D", "A", "Bm", "G"] * 2, 108, 2, 15, True, "D"),
    (["Em", "Am", "D7", "G"] * 2, 68, 4, 0, True, "G"),
]
def truth_at(prog, bpc, bpm, t):
    return prog[min(int(t / (bpc * 60 / bpm)), len(prog) - 1)]
CACHE = {}
def feats(k):
    if k not in CACHE:
        prog, bpm, bpc, cents, mel, key = SUITE[k]
        synth.rng = np.random.default_rng(100 + k)
        y = synth.make_song(prog, bpm=bpm, beats_per_chord=bpc, cents=cents)
        if mel: y = synth.add_melody(y, prog, bpm, bpc); y = (y / (np.abs(y).max() + 1e-9)).astype(np.float32)
        CACHE[k] = (y, engine.features(y))
    return CACHE[k]
TRIADS = [0, 1, 4, 5, 6, 7, 8]
def evaluate(precise=True, verbose=False, only=None, **kw):
    accs, bpmok, keyok = [], 0, 0
    for k, (prog, bpm, bpc, cents, mel, key) in enumerate(SUITE):
        if only is not None and k not in only: continue
        y, F = feats(k)
        r = engine.decode(F, precise=precise, **kw)
        bc = bpc * 60 / bpm; ok = tot = 0
        for t in np.arange(0.2, len(y) / synth.SR - 0.2, 0.05):
            d = (t % bc); 
            if d < 0.3 or bc - d < 0.3: continue
            seg = [s for s in r["segs"] if s[0] <= t < s[1]]
            tot += 1; ok += bool(seg) and seg[0][2] == truth_at(prog, bpc, bpm, t)
        acc = ok / tot; accs.append(acc)
        good = abs(r["bpm"] - bpm) < 2.5; bpmok += good
        kn = engine.NOTE[r["key"][0]] + ("m" if r["key"][1] else ""); keyok += kn == key
        if verbose:
            print(f"{k}: acc {acc*100:3.0f}%  bpm {r['bpm']:.1f}/{bpm} {'ok' if good else 'XX'}  key {kn}/{key}  tun {r['tuning']:+.2f}")
    return np.mean(accs), bpmok, keyok
if __name__ == "__main__":
    for precise in (False, True):
        m, b, kk = evaluate(precise, verbose=True, only=(None if precise else TRIADS))
        print("precise" if precise else "basic", f"mean acc {m*100:.1f}%  bpm {b}/{len(SUITE)}  key {kk}/{len(SUITE)}\n")
