import numpy as np
SR = 11025
rng = np.random.default_rng(7)
def midi_hz(m): return 440.0 * 2 ** ((m - 69) / 12)

def pluck(freq, dur, sr=SR, decay=2.2):
    t = np.arange(int(dur * sr)) / sr
    out = np.zeros_like(t)
    for h in range(1, 9):
        if freq * h > sr / 2 - 200: break
        amp = (1.0 / h ** 1.1) * (1 if h < 6 else 0.6)
        out += amp * np.sin(2 * np.pi * freq * h * (1 + 0.0002 * h * h) * t + rng.uniform(0, 6.28)) * np.exp(-t * (decay + 0.7 * h))
    return out * (1 - np.exp(-t * 400))

def pluck_ks(freq, dur, sr=SR, decay=2.2):
    """Karplus-Strong-ish plucked string (guitar-like harmonics)."""
    n = int(dur * sr)
    N = int(sr / freq)
    buf = rng.uniform(-1, 1, N)
    out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % N]
        buf[i % N] = 0.5 * (buf[i % N] + buf[(i + 1) % N]) * 0.996
    return out

# guitar shapes as MIDI notes (standard tuning E2 A2 D3 G3 B3 E4 = 40 45 50 55 59 64)
OPEN = [40, 45, 50, 55, 59, 64]
SHAPES = {  # name -> frets (-1 muted)
    "F#m": [2, 4, 4, 2, 2, 2], "D": [-1, -1, 0, 2, 3, 2], "G": [3, 2, 0, 0, 0, 3], "A": [-1, 0, 2, 2, 2, 0],
    "Em": [0, 2, 2, 0, 0, 0], "C": [-1, 3, 2, 0, 1, 0], "Am": [-1, 0, 2, 2, 1, 0], "F": [1, 3, 3, 2, 1, 1],
    "Dm": [-1, -1, 0, 2, 3, 1], "E": [0, 2, 2, 1, 0, 0], "Bm": [-1, 2, 4, 4, 3, 2], "A7": [-1, 0, 2, 0, 2, 0],
    "Cmaj7": [-1, 3, 2, 0, 0, 0], "Am7": [-1, 0, 2, 0, 1, 0], "G7": [3, 2, 0, 0, 0, 1], "D7": [-1, -1, 0, 2, 1, 2],
    "Bb": [-1, 1, 3, 3, 3, 1], "Em7": [0, 2, 0, 0, 0, 0],
}
def strum(name, dur, vel=1.0, cents=0.0, rate=0.012):
    y = np.zeros(int(dur * SR) + SR)
    for s, fr in enumerate(SHAPES[name]):
        if fr < 0: continue
        m = OPEN[s] + fr + cents / 100.0
        tone = pluck(midi_hz(m), dur + 0.3)
        t0 = int(s * rate * SR)
        y[t0:t0 + len(tone)] += tone[: len(y) - t0] * vel
    return y[: int(dur * SR)]

def kick(n=2200):
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * (60 + 90 * np.exp(-t * 30)) * t) * np.exp(-t * 14) * 0.6

def hat(n=700):
    return rng.normal(0, 1, n) * np.exp(-np.arange(n) / 120) * 0.15

def make_song(prog, bpm=112, beats_per_chord=4, strum_every=1, cents=0.0, noise=0.02, kicks=True):
    """prog: list of chord names, each lasts beats_per_chord beats. Strum on every `strum_every` beats."""
    beat = 60.0 / bpm
    total = len(prog) * beats_per_chord * beat + 1.0
    y = np.zeros(int(total * SR) + SR)
    for ci, name in enumerate(prog):
        for b in range(0, beats_per_chord, strum_every):
            t = (ci * beats_per_chord + b) * beat
            x = strum(name, beat * strum_every * 1.0, vel=1.0 if b == 0 else 0.7, cents=cents)
            i0 = int(t * SR); y[i0:i0 + len(x)] += x
    if kicks:
        nb = int(total / beat)
        for b in range(nb):
            k = kick() if b % 2 == 0 else hat() * 2
            i0 = int(b * beat * SR); y[i0:i0 + len(k)] += k[: len(y) - i0]
    y += rng.normal(0, noise, len(y))
    y /= np.max(np.abs(y)) + 1e-9
    return y[: int(total * SR)].astype(np.float32)


def add_melody(y, prog, bpm, bpc, root_midi=69, level=0.5):
    beat = 60.0 / bpm
    n_notes = int(len(y) / SR / (beat * 0.5))
    for i in range(n_notes):
        if rng.random() < 0.35: continue
        m = root_midi + int(rng.choice([-5, -3, -1, 0, 2, 4, 7]))
        t = i * beat * 0.5
        tone = pluck(midi_hz(m), 0.5, decay=3.0) * level
        i0 = int(t * SR)
        if i0 + len(tone) < len(y): y[i0:i0 + len(tone)] += tone
    return y
