# FLAC reference

`flac_mirror.py` is the Python version of `FlacSink` (app/src/main/java/com/songbook/app/recording/Sinks.kt), step for
step. `test_flac.py` encodes test sounds with it (silence, noise, clipping, odd lengths, mono and stereo), decodes the
files with `ffmpeg` and checks that every sample comes back identical. Needs `numpy` and `ffmpeg`.
If you change the encoder, change it here first and run the test. Run it from this folder: `python test_flac.py`.
