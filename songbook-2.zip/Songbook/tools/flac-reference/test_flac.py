import subprocess, struct, math, random, os, sys
pass
import numpy as np, flac_mirror as fm
random.seed(1)
def tone(n, rate, ch):
    t = np.arange(n) / rate
    y = 9000 * np.sin(2 * math.pi * 220 * t) + 5000 * np.sin(2 * math.pi * 330 * t + 1) + np.random.default_rng(3).normal(0, 300, n)
    y[int(0.2 * n):int(0.3 * n)] = 0                       # digital silence (constant subframes)
    m = min(3000, n // 4)
    y[int(0.5 * n):int(0.5 * n) + m] = np.random.default_rng(4).integers(-32768, 32767, m)   # loud noise (verbatim / big residuals)
    y[int(0.7 * n):int(0.7 * n) + min(50, n // 10)] = 32767              # clipping run
    y = np.clip(y, -32768, 32767).astype(np.int16)
    if ch == 2: y = np.stack([y, np.roll(y, 7) // 2], axis=1)
    return y
def run(name, n, rate, ch):
    y = tone(n, rate, ch)
    inter = [int(v) for v in y.reshape(-1)]
    data = fm.encode_flac(inter, ch, rate)
    open("t.flac", "wb").write(data)
    out = subprocess.run(["ffmpeg", "-v", "error", "-i", "t.flac", "-f", "s16le", "-acodec", "pcm_s16le", "-"], capture_output=True)
    back = np.frombuffer(out.stdout, dtype=np.int16)
    ok = len(back) == len(inter) and np.array_equal(back, np.array(inter, dtype=np.int16))
    probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=sample_rate,channels,duration", "-of", "csv=p=0", "t.flac"], capture_output=True, text=True).stdout.strip()
    print(f"{name:28s} identical={ok}  err={out.stderr.decode()[:80]!r}  raw {len(inter)*2/1e3:.0f} kB -> {len(data)/1e3:.0f} kB  probe={probe}")
run("mono 48k 3.0 s", 144000, 48000, 1)
run("stereo 48k 2.5 s (odd tail)", 120013, 48000, 2)
run("mono 44.1k tiny (100 samples)", 100, 44100, 1)
run("stereo 44.1k 5000 samples", 5000, 44100, 2)
run("mono exactly 4096", 4096, 44100, 1)
run("mono 4097", 4097, 44100, 1)
run("stereo 8192", 8192, 48000, 2)
run("mono 7 samples", 7, 48000, 1)
