"""Reference for the Kotlin FlacSink: same steps, same integer arithmetic."""
import hashlib, struct, math

def crc8(data):
    c = 0
    for b in data:
        c ^= b
        for _ in range(8):
            c = ((c << 1) ^ 0x07) & 0xFF if c & 0x80 else (c << 1) & 0xFF
    return c

def crc16(data):
    c = 0
    for b in data:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x8005) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return c

class BitWriter:
    def __init__(self): self.buf = bytearray(); self.acc = 0; self.n = 0
    def bits(self, value, count):
        for i in range(count - 1, -1, -1):
            self.acc = (self.acc << 1) | ((value >> i) & 1); self.n += 1
            if self.n == 8: self.buf.append(self.acc); self.acc = 0; self.n = 0
    def unary(self, q):
        for _ in range(q): self.bits(0, 1)
        self.bits(1, 1)
    def align(self):
        while self.n != 0: self.bits(0, 1)
    def bytes(self): return bytes(self.buf)

def utf8_num(v):
    if v < 0x80: return bytes([v])
    if v < 0x800: n = 2
    elif v < 0x10000: n = 3
    elif v < 0x200000: n = 4
    elif v < 0x4000000: n = 5
    else: n = 6
    out = []
    for _ in range(n - 1): out.append(0x80 | (v & 0x3F)); v >>= 6
    first = ((0xFF00 >> n) & 0xFF) | v
    out.append(first)
    return bytes(reversed(out))

def zigzag(r): return (r << 1) ^ (r >> 31) if r >= 0 else ((-r) << 1) - 1

def residuals(x, order):
    n = len(x)
    if order == 0: return list(x)
    out = []
    for i in range(order, n):
        if order == 1: r = x[i] - x[i-1]
        elif order == 2: r = x[i] - 2*x[i-1] + x[i-2]
        elif order == 3: r = x[i] - 3*x[i-1] + 3*x[i-2] - x[i-3]
        else: r = x[i] - 4*x[i-1] + 6*x[i-2] - 4*x[i-3] + x[i-4]
        out.append(r)
    return out

def rice_bits(us, k):
    return sum((u >> k) + 1 + k for u in us)

def best_k(us):
    if not us: return 0
    mean = sum(us) // len(us)
    k0 = 0
    while (1 << (k0 + 1)) <= mean + 1 and k0 < 14: k0 += 1
    best, bk = None, 0
    for k in range(max(0, k0 - 1), min(14, k0 + 1) + 1):
        c = rice_bits(us, k)
        if best is None or c < best: best, bk = c, k
    return bk

def pick_partition_order(us, n, order):
    """approximate: choose the partition order with the fewest estimated bits."""
    best, bp = None, 0
    for po in range(0, 7):
        if n % (1 << po) != 0 or (n >> po) <= order: break
        size = n >> po
        total = 4 * (1 << po)
        pos = 0
        for p in range(1 << po):
            cnt = size - order if p == 0 else size
            part = us[pos:pos + cnt]; pos += cnt
            s = sum(part)
            mean = s // max(1, cnt)
            k = 0
            while (1 << (k + 1)) <= mean + 1 and k < 14: k += 1
            total += cnt * (k + 1) + (s >> k)
        if best is None or total < best: best, bp = total, po
    return bp

def encode_subframe(bw, x):
    n = len(x)
    if all(v == x[0] for v in x):
        bw.bits(0, 1); bw.bits(0, 6); bw.bits(0, 1); bw.bits(x[0] & 0xFFFF, 16); return
    best_order, best_sum = 0, None
    for order in range(0, min(4, n - 1) + 1):
        res = residuals(x, order)
        s = sum(abs(r) for r in res)
        if best_sum is None or s < best_sum: best_sum, best_order = s, order
    order = best_order
    res = residuals(x, order)
    us = [zigzag(r) for r in res]
    po = pick_partition_order(us, n, order)
    size = n >> po
    # exact cost to compare with verbatim
    parts = []
    pos = 0
    bits = 8 + order * 16 + 2 + 4
    for p in range(1 << po):
        cnt = size - order if p == 0 else size
        part = us[pos:pos + cnt]; pos += cnt
        k = best_k(part)
        parts.append((k, part))
        bits += 4 + rice_bits(part, k)
    if bits >= 8 + n * 16:
        bw.bits(0, 1); bw.bits(1, 6); bw.bits(0, 1)
        for v in x: bw.bits(v & 0xFFFF, 16)
        return
    bw.bits(0, 1); bw.bits(8 + order, 6); bw.bits(0, 1)
    for i in range(order): bw.bits(x[i] & 0xFFFF, 16)
    bw.bits(0, 2); bw.bits(po, 4)
    for k, part in parts:
        bw.bits(k, 4)
        for u in part:
            bw.unary(u >> k)
            if k: bw.bits(u & ((1 << k) - 1), k)

def encode_frame(chs, frame_no, rate):
    n = len(chs[0]); ch = len(chs)
    hdr = bytearray([0xFF, 0xF8])
    hdr.append(((12 if n == 4096 else 7) << 4) | 0)
    hdr.append(((ch - 1) << 4) | (4 << 1))
    hdr += utf8_num(frame_no)
    if n != 4096: hdr += struct.pack(">H", n - 1)
    hdr.append(crc8(bytes(hdr)))
    bw = BitWriter()
    for x in chs: encode_subframe(bw, x)
    bw.align()
    body = bytes(hdr) + bw.bytes()
    return body + struct.pack(">H", crc16(body))

def streaminfo(rate, ch, total, min_b, max_b, min_f, max_f, md5):
    packed = (rate << 44) | ((ch - 1) << 41) | (15 << 36) | total
    return (struct.pack(">HH", min_b, max_b) + min_f.to_bytes(3, "big") + max_f.to_bytes(3, "big")
            + packed.to_bytes(8, "big") + md5)

def encode_flac(samples, ch, rate):
    """samples: list of interleaved int16."""
    total = len(samples) // ch
    frames = []
    md5 = hashlib.md5(struct.pack("<%dh" % len(samples), *samples)).digest()
    pos, no = 0, 0
    sizes = []
    while pos < total:
        n = min(4096, total - pos)
        chs = [[samples[(pos + i) * ch + c] for i in range(n)] for c in range(ch)]
        f = encode_frame(chs, no, rate)
        frames.append(f); sizes.append(len(f)); pos += n; no += 1
    min_b = 4096 if total >= 4096 else total
    info = streaminfo(rate, ch, total, min_b, 4096 if total >= 4096 else total, min(sizes), max(sizes), md5)
    return b"fLaC" + bytes([0x80, 0, 0, 34]) + info + b"".join(frames)
