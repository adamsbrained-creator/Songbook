# Songbook 3.2 - Paperback polish (not yet compiled)

## 3.2 changes (Coral look only; Old and Glass are untouched)
- Dialogs copy Paperback's PbDialog: big rounded card, serif title, Cancel pill + solid confirm pill (`CoralDialog` in `Dialogs.kt`)
- Text fields are filled and outline-free (`SbField` in `Fields.kt`, drop-in for OutlinedTextField)
- Segmented control is a soft track with a raised white thumb; switch has a lifted thumb on a softer off track
- Cards are flat with no hairline; settings dividers stop short of the card edges; section labels use Paperback's spacing
- Top bar: lighter wordmark, page name is a small label under it, 22dp icons

First `./gradlew assembleDebug` may still show small errors (nothing could be compiled here). Likeliest spots: `Dialogs.kt` imports, `Fields.kt`.

# Songbook 3.1 - new header and icon

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.
