# Songbook 3.9 - Analyze a song's demos, zoomed timeline (not yet compiled)

## 3.9 changes
- A demo recorded in a song has "Find chords" in its menu: the analyzer opens on it and starts at once (no copy is made, the demo is never deleted). Then "Add the chords to this song" adds the chord chart to the end of the song's text; "Save as song" still makes a new one. Route: `analyzer?file=&title=&song=` in `SongbookRoot.kt`
- The analyzer has a second, zoomed timeline: the 12 seconds around the playhead scroll by as the song plays, with the chords as blocks, the loudness, the beats and a fixed playhead in the middle; drag it to move through the song (`ZoomTimeline` in `AnalyzerScreen.kt`)
- Version 3.9

# Songbook 3.8 - Chord analyzer

## 3.8 changes
- New: Chord analyzer (menu > Chord analyzer, or Settings > Library > Chord Analyzer). Pick an audio file; it is decoded and analysed on the phone (nothing is uploaded) and shows the key, the tempo, the length, a timeline with the chords over the loudness curve, the chord now playing and the next one with guitar chord diagrams, the chords used, and a bar-by-bar chord chart. Play / pause, +-5 s, 1x / 0.75x / 0.5x, tap the timeline or a chart cell to jump. Basic (major and minor) or Precise (also 7, maj7, m7, sus4, sus2), 3 or 4 beats to a bar, tempo as found / x2 / half, transpose. "Save as song" makes a song with the chords, key and BPM; "Copy chords" puts the chart on the clipboard
- Code: `analysis/ChordEngine.kt` (chroma, tempo, key, templates, Viterbi), `analysis/AudioDecoder.kt` (MediaCodec to 11025 Hz mono), `analysis/GuitarShapes.kt`, `analysis/ChordNames.kt`, `ui/screens/AnalyzerScreen.kt`
- `tools/chord-engine-prototype/` is the Python version the engine was tuned in (10 synthetic test songs: about 95% Basic, 89% Precise, tempo 10/10, key 8/10). Real recordings will be harder
- The menu card scrolls on small screens; Version 3.8

# Songbook 3.7 - Outfit weights and more pages

## 3.7 changes
- Outfit now has all four weights: Regular and Bold are the original files, Medium (500) and SemiBold (600) are blended from them (`res/font/outfit_medium.ttf`, `outfit_semibold.ttf`, made by `tools/make_outfit_weights.py`). Before, Medium used the Regular file and SemiBold the Bold file. Drop the official Outfit Medium and SemiBold files over the two new ones (same names) to replace the blend
- Coral: the songwriting desk and the song editor get round header buttons, a plain title, and a gray "Edit text" pill / black "Done" pill
- Version 3.7

# Songbook 3.6 - Glassy home layout for Coral

## 3.6 changes
- New option Settings > Look > Home Layout (Coral only): Classic (default, unchanged) or Glassy. Glassy gives the Coral look the Glass look's main page: a big greeting with the tagline, the search box always shown, the pinned albums and recent songs as horizontal rows of plain tiles, then the songs. The Coral top bar, bottom bar and menu stay. Stored as `coralHome` (0 or 1); `Blocks.home(Glass)` supplies the default block order, so "Customize this page" works for it too (`CoralLibrary` in `LibraryScreen.kt`)
- Version 3.6

# Songbook 3.5 - Settings pages and empty states

## 3.5 changes (Coral look only)
- Settings is a short list of groups (Look, Library, Profile, Appearance, Layout, Sorting, Pages, Reading, Song Display, Data, About), each opening as its own page; Back or the arrow returns to the list (`SettingsGroup` + `SettingsNav` in `Common.kt`, state in `SettingsScreen.kt`)
- An empty library shows Paperback's empty card with a "New song" button (`CoralEmptyCard`)
- The Workflow page has the same header as the other pages, with "+ Idea" next to its title
- Version 3.5

# Songbook 3.4 - Paperback navigation and gestures

## 3.4 changes (Coral look only)
- Navigation like Paperback: the header's menu button opens a card of pages above a round close button; "More" opens a sheet with this page's actions and every page (`components/NavMenu.kt`, wired in `SongbookRoot.kt`)
- The plus button stays on Songs and Albums; "New song" is also the first row of the menu
- Gestures from Paperback 34 (`components/SwipeHost.kt`): swipe right to go back, swipe left or right on a main page to move between Songs, Albums, Favorites and Settings. Off in the reader and the editors. Two switches in Settings: "Swipe to Go Back", "Swipe Between Pages"
- Long press on a song row opens its menu
- Selected chips use the accent color; search is a big filled pill; "Sort: ..." and "View: ..." pills replace the two icon buttons; Albums and Favorites get the count pill
- Album tiles are a cover with the name under it, no card; album, group and reader pages use the wordmark with a small label under it
- Version 3.4

# Songbook 3.3 - closer to Paperback

## 3.3 changes (Coral look only)
- Paperback's palette: white page with soft gray (#F3F3F3) cards; black page and #161616 cards in dark (`theme/Theme.kt`)
- Bottom bar like Paperback's, with a soft pill on the current page, the plus button above it (`CoralBottomBar` in `Chrome.kt`)
- Header: lighter wordmark, the page name as a 16 sp label with a pill on the right ("24 songs" on the main page), rounded menu with icons
- Settings rows: an icon tile, the label, the value and a chevron, with the line starting under the label (`SettingsRow` in `Common.kt`)
- Main page: the pinned albums are a plain two-column grid, cover with the name and song count under it, no card (`albumsGrid` in `LibraryScreen.kt`)
- Version 3.3

# Songbook 3.2 - Paperback polish

## Build
One workflow now, like Eon: key in the repo (`app/debug.keystore`), builds loose files or a zip, APK in the run's Artifacts. See SIGNING.md.

## 3.2 changes (Coral look only; Old and Glass are untouched)
- Dialogs copy Paperback's PbDialog: big rounded card, serif title, Cancel pill + solid confirm pill (`CoralDialog` in `Dialogs.kt`)
- Text fields are filled and outline-free (`SbField` in `Fields.kt`, drop-in for OutlinedTextField)
- Segmented control is a soft track with a raised white thumb; switch has a lifted thumb on a softer off track
- Cards are flat with no hairline; settings dividers stop short of the card edges; section labels use Paperback's spacing
- Top bar: lighter wordmark, page name is a small label under it, 22dp icons

First `./gradlew assembleDebug` may still show small errors (nothing could be compiled here). Likeliest spots: `Dialogs.kt` imports, `Fields.kt`.

# Songbook 3.1 - new header and icon

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.
