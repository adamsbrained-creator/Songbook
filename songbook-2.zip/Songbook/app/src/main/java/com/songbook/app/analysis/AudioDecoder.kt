package com.songbook.app.analysis

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Turns an audio file (mp3, m4a, ogg, wav, flac... whatever the phone can play) into mono samples at
 * [ChordEngine.SR] Hz, using the phone's own decoder. Nothing is uploaded anywhere.
 */
object AudioDecoder {
    /** Recordings longer than this are cut off (the first part is analysed). */
    const val MAX_SECONDS = 600

    /** A growing list of floats without boxing. */
    private class FloatBuf {
        var data = FloatArray(1 shl 20)
        var size = 0
        fun add(v: Float) {
            if (size == data.size) data = data.copyOf(data.size * 2)
            data[size++] = v
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    /** A second-order low-pass filter, run twice to get a steeper cut before the sample rate is lowered. */
    private class Biquad(fs: Double, fc: Double, q: Double) {
        private val b0: Double
        private val b1: Double
        private val b2: Double
        private val a1: Double
        private val a2: Double
        private var x1 = 0.0
        private var x2 = 0.0
        private var y1 = 0.0
        private var y2 = 0.0

        init {
            val w0 = 2.0 * PI * fc / fs
            val alpha = sin(w0) / (2.0 * q)
            val cosw = cos(w0)
            val a0 = 1.0 + alpha
            b0 = (1.0 - cosw) / 2.0 / a0
            b1 = (1.0 - cosw) / a0
            b2 = (1.0 - cosw) / 2.0 / a0
            a1 = -2.0 * cosw / a0
            a2 = (1.0 - alpha) / a0
        }

        fun process(x: Double): Double {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            return y
        }
    }

    /**
     * [onProgress] gets 0..1 (how much of the file is read), [cancelled] is polled. Returns null when cancelled.
     * Throws an exception with a readable message when the file cannot be read.
     */
    fun decode(context: Context, uri: Uri, onProgress: (Float) -> Unit, cancelled: () -> Boolean): FloatArray? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) throw IllegalStateException("This file has no audio in it.")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw IllegalStateException("Unknown audio format.")
            var srcRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            val out = FloatBuf()
            val maxOut = ChordEngine.SR * MAX_SECONDS
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            // streaming resampler: two low-pass filters, then linear interpolation at the new rate
            var lp1 = Biquad(srcRate.toDouble(), 4500.0, 0.5412)
            var lp2 = Biquad(srcRate.toDouble(), 4500.0, 1.3066)
            var filter = srcRate > ChordEngine.SR * 1.1
            var step = srcRate.toDouble() / ChordEngine.SR
            var nextPos = 0.0
            var index = 0L
            var prev = 0.0

            while (!outputDone) {
                if (cancelled()) return null
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = c.getInputBuffer(inIdx)
                        val n = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = c.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    val buf = c.getOutputBuffer(outIdx)
                    if (buf != null && info.size > 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val shorts = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = shorts.remaining() / channels
                        for (i in 0 until frames) {
                            var sum = 0.0
                            for (ch in 0 until channels) sum += shorts.get() / 32768.0
                            var s = sum / channels
                            if (filter) s = lp2.process(lp1.process(s))
                            // emit every output sample that falls between the previous input sample and this one
                            while (nextPos <= index) {
                                val frac = nextPos - (index - 1)
                                out.add((prev + (s - prev) * frac).toFloat())
                                nextPos += step
                            }
                            prev = s
                            index++
                        }
                        if (durationUs > 0) {
                            val done = (info.presentationTimeUs.toDouble() / durationUs).coerceIn(0.0, 1.0)
                            onProgress(done.toFloat())
                        }
                    }
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    c.releaseOutputBuffer(outIdx, false)
                    if (out.size >= maxOut) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    val newRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (newRate != srcRate) {
                        srcRate = newRate
                        lp1 = Biquad(srcRate.toDouble(), 4500.0, 0.5412)
                        lp2 = Biquad(srcRate.toDouble(), 4500.0, 1.3066)
                        filter = srcRate > ChordEngine.SR * 1.1
                        step = srcRate.toDouble() / ChordEngine.SR
                        nextPos = index.toDouble()
                    }
                }
            }
            onProgress(1f)
            if (out.size < ChordEngine.SR) throw IllegalStateException("Could not read any audio from this file.")
            return out.toArray()
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }
}
