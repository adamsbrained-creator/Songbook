package com.songbook.app.recording

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteOrder
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.min

/** Where the recorded samples go: a file in one format. [count] is a number of shorts (all channels together). */
interface PcmSink {
    fun write(samples: ShortArray, count: Int)

    /** Finishes the file. Throws when the file is not usable. */
    fun finish()

    /** Gives up: closes everything, the caller deletes the file. */
    fun abort()
}

// ---------------------------------------------------------------------- WAV

/** An exact copy of the sound: 16-bit samples behind a 44-byte header that is filled in at the end. */
class WavSink(file: File, private val rate: Int, private val channels: Int) : PcmSink {
    private val raf = RandomAccessFile(file, "rw")
    private var dataBytes = 0L
    private var chunk = ByteArray(0)

    init {
        raf.setLength(0)
        raf.write(ByteArray(44))
    }

    override fun write(samples: ShortArray, count: Int) {
        if (chunk.size < count * 2) chunk = ByteArray(count * 2)
        for (i in 0 until count) {
            val v = samples[i].toInt()
            chunk[i * 2] = v.toByte()
            chunk[i * 2 + 1] = (v shr 8).toByte()
        }
        raf.write(chunk, 0, count * 2)
        dataBytes += count * 2L
    }

    private fun le32(v: Long) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
    private fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())

    override fun finish() {
        if (dataBytes < rate) throw IllegalStateException("The recording is too short.")
        val h = java.io.ByteArrayOutputStream()
        h.write("RIFF".toByteArray())
        h.write(le32(36 + dataBytes))
        h.write("WAVE".toByteArray())
        h.write("fmt ".toByteArray())
        h.write(le32(16))
        h.write(le16(1))
        h.write(le16(channels))
        h.write(le32(rate.toLong()))
        h.write(le32(rate.toLong() * channels * 2))
        h.write(le16(channels * 2))
        h.write(le16(16))
        h.write("data".toByteArray())
        h.write(le32(dataBytes))
        raf.seek(0)
        raf.write(h.toByteArray())
        raf.close()
    }

    override fun abort() {
        runCatching { raf.close() }
    }
}

// ---------------------------------------------------------------------- AAC and Opus

/** A compressed file made with the phone's own encoder: AAC in an .m4a, or Opus in an .ogg. */
class CodecSink(
    file: File, private val mime: String, muxerFormat: Int,
    private val rate: Int, private val channels: Int, bitRate: Int
) : PcmSink {
    private val muxer: MediaMuxer = MediaMuxer(file.path, muxerFormat)
    private val codec: MediaCodec = try {
        MediaCodec.createEncoderByType(mime)
    } catch (e: Exception) {
        runCatching { muxer.release() }
        throw e
    }
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var muxerStarted = false
    private var frames = 0L

    init {
        try {
            val fmt = MediaFormat.createAudioFormat(mime, rate, channels)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            }
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
        } catch (e: Exception) {
            runCatching { codec.release() }
            runCatching { muxer.release() }
            throw e
        }
    }

    override fun write(samples: ShortArray, count: Int) {
        var off = 0
        while (off < count) {
            val idx = codec.dequeueInputBuffer(20_000)
            if (idx < 0) {
                drain(false)
                continue
            }
            val buf = codec.getInputBuffer(idx) ?: continue
            buf.clear()
            buf.order(ByteOrder.nativeOrder())
            val fit = min(count - off, buf.capacity() / 2)
            val take = fit - fit % channels
            if (take <= 0) {
                codec.queueInputBuffer(idx, 0, 0, frames * 1_000_000L / rate, 0)
                continue
            }
            buf.asShortBuffer().put(samples, off, take)
            codec.queueInputBuffer(idx, 0, take * 2, frames * 1_000_000L / rate, 0)
            frames += take / channels
            off += take
            drain(false)
        }
    }

    private fun drain(endOfStream: Boolean) {
        var waits = 0
        while (true) {
            val idx = codec.dequeueOutputBuffer(info, 10_000)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) return
                    if (++waits > 500) throw IllegalStateException("The encoder did not finish.")
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    track = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    muxerStarted = true
                }
                idx >= 0 -> {
                    val data = codec.getOutputBuffer(idx)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && muxerStarted && data != null) {
                        data.position(info.offset)
                        data.limit(info.offset + info.size)
                        muxer.writeSampleData(track, data, info)
                    }
                    codec.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    override fun finish() {
        try {
            val idx = codec.dequeueInputBuffer(200_000)
            if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, frames * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            if (!muxerStarted) throw IllegalStateException("Nothing was recorded.")
            muxer.stop()
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            runCatching { muxer.release() }
        }
    }

    override fun abort() {
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { muxer.release() }
    }
}

// ---------------------------------------------------------------------- FLAC

/**
 * FLAC: an exact copy of the sound, compressed. Written by the app itself (Android has no FLAC recorder):
 * blocks of 4096 samples, each channel predicted from the samples before it (fixed predictors of order 0 to 4) and
 * the difference stored with Rice codes. Checked against ffmpeg: decodes to exactly the same samples.
 */
class FlacSink(file: File, private val rate: Int, private val channels: Int) : PcmSink {
    private companion object {
        const val BLOCK = 4096
        val CRC8 = IntArray(256) { i ->
            var c = i
            repeat(8) { c = if ((c and 0x80) != 0) ((c shl 1) xor 0x07) and 0xFF else (c shl 1) and 0xFF }
            c
        }
        val CRC16 = IntArray(256) { i ->
            var c = i shl 8
            repeat(8) { c = if ((c and 0x8000) != 0) ((c shl 1) xor 0x8005) and 0xFFFF else (c shl 1) and 0xFFFF }
            c
        }
    }

    private val raf = RandomAccessFile(file, "rw")
    private val md5 = MessageDigest.getInstance("MD5")
    private val pending = Array(channels) { IntArray(BLOCK) }
    private var filled = 0
    private var frameNo = 0L
    private var total = 0L
    private var minFrame = Int.MAX_VALUE
    private var maxFrame = 0
    private var md5Buf = ByteArray(0)

    init {
        raf.setLength(0)
        raf.write(ByteArray(42))          // "fLaC", the block header and STREAMINFO, filled in at the end
    }

    override fun write(samples: ShortArray, count: Int) {
        val usable = count - count % channels
        if (md5Buf.size < usable * 2) md5Buf = ByteArray(usable * 2)
        for (i in 0 until usable) {
            val v = samples[i].toInt()
            md5Buf[i * 2] = v.toByte()
            md5Buf[i * 2 + 1] = (v shr 8).toByte()
        }
        md5.update(md5Buf, 0, usable * 2)
        var i = 0
        while (i < usable) {
            for (c in 0 until channels) pending[c][filled] = samples[i + c].toInt()
            filled++
            i += channels
            if (filled == BLOCK) {
                encodeBlock(BLOCK)
                filled = 0
            }
        }
    }

    override fun finish() {
        if (filled > 0) {
            encodeBlock(filled)
            filled = 0
        }
        if (total < 16) throw IllegalStateException("The recording is too short.")
        val minBlock = if (total >= BLOCK) BLOCK else total.toInt()
        val info = ByteArray(34)
        fun put(pos: Int, v: Long, n: Int) {
            for (j in 0 until n) info[pos + j] = (v shr (8 * (n - 1 - j))).toByte()
        }
        put(0, minBlock.toLong(), 2)
        put(2, minBlock.toLong(), 2)
        put(4, minFrame.toLong(), 3)
        put(7, maxFrame.toLong(), 3)
        val packed = (rate.toLong() shl 44) or ((channels - 1).toLong() shl 41) or (15L shl 36) or total
        put(10, packed, 8)
        System.arraycopy(md5.digest(), 0, info, 18, 16)
        raf.seek(0)
        raf.write(byteArrayOf('f'.code.toByte(), 'L'.code.toByte(), 'a'.code.toByte(), 'C'.code.toByte(), 0x80.toByte(), 0, 0, 34))
        raf.write(info)
        raf.close()
    }

    override fun abort() {
        runCatching { raf.close() }
    }

    // ---- one block

    private class Bits {
        var buf = ByteArray(16 * 1024)
        var len = 0
        private var acc = 0
        private var n = 0

        fun bits(value: Int, count: Int) {
            for (i in count - 1 downTo 0) {
                acc = (acc shl 1) or ((value shr i) and 1)
                if (++n == 8) {
                    if (len == buf.size) buf = buf.copyOf(buf.size * 2)
                    buf[len++] = acc.toByte()
                    acc = 0
                    n = 0
                }
            }
        }

        fun unary(q: Int) {
            for (i in 0 until q) bits(0, 1)
            bits(1, 1)
        }

        fun align() {
            while (n != 0) bits(0, 1)
        }
    }

    private fun encodeBlock(n: Int) {
        val head = ArrayList<Byte>()
        head.add(0xFF.toByte())
        head.add(0xF8.toByte())
        head.add((((if (n == BLOCK) 12 else 7) shl 4)).toByte())
        head.add((((channels - 1) shl 4) or (4 shl 1)).toByte())
        for (b in utf8Number(frameNo)) head.add(b)
        if (n != BLOCK) {
            head.add(((n - 1) shr 8).toByte())
            head.add((n - 1).toByte())
        }
        val header = head.toByteArray()
        var c8 = 0
        for (b in header) c8 = CRC8[c8 xor (b.toInt() and 0xFF)]

        val bw = Bits()
        for (c in 0 until channels) subframe(bw, pending[c], n)
        bw.align()

        var c16 = 0
        fun crc(b: Int) {
            c16 = ((c16 shl 8) and 0xFFFF) xor CRC16[((c16 shr 8) xor b) and 0xFF]
        }
        for (b in header) crc(b.toInt() and 0xFF)
        crc(c8)
        for (i in 0 until bw.len) crc(bw.buf[i].toInt() and 0xFF)

        raf.write(header)
        raf.write(c8)
        raf.write(bw.buf, 0, bw.len)
        raf.write(c16 shr 8)
        raf.write(c16 and 0xFF)
        val size = header.size + 1 + bw.len + 2
        if (size < minFrame) minFrame = size
        if (size > maxFrame) maxFrame = size
        total += n
        frameNo++
    }

    private fun utf8Number(value: Long): ByteArray {
        var v = value
        if (v < 0x80) return byteArrayOf(v.toByte())
        val n = when {
            v < 0x800 -> 2
            v < 0x10000 -> 3
            v < 0x200000 -> 4
            v < 0x4000000 -> 5
            else -> 6
        }
        val out = ByteArray(n)
        for (i in n - 1 downTo 1) {
            out[i] = (0x80 or (v and 0x3F).toInt()).toByte()
            v = v shr 6
        }
        out[0] = ((((0xFF00 shr n) and 0xFF)) or v.toInt()).toByte()
        return out
    }

    private fun residuals(x: IntArray, n: Int, order: Int): IntArray {
        val out = IntArray(n - order)
        for (i in order until n) {
            out[i - order] = when (order) {
                0 -> x[i]
                1 -> x[i] - x[i - 1]
                2 -> x[i] - 2 * x[i - 1] + x[i - 2]
                3 -> x[i] - 3 * x[i - 1] + 3 * x[i - 2] - x[i - 3]
                else -> x[i] - 4 * x[i - 1] + 6 * x[i - 2] - 4 * x[i - 3] + x[i - 4]
            }
        }
        return out
    }

    private fun riceBits(us: IntArray, from: Int, to: Int, k: Int): Long {
        var s = 0L
        for (i in from until to) s += (us[i] shr k) + 1 + k
        return s
    }

    private fun bestK(us: IntArray, from: Int, to: Int): Int {
        val cnt = to - from
        if (cnt <= 0) return 0
        var sum = 0L
        for (i in from until to) sum += us[i]
        val mean = sum / cnt
        var k0 = 0
        while ((1L shl (k0 + 1)) <= mean + 1 && k0 < 14) k0++
        var best = Long.MAX_VALUE
        var bk = 0
        for (k in maxOf(0, k0 - 1)..min(14, k0 + 1)) {
            val c = riceBits(us, from, to, k)
            if (c < best) {
                best = c
                bk = k
            }
        }
        return bk
    }

    /** The partition order (the residual is cut into 2^order parts) with the fewest estimated bits. */
    private fun pickPartitionOrder(us: IntArray, n: Int, order: Int): Int {
        var best = Long.MAX_VALUE
        var bp = 0
        for (po in 0..6) {
            if (n % (1 shl po) != 0 || (n shr po) <= order) break
            val size = n shr po
            var total = 4L * (1 shl po)
            var pos = 0
            for (p in 0 until (1 shl po)) {
                val cnt = if (p == 0) size - order else size
                var s = 0L
                for (i in pos until pos + cnt) s += us[i]
                pos += cnt
                val mean = s / maxOf(1, cnt)
                var k = 0
                while ((1L shl (k + 1)) <= mean + 1 && k < 14) k++
                total += cnt.toLong() * (k + 1) + (s shr k)
            }
            if (total < best) {
                best = total
                bp = po
            }
        }
        return bp
    }

    private fun subframe(bw: Bits, x: IntArray, n: Int) {
        var constant = true
        for (i in 1 until n) if (x[i] != x[0]) {
            constant = false
            break
        }
        if (constant) {
            bw.bits(0, 1); bw.bits(0, 6); bw.bits(0, 1)
            bw.bits(x[0] and 0xFFFF, 16)
            return
        }
        var bestOrder = 0
        var bestSum = Long.MAX_VALUE
        for (order in 0..min(4, n - 1)) {
            val res = residuals(x, n, order)
            var s = 0L
            for (r in res) s += abs(r)
            if (s < bestSum) {
                bestSum = s
                bestOrder = order
            }
        }
        val order = bestOrder
        val res = residuals(x, n, order)
        val us = IntArray(res.size) { (res[it] shl 1) xor (res[it] shr 31) }
        val po = pickPartitionOrder(us, n, order)
        val size = n shr po
        val ks = IntArray(1 shl po)
        val bounds = IntArray((1 shl po) + 1)
        var pos = 0
        var bits = 8L + order * 16 + 2 + 4
        for (p in 0 until (1 shl po)) {
            val cnt = if (p == 0) size - order else size
            bounds[p] = pos
            ks[p] = bestK(us, pos, pos + cnt)
            bits += 4 + riceBits(us, pos, pos + cnt, ks[p])
            pos += cnt
        }
        bounds[1 shl po] = pos
        if (bits >= 8L + n * 16) {
            bw.bits(0, 1); bw.bits(1, 6); bw.bits(0, 1)
            for (i in 0 until n) bw.bits(x[i] and 0xFFFF, 16)
            return
        }
        bw.bits(0, 1); bw.bits(8 + order, 6); bw.bits(0, 1)
        for (i in 0 until order) bw.bits(x[i] and 0xFFFF, 16)
        bw.bits(0, 2); bw.bits(po, 4)
        for (p in 0 until (1 shl po)) {
            val k = ks[p]
            bw.bits(k, 4)
            for (i in bounds[p] until bounds[p + 1]) {
                val u = us[i]
                bw.unary(u shr k)
                if (k > 0) bw.bits(u and ((1 shl k) - 1), k)
            }
        }
    }
}
