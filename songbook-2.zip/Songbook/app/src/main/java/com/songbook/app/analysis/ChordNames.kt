package com.songbook.app.analysis

/** Names for the chords and keys the analyzer finds, in sharps or flats depending on the key. */
object ChordNames {
    private val SHARP = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val FLAT = arrayOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")

    fun note(pc: Int, flats: Boolean): String = (if (flats) FLAT else SHARP)[Math.floorMod(pc, 12)]

    /** Keys that are written with flats: F, Bb, Eb, Ab, Db and D, G, C, F, Bb, Eb minor. */
    fun preferFlats(tonic: Int, minor: Boolean): Boolean {
        val t = Math.floorMod(tonic, 12)
        return if (!minor) t in setOf(1, 3, 5, 8, 10) else t in setOf(0, 2, 3, 5, 7, 10)
    }

    /** "F#m", "Dmaj7" ... moved up by [shift] semitones. */
    fun chord(root: Int, type: String, shift: Int, flats: Boolean): String = note(root + shift, flats) + type

    /** The key as Songbook writes it ("G", "Bb", "F#m"), moved by [shift] semitones. */
    fun key(tonic: Int, minor: Boolean, shift: Int): String {
        val t = Math.floorMod(tonic + shift, 12)
        return note(t, preferFlats(t, minor)) + if (minor) "m" else ""
    }

    /** The key written out for the screen: "F# minor". */
    fun keyLong(tonic: Int, minor: Boolean, shift: Int): String {
        val t = Math.floorMod(tonic + shift, 12)
        return note(t, preferFlats(t, minor)) + if (minor) " minor" else " major"
    }
}
