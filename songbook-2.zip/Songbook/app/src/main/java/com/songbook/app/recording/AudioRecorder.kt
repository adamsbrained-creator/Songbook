package com.songbook.app.recording

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.Build
import com.songbook.app.data.AudioStore
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * Records from the microphone into a file in the app's audio folder.
 *
 * It reads the microphone itself (AudioRecord) instead of using the phone's ready-made recorder, so that
 * - with "raw" on it asks for the unprocessed signal: no automatic volume, no noise or echo clean-up, which are made
 *   for phone calls and make music pump and sound thin; where the phone has no raw source it uses the normal one;
 * - it records at 48 kHz, in stereo where the phone can, with 16-bit samples;
 * - the samples can go to any of the formats in [RecFormat].
 */
class AudioRecorder(private val context: Context, private val config: RecordingConfig) {
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    private var sink: PcmSink? = null
    private var file: File? = null
    private var startedAt = 0L

    @Volatile private var running = false
    @Volatile private var failed = false
    @Volatile private var peak = 0

    /** What is really being recorded, e.g. "48 kHz · stereo · FLAC". Known after [start]. */
    var summary: String = config.describe()
        private set

    private fun supportsUnprocessed(): Boolean =
        Build.VERSION.SDK_INT >= 24 &&
            context.getSystemService(AudioManager::class.java)?.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"

    @SuppressLint("MissingPermission")
    private fun open(rate: Int, channels: Int, source: Int): AudioRecord? {
        val mask = if (channels == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
        val min = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val size = max(min * 2, rate * channels * 2 / 4)       // about a quarter of a second of room
        return try {
            val r = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(size)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun makeSink(f: File, rate: Int, channels: Int): PcmSink = when (config.format) {
        RecFormat.WAV -> WavSink(f, rate, channels)
        RecFormat.FLAC -> FlacSink(f, rate, channels)
        RecFormat.OPUS -> CodecSink(f, "audio/opus", MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG, rate, channels, config.bitRate)
        RecFormat.AAC -> CodecSink(f, MediaFormat.MIMETYPE_AUDIO_AAC, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4, rate, channels, config.bitRate)
    }

    fun start(): Boolean {
        val sources = ArrayList<Int>()
        if (config.raw && supportsUnprocessed()) sources.add(MediaRecorder.AudioSource.UNPROCESSED)
        sources.add(MediaRecorder.AudioSource.MIC)
        // the best the phone will give: what was asked for, then mono, then the old CD rate
        val tries = listOf(config.rate to config.channels, config.rate to 1, 44_100 to 1).distinct()
        var rec: AudioRecord? = null
        var rate = config.rate
        var channels = config.channels
        search@ for (src in sources) {
            for ((r, c) in tries) {
                if (config.format == RecFormat.OPUS && r != 48_000) continue      // Opus only takes 48 kHz here
                val a = open(r, c, src)
                if (a != null) {
                    rec = a
                    rate = r
                    channels = c
                    break@search
                }
            }
        }
        val r = rec ?: return false
        val f = AudioStore.newFile(context, config.format.ext)
        return try {
            val s = makeSink(f, rate, channels)
            sink = s
            file = f
            record = r
            failed = false
            running = true
            summary = config.describe(rate, channels)
            val buf = ShortArray(rate / 20 * channels)          // 50 ms at a time
            r.startRecording()
            startedAt = System.currentTimeMillis()
            thread = Thread({
                while (running) {
                    val n = r.read(buf, 0, buf.size)
                    if (n < 0) {
                        failed = true
                        break
                    }
                    val usable = n - n % channels
                    if (usable <= 0) continue
                    var p = 0
                    for (i in 0 until usable) {
                        val a = abs(buf[i].toInt())
                        if (a > p) p = a
                    }
                    peak = p
                    try {
                        s.write(buf, usable)
                    } catch (e: Exception) {
                        failed = true
                        break
                    }
                }
            }, "songbook-recorder").also { it.start() }
            true
        } catch (e: Exception) {
            running = false
            runCatching { r.release() }
            record = null
            runCatching { sink?.abort() }
            sink = null
            f.delete()
            file = null
            false
        }
    }

    private fun halt() {
        running = false
        runCatching { thread?.join(3000) }
        thread = null
        record?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        record = null
    }

    /** Stops the recording. Returns the finished file, or null when nothing usable was recorded. */
    fun stop(): File? {
        if (record == null) return file
        halt()
        val s = sink
        sink = null
        val ok = !failed && s != null && runCatching { s.finish() }.isSuccess
        if (!ok) {
            runCatching { s?.abort() }
            file?.delete()
            file = null
            return null
        }
        return file
    }

    /** Throws the take away (stops it first if it is still running). */
    fun cancel() {
        halt()
        runCatching { sink?.abort() }
        sink = null
        file?.delete()
        file = null
    }

    /** The recorded file is kept; the recorder forgets it so [cancel] does not delete it. */
    fun keep(): File? = file.also { file = null }

    fun elapsedMs(): Long = if (record != null) System.currentTimeMillis() - startedAt else 0L

    /** Loudness 0..32767 of the last 50 ms while recording. */
    fun level(): Int = if (record != null) peak else 0

    val isRecording: Boolean get() = record != null
}
