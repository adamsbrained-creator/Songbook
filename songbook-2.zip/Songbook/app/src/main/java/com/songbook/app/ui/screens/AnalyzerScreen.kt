package com.songbook.app.ui.screens

import com.songbook.app.data.AudioStore
import androidx.compose.runtime.rememberUpdatedState
import android.content.Context
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.em
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.analysis.AnalysisResult
import com.songbook.app.analysis.AudioDecoder
import com.songbook.app.analysis.ChordEngine
import com.songbook.app.analysis.ChordNames
import com.songbook.app.analysis.ChordSeg
import com.songbook.app.analysis.GuitarShape
import com.songbook.app.analysis.GuitarShapes
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.components.CoralEmptyCard
import com.songbook.app.ui.components.CoralTopBar
import com.songbook.app.ui.components.SbIconButton
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.roundToInt

// The chord analyzer: pick a recording, Songbook listens to it on the phone and shows the chords with their
// times, the key, the tempo and how to play each chord on a guitar. The work is in analysis/ChordEngine.kt.

private sealed interface Phase {
    data object Idle : Phase
    data class Working(val label: String, val progress: Float) : Phase
    /** [owned]: the file is a copy in the cache (delete it when done), not a demo of the song. */
    data class Done(val title: String, val file: File, val result: AnalysisResult, val owned: Boolean = true) : Phase
    data class Failed(val message: String) : Phase
}

private val RootColors = listOf(
    Color(0xFFE4572E), Color(0xFFF08A24), Color(0xFFD9A400), Color(0xFF8AB531), Color(0xFF2FA84F), Color(0xFF1AA39A),
    Color(0xFF1D8FD6), Color(0xFF3F6FE0), Color(0xFF6C5CE7), Color(0xFF9B4DCA), Color(0xFFD6459D), Color(0xFFE0436B)
)

private fun fmtTime(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

private fun displayName(context: Context, uri: Uri): String {
    var name: String? = null
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) name = cur.getString(0)
        }
    }
    return (name ?: "Recording").substringBeforeLast('.').ifBlank { "Recording" }
}

/** Copies the picked file into the cache, decodes it and analyses it. Reports its progress through [set]. */
private suspend fun runAnalysis(context: Context, uri: Uri, set: (Phase) -> Unit): Phase = withContext(Dispatchers.Default) {
    val job = coroutineContext[Job]
    val cancelled = { job?.isActive == false }
    var copy: File? = null
    try {
        set(Phase.Working("Opening the file", 0f))
        val title = displayName(context, uri)
        val target = File(context.cacheDir, "analyzer_${System.nanoTime()}.audio")
        copy = target
        val input = context.contentResolver.openInputStream(uri) ?: return@withContext Phase.Failed("Could not open the file.")
        input.use { src -> target.outputStream().use { dst -> src.copyTo(dst) } }
        if (cancelled()) {
            target.delete()
            return@withContext Phase.Idle
        }
        val done = analyzeLocal(context, target, title, true, set, cancelled)
        if (done !is Phase.Done) target.delete()
        done
    } catch (e: CancellationException) {
        copy?.delete()
        throw e
    } catch (e: Exception) {
        copy?.delete()
        Phase.Failed(e.message ?: "Could not analyse this file.")
    }
}

/** Decodes and analyses a file that is already on the phone. Returns Idle when cancelled. */
private fun analyzeLocal(context: Context, file: File, title: String, owned: Boolean, set: (Phase) -> Unit, cancelled: () -> Boolean): Phase {
    set(Phase.Working("Reading the audio", 0.02f))
    val pcm = AudioDecoder.decode(context, Uri.fromFile(file), { set(Phase.Working("Reading the audio", 0.02f + 0.28f * it)) }, cancelled)
        ?: return Phase.Idle
    set(Phase.Working("Listening for chords", 0.3f))
    val result = ChordEngine.analyze(pcm, { set(Phase.Working("Listening for chords", 0.3f + 0.7f * it)) }, cancelled)
        ?: return Phase.Idle
    return Phase.Done(title, file, result, owned)
}

/** Analyses a demo recorded in Songbook, in place. */
private suspend fun runAnalysisFile(context: Context, file: File, title: String, set: (Phase) -> Unit): Phase = withContext(Dispatchers.Default) {
    val job = coroutineContext[Job]
    try {
        if (!file.exists()) return@withContext Phase.Failed("The recording could not be found.")
        analyzeLocal(context, file, title, false, set) { job?.isActive == false }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Phase.Failed(e.message ?: "Could not analyse this recording.")
    }
}

@Composable
fun AnalyzerScreen(
    onBack: () -> Unit,
    onSave: (title: String, body: String, key: String, bpm: Int, comment: String) -> Unit,
    /** A demo of a song to analyse right away (the file name in the audio folder), with its title. */
    recordingFile: String = "",
    recordingTitle: String = "",
    /** The song the demo belongs to: then the chords can be added to that song. */
    songId: Long = 0L,
    onAddToSong: ((songId: Long, chords: String) -> Unit)? = null
) {
    val c = Sb.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var phase by remember { mutableStateOf<Phase>(Phase.Idle) }
    var job by remember { mutableStateOf<Job?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            job?.cancel()
            job = scope.launch { phase = runAnalysis(context, uri) { phase = it } }
        }
    }
    DisposableEffect(Unit) { onDispose { job?.cancel() } }
    val doneFile = (phase as? Phase.Done)?.takeIf { it.owned }?.file
    DisposableEffect(doneFile) { onDispose { doneFile?.delete() } }
    // opened from a song's demo: start listening at once
    LaunchedEffect(recordingFile) {
        if (recordingFile.isNotEmpty() && phase is Phase.Idle) {
            val f = AudioStore.file(context, recordingFile)
            job = scope.launch { phase = runAnalysisFile(context, f, recordingTitle.ifBlank { "Demo" }) { phase = it } }
        }
    }

    Box(Modifier.fillMaxSize().screenBg().statusBarsPadding()) {
        val p = phase
        if (p is Phase.Done) {
            ResultView(p, onBack, onSave, songId, onAddToSong) { pick.launch(arrayOf("audio/*")) }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 40.dp)) {
                AnalyzerHeader(onBack)
                when (p) {
                    is Phase.Working -> WorkingCard(p) {
                        job?.cancel()
                        phase = Phase.Idle
                    }
                    is Phase.Failed -> CoralEmptyCard("That did not work", p.message, "Choose another file") { pick.launch(arrayOf("audio/*")) }
                    else -> {
                        CoralEmptyCard(
                            "Find the chords of a recording",
                            "Pick an audio file, or a demo you recorded. Songbook listens to it on your phone and shows the chords with their times, the key, the tempo and how to play each chord. Nothing is uploaded.",
                            "Choose audio file"
                        ) { pick.launch(arrayOf("audio/*")) }
                        Text(
                            "It works best with a clear guitar or piano. Drums, vocals and distortion make it less sure, so treat the result as a first draft and check it by ear.",
                            style = sbStyle(13, color = c.mu),
                            modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyzerHeader(onBack: () -> Unit) {
    val c = Sb.colors
    if (c.style == UiStyle.CORAL) {
        CoralTopBar("Chord analyzer", null, onBack = onBack)
    } else {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            SbIconButton(SbIcons.Back, "Back", onBack, size = 24.dp)
            Text("Chord analyzer", style = sbStyle(18, FontWeight.SemiBold, c.ac), modifier = Modifier.padding(start = 8.dp))
        }
    }
}

@Composable
private fun WorkingCard(p: Phase.Working, onCancel: () -> Unit) {
    val c = Sb.colors
    Column(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(p.label, style = sbStyle(20, FontWeight.SemiBold, c.tx))
        Text("${(p.progress * 100).roundToInt()}%", style = sbStyle(15, color = c.mu), modifier = Modifier.padding(top = 6.dp))
        Box(Modifier.padding(top = 18.dp).fillMaxWidth().height(10.dp).clip(CircleShape).background(c.track)) {
            Box(Modifier.fillMaxWidth(p.progress.coerceIn(0.02f, 1f)).height(10.dp).clip(CircleShape).background(c.ac))
        }
        Box(
            Modifier.padding(top = 20.dp).height(48.dp).clip(RoundedCornerShape(24.dp)).background(c.tx.copy(alpha = 0.08f))
                .clickable(onClick = onCancel).padding(horizontal = 28.dp),
            contentAlignment = Alignment.Center
        ) { Text("Cancel", style = sbStyle(15, FontWeight.SemiBold, c.tx)) }
    }
}

// ------------------------------------------------------------------ playback

private class AnalyzerPlayer(file: File) {
    private var mp: MediaPlayer? = null
    var playing by mutableStateOf(false)
    var posMs by mutableStateOf(0)
    var speed by mutableStateOf(1f)
    var durationMs = 0

    init {
        runCatching {
            val m = MediaPlayer()
            m.setDataSource(file.path)
            m.prepare()
            m.setOnCompletionListener {
                playing = false
                posMs = 0
                runCatching { it.seekTo(0) }
            }
            durationMs = m.duration
            mp = m
        }
    }

    val ready: Boolean get() = mp != null

    private fun applySpeed() {
        val m = mp ?: return
        runCatching { m.playbackParams = PlaybackParams().setSpeed(speed) }
    }

    fun toggle() {
        val m = mp ?: return
        if (playing) {
            m.pause()
            playing = false
        } else {
            m.start()
            playing = true
            if (speed != 1f) applySpeed()
        }
    }

    fun setSpeedTo(s: Float) {
        speed = s
        if (playing) applySpeed()
    }

    fun seekTo(ms: Int) {
        val m = mp ?: return
        val t = ms.coerceIn(0, max(0, durationMs))
        runCatching { m.seekTo(t) }
        posMs = t
    }

    fun tick() {
        val m = mp ?: return
        if (playing) posMs = runCatching { m.currentPosition }.getOrDefault(posMs)
    }

    fun release() {
        playing = false
        runCatching { mp?.release() }
        mp = null
    }
}

// ------------------------------------------------------------------ the chord chart

private class BarGrid(val cells: List<String?>, val pad: Int, val perBar: Int) {
    val bars: List<List<String?>> get() = cells.chunked(perBar)
}

/** Lays the chords out in bars: a cell shows the chord only on the beat where it changes. */
private fun buildBars(beats: DoubleArray, segs: List<ChordSeg>, names: List<String>, perBar: Int): BarGrid {
    if (beats.isEmpty() || segs.isEmpty()) return BarGrid(emptyList(), 0, perBar)
    fun idxAt(t: Double) = segs.indexOfLast { it.start <= t }.coerceAtLeast(0)
    val at = IntArray(beats.size) { idxAt(beats[it] + 0.08) }
    val changes = BooleanArray(beats.size) { i -> i == 0 || at[i] != at[i - 1] }
    // chords usually change on the first beat of a bar: pick the beat that most changes fall on
    var bestPhase = 0
    var bestCount = -1
    for (ph in 0 until perBar) {
        var cnt = 0
        for (i in beats.indices) if (changes[i] && segs[at[i]].isChord && i % perBar == ph) cnt++
        if (cnt > bestCount) {
            bestCount = cnt
            bestPhase = ph
        }
    }
    val cells = ArrayList<String?>()
    val pad = (perBar - bestPhase) % perBar
    repeat(pad) { cells.add(null) }
    for (i in beats.indices) cells.add(if (changes[i] && segs[at[i]].isChord) names[at[i]] else null)
    while (cells.size % perBar != 0) cells.add(null)
    return BarGrid(cells, pad, perBar)
}

/** Song text for the library: four bars to a line, every chord in square brackets as Songbook writes them. */
private fun songBody(grid: BarGrid): String {
    val sb = StringBuilder("# Chords\n")
    var last = ""
    val perBar = ArrayList<String>()
    for (bar in grid.bars) {
        val tokens = ArrayList<String>()
        for (cell in bar) if (cell != null) {
            tokens.add(cell)
            last = cell
        }
        if (tokens.isEmpty() && last.isNotEmpty()) tokens.add(last)
        perBar.add(tokens.joinToString(" "))
    }
    for (line in perBar.chunked(4)) {
        val chords = line.filter { it.isNotEmpty() }.joinToString(" ")
        if (chords.isNotEmpty()) sb.append('[').append(chords).append("]\n")
    }
    return sb.toString().trimEnd()
}

// ------------------------------------------------------------------ the result

@Composable
private fun ResultView(
    done: Phase.Done,
    onBack: () -> Unit,
    onSave: (title: String, body: String, key: String, bpm: Int, comment: String) -> Unit,
    songId: Long,
    onAddToSong: ((songId: Long, chords: String) -> Unit)?,
    onAnother: () -> Unit
) {
    val c = Sb.colors
    val result = done.result
    val clipboard = LocalClipboardManager.current
    var precise by rememberSaveable { mutableStateOf(false) }
    var perBar by rememberSaveable { mutableStateOf(4) }
    var shift by rememberSaveable { mutableStateOf(0) }
    var tempoMode by rememberSaveable { mutableStateOf(0) }   // 0 as found, 1 twice as fast, 2 half as fast

    val player = remember(done.file) { AnalyzerPlayer(done.file) }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(player.playing) {
        while (player.playing) {
            player.tick()
            delay(50)
        }
    }

    val segs = if (precise) result.precise else result.basic
    val flats = ChordNames.preferFlats(result.keyTonic + shift, result.keyMinor)
    val names = remember(segs, shift, flats) {
        segs.map { if (it.isChord) ChordNames.chord(it.root, it.type, shift, flats) else "" }
    }
    val beats = remember(result, tempoMode) {
        when (tempoMode) {
            1 -> DoubleArray(result.beats.size * 2) { i ->
                val a = result.beats[i / 2]
                if (i % 2 == 0) a else a + ((result.beats.getOrNull(i / 2 + 1) ?: (a + 60.0 / result.bpm)) - a) / 2
            }
            2 -> result.beats.filterIndexed { i, _ -> i % 2 == 0 }.toDoubleArray()
            else -> result.beats
        }
    }
    val bpmShown = result.bpm * (if (tempoMode == 1) 2.0 else if (tempoMode == 2) 0.5 else 1.0)
    val grid = remember(beats, segs, names, perBar) { buildBars(beats, segs, names, perBar) }
    val keyLong = ChordNames.keyLong(result.keyTonic, result.keyMinor, shift)

    val posSec = player.posMs / 1000.0
    val curIdx = if (segs.isEmpty()) -1 else segs.indexOfLast { it.start <= posSec }.coerceAtLeast(0)
    val nextIdx = if (curIdx >= 0) (curIdx + 1 until segs.size).firstOrNull { segs[it].isChord } ?: -1 else -1

    fun shapeOf(i: Int): GuitarShape? =
        if (i < 0 || !segs[i].isChord) null else GuitarShapes.shape(Math.floorMod(segs[i].root + shift, 12), segs[i].type)

    // the chords used, longest first
    val used = remember(segs, shift, flats) {
        val total = LinkedHashMap<Pair<Int, String>, Double>()
        for (s in segs) if (s.isChord) total[s.root to s.type] = (total[s.root to s.type] ?: 0.0) + (s.end - s.start)
        total.entries.sortedByDescending { it.value }.take(12).map { Triple(it.key, it.value, ChordNames.chord(it.key.first, it.key.second, shift, flats)) }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 150.dp)) {
            item { AnalyzerHeader(onBack) }
            item {
                Text(done.title, style = sbStyle(22, FontWeight.SemiBold, c.tx, serif = true), maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 26.dp, end = 26.dp, top = 4.dp))
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Key", keyLong, Modifier.weight(1.3f))
                    StatCard("Tempo", "${bpmShown.roundToInt()} BPM", Modifier.weight(1f))
                    StatCard("Length", fmtTime(result.durationSec), Modifier.weight(0.8f))
                }
            }
            item {
                Timeline(result, segs, names, posSec, { player.seekTo((it * 1000).toInt()) }, Modifier.padding(horizontal = 16.dp))
            }
            item {
                ZoomTimeline(result, segs, names, posSec, { player.seekTo((it * 1000).toInt()) }, Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp))
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ChordCard("Now", if (curIdx >= 0) names[curIdx] else "", shapeOf(curIdx), Modifier.weight(1f))
                    ChordCard("Next", if (nextIdx >= 0) names[nextIdx] else "", shapeOf(nextIdx), Modifier.weight(1f))
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).padding(vertical = 6.dp)) {
                    ControlRow("Chords") { Segmented(listOf("Basic", "Precise"), if (precise) 1 else 0) { precise = it == 1 } }
                    ControlRow("Beats in a bar") { Segmented(listOf("3", "4"), if (perBar == 3) 0 else 1) { perBar = if (it == 0) 3 else 4 } }
                    ControlRow("Tempo") { Segmented(listOf("As found", "×2", "÷2"), tempoMode) { tempoMode = it } }
                    ControlRow("Transpose") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StepButton("−") { shift = (shift - 1).coerceAtLeast(-11) }
                            Text(
                                if (shift > 0) "+$shift" else "$shift",
                                style = sbStyle(16, FontWeight.SemiBold, c.tx), textAlign = TextAlign.Center, modifier = Modifier.width(48.dp)
                            )
                            StepButton("+") { shift = (shift + 1).coerceAtMost(11) }
                        }
                    }
                }
            }
            if (used.isNotEmpty()) {
                item { SectionHeader("Chords in this recording") }
                itemsIndexed(used.chunked(3)) { _, row ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (key, seconds, name) ->
                            MiniChord(name, fmtTime(seconds), GuitarShapes.shape(Math.floorMod(key.first + shift, 12), key.second), Modifier.weight(1f))
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (grid.cells.isNotEmpty()) {
                item { SectionHeader("Chord chart") }
                val curBeat = beats.indexOfLast { it <= posSec + 0.05 }
                val curCell = if (curBeat >= 0) grid.pad + curBeat else -1
                itemsIndexed(grid.bars) { barIdx, bar ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        bar.forEachIndexed { col, cell ->
                            val cellIdx = barIdx * perBar + col
                            val on = cellIdx == curCell
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (on) c.ac.copy(alpha = 0.28f) else c.cd)
                                    .clickable {
                                        val b = cellIdx - grid.pad
                                        if (b >= 0 && b < beats.size) player.seekTo((beats[b] * 1000).toInt())
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (cell != null) Text(cell, style = sbStyle(16, FontWeight.SemiBold, c.tx), maxLines = 1)
                            }
                        }
                    }
                }
            }
            item {
                if (songId > 0 && onAddToSong != null) {
                    PillButton("Add the chords to this song", true, Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp).fillMaxWidth()) {
                        onAddToSong(songId, songBody(grid))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Save as song", !(songId > 0 && onAddToSong != null), Modifier.weight(1f)) {
                        val key = ChordNames.key(result.keyTonic, result.keyMinor, shift)
                        val bpm = bpmShown.roundToInt()
                        onSave(
                            done.title, songBody(grid), key, bpm,
                            "Chords found by Songbook's analyzer from “${done.title}”: $keyLong, $bpm BPM. It is an estimate, check it by ear."
                        )
                    }
                    PillButton("Copy chords", false, Modifier.weight(1f)) { clipboard.setText(AnnotatedString(songBody(grid))) }
                }
                PillButton("Analyze another file", false, Modifier.padding(horizontal = 16.dp).fillMaxWidth(), onAnother)
            }
        }
        PlayerBar(
            player = player, duration = result.durationSec, modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    val c = Sb.colors
    Text(
        text.uppercase(),
        style = sbStyle(12, FontWeight.Medium, c.mu).copy(letterSpacing = 0.14.em),
        modifier = Modifier.padding(start = 26.dp, end = 24.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    val c = Sb.colors
    Column(modifier.sbCard(20.dp).clip(RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Text(label, style = sbStyle(12, color = c.mu))
        Text(value, style = sbStyle(17, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ControlRow(label: String, content: @Composable () -> Unit) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = sbStyle(15, FontWeight.Medium, c.tx))
        content()
    }
}

@Composable
private fun StepButton(text: String, onClick: () -> Unit) {
    val c = Sb.colors
    Box(Modifier.size(40.dp).clip(CircleShape).background(c.track).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, style = sbStyle(20, FontWeight.SemiBold, c.tx))
    }
}

@Composable
private fun PillButton(text: String, solid: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = Sb.colors
    Box(
        modifier.height(54.dp).clip(RoundedCornerShape(27.dp)).background(if (solid) c.pill else c.cd).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, style = sbStyle(15, FontWeight.SemiBold, if (solid) c.onPill else c.tx), maxLines = 1) }
}

// ------------------------------------------------------------------ timeline

@Composable
private fun Timeline(
    result: AnalysisResult,
    segs: List<ChordSeg>,
    names: List<String>,
    posSec: Double,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Sb.colors
    val dur = max(1.0, result.durationSec)
    val accent = c.ac
    val muted = c.mu.copy(alpha = 0.45f)
    val ink = c.tx
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(132.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(c.cd)
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).coerceIn(0.0, dur)) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    onSeek((change.position.x / size.width * dur).coerceIn(0.0, dur))
                }
            }
    ) {
        val w = maxWidth
        Canvas(Modifier.fillMaxSize()) {
            val pw = size.width
            val ph = size.height
            // the loudness of the recording
            val n = result.peaks.size
            if (n > 0) {
                val barW = pw / n
                val midY = ph * 0.70f
                for (i in 0 until n) {
                    val h = (result.peaks[i] * ph * 0.30f).coerceAtLeast(1.5f)
                    val played = i * AnalysisResult.PEAK_STEP <= posSec
                    drawLine(
                        if (played) accent else muted, Offset(i * barW + barW / 2, midY - h), Offset(i * barW + barW / 2, midY + h),
                        strokeWidth = max(1f, barW * 0.7f), cap = StrokeCap.Round
                    )
                }
            }
            // the chords as coloured blocks
            for (s in segs) {
                if (!s.isChord) continue
                val x0 = (s.start / dur * pw).toFloat()
                val x1 = (s.end / dur * pw).toFloat()
                drawRoundRect(
                    RootColors[s.root % 12], Offset(x0 + 0.5.dp.toPx(), 8.dp.toPx()), Size(max(1f, x1 - x0 - 1.dp.toPx()), 32.dp.toPx()),
                    CornerRadius(8.dp.toPx())
                )
            }
            val px = (posSec / dur * pw).toFloat()
            drawLine(ink, Offset(px, 0f), Offset(px, ph), strokeWidth = 2.dp.toPx())
        }
        segs.forEachIndexed { i, s ->
            if (s.isChord) {
                val sw = w * ((s.end - s.start) / dur).toFloat()
                if (sw >= 30.dp) {
                    Text(
                        names[i], maxLines = 1, textAlign = TextAlign.Center,
                        style = sbStyle(12, FontWeight.SemiBold, Color.White),
                        modifier = Modifier.offset(x = w * (s.start / dur).toFloat(), y = 15.dp).width(sw)
                    )
                }
            }
        }
    }
}

/** A close-up of the 12 seconds around the playhead: it scrolls as the song plays, drag it to move through the song. */
@Composable
private fun ZoomTimeline(
    result: AnalysisResult,
    segs: List<ChordSeg>,
    names: List<String>,
    posSec: Double,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Sb.colors
    val window = 12.0
    val accent = c.ac
    val muted = c.mu.copy(alpha = 0.45f)
    val tick = c.mu.copy(alpha = 0.7f)
    val ink = c.tx
    val pos by rememberUpdatedState(posSec)
    val dur = result.durationSec
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(c.cd)
            .pointerInput(dur) {
                detectHorizontalDragGestures { change, dx ->
                    change.consume()
                    onSeek((pos - dx / (size.width / window)).coerceIn(0.0, dur))
                }
            }
    ) {
        val w = maxWidth
        val t0 = posSec - window / 2
        Canvas(Modifier.fillMaxSize()) {
            val pw = size.width
            val ph = size.height
            fun xOf(t: Double) = ((t - t0) / window * pw).toFloat()
            // loudness
            val first = kotlin.math.floor(t0 / AnalysisResult.PEAK_STEP).toInt().coerceAtLeast(0)
            val last = kotlin.math.ceil((t0 + window) / AnalysisResult.PEAK_STEP).toInt().coerceAtMost(result.peaks.size - 1)
            val barW = (pw / (window / AnalysisResult.PEAK_STEP)).toFloat()
            for (i in first..last) {
                val t = i * AnalysisResult.PEAK_STEP
                val h = (result.peaks[i] * ph * 0.26f).coerceAtLeast(1.5f)
                val x = xOf(t) + barW / 2
                drawLine(if (t <= posSec) accent else muted, Offset(x, ph * 0.66f - h), Offset(x, ph * 0.66f + h), strokeWidth = max(1f, barW * 0.7f), cap = StrokeCap.Round)
            }
            // chords
            for (s in segs) {
                if (!s.isChord || s.end < t0 || s.start > t0 + window) continue
                val x0 = max(0f, xOf(s.start))
                val x1 = kotlin.math.min(pw, xOf(s.end))
                if (x1 - x0 < 2f) continue
                drawRoundRect(RootColors[s.root % 12], Offset(x0 + 0.5.dp.toPx(), 8.dp.toPx()), Size(x1 - x0 - 1.dp.toPx(), 34.dp.toPx()), CornerRadius(9.dp.toPx()))
            }
            // beats
            for (b in result.beats) {
                if (b < t0 || b > t0 + window) continue
                drawLine(tick, Offset(xOf(b), ph - 12.dp.toPx()), Offset(xOf(b), ph - 4.dp.toPx()), strokeWidth = 1.5.dp.toPx())
            }
            drawLine(ink, Offset(pw / 2, 0f), Offset(pw / 2, ph), strokeWidth = 2.dp.toPx())
        }
        segs.forEachIndexed { i, s ->
            if (s.isChord && s.end >= t0 && s.start <= t0 + window) {
                val a = kotlin.math.max(s.start, t0)
                val b = kotlin.math.min(s.end, t0 + window)
                val sw = w * ((b - a) / window).toFloat()
                if (sw >= 34.dp) {
                    Text(
                        names[i], maxLines = 1, textAlign = TextAlign.Center,
                        style = sbStyle(16, FontWeight.SemiBold, Color.White),
                        modifier = Modifier.offset(x = w * ((a - t0) / window).toFloat(), y = 15.dp).width(sw)
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ chord diagrams

@Composable
private fun ChordCard(label: String, name: String, shape: GuitarShape?, modifier: Modifier) {
    val c = Sb.colors
    Column(modifier.sbCard(24.dp).clip(RoundedCornerShape(24.dp)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = sbStyle(12, color = c.mu))
        Text(if (name.isEmpty()) "–" else name, style = sbStyle(30, FontWeight.SemiBold, c.tx), maxLines = 1)
        Spacer(Modifier.height(6.dp))
        if (shape != null) GuitarDiagram(shape, Modifier.fillMaxWidth(0.8f).aspectRatio(0.85f))
        else Box(Modifier.fillMaxWidth(0.8f).aspectRatio(0.85f), contentAlignment = Alignment.Center) {
            Text(if (name.isEmpty()) "" else "no shape", style = sbStyle(12, color = c.mu))
        }
    }
}

@Composable
private fun MiniChord(name: String, time: String, shape: GuitarShape?, modifier: Modifier) {
    val c = Sb.colors
    Column(modifier.sbCard(20.dp).clip(RoundedCornerShape(20.dp)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, style = sbStyle(18, FontWeight.SemiBold, c.tx), maxLines = 1)
        Text(time, style = sbStyle(11, color = c.mu))
        Spacer(Modifier.height(4.dp))
        if (shape != null) GuitarDiagram(shape, Modifier.fillMaxWidth().aspectRatio(0.85f))
    }
}

/** A guitar chord box: six strings, five frets, dots for the fingers, x and o above the strings. */
@Composable
private fun GuitarDiagram(shape: GuitarShape, modifier: Modifier = Modifier) {
    val c = Sb.colors
    val ink = c.tx
    val dot = c.ac
    val soft = c.mu.copy(alpha = 0.55f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val left = w * 0.20f
        val right = w * 0.92f
        val top = h * 0.20f
        val bottom = h * 0.97f
        val sx = (right - left) / 5f
        val fy = (bottom - top) / 5f
        val base = shape.baseFret
        val line = 1.2.dp.toPx()
        // frets
        for (f in 0..5) {
            val y = top + fy * f
            val nut = f == 0 && base == 1
            drawLine(if (nut) ink else soft, Offset(left, y), Offset(right, y), strokeWidth = if (nut) 3.dp.toPx() else line)
        }
        // strings
        for (s in 0..5) drawLine(soft, Offset(left + sx * s, top), Offset(left + sx * s, bottom), strokeWidth = line)
        // barre
        if (shape.barre > 0) {
            val row = shape.barre - base
            if (row in 0..4) {
                val y = top + fy * (row + 0.5f)
                drawLine(dot, Offset(left + sx * shape.barreFrom, y), Offset(right, y), strokeWidth = fy * 0.62f, cap = StrokeCap.Round)
            }
        }
        // fingers, muted and open strings
        val r = min(sx, fy) * 0.34f
        for (s in 0..5) {
            val f = shape.frets[s]
            val x = left + sx * s
            if (f < 0) drawCross(x, top - fy * 0.45f, r * 0.7f, ink, line)
            else if (f == 0) drawCircle(ink, r * 0.7f, Offset(x, top - fy * 0.45f), style = androidx.compose.ui.graphics.drawscope.Stroke(line))
            else {
                val row = f - base
                if (row in 0..4 && !(shape.barre == f && s >= shape.barreFrom)) drawCircle(dot, r, Offset(x, top + fy * (row + 0.5f)))
            }
        }
        // the fret number when the chord is up the neck
        if (base > 1) {
            drawContext.canvas.nativeCanvas.drawText(
                "$base", 1.dp.toPx(), top + fy * 0.7f,
                android.graphics.Paint().apply { color = ink.toArgb(); textSize = fy * 0.6f; isAntiAlias = true }
            )
        }
    }
}

private fun min(a: Float, b: Float) = if (a < b) a else b

private fun DrawScope.drawCross(x: Float, y: Float, r: Float, color: Color, width: Float) {
    drawLine(color, Offset(x - r, y - r), Offset(x + r, y + r), strokeWidth = width)
    drawLine(color, Offset(x - r, y + r), Offset(x + r, y - r), strokeWidth = width)
}


// ------------------------------------------------------------------ player bar

@Composable
private fun PlayerBar(player: AnalyzerPlayer, duration: Double, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .fillMaxWidth()
            .height(68.dp)
            .clip(RoundedCornerShape(34.dp))
            .background(c.pill)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BarText("−5") { player.seekTo(player.posMs - 5000) }
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(c.onPill).clickable { player.toggle() },
            contentAlignment = Alignment.Center
        ) { StrokeIcon(if (player.playing) SbIcons.Pause else SbIcons.Play, c.pill, size = 22.dp, filled = true) }
        BarText("+5") { player.seekTo(player.posMs + 5000) }
        Text(
            "${fmtTime(player.posMs / 1000.0)} / ${fmtTime(duration)}",
            style = sbStyle(13, FontWeight.Medium, c.onPill), maxLines = 1,
            modifier = Modifier.weight(1f).padding(start = 8.dp)
        )
        val label = when (player.speed) {
            0.5f -> "0.5×"
            0.75f -> "0.75×"
            else -> "1×"
        }
        BarText(label) { player.setSpeedTo(when (player.speed) { 1f -> 0.75f; 0.75f -> 0.5f; else -> 1f }) }
    }
}

@Composable
private fun BarText(text: String, onClick: () -> Unit) {
    val c = Sb.colors
    Box(
        Modifier.height(40.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, style = sbStyle(14, FontWeight.SemiBold, c.onPill), maxLines = 1) }
}
