package com.songbook.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

// Paperback's navigation (MenuSheet.kt): the header's menu button opens a card of pages above a round close
// button, over a dimmed page; "More" opens a sheet with every page and the actions of the page you are on.

/** Opens the menu. Provided by the root; the Coral top bar calls it from its menu button. */
val LocalOpenMenu = staticCompositionLocalOf<(() -> Unit)?> { null }

/** The page's own actions (sort, layout...), left here by the top bar so "More" can list them. Not state on purpose. */
class PageActionsHolder {
    var actions: List<MenuAction> = emptyList()
}

val LocalPageActions = staticCompositionLocalOf<PageActionsHolder?> { null }

private class NavItem(val label: String, val route: String, val icon: IconSpec)

private val NavItems = listOf(
    NavItem("Songs", "library", SbIcons.Music),
    NavItem("Albums", "albums", SbIcons.Albums),
    NavItem("Favorites", "favorites", SbIcons.Heart),
    NavItem("Workflow", "workflow", SbIcons.Check),
    NavItem("Chord analyzer", "analyzer", SbIcons.Wave),
    NavItem("Statistics", "stats", SbIcons.Stats),
    NavItem("Settings", "settings", SbIcons.Sliders)
)

/** The round dark button: menu lines, or a cross while the menu is open. */
@Composable
fun NavMenuFab(onClick: () -> Unit, modifier: Modifier = Modifier, close: Boolean = false) {
    val c = Sb.colors
    Box(
        modifier
            .size(60.dp)
            .shadow(10.dp, CircleShape)
            .clip(CircleShape)
            .background(c.tx)
            .clickable(onClick = onClick)
            .semantics { contentDescription = if (close) "Close menu" else "Open menu" },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(if (close) SbIcons.Close else SbIcons.Menu, c.bg, size = 24.dp) }
}

@Composable
private fun Scrim(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x73161616))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    )
}

@Composable
private fun MenuRow(icon: IconSpec, name: String, on: Boolean, onClick: () -> Unit, accent: Boolean = false) {
    val c = Sb.colors
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (on) c.cd else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StrokeIcon(icon, if (accent) c.ac else c.tx, size = 22.dp)
        Spacer(Modifier.width(14.dp))
        Text(
            name,
            modifier = Modifier.weight(1f),
            style = sbStyle(16, if (on || accent) FontWeight.SemiBold else FontWeight.Medium, c.tx)
        )
        if (on) Box(Modifier.size(8.dp).background(c.ac, CircleShape))
    }
}

/** The menu card over a dimmed page. [onNewSong] and [onMore] are the two actions that are not pages. */
@Composable
fun NavMenuOverlay(
    open: Boolean,
    current: String?,
    onClose: () -> Unit,
    onGo: (String) -> Unit,
    onNewSong: () -> Unit,
    onMore: () -> Unit
) {
    if (!open) return
    val c = Sb.colors
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxSize()) {
        Scrim(onClose)
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 100.dp)
                .width(264.dp)
                .shadow(18.dp, shape)
                .clip(shape)
                .background(c.sheet)
                .heightIn(max = 520.dp)
                .verticalScroll(rememberScrollState())
                .padding(8.dp)
        ) {
            MenuRow(SbIcons.Plus, "New song", on = false, onClick = onNewSong, accent = true)
            NavItems.forEach { item -> MenuRow(item.icon, item.label, item.route == current, { onGo(item.route) }) }
            MenuRow(SbIcons.More, "More", on = false, onClick = onMore)
        }
        NavMenuFab(
            onClick = onClose,
            close = true,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp)
        )
    }
}

/** "More": a bottom sheet with the actions of this page and every page of the app. */
@Composable
fun AllPagesSheet(
    open: Boolean,
    pageActions: List<MenuAction>,
    onClose: () -> Unit,
    onGo: (String) -> Unit
) {
    if (!open) return
    val c = Sb.colors
    val groups = listOf(
        "Songs and albums" to NavItems.filter { it.route in listOf("library", "albums", "favorites", "workflow", "analyzer") },
        "App" to NavItems.filter { it.route in listOf("stats", "settings") }
    )
    Box(Modifier.fillMaxSize()) {
        Scrim(onClose)
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val maxSheet = maxHeight * 0.84f
            Column(
                Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .heightIn(max = maxSheet)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(c.sheet)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 28.dp)
            ) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(44.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0x66808080))
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("All pages", modifier = Modifier.weight(1f), style = sbStyle(20, FontWeight.SemiBold, c.tx))
                    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                        StrokeIcon(SbIcons.Close, c.tx, size = 20.dp)
                    }
                }
                if (pageActions.isNotEmpty()) {
                    SheetGroup("This page") {
                        pageActions.forEachIndexed { i, a ->
                            if (i > 0) Spacer(Modifier.height(12.dp))
                            SheetRow(a.label) { onClose(); a.run() }
                        }
                    }
                }
                groups.forEach { (label, items) ->
                    SheetGroup(label) {
                        items.forEachIndexed { i, item ->
                            if (i > 0) Spacer(Modifier.height(12.dp))
                            SheetRow(item.label) { onGo(item.route) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetGroup(label: String, content: @Composable () -> Unit) {
    val c = Sb.colors
    Text(
        label.uppercase(),
        modifier = Modifier.padding(top = 10.dp, bottom = 12.dp),
        style = sbStyle(12, FontWeight.Medium, c.mu).copy(letterSpacing = 0.1.em)
    )
    content()
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun SheetRow(name: String, onClick: () -> Unit) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.cd).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name,
            modifier = Modifier.weight(1f).padding(start = 6.dp, top = 6.dp, bottom = 6.dp),
            style = sbStyle(16, FontWeight.SemiBold, c.tx)
        )
        StrokeIcon(SbIcons.ChevronRight, c.tx, size = 18.dp)
    }
}
