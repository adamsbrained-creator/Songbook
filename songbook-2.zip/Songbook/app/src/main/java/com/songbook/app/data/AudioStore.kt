package com.songbook.app.data

import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File
import java.util.UUID

/** Demo recordings live in the app's private folder (filesDir/audio). Entities only keep the file name. */
object AudioStore {
    private fun dir(context: Context): File =
        File(context.applicationContext.filesDir, "audio").apply { mkdirs() }

    fun file(context: Context, name: String): File = File(dir(context), name)

    /** A new, empty file to record into. */
    fun newFile(context: Context, ext: String = "m4a"): File = File(dir(context), "rec_${UUID.randomUUID()}.$ext")

    fun readBytes(context: Context, name: String): ByteArray? =
        runCatching { file(context, name).takeIf { it.exists() }?.readBytes() }.getOrNull()

    /** Saves audio that came from a backup under a fresh name; [originalName] keeps its format (.wav, .flac, .ogg...). */
    fun saveBytes(context: Context, bytes: ByteArray, originalName: String? = null): String? = runCatching {
        val ext = originalName?.substringAfterLast('.', "")?.lowercase()?.takeIf { it.matches(Regex("[a-z0-9]{1,5}")) } ?: "m4a"
        val name = "rec_${UUID.randomUUID()}.$ext"
        file(context, name).writeBytes(bytes)
        name
    }.getOrNull()

    fun delete(context: Context, name: String) {
        runCatching { file(context, name).delete() }
    }

    /** Length of a recording in milliseconds, 0 when it cannot be read. */
    fun durationMs(file: File): Long = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            r.release()
        }
    }.getOrDefault(0L)

    /** Deletes recordings no song points at any more (a deleted song, a cancelled take). */
    fun cleanup(context: Context, used: Set<String>) {
        dir(context).listFiles()?.forEach { f ->
            if (f.name.startsWith("rec_") && f.name !in used) f.delete()
        }
    }
}
