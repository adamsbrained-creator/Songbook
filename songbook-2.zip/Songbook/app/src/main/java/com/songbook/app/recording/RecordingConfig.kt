package com.songbook.app.recording

import android.media.MediaCodecList
import android.os.Build

/** The file formats a demo can be recorded in. */
enum class RecFormat(val label: String, val ext: String, val note: String) {
    AAC("AAC", "m4a", "Small files, good sound"),
    WAV("WAV", "wav", "Exact copy of the sound, big files"),
    FLAC("FLAC", "flac", "Exact copy of the sound, about 60% of the size of WAV"),
    OPUS("Opus", "ogg", "Small files, very good sound (Android 10 and up)")
}

/** How a demo is recorded. [quality]: 0 Good, 1 High, 2 Studio. [raw]: no automatic volume or noise clean-up. */
class RecordingConfig(val format: RecFormat, val quality: Int, val raw: Boolean) {
    /** The sample rate and channels asked for, before the phone says what it can do. */
    val rate: Int get() = if (format == RecFormat.OPUS) 48_000 else if (quality == 0) 44_100 else 48_000
    val channels: Int get() = if (quality == 0) 1 else 2

    /** The bit rate of the compressed formats (AAC, Opus), in bits per second. */
    val bitRate: Int
        get() = when (format) {
            RecFormat.OPUS -> intArrayOf(96_000, 160_000, 256_000)[quality]
            else -> intArrayOf(128_000, 256_000, 320_000)[quality]
        }

    /** "48 kHz · stereo · FLAC", for the recording dialog. */
    fun describe(rate: Int = this.rate, channels: Int = this.channels): String {
        val ch = if (channels == 2) "stereo" else "mono"
        val extra = if (format == RecFormat.AAC || format == RecFormat.OPUS) " · ${bitRate / 1000} kbps" else ""
        return "${"%.1f".format(rate / 1000.0).removeSuffix(".0")} kHz · $ch · ${format.label}$extra"
    }

    companion object {
        fun from(format: Int, quality: Int, raw: Boolean): RecordingConfig {
            val f = RecFormat.values().getOrElse(format) { RecFormat.AAC }
            val usable = if (f in RecFormats.available()) f else RecFormat.AAC
            return RecordingConfig(usable, quality.coerceIn(0, 2), raw)
        }
    }
}

object RecFormats {
    private val opus: Boolean by lazy {
        Build.VERSION.SDK_INT >= 29 && runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { it.isEncoder && it.supportedTypes.any { t -> t.equals("audio/opus", true) } }
        }.getOrDefault(false)
    }

    /** The formats this phone can record: Opus only where it has an Opus encoder. */
    fun available(): List<RecFormat> = RecFormat.values().filter { it != RecFormat.OPUS || opus }
}
