package com.songbook.app.ui.components

import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.unit.em
import androidx.compose.foundation.background
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

// ---- GLASS: floating translucent tab bar + round plus ---------------------------------------

@Composable
fun GlassTabBar(current: String?, onNavigate: (String) -> Unit, onNew: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(modifier.fillMaxWidth()) {
        // list content fades out under the bar instead of running through it
        Box(
            Modifier.matchParentSize()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, c.bg.copy(alpha = 0.96f))))
        )
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp).padding(top = 34.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        Row(
            Modifier
                .weight(1f)
                .height(58.dp)
                .glassSurface(RoundedCornerShape(29.dp), strong = true)
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TopDests.forEach { d ->
                val on = d.route == current
                val tint = if (on) c.ac else c.mu
                Column(
                    Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (on) (if (c.isDark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.06f)) else Color.Transparent)
                        .clickable { onNavigate(d.route) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    StrokeIcon(d.icon, tint, size = 22.dp)
                    Text(d.label, style = sbStyle(9, FontWeight.Medium, tint), maxLines = 1)
                }
            }
        }
        Box(
            Modifier
                .size(58.dp)
                .shadow(12.dp, CircleShape, ambientColor = c.ac.copy(alpha = 0.5f), spotColor = c.ac.copy(alpha = 0.5f))
                .background(c.ac, CircleShape)
                .clip(CircleShape)
                .clickable(onClick = onNew)
                .semantics { contentDescription = "New song" },
            contentAlignment = Alignment.Center
        ) { StrokeIcon(SbIcons.Plus, Color.White, size = 28.dp) }
    }
    }
}

// ---- CORAL: round buttons, a centered title and a coral plus ----------------------------------------

class MenuAction(val label: String, val run: () -> Unit)

/** Round button of the Coral top bar: a dark gray (white in light mode) circle with a thin line icon, no outline. */
@Composable
fun CoralRoundButton(icon: IconSpec, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier
            .size(44.dp)
            .background(c.cd, CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, c.tx, size = 22.dp) }
}

/**
 * Top bar of the Coral look, the same on every page: a round menu button on the left, "songbook" in the middle
 * and a round search button on the right. The page name sits under the bar, left aligned, in bold.
 * The menu button opens the way between Songs, Albums, Favorites, Statistics and Settings; [extras] adds what
 * the page itself can do (sort, layout...). A page that is a step deeper passes [onBack], which turns the
 * menu button into a back arrow.
 */
@Composable
fun CoralTopBar(
    pageTitle: String,
    onSearch: (() -> Unit)?,
    modifier: Modifier = Modifier,
    current: String? = null,
    onNavigate: (String) -> Unit = {},
    extras: List<MenuAction> = emptyList(),
    onBack: (() -> Unit)? = null,
    subtitle: String? = null,
    /** A small pill on the right of the page name ("24 songs"), like Paperback's "3 books". */
    chip: String? = null
) {
    val c = Sb.colors
    var open by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 16.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) {
                if (onBack != null) CoralRoundButton(SbIcons.Back, "Back", onBack)
                else CoralRoundButton(SbIcons.Menu, "Menu", { open = true })
                DropdownMenu(
                    expanded = open,
                    onDismissRequest = { open = false },
                    shape = RoundedCornerShape(28.dp),
                    containerColor = c.sheet,
                    tonalElevation = 0.dp,
                    shadowElevation = 12.dp
                ) {
                    val pages = listOf(
                        Triple("library", "Songs", SbIcons.Music),
                        Triple("albums", "Albums", SbIcons.Albums),
                        Triple("favorites", "Favorites", SbIcons.Heart),
                        Triple("stats", "Statistics", SbIcons.Stats),
                        Triple("settings", "Settings", SbIcons.Sliders)
                    )
                    pages.forEach { (route, label, icon) ->
                        val on = route == current
                        DropdownMenuItem(
                            text = { Text(label, style = sbStyle(16, FontWeight.Medium, c.tx)) },
                            leadingIcon = { StrokeIcon(icon, c.tx, size = 22.dp) },
                            trailingIcon = if (on) {
                                { Box(Modifier.size(10.dp).background(c.ac, CircleShape)) }
                            } else null,
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(22.dp))
                                .background(if (on) c.cd else Color.Transparent),
                            onClick = { open = false; if (!on) onNavigate(route) }
                        )
                    }
                    if (extras.isNotEmpty()) {
                        Box(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().height(1.dp).background(c.ln))
                        extras.forEach { a ->
                            DropdownMenuItem(
                                text = { Text(a.label, style = sbStyle(15, FontWeight.Medium, c.tx)) },
                                modifier = Modifier.padding(horizontal = 8.dp),
                                onClick = { open = false; a.run() }
                            )
                        }
                    }
                }
            }
            Text(
                "songbook",
                style = sbStyle(26, FontWeight.Medium, c.tx).copy(letterSpacing = (-0.02).em),
                maxLines = 1,
                modifier = Modifier.align(Alignment.Center)
            )
            if (onSearch != null) CoralRoundButton(SbIcons.Search, "Search", onSearch, Modifier.align(Alignment.CenterEnd))
        }
        // the page name is a quiet label under the wordmark (16 sp, medium) with an optional pill on the right
        Row(
            Modifier.fillMaxWidth().heightIn(min = 36.dp).padding(start = 26.dp, end = 24.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                pageTitle,
                style = sbStyle(16, FontWeight.Medium, c.tx),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (chip != null) {
                Row(
                    Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(c.cd).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).background(c.ac, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(chip, style = sbStyle(13, FontWeight.Medium, c.tx), maxLines = 1)
                }
            }
        }
        if (subtitle != null) {
            Text(subtitle, style = sbStyle(13, color = c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 26.dp, end = 24.dp, top = 2.dp))
        }
    }
}

/**
 * The Coral bottom bar, copied from Paperback: white, a soft shadow on top, a gray icon and label for each page and
 * a soft pill behind the icon (accent colored) for the page you are on.
 */
@Composable
fun CoralBottomBar(current: String?, onNavigate: (String) -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier
            .fillMaxWidth()
            .shadow(10.dp, RectangleShape, ambientColor = Color.Black.copy(alpha = 0.05f), spotColor = Color.Black.copy(alpha = 0.08f))
            .background(c.bg)
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().height(NavBarHeight).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TopDests.forEach { d ->
                val on = d.route == current
                val tint = if (on) c.ac else c.mu
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onNavigate(d.route) }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.height(32.dp).width(64.dp).background(if (on) c.cd else Color.Transparent, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { StrokeIcon(d.icon, tint, size = 24.dp) }
                    Text(d.label, style = sbStyle(12, FontWeight.Medium, tint), maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

/** Coral plus button for a new song. */
@Composable
fun CoralFab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier
            .size(60.dp)
            .shadow(8.dp, CircleShape, ambientColor = c.ac.copy(alpha = 0.3f), spotColor = c.ac.copy(alpha = 0.3f))
            .background(c.ac, CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "New song" },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(SbIcons.Plus, c.onAc, size = 28.dp) }
}

/** Round translucent button used by the glass look (back, more, close...). */
@Composable
fun GlassRoundButton(icon: IconSpec, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Sb.colors.tx) {
    Box(
        modifier.size(40.dp).glassSurface(CircleShape).clip(CircleShape).clickable(onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, tint, size = 20.dp) }
}

/** Title block of the glass look: big title with a muted line under it. */
@Composable
fun GlassTitle(title: String, subtitle: String?, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier) {
        Text(title, style = sbStyle(26, FontWeight.Bold, c.tx))
        if (subtitle != null) Text(subtitle, style = sbStyle(12, color = c.mu), modifier = Modifier.padding(top = 3.dp))
    }
}

/** Small spacer-width helper so call sites read well. */
@Composable
fun HSpace(w: Int) = Box(Modifier.width(w.dp))
