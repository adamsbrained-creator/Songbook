package com.songbook.app.analysis

/**
 * How a chord is played on a guitar in standard tuning. [frets] has six entries from the low E string to the high
 * e string: -1 = not played, 0 = open, n = fret n. [barre] is the fret of a barre (0 = none) and [barreFrom] the
 * first string it covers.
 */
class GuitarShape(val frets: IntArray, val barre: Int = 0, val barreFrom: Int = 0) {
    /** The first fret drawn: 1, or the lowest fret used when the chord sits higher on the neck. */
    val baseFret: Int
        get() {
            val used = frets.filter { it > 0 }
            if (used.isEmpty()) return 1
            return if ((used.maxOrNull() ?: 1) <= 4) 1 else (used.minOrNull() ?: 1)
        }
}

object GuitarShapes {
    /** Open-position shapes: "root:type" to the frets of the six strings, x = not played. */
    private val OPEN = mapOf(
        "0:" to "x32010", "0:maj7" to "x32000", "0:7" to "x32310", "0:sus2" to "x30010", "0:sus4" to "x33011",
        "2:" to "xx0232", "2:m" to "xx0231", "2:7" to "xx0212", "2:maj7" to "xx0222", "2:m7" to "xx0211",
        "2:sus4" to "xx0233", "2:sus2" to "xx0230",
        "4:" to "022100", "4:m" to "022000", "4:7" to "020100", "4:maj7" to "021100", "4:m7" to "020000",
        "4:sus4" to "022200", "4:sus2" to "024400",
        "5:maj7" to "xx3210",
        "7:" to "320003", "7:7" to "320001", "7:maj7" to "320002", "7:sus4" to "330013",
        "9:" to "x02220", "9:m" to "x02210", "9:7" to "x02020", "9:maj7" to "x02120", "9:m7" to "x02010",
        "9:sus4" to "x02230", "9:sus2" to "x02200",
        "11:7" to "x21202"
    )

    /** Barre shapes with the root on the low E string, relative to the barre fret. */
    private val E_SHAPE = mapOf(
        "" to intArrayOf(0, 2, 2, 1, 0, 0), "m" to intArrayOf(0, 2, 2, 0, 0, 0), "7" to intArrayOf(0, 2, 0, 1, 0, 0),
        "m7" to intArrayOf(0, 2, 0, 0, 0, 0), "maj7" to intArrayOf(0, 2, 1, 1, 0, 0),
        "sus4" to intArrayOf(0, 2, 2, 2, 0, 0), "sus2" to intArrayOf(0, 2, 4, 4, 0, 0)
    )

    /** Barre shapes with the root on the A string. */
    private val A_SHAPE = mapOf(
        "" to intArrayOf(-1, 0, 2, 2, 2, 0), "m" to intArrayOf(-1, 0, 2, 2, 1, 0), "7" to intArrayOf(-1, 0, 2, 0, 2, 0),
        "m7" to intArrayOf(-1, 0, 2, 0, 1, 0), "maj7" to intArrayOf(-1, 0, 2, 1, 2, 0),
        "sus4" to intArrayOf(-1, 0, 2, 2, 3, 0), "sus2" to intArrayOf(-1, 0, 2, 2, 0, 0)
    )

    fun shape(root: Int, type: String): GuitarShape? {
        val open = OPEN["$root:$type"]
        if (open != null) return GuitarShape(IntArray(6) { if (open[it] == 'x') -1 else open[it] - '0' })
        val e = E_SHAPE[type] ?: return null
        val a = A_SHAPE[type] ?: return null
        var fe = Math.floorMod(root - 4, 12)
        if (fe == 0) fe = 12
        var fa = Math.floorMod(root - 9, 12)
        if (fa == 0) fa = 12
        return if (fa < fe) {
            GuitarShape(IntArray(6) { if (a[it] < 0) -1 else a[it] + fa }, barre = fa, barreFrom = 1)
        } else {
            GuitarShape(IntArray(6) { e[it] + fe }, barre = fe, barreFrom = 0)
        }
    }
}
