package com.songbook.app.ui

import com.songbook.app.ui.screens.AnalyzerPrefs
import com.songbook.app.ui.screens.AnalyzerDemo
import com.songbook.app.ui.components.SongPickDialog
import com.songbook.app.recording.RecordingConfig
import android.net.Uri
import com.songbook.app.ui.screens.AnalyzerScreen
import com.songbook.app.ui.components.swipePages
import com.songbook.app.ui.components.PageActionsHolder
import com.songbook.app.ui.components.LocalPageActions
import com.songbook.app.ui.components.LocalOpenMenu
import com.songbook.app.ui.components.AllPagesSheet
import com.songbook.app.ui.components.NavMenuOverlay
import androidx.compose.runtime.CompositionLocalProvider
import androidx.activity.compose.BackHandler
import com.songbook.app.ui.components.CoralBottomBar
import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.songbook.app.applySystemBars
import com.songbook.app.data.AlbumSort
import com.songbook.app.data.autoKey
import com.songbook.app.data.SongEntity
import com.songbook.app.data.SongSort
import com.songbook.app.data.TrackSort
import com.songbook.app.data.inAlbumOrder
import com.songbook.app.data.sideList
import com.songbook.app.data.sortedAlbums
import com.songbook.app.data.sortedGroups
import com.songbook.app.data.sortedSongs
import com.songbook.app.data.withAlbumCover
import com.songbook.app.data.Stage
import com.songbook.app.data.ThemeMode
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.components.GlassBackdrop
import com.songbook.app.ui.components.GlassTabBar
import com.songbook.app.ui.components.BpmDialog
import com.songbook.app.ui.components.CommentDialog
import com.songbook.app.ui.components.CoralFab
import com.songbook.app.ui.components.KeyDialog
import com.songbook.app.ui.components.RecorderDialog
import com.songbook.app.ui.components.NavBarHeight
import com.songbook.app.ui.components.SbBottomBar
import com.songbook.app.ui.components.SbFab
import com.songbook.app.ui.components.SongMenuActions
import com.songbook.app.ui.components.SongMenuSheet
import com.songbook.app.ui.components.TopDests
import com.songbook.app.ui.components.greetingLine
import com.songbook.app.ui.components.songType
import com.songbook.app.ui.screens.AlbumActions
import com.songbook.app.ui.screens.AlbumScreen
import com.songbook.app.ui.screens.AlbumsActions
import com.songbook.app.ui.screens.ArrangeItem
import com.songbook.app.ui.screens.ArrangeScreen
import com.songbook.app.ui.screens.GroupActions
import com.songbook.app.ui.screens.AlbumsScreen
import com.songbook.app.ui.screens.DeskScreen
import com.songbook.app.ui.screens.EditorScreen
import com.songbook.app.ui.screens.FavoritesScreen
import com.songbook.app.ui.screens.GroupScreen
import com.songbook.app.ui.screens.LibraryActions
import com.songbook.app.ui.screens.LibraryScreen
import com.songbook.app.ui.screens.NewSongRequest
import com.songbook.app.ui.screens.NewSongSheet
import com.songbook.app.ui.screens.OnboardingScreen
import com.songbook.app.ui.screens.ReaderActions
import com.songbook.app.ui.screens.SettingsScreen
import com.songbook.app.ui.screens.SongScreen
import com.songbook.app.ui.screens.StatsScreen
import com.songbook.app.ui.screens.TunerScreen
import com.songbook.app.ui.screens.WorkflowScreen
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.SongbookTheme

@Composable
fun SongbookRoot(vm: AppViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val settingsLoaded by vm.settingsLoaded.collectAsStateWithLifecycle()
    val dbSongs by vm.songs.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val groups by vm.groups.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val recordings by vm.recordings.collectAsStateWithLifecycle()

    val systemDark = isSystemInDarkTheme()
    val dark = when (settings.theme) {
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
        ThemeMode.System -> systemDark
    }
    val context = LocalContext.current
    (context as? ComponentActivity)?.let { activity ->
        LaunchedEffect(dark) { activity.applySystemBars(dark) }
    }

    // Wait for the saved settings so the intro / theme do not flash on every launch.
    if (!settingsLoaded) {
        Box(Modifier.fillMaxSize().background(if (systemDark) Color(0xFF0B0B0D) else Color(0xFFF5F5F7)))
        return
    }

    SongbookTheme(dark = dark, accent = settings.accent, accentCustom = settings.accentCustom, style = settings.uiStyle) {
        val c = Sb.colors

        if (!settings.onboarded) {
            Box(Modifier.fillMaxSize()) {
                if (settings.uiStyle == UiStyle.GLASS) GlassBackdrop()
                OnboardingScreen(
                    initialName = settings.userName,
                    onDone = { name -> vm.edit { setUserName(name); setOnboarded(true) } }
                )
            }
            return@SongbookTheme
        }

        val nav = rememberNavController()
        val backEntry by nav.currentBackStackEntryAsState()
        val route = backEntry?.destination?.route
        val coral = settings.uiStyle == UiStyle.CORAL
        val topLevel = route != null && (TopDests.any { it.route == route } || (coral && route == "stats"))
        val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        var newSong by remember { mutableStateOf<NewSongRequest?>(null) }
        var pickRecordSong by remember { mutableStateOf(false) }
        var menuSongId by remember { mutableStateOf<Long?>(null) }
        // "key", "bpm", "comment" or "record" for one song: asked for from the song menu or from the reader
        var tool by remember { mutableStateOf<Pair<String, Long>?>(null) }
        var searchTick by remember { mutableIntStateOf(0) }
        val albumNames = remember(albums) { albums.associate { it.id to it.name } }

        // Songs are drawn with the cover of their album (unless the cover was chosen by hand). These copies are
        // only for drawing; everything that saves goes through the view model, which reads the stored song.
        val albumsById = remember(albums) { albums.associateBy { it.id } }
        val allSongs = remember(dbSongs, albumsById) { dbSongs.map { it.withAlbumCover(albumsById) } }
        // Ideas live on the Workflow page only; every other screen sees the songs without them.
        val songs = remember(allSongs) { allSongs.filter { it.stage != Stage.IDEA } }
        val workflowCount = remember(allSongs) { allSongs.count { it.stage < Stage.DONE } }
        val ideaCount = remember(allSongs) { allSongs.count { it.stage == Stage.IDEA } }

        fun navigateTop(dest: String) {
            nav.navigate(dest) {
                popUpTo("library") { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
        fun openSong(id: Long) {
            nav.navigate("song/$id")
        }

        var menuOpen by remember { mutableStateOf(false) }
        var allOpen by remember { mutableStateOf(false) }

        // Paperback's swipes (Coral): right goes back, or to the previous main page; left goes to the next main
        // page. Not on the reader or the editors, where sideways drags belong to the text.
        val tabOrder = listOf("library", "albums", "favorites", "settings")
        val tabIndex = tabOrder.indexOf(route)
        val swipeHere = coral && route != null &&
            (topLevel || route == "workflow" || route.startsWith("album/") || route.startsWith("group/"))
        val swipeRight: (() -> Unit)? = when {
            !swipeHere -> null
            tabIndex >= 0 && (settings.swipeTabs || settings.hideNav) -> tabOrder.getOrNull(tabIndex - 1)?.let { prev -> { navigateTop(prev) } }
            settings.swipeBack && nav.previousBackStackEntry != null -> { { nav.popBackStack() } }
            else -> null
        }
        val swipeLeft: (() -> Unit)? =
            if (swipeHere && tabIndex >= 0 && (settings.swipeTabs || settings.hideNav)) tabOrder.getOrNull(tabIndex + 1)?.let { next -> { navigateTop(next) } } else null
        val pageActions = remember { PageActionsHolder() }
        BackHandler(enabled = menuOpen || allOpen) { menuOpen = false; allOpen = false }

        CompositionLocalProvider(LocalOpenMenu provides { menuOpen = true }, LocalPageActions provides pageActions) {
        Box(Modifier.fillMaxSize().background(c.bg)) {
            if (Sb.style == UiStyle.GLASS) GlassBackdrop()
            NavHost(
                nav, startDestination = "library",
                modifier = Modifier.fillMaxSize().swipePages(!menuOpen && !allOpen, swipeRight, swipeLeft)
            ) {
                composable("library") {
                    LibraryScreen(
                        songs = songs,
                        albums = albums,
                        settings = settings,
                        greeting = greetingLine(settings),
                        workflowCount = workflowCount,
                        ideaCount = ideaCount,
                        searchTick = searchTick,
                        actions = LibraryActions(
                            onOpenSong = ::openSong,
                            onOpenAlbum = { nav.navigate("album/$it") },
                            onToggleFavorite = vm::toggleFavorite,
                            onMenu = { menuSongId = it },
                            onOpenWorkflow = { nav.navigate("workflow") },
                            onNew = { newSong = NewSongRequest() },
                            onNavigate = ::navigateTop,
                            onSettings = { navigateTop("settings") },
                            onSongSort = { v -> vm.edit { setSongSort(v) } },
                            onSongsLayout = { v -> vm.edit { setSongsLayout(v) } },
                            onArrangeSongs = { nav.navigate("arrange/songs/0") },
                            onSaveHome = { v -> vm.edit { if (coral && settings.coralHome == 2) setHomeLayoutTools(v) else setHomeLayout(v) } },
                            onOpenAnalyzer = { nav.navigate("analyzer") },
                            onOpenLive = { nav.navigate("analyzer?live=1") },
                            onOpenTuner = { nav.navigate("tuner") },
                            onRecordDemo = { pickRecordSong = true },
                            onSaveTiles = { v -> vm.setHomeTiles(v) },
                            onSetTheme = { i -> vm.setTheme(ThemeMode.entries[i]) },
                            onSetHideNav = { v -> vm.setHideNav(v) }
                        )
                    )
                }
                composable("albums") {
                    AlbumsScreen(
                        albums = albums,
                        songs = songs,
                        groups = groups,
                        settings = settings,
                        workflowCount = workflowCount,
                        ideaCount = ideaCount,
                        actions = AlbumsActions(
                            onOpenAlbum = { nav.navigate("album/$it") },
                            onOpenGroup = { nav.navigate("group/$it") },
                            onCreateAlbum = { vm.createAlbum(it) },
                            onCreateGroup = { name, ids -> vm.createGroup(name, ids) },
                            onOpenWorkflow = { nav.navigate("workflow") },
                            onNavigate = ::navigateTop,
                            onSettings = { navigateTop("settings") },
                            onSearch = { navigateTop("library"); searchTick++ },
                            onAlbumSort = { v -> vm.edit { setAlbumSort(v) } },
                            onAlbumColumns = { v -> vm.edit { setAlbumColumns(v) } },
                            onGroupColumns = { v -> vm.edit { setGroupColumns(v) } },
                            onArrange = { kind -> nav.navigate("arrange/$kind/0") },
                            onSaveLayout = { v -> vm.edit { setAlbumsLayout(v) } }
                        )
                    )
                }
                composable("favorites") {
                    FavoritesScreen(
                        songs = songs,
                        albums = albums,
                        onOpenSong = ::openSong,
                        onToggleFavorite = vm::toggleFavorite,
                        onMenu = { menuSongId = it },
                        onNavigate = ::navigateTop,
                        onSettings = { navigateTop("settings") },
                        onNew = { newSong = NewSongRequest() },
                        layout = settings.favLayout,
                        onSearch = { navigateTop("library"); searchTick++ }
                    )
                }
                composable("settings") {
                    SettingsScreen(
                        settings = settings,
                        vm = vm,
                        songTotal = allSongs.size,
                        songsFinished = allSongs.count { it.stage >= Stage.DONE },
                        onReplayIntro = { vm.edit { setOnboarded(false) } },
                        onOpenWorkflow = { nav.navigate("workflow") },
                        onOpenStats = { navigateTop("stats") },
                        onOpenAnalyzer = { nav.navigate("analyzer") },
                        onOpenTuner = { nav.navigate("tuner") },
                        onNavigate = ::navigateTop,
                        onSearch = { navigateTop("library"); searchTick++ }
                    )
                }

                composable(
                    "analyzer?file={file}&title={title}&song={song}&live={live}",
                    arguments = listOf(
                        navArgument("file") { type = NavType.StringType; defaultValue = "" },
                        navArgument("title") { type = NavType.StringType; defaultValue = "" },
                        navArgument("song") { type = NavType.LongType; defaultValue = 0L },
                        navArgument("live") { type = NavType.IntType; defaultValue = 0 }
                    )
                ) { entry ->
                    val songId = entry.arguments?.getLong("song") ?: 0L
                    AnalyzerScreen(
                        onBack = { nav.popBackStack() },
                        onSave = { title, body, key, bpm, comment ->
                            vm.createSong(SongEntity(title = title, body = body, songKey = key, bpm = bpm, comment = comment)) { newId -> openSong(newId) }
                        },
                        recordingFile = entry.arguments?.getString("file").orEmpty(),
                        recordingTitle = entry.arguments?.getString("title").orEmpty(),
                        songId = songId,
                        onAddToSong = { sid, chords ->
                            val old = allSongs.firstOrNull { it.id == sid }?.body.orEmpty().trimEnd()
                            vm.setBody(sid, if (old.isEmpty()) chords else old + "\n\n" + chords)
                            openSong(sid)
                        },
                        songs = allSongs,
                        demos = recordings.sortedByDescending { it.createdAt }.mapNotNull { r ->
                            allSongs.firstOrNull { it.id == r.songId }?.let { s -> AnalyzerDemo(r.file, r.title, s.title, s.id, (r.durationMs / 1000).toInt()) }
                        },
                        prefs = AnalyzerPrefs(
                            settings.anaDefault, settings.anaLast, settings.anaOpenLast, settings.anaTabs, settings.anaPlayer, settings.anaInstrument,
                            liveSens = settings.liveSens, livePrecise = settings.livePrecise
                        ),
                        onPrefs = { p ->
                            vm.setAnalyzer(p.default, p.last, p.openLast, p.tabs, p.player, p.instrument)
                            vm.edit { setLive(p.liveSens, p.livePrecise) }
                        },
                        onRecord = { pickRecordSong = true },
                        startLive = (entry.arguments?.getInt("live") ?: 0) == 1
                    )
                }

                composable("tuner") {
                    TunerScreen(
                        onBack = { nav.popBackStack() },
                        tuningIndex = settings.tunerTuning,
                        refHz = settings.tunerRef,
                        onTuning = { i -> vm.edit { setTunerTuning(i) } },
                        onRef = { hz -> vm.edit { setTunerRef(hz) } }
                    )
                }

                composable("stats") {
                    StatsScreen(
                        songs = allSongs,
                        albums = albums,
                        groups = groups,
                        recordings = recordings,
                        onBack = { nav.popBackStack() },
                        onNavigate = ::navigateTop,
                        onOpenSong = ::openSong,
                        onOpenWorkflow = { nav.navigate("workflow") }
                    )
                }

                composable("workflow") {
                    WorkflowScreen(
                        songs = allSongs,
                        albums = albums,
                        onBack = { nav.popBackStack() },
                        onOpenSong = ::openSong,
                        onOpenDesk = { nav.navigate("desk/$it") },
                        onPatch = { id, change -> vm.patchSong(id, change = change) },
                        onNewIdea = { newSong = NewSongRequest(stage = Stage.IDEA) }
                    )
                }

                composable("desk/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments!!.getLong("id")
                    if (!loaded) Box(Modifier.fillMaxSize()) else DeskScreen(
                        song = dbSongs.firstOrNull { it.id == id },
                        onBack = { nav.popBackStack() },
                        onSave = { vm.saveSong(it) },
                        onEditText = { nav.navigate("edit/$it") }
                    )
                }

                composable("album/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments!!.getLong("id")
                    if (!loaded) Box(Modifier.fillMaxSize()) else AlbumScreen(
                        album = albums.firstOrNull { it.id == id },
                        songs = songs,
                        settings = settings,
                        userName = settings.userName,
                        actions = AlbumActions(
                            onBack = { nav.popBackStack() },
                            onOpenSong = ::openSong,
                            onToggleFavorite = vm::toggleFavorite,
                            onMenu = { menuSongId = it },
                            onAddSong = { newSong = NewSongRequest(it) },
                            onUpdateAlbum = vm::updateAlbum,
                            onDeleteAlbum = vm::deleteAlbum,
                            onTrackLayout = { v -> vm.edit { setTrackLayout(v) } },
                            onTrackSort = { v -> vm.edit { setTrackSort(v) } },
                            onArrange = { nav.navigate("arrange/tracks/$it") },
                            onSetSides = { album, names -> vm.setAlbumSides(album, names) },
                            onRemoveSide = { album, index -> vm.removeAlbumSide(album, index) },
                            onFollowCover = vm::followAlbumCover,
                            onQuickAdd = { albumId, title ->
                                vm.createSong(SongEntity(title = title, albumId = albumId)) { newId -> nav.navigate("edit/$newId?new=true") }
                            }
                        )
                    )
                }

                composable("group/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments!!.getLong("id")
                    if (!loaded) Box(Modifier.fillMaxSize()) else GroupScreen(
                        group = groups.firstOrNull { it.id == id },
                        albums = albums,
                        songs = songs,
                        settings = settings,
                        actions = GroupActions(
                            onBack = { nav.popBackStack() },
                            onOpenAlbum = { nav.navigate("album/$it") },
                            onUpdateGroup = vm::updateGroup,
                            onSetMembers = { vm.setGroupMembers(id, it) },
                            onUngroup = { vm.ungroup(id) },
                            onArrange = { nav.navigate("arrange/members/$id") }
                        )
                    )
                }

                // drag songs, albums and groups into your own order
                composable(
                    "arrange/{kind}/{id}",
                    arguments = listOf(navArgument("kind") { type = NavType.StringType }, navArgument("id") { type = NavType.LongType })
                ) { entry ->
                    val kind = entry.arguments!!.getString("kind") ?: "songs"
                    val id = entry.arguments!!.getLong("id")
                    if (!loaded) Box(Modifier.fillMaxSize()) else {
                        val memberCounts = albums.groupingBy { it.groupId }.eachCount()
                        val groupIds = groups.map { it.id }.toSet()
                        val loose = albums.filter { it.groupId == null || it.groupId !in groupIds }
                        fun albumItem(a: com.songbook.app.data.AlbumEntity) =
                            ArrangeItem(a.id, a.name, a.typeName.ifBlank { "Album" } + " · " + a.year, a.gradient, a.image)
                        val sides: List<String> = if (kind == "tracks") (albums.firstOrNull { it.id == id }?.sideList ?: emptyList()) else emptyList()
                        val items: List<ArrangeItem> = when (kind) {
                            "tracks" -> songs.filter { it.albumId == id }.inAlbumOrder().map {
                                ArrangeItem(it.id, it.title, songType(it.typeName), it.gradient, it.image, it.side)
                            }
                            "albums" -> loose.sortedAlbums(AlbumSort.MANUAL).map(::albumItem)
                            "members" -> albums.filter { it.groupId == id }.sortedAlbums(AlbumSort.MANUAL).map(::albumItem)
                            "groups" -> groups.sortedGroups(AlbumSort.MANUAL).map {
                                ArrangeItem(it.id, it.name, it.typeName.ifBlank { "Group" } + " · " + (memberCounts[it.id] ?: 0) + " albums", it.gradient, it.image)
                            }
                            else -> songs.sortedSongs(SongSort.MANUAL, albumNames).map {
                                ArrangeItem(it.id, it.title, albumNames[it.albumId] ?: "No album", it.gradient, it.image)
                            }
                        }
                        ArrangeScreen(
                            title = when (kind) { "tracks" -> "Arrange songs"; "albums", "members" -> "Arrange albums"; "groups" -> "Arrange groups"; else -> "Arrange songs" },
                            items = items,
                            sides = sides,
                            onCancel = { nav.popBackStack() },
                            onDone = { ids ->
                                when (kind) {
                                    "tracks" -> { vm.arrange(ArrangeKind.TRACKS, ids); vm.edit { setTrackSort(TrackSort.ALBUM) } }
                                    "albums", "members" -> { vm.arrange(ArrangeKind.ALBUMS, ids); vm.edit { setAlbumSort(AlbumSort.MANUAL) } }
                                    "groups" -> { vm.arrange(ArrangeKind.GROUPS, ids); vm.edit { setAlbumSort(AlbumSort.MANUAL) } }
                                    else -> { vm.arrange(ArrangeKind.SONGS, ids); vm.edit { setSongSort(SongSort.MANUAL) } }
                                }
                                nav.popBackStack()
                            }
                        )
                    }
                }

                composable("song/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments!!.getLong("id")
                    val song = allSongs.firstOrNull { it.id == id }
                    if (!loaded) Box(Modifier.fillMaxSize()) else SongScreen(
                        song = song,
                        album = albums.firstOrNull { it.id == song?.albumId },
                        settings = settings,
                        appDark = dark,
                        recordings = recordings.filter { it.songId == id },
                        actions = ReaderActions(
                            onClose = { nav.popBackStack() },
                            onMenu = { menuSongId = id },
                            onEdit = { nav.navigate("edit/$id") },
                            onToggleFavorite = { song?.let(vm::toggleFavorite) },
                            onCapo = { capo, adjust -> song?.let { vm.setCapo(it, capo, adjust) } },
                            onShowTabs = { vm.setShowTabs(it) },
                            onReading = { l, ch, sp, off, sec -> vm.setReading(l, ch, sp, off, sec) },
                            onLyricsView = { v -> vm.edit { setLyricsView(v) } },
                            onAutoScroll = { vm.setAutoScroll(it) },
                            onScrollSpeed = { v -> vm.edit { setScrollSpeed(v) } },
                            onSongTheme = { v -> vm.edit { setSongTheme(v) } },
                            onRate = { r -> song?.let { vm.setRating(it, r) } },
                            onBody = { body -> vm.setBody(id, body) },
                            onKey = { tool = "key" to id },
                            onBpm = { tool = "bpm" to id },
                            onComment = { tool = "comment" to id },
                            onRecord = { tool = "record" to id },
                            onOpened = { vm.markOpened(id) },
                            onRead = { seconds -> vm.addReadSeconds(id, seconds) },
                            onRenameRecording = { rid, title -> vm.renameRecording(rid, title) },
                            onDeleteRecording = { rid -> vm.deleteRecording(rid) },
                            onAnalyzeRecording = { r -> nav.navigate("analyzer?file=${Uri.encode(r.file)}&title=${Uri.encode(r.title)}&song=$id") }
                        )
                    )
                }

                composable(
                    "edit/{id}?new={new}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.LongType },
                        navArgument("new") { type = NavType.BoolType; defaultValue = false }
                    )
                ) { entry ->
                    val id = entry.arguments!!.getLong("id")
                    val isNew = entry.arguments!!.getBoolean("new")
                    var song by remember { mutableStateOf<SongEntity?>(null) }
                    LaunchedEffect(id) { song = vm.getSong(id) }
                    EditorScreen(
                        song = song,
                        isNew = isNew,
                        albums = albums,
                        onClose = { nav.popBackStack() },
                        onDiscardNew = { vm.deleteSong(id); nav.popBackStack() },
                        onSave = { vm.saveSong(it) { nav.popBackStack() } },
                        onCreateAlbum = { name, done -> vm.createAlbum(name, onCreated = done) }
                    )
                }
            }

            if (topLevel) {
                when (Sb.style) {
                    UiStyle.GLASS -> GlassTabBar(
                        current = route,
                        onNavigate = ::navigateTop,
                        onNew = { newSong = NewSongRequest() },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                    // Coral copies Paperback: a bottom bar with a pill on the current page, the plus button above it
                    UiStyle.CORAL -> {
                        // "Bottom Navigation: Hide" (Settings > Look): the swipes and the menu are the way around
                        if (!settings.hideNav) CoralBottomBar(
                            current = route,
                            onNavigate = ::navigateTop,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                        // the plus button stays on the pages that list songs; everywhere else "New song" is in the menu
                        if (route == "library" || route == "albums") CoralFab(
                            onClick = { newSong = NewSongRequest() },
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = (if (settings.hideNav) 8.dp else NavBarHeight) + navInset + 16.dp)
                        )
                    }
                    else -> {
                        SbBottomBar(
                            current = route,
                            raised = settings.navRaised,
                            onNavigate = ::navigateTop,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                        SbFab(
                            raised = settings.navRaised,
                            onClick = { newSong = NewSongRequest() },
                            modifier = if (settings.navRaised) {
                                Modifier.align(Alignment.BottomCenter).padding(bottom = 44.dp + navInset)
                            } else {
                                Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = NavBarHeight + navInset + 20.dp)
                            }
                        )
                    }
                }
            }

            if (coral) {
                NavMenuOverlay(
                    open = menuOpen,
                    current = route?.substringBefore('?'),
                    onClose = { menuOpen = false },
                    onGo = { dest ->
                        menuOpen = false; allOpen = false
                        if (dest == "workflow" || dest == "analyzer" || dest == "tuner") nav.navigate(dest) else navigateTop(dest)
                    },
                    onNewSong = { menuOpen = false; newSong = NewSongRequest() },
                    onMore = { menuOpen = false; allOpen = true }
                )
                AllPagesSheet(
                    open = allOpen,
                    pageActions = pageActions.actions,
                    onClose = { allOpen = false },
                    onGo = { dest ->
                        allOpen = false
                        if (dest == "workflow" || dest == "analyzer" || dest == "tuner") nav.navigate(dest) else navigateTop(dest)
                    }
                )
            }
        }
        }

        newSong?.let { request ->
            NewSongSheet(
                request = request,
                albums = albums,
                onDismiss = { newSong = null },
                onCreate = { input ->
                    newSong = null
                    vm.createSong(
                        SongEntity(
                            title = input.title,
                            albumId = input.albumId,
                            genre = input.genre,
                            tags = input.tags,
                            gradient = input.gradient,
                            body = input.body,
                            image = input.image,
                            stage = input.stage,
                            typeName = input.typeName,
                            coverManual = input.coverManual
                        )
                    ) { id ->
                        // ideas start on the songwriting desk, songs in the editor
                        if (input.stage == Stage.IDEA) nav.navigate("desk/$id") else nav.navigate("edit/$id?new=true")
                    }
                },
                onCreateAlbum = { name, done -> vm.createAlbum(name, onCreated = done) }
            )
        }

        val toolRequest = tool
        if (pickRecordSong) {
            SongPickDialog(
                "Record a demo for...", allSongs,
                onPick = { songId -> pickRecordSong = false; tool = "record" to songId },
                onDismiss = { pickRecordSong = false }
            )
        }
        val toolSong = toolRequest?.let { (_, id) -> allSongs.firstOrNull { it.id == id } }
        if (toolRequest != null && toolSong != null) {
            val close = { tool = null }
            when (toolRequest.first) {
                "key" -> KeyDialog(toolSong.songKey, toolSong.autoKey(), { vm.setKey(toolSong, it); close() }, close)
                "bpm" -> BpmDialog(toolSong.bpm, { vm.setBpm(toolSong, it); close() }, close)
                "comment" -> CommentDialog(
                    toolSong.comment,
                    onSave = { vm.setComment(toolSong, it); close() },
                    onRemove = if (toolSong.comment.isNotBlank()) ({ vm.setComment(toolSong, ""); close() }) else null,
                    onDismiss = close
                )
                "record" -> RecorderDialog(
                    config = RecordingConfig.from(settings.recFormat, settings.recQuality, settings.recRaw),
                    onSaved = { file, ms ->
                        vm.addRecording(toolSong.id, file.name, ms, "Demo " + (recordings.count { it.songId == toolSong.id } + 1))
                        close()
                    },
                    onDismiss = close
                )
            }
        }

        val menuSong = allSongs.firstOrNull { it.id == menuSongId }
        if (menuSong != null) {
            SongMenuSheet(
                song = menuSong,
                albumName = albumNames[menuSong.albumId],
                albums = albums,
                sides = albums.firstOrNull { it.id == menuSong.albumId }?.sideList ?: emptyList(),
                actions = SongMenuActions(
                    onEdit = { nav.navigate("edit/${menuSong.id}") },
                    onDesk = { nav.navigate("desk/${menuSong.id}") },
                    onDuplicate = { vm.duplicateSong(menuSong) },
                    onMove = { vm.moveToAlbum(menuSong, it) },
                    onCreateAlbumAndMove = { name -> vm.createAlbum(name) { id -> vm.moveToAlbum(menuSong, id) } },
                    onToggleFavorite = { vm.toggleFavorite(menuSong) },
                    onArtwork = { g, img -> vm.setArtwork(menuSong, g, img) },
                    onBadge = { t, col -> vm.setBadge(menuSong, t, col) },
                    onStage = { vm.setStage(menuSong, it) },
                    onRate = { vm.setRating(menuSong, it) },
                    onType = { vm.setType(menuSong, it) },
                    onSide = { vm.setSide(menuSong, it) },
                    onUseAlbumCover = { vm.useAlbumCover(menuSong) },
                    onRecord = { tool = "record" to menuSong.id },
                    onComment = { tool = "comment" to menuSong.id },
                    onKey = { tool = "key" to menuSong.id },
                    onBpm = { tool = "bpm" to menuSong.id },
                    onExport = { context.shareSong(menuSong) },
                    onDelete = { vm.deleteSong(menuSong.id) }
                ),
                onDismiss = { menuSongId = null }
            )
        }
    }
}

private fun Context.shareSong(song: SongEntity) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, song.title)
        putExtra(Intent.EXTRA_TEXT, "${song.title}\n\n${song.body}")
    }
    startActivity(Intent.createChooser(send, "Export song").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
