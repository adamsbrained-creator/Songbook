# Songbook 5.1 - Guitar tuner and Live chords (not yet compiled)

## 5.1 changes
- Tuner (menu > Tuner, Settings > Library > Guitar Tuner, home tile "Tuner"): listens to the microphone, finds the pitch with YIN (`analysis/Tuner.kt`), shows the note, Hz and a cents meter (green within 5 cents). Tunings: Standard, Drop D, Half/Full step down, DADGAD, Open G, Open D, Ukulele, Bass, Chromatic. Auto finds the string you play; tap a string to hear it (additive pluck tone) and lock it; a green dot marks strings held in tune. Reference pitch A = 430-450 Hz. Settings `tunerTuning`, `tunerRef` (in backups)
- Live mode of the chord analyzer (start page > "Live mode", home tile "Live chords"): `analysis/LiveChords.kt` is the engine's chroma/template idea on a 0.37 s moving window with hysteresis (a new chord must win clearly twice in a row), live tuning follow and a key guess. Shows the chord with its shape, the last chords, the 12 notes heard, level bar, capo, Basic/Precise, sensitivity. Save as song / copy / share. Settings `liveSens`, `livePrecise` (in backups). Nothing is recorded
- `analysis/MicStream.kt` (shared microphone reader, unprocessed source where available), `ui/components/MicPermission.kt`
- `ChordEngine` tables and FFT are now `internal` so Live mode reuses them (offline behavior unchanged)
- Version 5.1

# Songbook 5.0 - The chord analyzer, redesigned (not yet compiled)

## 5.0 changes
- Start page: a card with "Choose audio file" and "Record now" (asks which song, then records a demo), "From your songs" (the demos, one tap), "Recent" (kept analyses; press and hold removes one)
- While it listens: a progress ring with the three steps; the cross stops it
- Result: a header with the title, "E major · 99 BPM", and the Tune and Save buttons; a switch for four views: Play (the chord now with its shape, the next chord, a zoomed timeline, big player), Chords (the chords used, most played first, tap to jump), Chart (bar grid, bar numbers), Follow along (the chords scroll by, the current one big with its shape and beat dots). Small player on the other views
- Sheets: Views (which view, open on last used or this view, tabs on or off, player on every view), Tune (Basic/Precise, beats in a bar, tempo x2 / half, transpose, capo, instrument), Save (add to a song, save as a new song, keep this analysis, copy, share as text)
- Shapes for Guitar, Ukulele (searched, see `analysis/Instruments.kt`), Piano (two octaves, notes lit) or none. With a capo the shapes shown are lower; saved chords are the sounding ones
- Kept analyses: `analysis/AnalysisStore.kt` (index.json, one json per result, a copy of the audio for files from outside the app; demos are referenced, not copied). Not in backups yet
- Code: `ui/screens/AnalyzerScreen.kt` (flow and pages), `ui/screens/AnalyzerParts.kt` (player, chart, timeline, shapes, sheets). New settings `anaDefault`, `anaLast`, `anaOpenLast`, `anaTabs`, `anaPlayer`, `anaInstrument`
- Not done: the PDF chord sheet (text sharing only)
- Version 5.0

# Songbook 4.3 - Greeting size

## 4.3 changes
- Settings > Profile > Greeting Size: Hide / Small (22 sp) / Medium (26 sp, new standard) / Large (32 sp, what it was). It sets the size of "Hi, John" and the line under it on the Glassy and Tools main pages of the Coral look; Hide leaves only a small gap. New setting `greetingSize` (saved in backups). Version 4.3

# Songbook 4.2 - More home sections

## 4.2 changes (Coral look only)
- Every section of the main page can be hidden, moved or added: a "Customize this page" button now ends the page (it was only in the menu before). It opens the same list as before, with a switch for each of: Tiles, Filters, Search, Pinned albums, Favorite songs, Progress card, Chord analyzer card, Quick settings, Albums (grid), Workflow, Recent songs, All songs
- New sections: Chord analyzer card (dark card with "Analyze audio" and "Record a demo"), Quick settings (theme, bottom bar, "All settings"), Albums as a grid; the Progress card now also shows the numbers of songs, albums, favorites and songs in progress
- New tiles for the Tools section: Settings, and "Surprise me" (opens a random song)
- If everything is hidden the page says so, with the Customize button
- Version 4.2

# Songbook 4.1 - Tools home page, customizable home, hide the bottom bar

## 4.1 changes (Coral look only)
- Settings > Look > Home Layout now has a third choice, Tools: the Glassy main page with shortcut tiles under the greeting (mockup "A" from the design canvas): Chord analyzer, Record a demo, Workflow, Statistics, then the pinned albums and the songs. Tiles are two to a row, the first is coral. "Edit" next to Tools (or Settings > Look > Home Tiles) chooses and orders the tiles: also New song, Albums, Favorites
- "Record a demo" asks which song (`ui/components/SongPickDialog.kt`), then opens the recorder for it
- New blocks for every Coral main page (off by default except on Tools): Tiles, Favorite songs, Progress card. "Customize this page" (and Settings > Pages) orders and hides all of the blocks; the Tools page keeps its own order (`homeLayoutTools`) so it does not disturb the Classic and Glassy pages
- Settings > Look > Bottom Navigation: Show / Hide. Hidden: no bottom bar, the plus button drops down, and the swipes between Songs, Albums, Favorites and Settings are always on whatever "Swipe Between Pages" says; the menu button still opens everything
- New settings (saved in backups): `hideNav`, `homeTiles`, `homeLayoutTools`; `coralHome` can be 0, 1 or 2
- Version 4.1

# Songbook 4.0 - Better recordings, more formats

## 4.0 changes
- Demos are recorded by reading the microphone directly (AudioRecord) instead of the phone's ready-made recorder (`recording/AudioRecorder.kt`). With "Raw Microphone" on it asks for the unprocessed signal (no automatic volume, no noise or echo clean-up, which are made for calls); where the phone has none it uses the normal microphone. 16-bit samples at 48 kHz, in stereo where the phone allows it
- Formats (Settings > Recording > Format): AAC (.m4a), WAV (.wav, exact copy), FLAC (.flac, exact copy, about 60% of WAV; written by the app itself in `recording/Sinks.kt`, checked bit for bit against ffmpeg in `tools/flac-reference`), Opus (.ogg, only on phones with an Opus encoder, Android 10 and up)
- Quality: Good (44.1 kHz mono, AAC 128 kbps), High (48 kHz stereo, AAC 256), Studio (48 kHz stereo, AAC 320). Opus 96 / 160 / 256 kbps. WAV and FLAC are exact copies, so only the rate and the channels change
- The recording dialog shows what is really being recorded ("48 kHz · stereo · FLAC"); file names keep their format, also when restored from a backup; the chord analyzer reads all of them
- Old demos (.m4a) are untouched. New settings: `recFormat`, `recQuality`, `recRaw` (saved in backups)
- Version 4.0

# Songbook 3.9 - Analyze a song's demos, zoomed timeline

## 3.9 changes
- A demo recorded in a song has "Find chords" in its menu: the analyzer opens on it and starts at once (no copy is made, the demo is never deleted). Then "Add the chords to this song" adds the chord chart to the end of the song's text; "Save as song" still makes a new one. Route: `analyzer?file=&title=&song=` in `SongbookRoot.kt`
- The analyzer has a second, zoomed timeline: the 12 seconds around the playhead scroll by as the song plays, with the chords as blocks, the loudness, the beats and a fixed playhead in the middle; drag it to move through the song (`ZoomTimeline` in `AnalyzerScreen.kt`)
- Version 3.9

# Songbook 3.8 - Chord analyzer

## 3.8 changes
- New: Chord analyzer (menu > Chord analyzer, or Settings > Library > Chord Analyzer). Pick an audio file; it is decoded and analysed on the phone (nothing is uploaded) and shows the key, the tempo, the length, a timeline with the chords over the loudness curve, the chord now playing and the next one with guitar chord diagrams, the chords used, and a bar-by-bar chord chart. Play / pause, +-5 s, 1x / 0.75x / 0.5x, tap the timeline or a chart cell to jump. Basic (major and minor) or Precise (also 7, maj7, m7, sus4, sus2), 3 or 4 beats to a bar, tempo as found / x2 / half, transpose. "Save as song" makes a song with the chords, key and BPM; "Copy chords" puts the chart on the clipboard
- Code: `analysis/ChordEngine.kt` (chroma, tempo, key, templates, Viterbi), `analysis/AudioDecoder.kt` (MediaCodec to 11025 Hz mono), `analysis/GuitarShapes.kt`, `analysis/ChordNames.kt`, `ui/screens/AnalyzerScreen.kt`
- `tools/chord-engine-prototype/` is the Python version the engine was tuned in (10 synthetic test songs: about 95% Basic, 89% Precise, tempo 10/10, key 8/10). Real recordings will be harder
- The menu card scrolls on small screens; Version 3.8

# Songbook 3.7 - Outfit weights and more pages

## 3.7 changes
- Outfit now has all four weights: Regular and Bold are the original files, Medium (500) and SemiBold (600) are blended from them (`res/font/outfit_medium.ttf`, `outfit_semibold.ttf`, made by `tools/make_outfit_weights.py`). Before, Medium used the Regular file and SemiBold the Bold file. Drop the official Outfit Medium and SemiBold files over the two new ones (same names) to replace the blend
- Coral: the songwriting desk and the song editor get round header buttons, a plain title, and a gray "Edit text" pill / black "Done" pill
- Version 3.7

# Songbook 3.6 - Glassy home layout for Coral

## 3.6 changes
- New option Settings > Look > Home Layout (Coral only): Classic (default, unchanged) or Glassy. Glassy gives the Coral look the Glass look's main page: a big greeting with the tagline, the search box always shown, the pinned albums and recent songs as horizontal rows of plain tiles, then the songs. The Coral top bar, bottom bar and menu stay. Stored as `coralHome` (0 or 1); `Blocks.home(Glass)` supplies the default block order, so "Customize this page" works for it too (`CoralLibrary` in `LibraryScreen.kt`)
- Version 3.6

# Songbook 3.5 - Settings pages and empty states

## 3.5 changes (Coral look only)
- Settings is a short list of groups (Look, Library, Profile, Appearance, Layout, Sorting, Pages, Reading, Song Display, Data, About), each opening as its own page; Back or the arrow returns to the list (`SettingsGroup` + `SettingsNav` in `Common.kt`, state in `SettingsScreen.kt`)
- An empty library shows Paperback's empty card with a "New song" button (`CoralEmptyCard`)
- The Workflow page has the same header as the other pages, with "+ Idea" next to its title
- Version 3.5

# Songbook 3.4 - Paperback navigation and gestures

## 3.4 changes (Coral look only)
- Navigation like Paperback: the header's menu button opens a card of pages above a round close button; "More" opens a sheet with this page's actions and every page (`components/NavMenu.kt`, wired in `SongbookRoot.kt`)
- The plus button stays on Songs and Albums; "New song" is also the first row of the menu
- Gestures from Paperback 34 (`components/SwipeHost.kt`): swipe right to go back, swipe left or right on a main page to move between Songs, Albums, Favorites and Settings. Off in the reader and the editors. Two switches in Settings: "Swipe to Go Back", "Swipe Between Pages"
- Long press on a song row opens its menu
- Selected chips use the accent color; search is a big filled pill; "Sort: ..." and "View: ..." pills replace the two icon buttons; Albums and Favorites get the count pill
- Album tiles are a cover with the name under it, no card; album, group and reader pages use the wordmark with a small label under it
- Version 3.4

# Songbook 3.3 - closer to Paperback

## 3.3 changes (Coral look only)
- Paperback's palette: white page with soft gray (#F3F3F3) cards; black page and #161616 cards in dark (`theme/Theme.kt`)
- Bottom bar like Paperback's, with a soft pill on the current page, the plus button above it (`CoralBottomBar` in `Chrome.kt`)
- Header: lighter wordmark, the page name as a 16 sp label with a pill on the right ("24 songs" on the main page), rounded menu with icons
- Settings rows: an icon tile, the label, the value and a chevron, with the line starting under the label (`SettingsRow` in `Common.kt`)
- Main page: the pinned albums are a plain two-column grid, cover with the name and song count under it, no card (`albumsGrid` in `LibraryScreen.kt`)
- Version 3.3

# Songbook 3.2 - Paperback polish

## Build
One workflow now, like Eon: key in the repo (`app/debug.keystore`), builds loose files or a zip, APK in the run's Artifacts. See SIGNING.md.

## 3.2 changes (Coral look only; Old and Glass are untouched)
- Dialogs copy Paperback's PbDialog: big rounded card, serif title, Cancel pill + solid confirm pill (`CoralDialog` in `Dialogs.kt`)
- Text fields are filled and outline-free (`SbField` in `Fields.kt`, drop-in for OutlinedTextField)
- Segmented control is a soft track with a raised white thumb; switch has a lifted thumb on a softer off track
- Cards are flat with no hairline; settings dividers stop short of the card edges; section labels use Paperback's spacing
- Top bar: lighter wordmark, page name is a small label under it, 22dp icons

First `./gradlew assembleDebug` may still show small errors (nothing could be compiled here). Likeliest spots: `Dialogs.kt` imports, `Fields.kt`.

# Songbook 3.1 - new header and icon

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.
