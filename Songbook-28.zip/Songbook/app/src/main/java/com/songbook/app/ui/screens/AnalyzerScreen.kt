package com.songbook.app.ui.screens

import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.Dp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import com.songbook.app.ui.theme.Outfit
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.analysis.AnaMeta
import com.songbook.app.analysis.AnalysisResult
import com.songbook.app.analysis.AnalysisStore
import com.songbook.app.analysis.AudioDecoder
import com.songbook.app.analysis.ChordEngine
import com.songbook.app.analysis.ChordNames
import com.songbook.app.analysis.ChordSeg
import com.songbook.app.analysis.Instrument
import com.songbook.app.analysis.Lyrics
import androidx.compose.runtime.mutableStateListOf
import com.songbook.app.data.AudioStore
import com.songbook.app.data.SongEntity
import com.songbook.app.ui.components.IconSpec
import com.songbook.app.ui.components.SbDialog
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.SbSwitch
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.SongPickDialog
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.roundToInt

// The chord analyzer: a start page (a file, a demo, an earlier analysis), a page while it listens, and the result with
// four views of the chords (Play, Chords, Chart, Follow along), Tune, Save and Views sheets. The analysis is in
// analysis/ChordEngine.kt; the pieces shared by the views are in AnalyzerParts.kt.

/** A demo recorded in a song, as the start page lists it. [file] is its name in the audio folder. */
class AnalyzerDemo(val file: String, val title: String, val songTitle: String, val songId: Long, val seconds: Int)

/** How the analyzer's views are set up (Settings are saved by the caller). */
data class AnalyzerPrefs(
    val default: Int = 0,
    val last: Int = 0,
    val openLast: Boolean = false,
    val tabs: Boolean = true,
    val player: Boolean = true,
    val instrument: Int = 0,
    /** Live mode: 0 low, 1 normal, 2 high sensitivity, and whether it also hears 7th, maj7 and sus chords. */
    val liveSens: Int = 1,
    val livePrecise: Boolean = true
)

private sealed interface Phase {
    data object Idle : Phase
    /** Live mode: the chords of what is played now, from the microphone. */
    data object Live : Phase
    data class Working(val title: String, val progress: Float) : Phase
    data class Done(val title: String, val file: File, val result: AnalysisResult, val owned: Boolean, val demoName: String?, val keptId: String? = null) : Phase
    data class Failed(val message: String) : Phase
}

private fun displayName(context: Context, uri: Uri): String {
    var name: String? = null
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) name = cur.getString(0)
        }
    }
    return (name ?: "Recording").substringBeforeLast('.').ifBlank { "Recording" }
}

/** Decodes and analyses a file that is already on the phone. Returns Idle when cancelled. */
private fun analyzeLocal(
    context: Context, file: File, title: String, owned: Boolean, demoName: String?, set: (Phase) -> Unit, cancelled: () -> Boolean
): Phase {
    set(Phase.Working(title, 0.02f))
    val pcm = AudioDecoder.decode(context, Uri.fromFile(file), { set(Phase.Working(title, 0.02f + 0.28f * it)) }, cancelled) ?: return Phase.Idle
    set(Phase.Working(title, 0.3f))
    val result = ChordEngine.analyze(pcm, { set(Phase.Working(title, 0.3f + 0.7f * it)) }, cancelled) ?: return Phase.Idle
    return Phase.Done(title, file, result, owned, demoName)
}

/** Copies the picked file into the cache, then analyses it. */
private suspend fun runAnalysis(context: Context, uri: Uri, set: (Phase) -> Unit): Phase = withContext(Dispatchers.Default) {
    val job = coroutineContext[Job]
    var copy: File? = null
    try {
        val title = displayName(context, uri)
        set(Phase.Working(title, 0f))
        val target = File(context.cacheDir, "analyzer_${System.nanoTime()}.audio")
        copy = target
        val input = context.contentResolver.openInputStream(uri) ?: return@withContext Phase.Failed("Could not open the file.")
        input.use { src -> target.outputStream().use { dst -> src.copyTo(dst) } }
        val done = analyzeLocal(context, target, title, true, null, set) { job?.isActive == false }
        if (done !is Phase.Done) target.delete()
        done
    } catch (e: CancellationException) {
        copy?.delete()
        throw e
    } catch (e: Exception) {
        copy?.delete()
        Phase.Failed(e.message ?: "Could not analyse this file.")
    }
}

/** Analyses a demo recorded in Songbook, in place. */
private suspend fun runAnalysisFile(context: Context, file: File, title: String, demoName: String, set: (Phase) -> Unit): Phase =
    withContext(Dispatchers.Default) {
        val job = coroutineContext[Job]
        try {
            if (!file.exists()) return@withContext Phase.Failed("The recording could not be found.")
            analyzeLocal(context, file, title, false, demoName, set) { job?.isActive == false }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Phase.Failed(e.message ?: "Could not analyse this recording.")
        }
    }

@Composable
fun AnalyzerScreen(
    onBack: () -> Unit,
    onSave: (title: String, body: String, key: String, bpm: Int, comment: String) -> Unit,
    /** A demo of a song to analyse right away (the file name in the audio folder), with its title. */
    recordingFile: String = "",
    recordingTitle: String = "",
    /** The song the demo belongs to: the chords can be added to that song straight away. */
    songId: Long = 0L,
    onAddToSong: ((songId: Long, chords: String) -> Unit)? = null,
    songs: List<SongEntity> = emptyList(),
    demos: List<AnalyzerDemo> = emptyList(),
    prefs: AnalyzerPrefs = AnalyzerPrefs(),
    onPrefs: (AnalyzerPrefs) -> Unit = {},
    /** Record a demo (the app asks which song first). */
    onRecord: () -> Unit = {},
    /** Open on Live mode (the home tile does this). */
    startLive: Boolean = false,
    /** Replaces the whole text of a song (used to save chords and lyrics together). */
    onReplaceSong: ((songId: Long, body: String) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val direct = recordingFile.isNotEmpty()
    var phase by remember { mutableStateOf<Phase>(if (startLive && recordingFile.isEmpty()) Phase.Live else Phase.Idle) }
    var job by remember { mutableStateOf<Job?>(null) }
    var recent by remember { mutableStateOf<List<AnaMeta>>(emptyList()) }
    var removeMeta by remember { mutableStateOf<AnaMeta?>(null) }

    fun startDemo(file: String, title: String) {
        job?.cancel()
        job = scope.launch { phase = runAnalysisFile(context, AudioStore.file(context, file), title, file) { phase = it } }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            job?.cancel()
            job = scope.launch { phase = runAnalysis(context, uri) { phase = it } }
        }
    }
    DisposableEffect(Unit) { onDispose { job?.cancel() } }
    val doneFile = (phase as? Phase.Done)?.takeIf { it.owned }?.file
    DisposableEffect(doneFile) { onDispose { doneFile?.delete() } }
    LaunchedEffect(recordingFile) {
        if (direct && phase is Phase.Idle) startDemo(recordingFile, recordingTitle.ifBlank { "Demo" })
    }
    LaunchedEffect(phase is Phase.Idle) {
        if (phase is Phase.Idle) recent = withContext(Dispatchers.IO) { AnalysisStore.list(context) }
    }

    BackHandler(enabled = phase is Phase.Working) {
        job?.cancel()
        phase = Phase.Idle
        if (direct) onBack()
    }
    BackHandler(enabled = (phase is Phase.Done || phase is Phase.Failed) && !direct) { phase = Phase.Idle }

    Box(Modifier.fillMaxSize().screenBg().statusBarsPadding()) {
        when (val p = phase) {
            is Phase.Done -> ResultPage(
                p, prefs, onPrefs, { if (direct) onBack() else phase = Phase.Idle }, onSave, songId, onAddToSong, songs, onReplaceSong
            )
            is Phase.Working -> ListeningPage(p) {
                job?.cancel()
                phase = Phase.Idle
                if (direct) onBack()
            }
            Phase.Live -> LivePage(prefs, onPrefs, { if (startLive) onBack() else phase = Phase.Idle }, onSave, songs)
            is Phase.Failed -> Column(Modifier.fillMaxSize()) {
                AnaHeader("Chord analyzer", null, { RoundBtn(SbIcons.Back, "Back", { if (direct) onBack() else phase = Phase.Idle }) }) {}
                Column(Modifier.padding(horizontal = 16.dp, vertical = 22.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).padding(24.dp)) {
                    Text("That did not work", style = sbStyle(20, FontWeight.SemiBold, Sb.colors.tx))
                    Text(p.message, style = sbStyle(15, color = Sb.colors.mu), modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
                    PillButton("Choose another file", true, Modifier.fillMaxWidth()) { pick.launch(arrayOf("audio/*")) }
                }
            }
            Phase.Idle -> StartPage(
                demos = demos, recent = recent, onBack = onBack,
                onFile = { pick.launch(arrayOf("audio/*")) }, onRecord = onRecord, onLive = { phase = Phase.Live },
                onDemo = { d -> startDemo(d.file, d.songTitle.ifBlank { d.title }) },
                onRecent = { m ->
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { AnalysisStore.load(context, m) { AudioStore.file(context, it) } }
                        phase = if (r != null) Phase.Done(m.title, r.first, r.second, false, null, m.id) else Phase.Failed("That analysis could not be opened any more.")
                    }
                },
                onRemove = { removeMeta = it }
            )
        }
        removeMeta?.let { m ->
            SbDialog("Remove from Recent?", { removeMeta = null }, "Remove", {
                scope.launch { withContext(Dispatchers.IO) { AnalysisStore.delete(context, m.id) }; recent = recent.filter { it.id != m.id }; removeMeta = null }
            }) { Text("\"${m.title}\" is taken off the list. The recording itself is not touched.", style = sbStyle(14, color = Sb.colors.mu)) }
        }
    }
}

// ------------------------------------------------------------------ pieces of every page

/**
 * The top of every analyzer page (Live, Tuner, a song): a round button on each side and the page name in the middle,
 * in Outfit Medium like Paperback's header, centred on the screen whatever the buttons beside it. What the page adds
 * (the key and tempo, the tuning, "Listening") is a small pill under it. [inset] keeps the title clear of the buttons:
 * 72 dp for one button on the right, 112 dp for two.
 */
@Composable
internal fun AnaHeader(
    title: String, subtitle: String?, left: @Composable () -> Unit,
    inset: Dp = 72.dp,
    /** A dot in the pill: the microphone is listening. */
    dot: Boolean = false,
    right: @Composable RowScope.() -> Unit
) {
    val c = Sb.colors
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp).heightIn(min = 44.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) { left() }
            Text(
                title,
                style = sbStyle(28, FontWeight.Medium, c.tx).copy(fontFamily = Outfit, letterSpacing = (-0.01).em),
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(horizontal = inset)
            )
            Row(
                Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically, content = right
            )
        }
        if (subtitle != null) {
            Row(
                Modifier.align(Alignment.CenterHorizontally).padding(top = 12.dp, start = 24.dp, end = 24.dp)
                    .clip(RoundedCornerShape(16.dp)).background(c.cd).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (dot) {
                    Box(Modifier.size(8.dp).background(c.ac, CircleShape))
                    Spacer(Modifier.width(8.dp))
                }
                Text(subtitle, style = sbStyle(13, FontWeight.Medium, c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** A round "more" button that opens a small menu: what a page can do, when there is no room for a button for each. */
@Composable
internal fun MoreButton(items: List<Pair<String, () -> Unit>>) {
    val c = Sb.colors
    var open by remember { mutableStateOf(false) }
    Box {
        RoundBtn(SbIcons.More, "More", { open = true })
        DropdownMenu(
            expanded = open, onDismissRequest = { open = false },
            shape = RoundedCornerShape(28.dp), containerColor = c.sheet, tonalElevation = 0.dp, shadowElevation = 12.dp
        ) {
            items.forEach { (label, run) ->
                DropdownMenuItem(
                    text = { Text(label, style = sbStyle(15, FontWeight.Medium, c.tx)) },
                    modifier = Modifier.padding(horizontal = 8.dp),
                    onClick = { open = false; run() }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ListRow(icon: IconSpec, title: String, sub: String, onClick: () -> Unit, onLong: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).combinedClickable(onClick = onClick, onLongClick = onLong).heightIn(min = 60.dp).padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).background(c.cd, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { StrokeIcon(icon, c.tx, size = 22.dp) }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, style = sbStyle(16, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = sbStyle(13, color = c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
        StrokeIcon(SbIcons.ChevronRight, c.mu, size = 18.dp)
    }
}

// ------------------------------------------------------------------ start page

@Composable
private fun StartPage(
    demos: List<AnalyzerDemo>, recent: List<AnaMeta>, onBack: () -> Unit,
    onFile: () -> Unit, onRecord: () -> Unit, onLive: () -> Unit, onDemo: (AnalyzerDemo) -> Unit, onRecent: (AnaMeta) -> Unit, onRemove: (AnaMeta) -> Unit
) {
    val c = Sb.colors
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp)) {
        item { AnaHeader("Chord analyzer", null, { RoundBtn(SbIcons.Back, "Back", onBack) }) {} }
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 22.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(c.cd).padding(22.dp)) {
                Text("Find the chords of a song", style = sbStyle(26, FontWeight.SemiBold, c.tx))
                Text("Pick a recording. It is analysed on your phone and never uploaded.", style = sbStyle(14, color = c.mu), modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                PillButton("Choose audio file", true, Modifier.fillMaxWidth(), onFile)
                Spacer(Modifier.height(10.dp))
                PillButton("Record now", false, Modifier.fillMaxWidth(), onRecord)
                Spacer(Modifier.height(10.dp))
                PillButton("Live mode · chords as you play", false, Modifier.fillMaxWidth(), onLive)
            }
        }
        if (demos.isNotEmpty()) {
            item { AnaLabel("From your songs", Modifier.padding(start = 24.dp, top = 6.dp, bottom = 6.dp)) }
            itemsIndexed(demos.take(4)) { _, d ->
                Box(Modifier.padding(horizontal = 20.dp)) {
                    ListRow(SbIcons.Music, d.songTitle.ifBlank { d.title }, "Demo · ${fmtTime(d.seconds.toDouble())}", { onDemo(d) })
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { AnaLabel("Recent", Modifier.padding(start = 24.dp, top = 18.dp, bottom = 6.dp)) }
            itemsIndexed(recent.take(8)) { _, m ->
                Box(Modifier.padding(horizontal = 20.dp)) {
                    ListRow(SbIcons.Bookmark, m.title, "${m.key} · ${m.bpm} BPM", { onRecent(m) }, { onRemove(m) }) {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(end = 10.dp)) {
                            for (r in m.strip.take(5)) Box(Modifier.width(14.dp).height(8.dp).clip(RoundedCornerShape(3.dp)).background(RootColors[r % 12]))
                        }
                    }
                }
            }
            item { Text("Press and hold an entry to remove it.", style = sbStyle(12, color = c.mu), modifier = Modifier.padding(start = 28.dp, top = 8.dp)) }
        }
    }
}

// ------------------------------------------------------------------ while it listens

@Composable
private fun ListeningPage(p: Phase.Working, onCancel: () -> Unit) {
    val c = Sb.colors
    val pct = (p.progress * 100).roundToInt().coerceIn(0, 100)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        AnaHeader("", null, { RoundBtn(SbIcons.Close, "Cancel", onCancel) }) {}
        Spacer(Modifier.height(48.dp))
        Box(Modifier.size(180.dp), contentAlignment = Alignment.Center) {
            val track = c.track
            val ac = c.ac
            Canvas(Modifier.fillMaxSize()) {
                val w = 10.dp.toPx()
                val s = Size(size.width - w, size.height - w)
                drawArc(track, 0f, 360f, false, Offset(w / 2, w / 2), s, style = Stroke(w))
                drawArc(ac, -90f, 360f * p.progress.coerceIn(0.01f, 1f), false, Offset(w / 2, w / 2), s, style = Stroke(w, cap = StrokeCap.Round))
            }
            Text("$pct%", style = sbStyle(40, FontWeight.SemiBold, c.tx))
        }
        Text("Listening for chords", style = sbStyle(24, FontWeight.SemiBold, c.tx), modifier = Modifier.padding(top = 26.dp))
        Text(p.title, style = sbStyle(14, color = c.mu), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp, start = 24.dp, end = 24.dp))
        Column(Modifier.padding(start = 36.dp, end = 36.dp, top = 36.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val step = if (p.progress < 0.3f) 0 else if (p.progress < 0.9f) 1 else 2
            listOf("Reading the audio", "Listening for chords", "Finding the tempo and key").forEachIndexed { i, label ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(36.dp).background(c.cd, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        StrokeIcon(if (i < step) SbIcons.Check else if (i == 0) SbIcons.Wave else SbIcons.Music, if (i <= step) c.tx else c.mu, size = 18.dp)
                    }
                    Text(label, style = sbStyle(15, FontWeight.Medium, if (i <= step) c.tx else c.mu), modifier = Modifier.weight(1f).padding(start = 14.dp))
                    Text(if (i < step) "Done" else if (i == step) "Now" else "Next", style = sbStyle(13, color = c.mu))
                }
            }
        }
        Text("You can leave this page. Closing it stops the listening.", style = sbStyle(13, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
    }
}

// ------------------------------------------------------------------ the result

private class Used(val root: Int, val type: String, val seconds: Double, val first: Double, val name: String)

@Composable
private fun ResultPage(
    done: Phase.Done,
    prefs: AnalyzerPrefs,
    onPrefs: (AnalyzerPrefs) -> Unit,
    onLeave: () -> Unit,
    onSave: (title: String, body: String, key: String, bpm: Int, comment: String) -> Unit,
    songId: Long,
    onAddToSong: ((songId: Long, chords: String) -> Unit)?,
    songs: List<SongEntity>,
    onReplaceSong: ((songId: Long, body: String) -> Unit)? = null
) {
    val c = Sb.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val result = done.result
    var precise by rememberSaveable { mutableStateOf(false) }
    var perBar by rememberSaveable { mutableStateOf(4) }
    var shift by rememberSaveable { mutableStateOf(0) }
    var capo by rememberSaveable { mutableStateOf(0) }
    var tempoMode by rememberSaveable { mutableStateOf(0) }       // 0 as found, 1 twice as fast, 2 half as fast
    var view by rememberSaveable { mutableStateOf(if (prefs.openLast) prefs.last else prefs.default) }
    var sheet by rememberSaveable { mutableStateOf(0) }           // 1 views, 2 tune, 3 save
    var pickSong by remember { mutableStateOf(false) }
    // lyrics: taken from the song this demo belongs to when it has words, or typed / taken from another song
    val lyrics = remember {
        mutableStateListOf<com.songbook.app.analysis.LyricLine>().also { l ->
            if (songId > 0) songs.firstOrNull { it.id == songId }?.body?.let { l.addAll(Lyrics.parse(it)) }
        }
    }
    var syncing by remember { mutableStateOf(false) }
    var lyricDialog by remember { mutableStateOf(0) }            // 1 type or edit, 2 pick a song
    var confirmReplace by remember { mutableStateOf<String?>(null) }
    var kept by remember { mutableStateOf(done.keptId != null) }
    val instrument = Instrument.values()[prefs.instrument.coerceIn(0, 3)]

    val player = remember(done.file) { AnalyzerPlayer(done.file) }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(player.playing) {
        while (player.playing) {
            player.tick()
            delay(50)
        }
    }

    val segs = if (precise) result.precise else result.basic
    val showShift = shift - capo                       // the shapes to play: lower when a capo is on
    val flatsShow = ChordNames.preferFlats(result.keyTonic + showShift, result.keyMinor)
    val flatsSaved = ChordNames.preferFlats(result.keyTonic + shift, result.keyMinor)
    val names = remember(segs, showShift, flatsShow) { segs.map { if (it.isChord) ChordNames.chord(it.root, it.type, showShift, flatsShow) else "" } }
    val savedNames = remember(segs, shift, flatsSaved) { segs.map { if (it.isChord) ChordNames.chord(it.root, it.type, shift, flatsSaved) else "" } }
    val beats = remember(result, tempoMode) {
        when (tempoMode) {
            1 -> DoubleArray(result.beats.size * 2) { i ->
                val a = result.beats[i / 2]
                if (i % 2 == 0) a else a + ((result.beats.getOrNull(i / 2 + 1) ?: (a + 60.0 / result.bpm)) - a) / 2
            }
            2 -> result.beats.filterIndexed { i, _ -> i % 2 == 0 }.toDoubleArray()
            else -> result.beats
        }
    }
    val bpmShown = (result.bpm * (if (tempoMode == 1) 2.0 else if (tempoMode == 2) 0.5 else 1.0)).roundToInt()
    val grid = remember(beats, segs, names, perBar) { buildBars(beats, segs, names, perBar) }
    val saveGrid = remember(beats, segs, savedNames, perBar) { buildBars(beats, segs, savedNames, perBar) }
    val keyLong = ChordNames.keyLong(result.keyTonic, result.keyMinor, shift)
    val subtitle = "$keyLong · $bpmShown BPM" + if (capo > 0) " · Capo $capo" else ""

    val posSec = player.posMs / 1000.0
    val curIdx = if (segs.isEmpty()) -1 else segs.indexOfLast { it.start <= posSec }.coerceAtLeast(0)
    val nextIdx = if (curIdx >= 0) (curIdx + 1 until segs.size).firstOrNull { segs[it].isChord } ?: -1 else -1
    val used = remember(segs, showShift, flatsShow) {
        val total = LinkedHashMap<Pair<Int, String>, DoubleArray>()
        for (s in segs) if (s.isChord) {
            val a = total.getOrPut(s.root to s.type) { doubleArrayOf(0.0, s.start) }
            a[0] += s.end - s.start
        }
        total.entries.sortedByDescending { it.value[0] }.take(12).map { Used(it.key.first, it.key.second, it.value[0], it.value[1], ChordNames.chord(it.key.first, it.key.second, showShift, flatsShow)) }
    }

    fun setView(v: Int) {
        view = v
        if (prefs.openLast) onPrefs(prefs.copy(last = v))
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            AnaHeader(done.title, subtitle, { RoundBtn(SbIcons.Back, "Back", onLeave) }) {
                MoreButton(listOf("Tune" to { sheet = 2 }, "Lyrics" to { sheet = 4 }, "Save" to { sheet = 3 }))
            }
            ViewSwitch(view, prefs.tabs, ::setView) { sheet = 1 }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (view) {
                    0 -> PlayView(
                        instrument, segs, names, curIdx, nextIdx, showShift, result, posSec, player,
                        onSeek = { player.seekSec(it) }
                    )
                    1 -> ChordsView(used, instrument, showShift, bottom = if (prefs.player) 110 else 24) { player.seekSec(it) }
                    2 -> ChartView(grid, beats, posSec, perBar, bottom = if (prefs.player) 110 else 24) { player.seekSec(it) }
                    else -> if (Lyrics.hasLines(lyrics)) LyricsView(
                        lyrics, segs, names, posSec, result.durationSec,
                        bottom = if (syncing) 360 else if (prefs.player) 110 else 24, onSeek = { player.seekSec(it) }, onOpenLyrics = { sheet = 4 }
                    ) else FollowView(segs, names, curIdx, instrument, showShift, grid, beats, posSec, perBar, bottom = if (prefs.player) 110 else 24) { player.seekSec(it) }
                }
            }
        }
        if ((prefs.player || syncing) && view != 0) MiniPlayer(player, result.durationSec, Modifier.align(Alignment.BottomCenter))
        if (syncing) {
            val nextLine = lyrics.firstOrNull { !it.section && !it.synced }
            SyncBar(
                nextLine, lyrics.count { !it.section && !it.synced },
                onTap = {
                    val i = lyrics.indexOfFirst { !it.section && !it.synced }
                    if (i >= 0) lyrics[i] = lyrics[i].at(max(0.0, player.posMs / 1000.0 - 0.2))
                },
                onUndo = {
                    val i = lyrics.indexOfLast { it.synced }
                    if (i >= 0) lyrics[i] = lyrics[i].untimed()
                },
                onDone = { syncing = false },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 108.dp)
            )
        }

        if (sheet == 1) ViewsSheet(view, prefs, ::setView, onPrefs) { sheet = 0 }
        if (sheet == 2) TuneSheet(
            precise, { precise = it }, perBar, { perBar = it }, tempoMode, { tempoMode = it }, bpmShown, shift, { shift = it }, capo, { capo = it },
            prefs.instrument, { onPrefs(prefs.copy(instrument = it)) },
            reset = { precise = false; perBar = 4; tempoMode = 0; shift = 0; capo = 0 }
        ) { sheet = 0 }
        if (sheet == 3) AnalyzerSheet("Save", onClose = { sheet = 0 }) {
            val chordsText = songBody(saveGrid)
            val bpm = bpmShown
            val key = ChordNames.key(result.keyTonic, result.keyMinor, shift)
            val comment = "Chords found by Songbook's analyzer from “${done.title}”: $keyLong, $bpm BPM. It is an estimate, check it by ear."
            if (Lyrics.syncedCount(lyrics) > 0) {
                val lyricBody = Lyrics.toSongText(lyrics.toList(), segs, savedNames, result.durationSec)
                if (songId > 0 && onReplaceSong != null) ActionRow(SbIcons.Edit, "Save chords and lyrics to this song", "The chords over the words; replaces the song's text") { confirmReplace = lyricBody }
                ActionRow(SbIcons.Music, "Save chords and lyrics as a new song", "The chords over the words") { onSave(done.title, lyricBody, key, bpm, comment) }
            }
            if (songId > 0 && onAddToSong != null) ActionRow(SbIcons.Plus, "Add to this song", "The song this demo belongs to") { onAddToSong(songId, chordsText) }
            else if (onAddToSong != null && songs.isNotEmpty()) ActionRow(SbIcons.Plus, "Add to a song", "Pick one of your songs") { pickSong = true }
            ActionRow(SbIcons.Music, "Save as a new song", "Chords, key and tempo filled in") { onSave(done.title, chordsText, key, bpm, comment) }
            ActionRow(SbIcons.Bookmark, if (kept) "Kept" else "Keep this analysis", if (kept) "Find it again under Recent" else "Find it again under Recent, without analysing again") {
                if (!kept) {
                    kept = true
                    scope.launch(Dispatchers.IO) {
                        runCatching { AnalysisStore.save(context, done.title, done.file, done.demoName, ChordNames.key(result.keyTonic, result.keyMinor, 0), result) }
                    }
                }
            }
            ActionRow(SbIcons.Copy, "Copy the chords", "As text") { clipboard.setText(AnnotatedString(chordsText)); sheet = 0 }
            ActionRow(SbIcons.Share, "Share a chord sheet", "As text") {
                val text = done.title + "\n" + subtitle + "\n\n" + chordsText.removePrefix("# Chords").trim()
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, done.title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                context.startActivity(Intent.createChooser(i, "Share chords").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                sheet = 0
            }
            Text("The chords are an estimate. Check them by ear.", style = sbStyle(13, color = c.mu), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 14.dp))
        }
        if (sheet == 4) LyricsSheet(
            lyrics.toList(),
            onType = { lyricDialog = 1 },
            onFromSong = if (songs.isNotEmpty()) ({ lyricDialog = 2 }) else null,
            onSync = {
                for (i in lyrics.indices) if (!lyrics[i].section) lyrics[i] = lyrics[i].untimed()
                view = 3
                syncing = true
                sheet = 0
                player.seekSec(0.0)
                if (!player.playing) player.toggle()
            },
            onSpread = {
                val spread = Lyrics.spread(lyrics.toList(), segs.firstOrNull { it.isChord }?.start ?: 0.0, result.durationSec)
                lyrics.clear()
                lyrics.addAll(spread)
                view = 3
                sheet = 0
            },
            onClearTimes = { for (i in lyrics.indices) lyrics[i] = lyrics[i].untimed() },
            onRemove = { lyrics.clear(); syncing = false; sheet = 0 },
            onClose = { sheet = 0 }
        )
        if (lyricDialog == 1) com.songbook.app.ui.screens.LyricsDialog(Lyrics.toEditText(lyrics.toList()), { text ->
            val old = lyrics.toList()
            val parsed = Lyrics.parse(text)
            lyrics.clear()
            lyrics.addAll(parsed.mapIndexed { i, ln ->
                val o = old.getOrNull(i)
                if (o != null && o.synced && o.text == ln.text) ln.at(o.start) else ln
            })
            lyricDialog = 0
            if (Lyrics.hasLines(lyrics)) { view = 3; sheet = 0 }
        }, { lyricDialog = 0 })
        if (lyricDialog == 2) SongPickDialog("Take the lyrics from...", songs, { id ->
            songs.firstOrNull { it.id == id }?.body?.let { b -> lyrics.clear(); lyrics.addAll(Lyrics.parse(b)) }
            lyricDialog = 0
            if (Lyrics.hasLines(lyrics)) { view = 3; sheet = 0 }
        }, { lyricDialog = 0 })
        confirmReplace?.let { body ->
            SbDialog("Replace the song's text?", { confirmReplace = null }, "Replace", {
                confirmReplace = null
                onReplaceSong?.invoke(songId, body)
            }) { Text("The song's text becomes the lyrics with the chords over the words. Anything else written in it, like tabs or notes, is gone.", style = sbStyle(14, color = Sb.colors.mu)) }
        }
        if (pickSong && onAddToSong != null) {
            SongPickDialog("Add the chords to...", songs, { id -> pickSong = false; sheet = 0; onAddToSong(id, songBody(saveGrid)) }, { pickSong = false })
        }
    }
}

@Composable
private fun ViewSwitch(view: Int, tabs: Boolean, onSelect: (Int) -> Unit, onViews: () -> Unit) {
    val c = Sb.colors
    val labels = listOf("Play", "Chords", "Chart", "Follow")
    val on = if (c.isDark) Color(0xFF2C2C2C) else Color.White
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(c.cd).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (tabs) {
                labels.forEachIndexed { i, l ->
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(20.dp)).background(if (i == view) on else Color.Transparent).clickable { onSelect(i) },
                        contentAlignment = Alignment.Center
                    ) { Text(l, style = sbStyle(14, FontWeight.Medium, if (i == view) c.tx else c.mu), maxLines = 1) }
                }
            } else {
                Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(20.dp)).background(on).clickable(onClick = onViews), contentAlignment = Alignment.Center) {
                    Text(labels[view.coerceIn(0, 3)], style = sbStyle(14, FontWeight.Medium, c.tx))
                }
            }
        }
        RoundBtn(SbIcons.Grid, "Views", onViews)
    }
}

// ------------------------------------------------------------------ the four views

@Composable
private fun PlayView(
    instrument: Instrument, segs: List<ChordSeg>, names: List<String>, cur: Int, next: Int, showShift: Int,
    result: AnalysisResult, posSec: Double, player: AnalyzerPlayer, onSeek: (Double) -> Unit
) {
    val c = Sb.colors
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(18.dp))
            AnaLabel("Now", Modifier)
            Text(if (cur >= 0 && names[cur].isNotEmpty()) names[cur] else "–", style = sbStyle(104, FontWeight.SemiBold, c.tx), maxLines = 1)
            if (cur >= 0 && segs[cur].isChord) ChordShapeView(instrument, Math.floorMod(segs[cur].root + showShift, 12), segs[cur].type, Modifier.fillMaxWidth(if (instrument == Instrument.PIANO) 0.7f else 0.42f))
            Row(
                Modifier.padding(top = 12.dp).height(40.dp).clip(RoundedCornerShape(20.dp)).background(c.cd).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Next", style = sbStyle(15, color = c.mu))
                Text(if (next >= 0) names[next] else "–", style = sbStyle(15, FontWeight.SemiBold, c.tx))
            }
            ZoomTimeline(result, segs, names, posSec, onSeek, Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp), height = 88.dp)
            Spacer(Modifier.height(12.dp))
        }
        BigControls(player, result.durationSec)
    }
}

@Composable
private fun ChordsView(used: List<Used>, instrument: Instrument, showShift: Int, bottom: Int, onSeek: (Double) -> Unit) {
    val c = Sb.colors
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottom.dp)) {
        item { AnaLabel("${used.size} chords · most played first", Modifier.padding(start = 24.dp, top = 18.dp, bottom = 10.dp)) }
        itemsIndexed(used.chunked(2)) { _, row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { u ->
                    Column(
                        Modifier.weight(1f).sbCard(28.dp).clip(RoundedCornerShape(28.dp)).clickable { onSeek(u.first) }.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(u.name, style = sbStyle(24, FontWeight.SemiBold, c.tx), maxLines = 1)
                        Text(fmtTime(u.seconds), style = sbStyle(13, color = c.mu))
                        Spacer(Modifier.height(6.dp))
                        ChordShapeView(instrument, Math.floorMod(u.root + showShift, 12), u.type, Modifier.fillMaxWidth(if (instrument == Instrument.PIANO) 0.9f else 0.7f))
                    }
                }
                if (row.size < 2) Spacer(Modifier.weight(1f))
            }
        }
        item { Text("Tap a chord to jump to where it first plays.", style = sbStyle(13, color = c.mu), modifier = Modifier.padding(start = 24.dp, top = 12.dp)) }
    }
}

@Composable
private fun ChartView(grid: BarGrid, beats: DoubleArray, posSec: Double, perBar: Int, bottom: Int, onSeek: (Double) -> Unit) {
    val c = Sb.colors
    val curBeat = beats.indexOfLast { it <= posSec + 0.05 }
    val curCell = if (curBeat >= 0) grid.pad + curBeat else -1
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 14.dp, bottom = bottom.dp)) {
        itemsIndexed(grid.bars) { barIdx, bar ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${barIdx + 1}", style = sbStyle(12, color = c.mu), textAlign = TextAlign.End, modifier = Modifier.width(24.dp))
                bar.forEachIndexed { col, cell ->
                    val idx = barIdx * perBar + col
                    Box(
                        Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp)).background(if (idx == curCell) c.ac.copy(alpha = 0.28f) else c.cd)
                            .clickable { val b = idx - grid.pad; if (b >= 0 && b < beats.size) onSeek(beats[b]) },
                        contentAlignment = Alignment.Center
                    ) { if (cell != null) Text(cell, style = sbStyle(16, FontWeight.SemiBold, c.tx), maxLines = 1) }
                }
            }
        }
    }
}

@Composable
private fun FollowView(
    segs: List<ChordSeg>, names: List<String>, cur: Int, instrument: Instrument, showShift: Int,
    grid: BarGrid, beats: DoubleArray, posSec: Double, perBar: Int, bottom: Int, onSeek: (Double) -> Unit
) {
    val c = Sb.colors
    val chordRows = remember(segs) { segs.indices.filter { segs[it].isChord } }
    val row = chordRows.indexOfLast { it <= cur }.coerceAtLeast(0)
    val state = rememberLazyListState()
    LaunchedEffect(row) { if (chordRows.isNotEmpty()) state.animateScrollToItem(max(0, row - 1)) }
    fun barOf(t: Double): Int {
        val b = beats.indexOfFirst { it >= t - 0.2 }.let { if (it < 0) beats.size - 1 else it }
        return (grid.pad + max(0, b)) / perBar + 1
    }
    val curBeat = beats.indexOfLast { it <= posSec + 0.05 }
    val inBar = if (curBeat >= 0) (grid.pad + curBeat) % perBar else 0
    LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(top = 18.dp, bottom = bottom.dp)) {
        itemsIndexed(chordRows) { i, segIdx ->
            val s = segs[segIdx]
            if (i == row) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().sbCard(28.dp).clip(RoundedCornerShape(28.dp)).clickable { onSeek(s.start) }.padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Bar ${barOf(s.start)}", style = sbStyle(13, color = c.mu))
                        Text(names[segIdx], style = sbStyle(72, FontWeight.SemiBold, c.tx), maxLines = 1)
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (b in 0 until perBar) Box(Modifier.size(10.dp).clip(CircleShape).background(if (b <= inBar) c.ac else c.track))
                        }
                    }
                    ChordShapeView(instrument, Math.floorMod(s.root + showShift, 12), s.type, Modifier.width(if (instrument == Instrument.PIANO) 150.dp else 92.dp))
                }
            } else {
                val d = kotlin.math.abs(i - row)
                Row(
                    Modifier.fillMaxWidth().clickable { onSeek(s.start) }.padding(start = 36.dp, end = 36.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text("Bar ${barOf(s.start)}", style = sbStyle(13, color = c.mu), modifier = Modifier.width(58.dp).padding(bottom = 6.dp))
                    Text(
                        names[segIdx], style = sbStyle(if (d == 1) 44 else 36, FontWeight.SemiBold, c.tx.copy(alpha = if (i < row) 0.4f else (if (d == 1) 0.9f else if (d == 2) 0.6f else 0.38f))), maxLines = 1
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ the sheets

@Composable
private fun ViewsSheet(view: Int, prefs: AnalyzerPrefs, onSelect: (Int) -> Unit, onPrefs: (AnalyzerPrefs) -> Unit, onClose: () -> Unit) {
    val c = Sb.colors
    AnalyzerSheet("Views", "How the chords are shown", onClose) {
        Spacer(Modifier.height(10.dp))
        listOf(listOf("Play", "Chords"), listOf("Chart", "Follow along")).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEachIndexed { k, name ->
                    val i = r * 2 + k
                    val sel = i == view
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(c.cd)
                            .then(if (sel) Modifier.background(c.ac.copy(alpha = 0.16f)) else Modifier)
                            .clickable { onSelect(i); onPrefs(prefs.copy(default = i, last = i)) }.padding(12.dp)
                    ) {
                        Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(12.dp)).background(c.track), contentAlignment = Alignment.Center) {
                            when (i) {
                                0 -> Text("E", style = sbStyle(34, FontWeight.SemiBold, c.tx))
                                1 -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(3) { Box(Modifier.size(width = 24.dp, height = 34.dp).clip(RoundedCornerShape(6.dp)).background(c.cd)) } }
                                2 -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { repeat(2) { Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { repeat(4) { Box(Modifier.size(width = 16.dp, height = 12.dp).clip(RoundedCornerShape(4.dp)).background(c.cd)) } } } }
                                else -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Box(Modifier.size(width = 30.dp, height = 7.dp).clip(RoundedCornerShape(3.dp)).background(c.cd))
                                    Box(Modifier.size(width = 70.dp, height = 14.dp).clip(RoundedCornerShape(5.dp)).background(c.ac))
                                    Box(Modifier.size(width = 44.dp, height = 9.dp).clip(RoundedCornerShape(3.dp)).background(c.cd))
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, style = sbStyle(15, FontWeight.SemiBold, c.tx), modifier = Modifier.weight(1f))
                            Box(Modifier.size(18.dp).clip(CircleShape).background(if (sel) c.ac else Color.Transparent).then(if (sel) Modifier else Modifier.background(c.track)))
                        }
                    }
                }
            }
        }
        AnaLabel("Options")
        AnaRow("Open on") { Segmented(listOf("Last used", "This view"), if (prefs.openLast) 0 else 1) { onPrefs(prefs.copy(openLast = it == 0)) } }
        AnaRow("Show views as tabs") { SbSwitch(prefs.tabs) { onPrefs(prefs.copy(tabs = it)) } }
        AnaRow("Keep the player on every view", "Not on Play, which has its own") { SbSwitch(prefs.player) { onPrefs(prefs.copy(player = it)) } }
    }
}

@Composable
private fun TuneSheet(
    precise: Boolean, onPrecise: (Boolean) -> Unit, perBar: Int, onPerBar: (Int) -> Unit, tempoMode: Int, onTempo: (Int) -> Unit, bpm: Int,
    shift: Int, onShift: (Int) -> Unit, capo: Int, onCapo: (Int) -> Unit, instrument: Int, onInstrument: (Int) -> Unit, reset: () -> Unit, onClose: () -> Unit
) {
    val c = Sb.colors
    AnalyzerSheet("Tune", null, onClose) {
        AnaLabel("Chords")
        AnaRow("Detail") { Segmented(listOf("Basic", "Precise"), if (precise) 1 else 0) { onPrecise(it == 1) } }
        AnaRow("Beats in a bar") { Segmented(listOf("3", "4"), if (perBar == 3) 0 else 1) { onPerBar(if (it == 0) 3 else 4) } }
        AnaLabel("Tempo")
        AnaRow("$bpm BPM") { Segmented(listOf("As found", "×2", "÷2"), tempoMode) { onTempo(it) } }
        AnaLabel("Key")
        AnaRow("Transpose") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StepButton("−") { onShift((shift - 1).coerceAtLeast(-11)) }
                Text(if (shift > 0) "+$shift" else "$shift", style = sbStyle(16, FontWeight.SemiBold, c.tx), textAlign = TextAlign.Center, modifier = Modifier.width(48.dp))
                StepButton("+") { onShift((shift + 1).coerceAtMost(11)) }
            }
        }
        AnaRow("Capo", "The shapes are shown for the capo") { Segmented(listOf("None", "1", "2", "3", "4"), capo) { onCapo(it) } }
        AnaLabel("Shapes")
        AnaRow("Instrument") { Segmented(Instrument.values().map { it.label }, instrument) { onInstrument(it) } }
        Box(Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = reset).padding(12.dp), contentAlignment = Alignment.Center) {
            Text("Reset to found values", style = sbStyle(15, FontWeight.SemiBold, c.mu))
        }
    }
}
