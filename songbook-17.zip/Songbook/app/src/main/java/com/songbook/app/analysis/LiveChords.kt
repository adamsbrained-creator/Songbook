package com.songbook.app.analysis

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** What Live mode hears at one moment. */
class LiveReading(
    /** The chord now (0..11, C = 0), or -1 when nothing is playing or nothing is clear yet. */
    val root: Int,
    val type: String,
    /** 0..1, how well the sound fits the chord. */
    val fit: Float,
    /** 0..1, the loudness for a meter. */
    val level: Float,
    /** The 12 notes (C first) as they sound now, the loudest = 1. */
    val notes: FloatArray,
    /** The key heard so far, or -1 while there is not enough to say. */
    val keyTonic: Int,
    val keyMinor: Boolean,
    /** True while it is too quiet to hear a chord. */
    val quiet: Boolean,
    /** 0..1, where the "someone is playing" gate sits on the same scale as [level]. */
    val gate: Float = 0f,
    /** True while it is learning the noise of the room ([LiveChords.calibrate]). */
    val calibrating: Boolean = false
)

/**
 * Finds the chord that is playing right now, from the microphone, a bit more than twenty times a second.
 *
 * It is the same idea as [ChordEngine] (a chromagram of the last 0.37 s matched against chord templates, a bonus for
 * the chords of the key, the bass note counts a little) but works on a moving window and cannot look ahead, so the
 * Viterbi search is replaced by a simple rule: a new chord has to fit clearly better than the one that is playing,
 * for two readings in a row. The tuning is followed while it plays (a guitar a few cents flat still gives the right
 * chords) and the key is guessed from the chords of the last minute or so.
 *
 * Plain Kotlin: [feed] takes mono samples at the microphone's rate (44.1 or 48 kHz).
 */
class LiveChords(private val inRate: Int) {
    @Volatile var precise = false

    /** 0 low (loud rooms), 1 normal, 2 high (quiet playing). */
    @Volatile var sensitivity = 1

    private class Vocab(val types: List<String>) {
        val templates = Array(12 * types.size) { DoubleArray(12) }

        init {
            for (r in 0 until 12) {
                for ((ti, t) in types.withIndex()) {
                    val v = templates[r * types.size + ti]
                    for ((iv, w) in ChordEngine.TYPE_NOTES.getValue(t)) v[(r + iv) % 12] = w
                    var norm = 0.0
                    for (x in v) norm += x * x
                    norm = sqrt(norm)
                    for (i in 0 until 12) v[i] = v[i] / norm
                }
            }
        }
    }

    private val basicVocab = Vocab(ChordEngine.LIVE_BASIC)
    private val preciseVocab = Vocab(ChordEngine.LIVE_FULL)

    // ---------------------------------------------------------------- down to about 11 kHz

    private val dec = max(1, Math.round(inRate / 11025.0).toInt())
    private val sr = inRate.toDouble() / dec
    private val taps = 8 * dec + 1
    private val lp = FloatArray(taps)
    private val hist = FloatArray(taps)
    private var hp = 0
    private var phase = 0

    init {
        if (dec > 1) {
            val fc = 0.45 / dec
            val mid = (taps - 1) / 2.0
            var sum = 0.0
            for (i in 0 until taps) {
                val x = i - mid
                val sinc = if (x == 0.0) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
                val w = 0.54 - 0.46 * cos(2 * PI * i / (taps - 1))
                lp[i] = (sinc * w).toFloat()
                sum += lp[i]
            }
            for (i in 0 until taps) lp[i] = (lp[i] / sum).toFloat()
        }
    }

    // ---------------------------------------------------------------- the window

    private val n = ChordEngine.N
    private val nb = ChordEngine.NB
    private val ring = FloatArray(n)
    private var rp = 0
    private var filled = 0
    private var since = 0
    private val fft = ChordEngine.Fft(n)
    private val re = DoubleArray(n)
    private val im = DoubleArray(n)
    private val mag = DoubleArray(nb)

    private val kLo = ceil(ChordEngine.FMIN * n / sr).toInt()
    private val kHi = min(nb - 1, (ChordEngine.FMAX * n / sr).toInt())
    private val kBassLo = ceil(ChordEngine.BASS_MIN * n / sr).toInt()
    private val kBassHi = min(nb - 1, (ChordEngine.BASS_MAX * n / sr).toInt())
    private val tuneLo = (100 * n / sr).toInt()
    private val tuneHi = min(nb - 2, (1500 * n / sr).toInt())
    private val midiBase = DoubleArray(nb) { k -> if (k == 0) 0.0 else 69.0 + 12.0 * log2(k * sr / n / 440.0) }
    private val weight = DoubleArray(nb) { k ->
        val d = (midiBase[k] - 57.0) / 14.0
        exp(-0.5 * d * d)
    }

    // ---------------------------------------------------------------- separating the notes
    // The partials of a low note fall on the notes of the chord (the 5th partial of an E is a G#, a major third), which
    // made power chords, add9, 6 and the like look like plain major chords. So the spectrum is split into notes instead:
    // every note 36..88 (C2..E6) is a comb of its first 8 partials (each 0.7 times the one before), and the loudness of
    // each note is found so that the combs together match what is heard (non-negative least squares, 40 steps).

    private val nnG = NN_NOTES * NN_SUB
    private val nnDict = Array(nnG) { DoubleArray(NN_NOTES) }
    private val nnDtD = Array(NN_NOTES) { DoubleArray(NN_NOTES) }
    private val nnS = DoubleArray(nnG)
    private val nnSort = DoubleArray(nnG)
    private val nnDtS = DoubleArray(NN_NOTES)
    private val nnA = DoubleArray(NN_NOTES)
    private val nnNew = DoubleArray(NN_NOTES)

    init {
        for (j in 0 until NN_NOTES) {
            val m = NN_M0 + j
            var amp = 1.0
            for (h in 1..8) {
                val mh = m + 12.0 * log2(h.toDouble())
                for (g in 0 until nnG) {
                    val d = (NN_M0 - 0.5 + g.toDouble() / NN_SUB - mh) / 0.3
                    nnDict[g][j] += amp * exp(-0.5 * d * d)
                }
                amp *= 0.7
            }
        }
        for (i in 0 until NN_NOTES) for (j in 0 until NN_NOTES) {
            var s = 0.0
            for (g in 0 until nnG) s += nnDict[g][i] * nnDict[g][j]
            nnDtD[i][j] = s
        }
    }

    /** Fills [cur] (how much each of the 12 notes sounds) and [bass] (the low notes only) from [mag]. */
    private fun noteChroma(cur: DoubleArray, bass: DoubleArray) {
        val kmax = nb - 1
        for (g in 0 until nnG) {
            val c = NN_M0 - 0.5 + g.toDouble() / NN_SUB + tuning
            val flo = 440.0 * 2.0.pow((c - 0.5 / NN_SUB - 69.0) / 12.0)
            val fhi = 440.0 * 2.0.pow((c + 0.5 / NN_SUB - 69.0) / 12.0)
            val k0 = max(1, floor(flo * n / sr).toInt())
            val k1 = min(kmax, ceil(fhi * n / sr).toInt())
            var mx = 0.0
            for (k in k0..k1) if (mag[k] > mx) mx = mag[k]
            nnS[g] = sqrt(mx)
        }
        System.arraycopy(nnS, 0, nnSort, 0, nnG)
        java.util.Arrays.sort(nnSort)
        val sortFloor = 0.5 * nnSort[nnG / 2]
        for (g in 0 until nnG) nnS[g] = max(0.0, nnS[g] - sortFloor)

        for (j in 0 until NN_NOTES) {
            var s = 0.0
            for (g in 0 until nnG) s += nnDict[g][j] * nnS[g]
            nnDtS[j] = s
            nnA[j] = 0.1
        }
        repeat(40) {
            for (j in 0 until NN_NOTES) {
                var d = 0.0
                for (i in 0 until NN_NOTES) d += nnDtD[j][i] * nnA[i]
                nnNew[j] = nnA[j] * nnDtS[j] / (d + 1e-9)
            }
            System.arraycopy(nnNew, 0, nnA, 0, NN_NOTES)
        }
        for (j in 0 until NN_NOTES) {
            val m = NN_M0 + j
            val p = m % 12
            cur[p] += nnA[j]
            if (m <= 55 && nnA[j] > bass[p]) bass[p] = nnA[j]
        }
    }

    // ---------------------------------------------------------------- what it remembers

    private var sx = 0.0
    private var sy = 0.0
    private var tuning = 0.0
    private val chromaS = DoubleArray(12)
    private val bassS = DoubleArray(12)
    private var wasLoud = false
    private var quietFrames = 0

    // the room: how loud it is when nobody plays, and the spectrum of that noise (learned while it is quiet)
    private val noiseMag = DoubleArray(nb)
    private var noiseRms = -1.0
    @Volatile private var calibRequest = false
    private var calib = 0

    // strum detection: hops since the sound last jumped up (99 = none lately), and the fit of the last reading
    private var sinceOnset = 99
    private var lastFit = 0f

    private var curRoot = -1
    private var curType = ""
    private var pendRoot = -1
    private var pendType = ""
    private var pendCount = 0

    private val hopSec = HOP.toDouble() / sr
    private val keyDecay = exp(-ln(2.0) * hopSec / 60.0)
    private val keyProf = DoubleArray(12)
    private val chordTime = DoubleArray(24)
    private var keyTotal = 0.0
    private var keyTonic = -1
    private var keyMinor = false
    private var keyTick = 0

    fun reset() {
        java.util.Arrays.fill(ring, 0f)
        java.util.Arrays.fill(hist, 0f)
        rp = 0; filled = 0; since = 0; hp = 0; phase = 0
        sx = 0.0; sy = 0.0; tuning = 0.0
        java.util.Arrays.fill(chromaS, 0.0)
        java.util.Arrays.fill(bassS, 0.0)
        wasLoud = false; quietFrames = 0
        noiseRms = -1.0
        java.util.Arrays.fill(noiseMag, 0.0)
        calibRequest = false; calib = 0; sinceOnset = 99; lastFit = 0f
        curRoot = -1; curType = ""; pendRoot = -1; pendType = ""; pendCount = 0
        java.util.Arrays.fill(keyProf, 0.0)
        java.util.Arrays.fill(chordTime, 0.0)
        keyTotal = 0.0; keyTonic = -1; keyMinor = false; keyTick = 0
    }

    // ---------------------------------------------------------------- input

    /** Takes [count] microphone samples. Returns a reading when a new one is due (about every 46 ms), else null. */
    fun feed(x: FloatArray, count: Int): LiveReading? {
        var out: LiveReading? = null
        for (i in 0 until count) {
            val s = x[i]
            if (dec == 1) {
                push(s)
            } else {
                hist[hp] = s
                hp = if (hp + 1 == taps) 0 else hp + 1
                phase++
                if (phase == dec) {
                    phase = 0
                    var idx = hp - 1
                    if (idx < 0) idx += taps
                    var acc = 0f
                    for (t in 0 until taps) {
                        acc += lp[t] * hist[idx]
                        idx--
                        if (idx < 0) idx = taps - 1
                    }
                    push(acc)
                }
            }
            if (filled >= n && since >= HOP) {
                since = 0
                out = process()
            }
        }
        return out
    }

    private fun push(v: Float) {
        ring[rp] = v
        rp = if (rp + 1 == n) 0 else rp + 1
        if (filled < n) filled++
        since++
    }

    // ---------------------------------------------------------------- one reading

    /** Learns the noise of the room again for about two seconds: the sound heard meanwhile counts as noise, so stay quiet. */
    fun calibrate() {
        calibRequest = true
    }

    /** How far above the room's own noise the sound has to be (in RMS) before it counts as playing. */
    private fun gateRatio(): Double = when (sensitivity) {
        0 -> 2.5
        2 -> 1.35
        else -> 1.8
    }

    /** The lowest level that can ever count, for a very quiet room. */
    private fun gateFloor(): Double = when (sensitivity) {
        0 -> 0.003
        2 -> 0.0005
        else -> 0.0012
    }

    /** How well a chord has to fit (cosine) to be named. High accepts weaker, quieter matches. */
    private fun minFit(): Double = when (sensitivity) {
        0 -> 0.62
        2 -> 0.50
        else -> 0.58
    }

    private fun currentGate(): Double = max(gateFloor(), gateRatio() * max(noiseRms, 0.0))

    /** Learns the room: the level and the spectrum of what is heard when nobody plays. It falls fast, rises slowly. */
    private fun trackNoise(rms: Double, quietNow: Boolean) {
        if (noiseRms < 0) {
            noiseRms = rms
            for (k in 0 until nb) noiseMag[k] = mag[k]
            return
        }
        noiseRms = when {
            rms < noiseRms -> noiseRms + 0.3 * (rms - noiseRms)
            quietNow -> noiseRms + 0.1 * (rms - noiseRms)
            else -> min(rms, noiseRms * 1.002)
        }
        for (k in 0 until nb) {
            val m = mag[k]
            val z = noiseMag[k]
            noiseMag[k] = when {
                m < z -> z + 0.2 * (m - z)
                quietNow -> z + 0.1 * (m - z)
                else -> min(m, z * 1.003)
            }
        }
    }

    private fun process(): LiveReading {
        var sumSq = 0.0
        for (i in 0 until n) {
            val v = ring[(rp + i) % n].toDouble()
            sumSq += v * v
            re[i] = v * ChordEngine.window[i]
            im[i] = 0.0
        }
        val rms = sqrt(sumSq / n)
        val level = ((20.0 * log10(max(rms, 1e-6)) + 60.0) / 50.0).coerceIn(0.0, 1.0).toFloat()

        // the newest hop against the one before it: a jump up is a strum
        var newSq = 0.0
        var oldSq = 0.0
        for (i in 0 until HOP) {
            val a = ring[(rp + n - HOP + i) % n].toDouble()
            val b = ring[(rp + n - 2 * HOP + i) % n].toDouble()
            newSq += a * a
            oldSq += b * b
        }
        val newRms = sqrt(newSq / HOP)
        val oldRms = sqrt(oldSq / HOP)

        fft.transform(re, im)
        val norm = 4.0 / n
        for (k in 0 until nb) mag[k] = hypot(re[k], im[k]) * norm

        if (calibRequest) {
            calibRequest = false
            calib = CALIB_FRAMES
            noiseRms = -1.0
        }
        val calibrating = calib > 0
        if (calibrating) calib--
        val quietNow = calibrating || noiseRms < 0 || rms < currentGate()
        trackNoise(rms, quietNow)

        if (calibrating || rms < currentGate()) {
            // quiet: the sound dies away, the chord is cleared after about half a second
            wasLoud = false
            sinceOnset = 99
            quietFrames++
            for (p in 0 until 12) chromaS[p] *= 0.8
            if (quietFrames >= 11) {
                curRoot = -1
                curType = ""
                pendRoot = -1
                pendCount = 0
            }
            return reading(level, 0f, quiet = true, calibrating = calibrating)
        }
        quietFrames = 0

        // A strum: the sound jumps up. The old chord is still in the window, so for the next few readings only the sound
        // since the strum is looked at (a shorter window, a bit less sharp) and the new chord may win at once.
        if (newRms > ONSET_RATIO * oldRms + 1e-9 && newRms > currentGate()) sinceOnset = 0
        else if (sinceOnset < 99) sinceOnset++
        if (sinceOnset < 2) return reading(level, lastFit, quiet = false)       // too early to tell: keep what was shown
        val fast = sinceOnset <= FAST_UNTIL
        val eager = sinceOnset <= EAGER_UNTIL
        var cut = NOISE_CUT
        if (fast) {
            val len = min(n, (sinceOnset + 1) * HOP)
            for (i in 0 until n) {
                if (i < len) {
                    val w = 0.5 - 0.5 * cos(2.0 * PI * i / (len - 1))
                    re[i] = ring[(rp + n - len + i) % n].toDouble() * w
                } else {
                    re[i] = 0.0
                }
                im[i] = 0.0
            }
            fft.transform(re, im)
            val nrm = 4.0 / len
            for (k in 0 until nb) mag[k] = hypot(re[k], im[k]) * nrm
            cut = NOISE_CUT * sqrt(n.toDouble() / len)      // a shorter window sees more of the noise
        }

        // take the room's noise out of the spectrum, so that a soft chord is not drowned in it
        for (k in 0 until nb) mag[k] = max(0.0, mag[k] - cut * noiseMag[k])

        followTuning()

        val cur = DoubleArray(12)
        val bass = DoubleArray(12)
        noteChroma(cur, bass)
        if (!wasLoud || fast) {
            for (p in 0 until 12) {
                chromaS[p] = cur[p]
                bassS[p] = bass[p]
            }
        } else {
            for (p in 0 until 12) {
                chromaS[p] = SMOOTH * chromaS[p] + (1 - SMOOTH) * cur[p]
                bassS[p] = SMOOTH * bassS[p] + (1 - SMOOTH) * bass[p]
            }
        }
        wasLoud = true

        val fit = decide(eager)
        lastFit = fit
        listen()
        return reading(level, fit, quiet = false)
    }

    /** Follows how far the instrument is tuned from A = 440 Hz: the loud partials vote, with the recent past counting most. */
    private fun followTuning() {
        var mx = 0.0
        for (k in tuneLo until tuneHi) if (mag[k] > mx) mx = mag[k]
        if (mx <= 0.0) return
        sx *= TUNE_KEEP
        sy *= TUNE_KEEP
        for (k in tuneLo + 1 until tuneHi - 1) {
            val v = mag[k]
            if (v > mag[k - 1] && v >= mag[k + 1] && v > 0.1 * mx) {
                val a = mag[k - 1]
                val c = mag[k + 1]
                val d = 0.5 * (a - c) / (a - 2 * v + c + 1e-12)
                val fr = (k + d) * sr / n
                val midi = 69 + 12 * log2(fr / 440.0)
                val dev = midi - Math.rint(midi)
                sx += v * cos(2 * PI * dev)
                sy += v * sin(2 * PI * dev)
            }
        }
        if (sx != 0.0 || sy != 0.0) tuning = atan2(sy, sx) / (2 * PI)
    }

    /** Picks the chord. Returns how well the chord that is playing fits (0..1). */
    private fun decide(eager: Boolean): Float {
        val vocab = if (precise) preciseVocab else basicVocab
        val types = vocab.types
        val nt = types.size

        var norm = 0.0
        for (p in 0 until 12) norm += chromaS[p] * chromaS[p]
        norm = sqrt(norm) + 1e-9
        var bmax = 1e-9
        for (p in 0 until 12) if (bassS[p] > bmax) bmax = bassS[p]
        val dia = if (keyTonic >= 0) ChordEngine.diatonic(keyTonic, keyMinor) else emptySet()

        var bestJ = -1
        var bestE = -1e9
        var bestDot = 0.0
        var curE = -1e9
        var curDot = 0.0
        for (r in 0 until 12) {
            for (ti in 0 until nt) {
                val j = r * nt + ti
                val t = types[ti]
                var dot = 0.0
                for (p in 0 until 12) dot += chromaS[p] / norm * vocab.templates[j][p]
                var e = ChordEngine.SCALE * dot
                e += ChordEngine.BASS_W * ChordEngine.SCALE * (bassS[r] / bmax)
                e -= ChordEngine.TYPE_PEN * ChordEngine.TYPE_PENALTY.getValue(t) * ChordEngine.SCALE
                val minorBase = t == "m" || t == "m7" || t == "m6"
                if (dia.contains(r * 2 + (if (minorBase) 1 else 0))) e += ChordEngine.DIA_W * ChordEngine.SCALE
                if (e > bestE) {
                    bestE = e
                    bestJ = j
                    bestDot = dot
                }
                if (r == curRoot && t == curType) {
                    curE = e
                    curDot = dot
                }
            }
        }

        // a chord of the other vocabulary (7th chords after switching to Basic) cannot stay
        if (curRoot >= 0 && curE < -1e8) {
            curRoot = -1
            curType = ""
        }
        if (bestJ < 0 || bestDot < minFit()) {
            pendCount = 0
            return if (curRoot >= 0) curDot.toFloat() else 0f
        }
        val bestRoot = bestJ / nt
        val bestType = types[bestJ % nt]
        if (bestRoot == curRoot && bestType == curType) {
            pendCount = 0
        } else if (curRoot < 0 || bestE - curE > (if (eager) MARGIN * 0.4 else MARGIN)) {
            if (bestRoot == pendRoot && bestType == pendType) pendCount++ else {
                pendRoot = bestRoot
                pendType = bestType
                pendCount = 1
            }
            if (pendCount >= (if (eager) 1 else CONFIRM)) {
                curRoot = bestRoot
                curType = bestType
                curDot = bestDot
                pendCount = 0
            }
        } else {
            pendCount = 0
        }
        return curDot.toFloat()
    }

    /** Adds the chord that plays to the picture of the key, and reads the key from it now and then. */
    private fun listen() {
        for (i in 0 until 12) keyProf[i] *= keyDecay
        for (i in 0 until 24) chordTime[i] *= keyDecay
        keyTotal *= keyDecay
        if (curRoot < 0) return
        for ((iv, w) in ChordEngine.TYPE_NOTES.getValue(curType)) keyProf[(curRoot + iv) % 12] += hopSec * w
        chordTime[curRoot * 2 + (if (ChordEngine.isMinorType(curType)) 1 else 0)] += hopSec
        keyTotal += hopSec
        keyTick++
        if (keyTotal < KEY_AFTER || keyTick % 10 != 0) return
        var best = -1e9
        var bt = 0
        var bm = false
        for (minor in listOf(false, true)) {
            val kk = if (minor) ChordEngine.KK_MIN else ChordEngine.KK_MAJ
            for (t in 0 until 12) {
                var sc = ChordEngine.pearson(keyProf, ChordEngine.rolled(kk, t))
                sc += 0.25 * chordTime[t * 2 + (if (minor) 1 else 0)] / keyTotal
                if (sc > best) {
                    best = sc
                    bt = t
                    bm = minor
                }
            }
        }
        keyTonic = bt
        keyMinor = bm
    }

    private fun reading(level: Float, fit: Float, quiet: Boolean, calibrating: Boolean = false): LiveReading {
        var top = 1e-9
        for (p in 0 until 12) if (chromaS[p] > top) top = chromaS[p]
        val notes = FloatArray(12) { (chromaS[it] / top).toFloat() }
        val gateLevel = ((20.0 * log10(max(currentGate(), 1e-6)) + 60.0) / 50.0).coerceIn(0.0, 1.0).toFloat()
        return LiveReading(curRoot, curType, fit, level, notes, keyTonic, keyMinor, quiet, gateLevel, calibrating)
    }

    private companion object {
        /** New samples (at about 11 kHz) between two readings: 46 ms. */
        const val HOP = 512
        const val SMOOTH = 0.5
        const val TUNE_KEEP = 0.97
        /** How many times the learned room noise is taken off each bin of the spectrum. */
        const val NOISE_CUT = 1.5
        const val NN_M0 = 36
        const val NN_NOTES = 53
        const val NN_SUB = 3
        /** The newest 46 ms has to be this many times louder than the 46 ms before to count as a strum. */
        const val ONSET_RATIO = 2.2
        /** After a strum, readings up to this many hops later use only the sound since the strum. */
        const val FAST_UNTIL = 7
        /** ... and up to this many hops later the new chord may win at once. */
        const val EAGER_UNTIL = 4
        /** Readings (46 ms each) of "Listen to the room": about two seconds. */
        const val CALIB_FRAMES = 44
        /** A new chord has to beat the one playing by this much (in the engine's score units, 8 = a perfect match). */
        const val MARGIN = 0.9
        /** Readings in a row it has to win. */
        const val CONFIRM = 2
        /** Seconds of chords needed before a key is named. */
        const val KEY_AFTER = 8.0
    }
}
