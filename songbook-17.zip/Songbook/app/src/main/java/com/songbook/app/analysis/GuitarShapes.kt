package com.songbook.app.analysis

/**
 * How a chord is played on a guitar in standard tuning. [frets] has six entries from the low E string to the high
 * e string: -1 = not played, 0 = open, n = fret n. [barre] is the fret of a barre (0 = none) and [barreFrom] the
 * first string it covers.
 */
class GuitarShape(val frets: IntArray, val barre: Int = 0, val barreFrom: Int = 0) {
    /** The first fret drawn: 1, or the lowest fret used when the chord sits higher on the neck. */
    val baseFret: Int
        get() {
            val used = frets.filter { it > 0 }
            if (used.isEmpty()) return 1
            return if ((used.maxOrNull() ?: 1) <= 4) 1 else (used.minOrNull() ?: 1)
        }
}

object GuitarShapes {
    /** Open-position shapes: "root:type" to the frets of the six strings, x = not played. */
    private val OPEN = mapOf(
        "0:" to "x32010", "0:maj7" to "x32000", "0:7" to "x32310", "0:sus2" to "x30010", "0:sus4" to "x33011",
        "2:" to "xx0232", "2:m" to "xx0231", "2:7" to "xx0212", "2:maj7" to "xx0222", "2:m7" to "xx0211",
        "2:sus4" to "xx0233", "2:sus2" to "xx0230",
        "4:" to "022100", "4:m" to "022000", "4:7" to "020100", "4:maj7" to "021100", "4:m7" to "020000",
        "4:sus4" to "022200", "4:sus2" to "024400",
        "5:maj7" to "xx3210",
        "7:" to "320003", "7:7" to "320001", "7:maj7" to "320002", "7:sus4" to "330013",
        "9:" to "x02220", "9:m" to "x02210", "9:7" to "x02020", "9:maj7" to "x02120", "9:m7" to "x02010",
        "9:sus4" to "x02230", "9:sus2" to "x02200",
        "11:7" to "x21202",
        // the extra chords of Live mode
        "0:add9" to "x32030", "4:add9" to "022102", "7:add9" to "320203", "9:add9" to "x02420",
        "0:6" to "x32210", "2:6" to "xx0202", "7:6" to "320000", "2:m6" to "xx0201",
        "2:5" to "xx023x", "4:5" to "022xxx", "9:5" to "x022xx",
        "2:7sus4" to "xx0213", "7:7sus4" to "330011"
    )

    /** Barre shapes with the root on the low E string, relative to the barre fret (-1 = not played). */
    private val E_SHAPE = mapOf(
        "" to intArrayOf(0, 2, 2, 1, 0, 0), "m" to intArrayOf(0, 2, 2, 0, 0, 0), "7" to intArrayOf(0, 2, 0, 1, 0, 0),
        "m7" to intArrayOf(0, 2, 0, 0, 0, 0), "maj7" to intArrayOf(0, 2, 1, 1, 0, 0),
        "sus4" to intArrayOf(0, 2, 2, 2, 0, 0), "sus2" to intArrayOf(0, 2, 4, 4, 0, 0),
        "add9" to intArrayOf(0, 2, 2, 1, 0, 2), "6" to intArrayOf(0, 2, 2, 1, 2, 0), "m6" to intArrayOf(0, 2, 2, 0, 2, 0),
        "5" to intArrayOf(0, 2, 2, -1, -1, -1), "7sus4" to intArrayOf(0, 2, 0, 2, 0, 0), "9" to intArrayOf(0, 2, 0, 1, 0, 2)
    )

    /** Barre shapes with the root on the A string. */
    private val A_SHAPE = mapOf(
        "" to intArrayOf(-1, 0, 2, 2, 2, 0), "m" to intArrayOf(-1, 0, 2, 2, 1, 0), "7" to intArrayOf(-1, 0, 2, 0, 2, 0),
        "m7" to intArrayOf(-1, 0, 2, 0, 1, 0), "maj7" to intArrayOf(-1, 0, 2, 1, 2, 0),
        "sus4" to intArrayOf(-1, 0, 2, 2, 3, 0), "sus2" to intArrayOf(-1, 0, 2, 2, 0, 0),
        "add9" to intArrayOf(-1, 0, 2, 4, 2, 0), "6" to intArrayOf(-1, 0, 2, 2, 2, 2), "m6" to intArrayOf(-1, 0, 2, 2, 1, 2),
        "5" to intArrayOf(-1, 0, 2, 2, -1, -1), "7sus4" to intArrayOf(-1, 0, 2, 0, 3, 0), "9" to intArrayOf(-1, 0, 2, 4, 2, 3)
    )

    /** Shapes with the root on the D string (the four high strings), for the chords that have no good E or A shape. */
    private val D_SHAPE = mapOf(
        "dim" to intArrayOf(-1, -1, 0, 1, 3, 1), "aug" to intArrayOf(-1, -1, 0, 3, 3, 2)
    )

    /** Chords where a barre line across the strings would be wrong (some strings are not played). */
    private val NO_BARRE = setOf("5", "dim", "aug")

    fun shape(root: Int, type: String): GuitarShape? {
        val open = OPEN["$root:$type"]
        if (open != null) return GuitarShape(IntArray(6) { if (open[it] == 'x') -1 else open[it] - '0' })
        // the nearest to the nut wins: the shape whose root string is nearest below the root note (E before A before D)
        var best: GuitarShape? = null
        var bestFret = 99
        for ((openPc, table, barreFrom) in listOf(Triple(4, E_SHAPE, 0), Triple(9, A_SHAPE, 1), Triple(2, D_SHAPE, 2))) {
            val rel = table[type] ?: continue
            val f = Math.floorMod(root - openPc, 12)
            if (f < bestFret) {
                bestFret = f
                val useBarre = f > 0 && type !in NO_BARRE
                best = GuitarShape(IntArray(6) { if (rel[it] < 0) -1 else rel[it] + f }, barre = if (useBarre) f else 0, barreFrom = barreFrom)
            }
        }
        return best
    }
}
