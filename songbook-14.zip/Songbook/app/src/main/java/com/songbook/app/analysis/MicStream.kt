package com.songbook.app.analysis

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import kotlin.math.max

/**
 * Reads the microphone live, for the tuner and for the chord analyzer's Live mode. Nothing is stored: the samples go
 * to [start]'s callback as floats between -1 and 1, mono, in blocks of about 23 ms, on the recording thread (so the
 * callback has to be quick; the detectors do their work in a few milliseconds).
 *
 * It asks for the unprocessed microphone where the phone has one (no automatic volume, no noise clean-up: those are
 * made for calls and blur the notes) and falls back to the normal microphone.
 */
class MicStream(private val context: Context) {
    private var record: AudioRecord? = null
    private var thread: Thread? = null

    @Volatile private var running = false

    /** The sample rate that is really used (44100 or 48000). Known after a successful [start]. */
    var rate: Int = 44_100
        private set

    val isRunning: Boolean get() = running

    private fun supportsUnprocessed(): Boolean =
        Build.VERSION.SDK_INT >= 24 &&
            context.getSystemService(AudioManager::class.java)?.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"

    @SuppressLint("MissingPermission")
    private fun open(sampleRate: Int, source: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val size = max(min * 2, sampleRate)                   // about half a second of room
        return try {
            val r = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(size)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Starts listening. Returns false when the microphone could not be opened (no permission, or in use). */
    fun start(onSamples: (FloatArray, Int) -> Unit): Boolean {
        if (running) return true
        val sources = ArrayList<Int>()
        if (supportsUnprocessed()) sources.add(MediaRecorder.AudioSource.UNPROCESSED)
        sources.add(MediaRecorder.AudioSource.MIC)
        var rec: AudioRecord? = null
        var usedRate = 44_100
        search@ for (src in sources) {
            for (r in intArrayOf(44_100, 48_000)) {
                val a = open(r, src)
                if (a != null) {
                    rec = a
                    usedRate = r
                    break@search
                }
            }
        }
        val r = rec ?: return false
        return try {
            record = r
            rate = usedRate
            running = true
            r.startRecording()
            thread = Thread({
                runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) }
                val shorts = ShortArray(1024)
                val floats = FloatArray(1024)
                while (running) {
                    val n = r.read(shorts, 0, shorts.size)
                    if (n < 0) break
                    if (n == 0) continue
                    for (i in 0 until n) floats[i] = shorts[i] / 32768f
                    onSamples(floats, n)
                }
            }, "songbook-mic").also { it.start() }
            true
        } catch (e: Exception) {
            running = false
            runCatching { r.release() }
            record = null
            false
        }
    }

    /** Stops listening and lets the microphone go. Safe to call more than once. */
    fun stop() {
        running = false
        runCatching { thread?.join(1500) }
        thread = null
        record?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        record = null
    }
}
