package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The "sb" wordmark of the launcher icon (res/drawable/ic_launcher_foreground.xml), drawn on a 108 x 108 grid. */
private const val WordPath =
    "M39.99 72.27Q37.86 72.27 35.81 71.72Q33.75 71.18 32 70.16Q30.24 69.15 29 67.81L33.31 63.46Q34.5 64.74 36.13 65.46Q37.76 66.18 39.69 66.18Q41.03 66.18 41.75 65.78Q42.47 65.39 42.47 64.69Q42.47 63.8 41.6 63.33Q40.73 62.86 39.4 62.49Q38.06 62.12 36.57 61.67Q35.09 61.23 33.75 60.44Q32.42 59.64 31.57 58.23Q30.73 56.82 30.73 54.64Q30.73 52.32 31.92 50.61Q33.11 48.9 35.29 47.91Q37.47 46.92 40.39 46.92Q43.46 46.92 46.05 47.99Q48.65 49.05 50.29 51.13L45.98 55.49Q44.84 54.15 43.43 53.6Q42.02 53.06 40.68 53.06Q39.4 53.06 38.75 53.43Q38.11 53.8 38.11 54.5Q38.11 55.24 38.95 55.68Q39.79 56.13 41.13 56.48Q42.47 56.82 43.95 57.32Q45.44 57.81 46.77 58.65Q48.11 59.5 48.95 60.91Q49.79 62.32 49.79 64.59Q49.79 68.11 47.14 70.19Q44.5 72.27 39.99 72.27Z M67.27 72.17Q64.84 72.17 62.81 71.15Q60.78 70.14 59.5 68.43Q58.21 66.72 58.01 64.59V54.45Q58.21 52.32 59.5 50.66Q60.78 49 62.81 48.06Q64.84 47.12 67.27 47.12Q70.68 47.12 73.33 48.75Q75.98 50.39 77.49 53.21Q79 56.03 79 59.64Q79 63.26 77.49 66.08Q75.98 68.9 73.33 70.53Q70.68 72.17 67.27 72.17ZM53.41 71.67V35.73H60.98V53.5L59.74 59.35L60.88 65.19V71.67ZM65.93 65.34Q67.51 65.34 68.73 64.59Q69.94 63.85 70.63 62.56Q71.33 61.28 71.33 59.64Q71.33 57.96 70.63 56.67Q69.94 55.39 68.73 54.67Q67.51 53.95 65.93 53.95Q64.35 53.95 63.11 54.67Q61.87 55.39 61.2 56.67Q60.53 57.96 60.53 59.64Q60.53 61.33 61.23 62.61Q61.92 63.9 63.13 64.62Q64.35 65.34 65.93 65.34Z"

/** In-app copy of the Songbook 3.0 icon: a coral tile with the Outfit Bold letters "sb" in white. */
@Composable
fun AppIconArt(size: Dp, modifier: Modifier = Modifier) {
    val word = remember { PathParser().parsePathString(WordPath).toPath() }
    val shape = RoundedCornerShape(size * 0.225f)
    Canvas(modifier.size(size).shadow(if (size > 60.dp) 14.dp else 0.dp, shape).clip(shape)) {
        val s = this.size.width / 108f
        scale(s, s, pivot = Offset.Zero) {
            drawRect(
                Brush.verticalGradient(listOf(Color(0xFFFF7B5E), Color(0xFFF0593A)), startY = 0f, endY = 108f),
                size = Size(108f, 108f)
            )
            // the letters are drawn a little larger than in the launcher icon because the whole tile is visible here
            scale(1.25f, 1.25f, pivot = Offset(54f, 54f)) { drawPath(word, Color.White) }
        }
    }
}
