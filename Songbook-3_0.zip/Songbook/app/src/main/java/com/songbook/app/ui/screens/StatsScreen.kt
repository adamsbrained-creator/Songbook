package com.songbook.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.songbook.app.data.AlbumEntity
import com.songbook.app.data.GroupEntity
import com.songbook.app.data.LibraryStats
import com.songbook.app.data.RecordingEntity
import com.songbook.app.data.SongEntity
import com.songbook.app.data.Stage
import com.songbook.app.data.Stats
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.components.CoralTopBar
import com.songbook.app.ui.components.EmptyHint
import com.songbook.app.ui.components.IconSpec
import com.songbook.app.ui.components.ProgressRing
import com.songbook.app.ui.components.RatingTag
import com.songbook.app.ui.components.SbIconButton
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.Segmented
import com.songbook.app.ui.components.SectionTitle
import com.songbook.app.ui.components.SquareArtwork
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.formatDuration
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.components.songType
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlin.math.roundToInt

private class StatsTab(val label: String, val icon: IconSpec)

private val StatsTabs = listOf(
    StatsTab("Progress", IconSpec(listOf("M22 12h-4l-3 9L9 3l-3 9H2"))),
    StatsTab("Top rated", IconSpec(listOf("M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z", "M17 5h3v2a3 3 0 0 1-3 3", "M7 5H4v2a3 3 0 0 0 3 3"))),
    StatsTab("Albums", IconSpec(listOf("M2 4h7a3 3 0 0 1 3 3v14a2 2 0 0 0-2-2H2z", "M22 4h-7a3 3 0 0 0-3 3v14a2 2 0 0 1 2-2h8z"))),
    StatsTab("History", IconSpec(listOf("M3 12a9 9 0 1 0 3-6.7L3 8", "M3 3v5h5", "M12 7v5l3 2"))),
    StatsTab("Insights", IconSpec(listOf("M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z", "M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z")))
)

private val HeartIcon = IconSpec(listOf("M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"))
private val CheckCircleIcon = IconSpec(listOf("M9 12l2 2 4-4"), listOf(Triple(12f, 12f, 10f)))
private val ListIcon = IconSpec(listOf("M8 6h13M8 12h13M8 18h13"), listOf(Triple(3.5f, 6f, 1f), Triple(3.5f, 12f, 1f), Triple(3.5f, 18f, 1f)))

/** Album filter value: everything, songs without an album, or one album's id. */
private const val ALL = 0L
private const val NO_ALBUM = -1L

/**
 * The Statistics page: how far the library is (progress by stage or by rating), the best rated songs,
 * the albums, what was opened and read lately, and some facts about the writing itself.
 * [songs] includes the ideas, so the stage chart is complete.
 */
@Composable
fun StatsScreen(
    songs: List<SongEntity>,
    albums: List<AlbumEntity>,
    groups: List<GroupEntity>,
    recordings: List<RecordingEntity>,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    onOpenSong: (Long) -> Unit,
    onOpenWorkflow: () -> Unit
) {
    val c = Sb.colors
    var tab by rememberSaveable { mutableStateOf(0) }
    var albumFilter by rememberSaveable { mutableStateOf(ALL) }
    var byRating by rememberSaveable { mutableStateOf(false) }
    var filterMenu by remember { mutableStateOf(false) }

    val albumNames = remember(albums) { albums.associate { it.id to it.name } }
    // an album that was deleted while it was the filter falls back to "All albums"
    val filter = if (albumFilter > 0 && albumFilter !in albumNames) ALL else albumFilter
    val shown = remember(songs, filter) {
        when (filter) {
            ALL -> songs
            NO_ALBUM -> songs.filter { it.albumId == null }
            else -> songs.filter { it.albumId == filter }
        }
    }
    val stats = remember(shown, albums, groups, recordings) { Stats.compute(shown, albums, groups, recordings) }
    val stageCounts = remember(shown) { List(Stage.DONE + 1) { st -> shown.count { it.stage.coerceIn(0, Stage.DONE) == st } } }
    val filterLabel = when (filter) { ALL -> "All albums"; NO_ALBUM -> "No album"; else -> albumNames[filter] ?: "All albums" }

    LazyColumn(Modifier.fillMaxSize().screenBg().statusBarsPadding(), contentPadding = PaddingValues(bottom = 130.dp)) {
        item {
            when (Sb.style) {
                UiStyle.CORAL -> CoralTopBar("stats", SbIcons.Back, "Back", onBack, current = "stats", onNavigate = onNavigate)
                else -> Row(
                    Modifier.fillMaxWidth().padding(start = 8.dp, end = 24.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SbIconButton(SbIcons.Back, "Back", onBack)
                    Text("Statistics", style = sbStyle(26, FontWeight.Bold, c.tx))
                }
            }
        }
        item {
            // album filter
            Row(Modifier.padding(horizontal = 24.dp, vertical = 6.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${stats.songs} ${if (stats.songs == 1) "song" else "songs"}",
                    style = sbStyle(14, color = c.mu), modifier = Modifier.weight(1f)
                )
                Box {
                    Row(
                        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(c.track).clickable { filterMenu = true }.padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(Modifier.size(12.dp).background(c.ac, CircleShape))
                        Text(filterLabel, style = sbStyle(15, FontWeight.Medium, c.tx), maxLines = 1, modifier = Modifier.widthIn(max = 150.dp))
                    }
                    DropdownMenu(expanded = filterMenu, onDismissRequest = { filterMenu = false }, modifier = Modifier.background(c.sheet)) {
                        val choices = buildList {
                            add(ALL to "All albums")
                            albums.forEach { add(it.id to it.name) }
                            if (songs.any { it.albumId == null }) add(NO_ALBUM to "No album")
                        }
                        choices.forEach { (id, name) ->
                            DropdownMenuItem(
                                text = { Text(name, style = sbStyle(14, if (id == filter) FontWeight.SemiBold else FontWeight.Normal, if (id == filter) c.ct else c.tx)) },
                                onClick = { albumFilter = id; filterMenu = false }
                            )
                        }
                    }
                }
            }
        }
        item {
            // tab bar: icons, the chosen one is a black pill with its name
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(c.track).padding(5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                StatsTabs.forEachIndexed { i, t ->
                    if (i == tab) {
                        Row(
                            Modifier.height(46.dp).clip(RoundedCornerShape(23.dp)).background(c.pill).padding(horizontal = 18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StrokeIcon(t.icon, c.onPill, size = 20.dp)
                            Text(t.label, style = sbStyle(15, FontWeight.Medium, c.onPill), maxLines = 1)
                        }
                    } else {
                        Box(
                            Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(22.dp)).clickable { tab = i },
                            contentAlignment = Alignment.Center
                        ) { StrokeIcon(t.icon, c.tx, size = 22.dp) }
                    }
                }
            }
        }

        when (tab) {
            0 -> progressTab(stats, stageCounts, byRating, { byRating = it }, onOpenWorkflow)
            1 -> topRatedTab(stats, onOpenSong, albumNames)
            2 -> albumsTab(shown, albums)
            3 -> historyTab(stats, onOpenSong)
            else -> insightsTab(stats)
        }
    }
}

// ---- Progress ------------------------------------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.progressTab(
    stats: LibraryStats,
    stageCounts: List<Int>,
    byRating: Boolean,
    onMode: (Boolean) -> Unit,
    onOpenWorkflow: () -> Unit
) {
    item {
        val c = Sb.colors
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().sbCard(32.dp).padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                SectionTitle(if (byRating) "Ratings · all songs" else "Finished · by stage")
                Segmented(listOf("Stage", "Rating"), if (byRating) 1 else 0) { onMode(it == 1) }
            }
            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (byRating) {
                    Text("${stats.rated}", style = sbStyle(60, FontWeight.Medium, c.tx, serif = true))
                    Text("rated of ${stats.songs} songs", style = sbStyle(18, color = c.mu), modifier = Modifier.padding(bottom = 10.dp))
                } else {
                    Text("${stats.finished}", style = sbStyle(60, FontWeight.Medium, c.tx, serif = true))
                    Text("of ${stats.songs} songs", style = sbStyle(20, color = c.mu), modifier = Modifier.padding(bottom = 10.dp))
                }
            }
            if (byRating) {
                BarChart(stats.ratingBuckets, listOf("1★", "2★", "3★", "4★", "5★"), List(5) { Fill.Main }, highlight = stats.ratingBuckets.indexOfLast { it > 0 })
            } else {
                val fills = stageCounts.mapIndexed { st, n ->
                    when {
                        n == 0 -> Fill.Empty
                        st >= Stage.DONE -> Fill.Main
                        else -> Fill.Soft
                    }
                }
                BarChart(stageCounts, Stage.names, fills, highlight = Stage.DONE)
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Legend(c.ac, "Finished")
                    Legend(c.ac.copy(alpha = 0.38f), "In progress")
                    Legend(c.ln, "Empty stage")
                }
            }
            Box(Modifier.padding(top = 16.dp).fillMaxWidth().height(1.dp).background(c.ln))
            Row(
                Modifier.fillMaxWidth().height(48.dp).padding(top = 6.dp).clip(RoundedCornerShape(24.dp)).clickable(onClick = onOpenWorkflow),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                StrokeIcon(ListIcon, c.ct, size = 20.dp)
                Text("View workflow", style = sbStyle(16, FontWeight.Medium, c.ct), modifier = Modifier.padding(horizontal = 10.dp))
                StrokeIcon(SbIcons.ChevronRight, c.ct, size = 18.dp)
            }
        }
    }
    item {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile(SbIcons.Star, if (stats.rated == 0) "–" else "%.2f".format(stats.avgRating), "Avg. rating", Modifier.weight(1f))
            Tile(HeartIcon, "${stats.favorites}", "Favorites", Modifier.weight(1f))
            Tile(CheckCircleIcon, "${stats.finished}", "Finished", Modifier.weight(1f))
        }
    }
    item {
        val c = Sb.colors
        val fraction = if (stats.songs == 0) 0f else stats.finished / stats.songs.toFloat()
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().sbCard(32.dp).padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            ProgressRing(fraction, 104.dp, 11.dp, c.ln, c.ac, "${(fraction * 100).roundToInt()}%", c.tx, 22)
            Column {
                Text("Songs finished", style = sbStyle(24, FontWeight.SemiBold, c.tx))
                Text("${stats.finished} of ${stats.songs} songs", style = sbStyle(15, color = c.mu), modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

private enum class Fill { Main, Soft, Empty }

/** Columns with the number above and a name under each. The [highlight] column has its number in the deeper coral. */
@Composable
private fun BarChart(values: List<Int>, labels: List<String>, fills: List<Fill>, highlight: Int) {
    val c = Sb.colors
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    Row(
        Modifier.padding(top = 14.dp).fillMaxWidth().height(128.dp).padding(bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        values.forEachIndexed { i, v ->
            val h = if (v == 0) 8.dp else (12 + 66f * v / max).dp
            val color = when (fills.getOrElse(i) { Fill.Main }) {
                Fill.Main -> c.ac
                Fill.Soft -> c.ac.copy(alpha = 0.38f)
                Fill.Empty -> c.ln
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp, Alignment.Bottom)) {
                Text("$v", style = sbStyle(13, FontWeight.SemiBold, if (i == highlight) c.ct else c.tx))
                Box(Modifier.width(44.dp).height(h).clip(RoundedCornerShape(if (v == 0) 4.dp else 14.dp)).background(color))
            }
        }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(c.ln))
    Row(Modifier.padding(top = 8.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, l ->
            Text(
                l, style = sbStyle(11, if (i == highlight) FontWeight.Medium else FontWeight.Normal, if (i == highlight) c.tx else c.mu),
                maxLines = 1, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(12.dp).clip(RoundedCornerShape(4.dp)).background(color))
        Text(label, style = sbStyle(12, color = Sb.colors.mu))
    }
}

@Composable
private fun Tile(icon: IconSpec, value: String, label: String, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier.sbCard(28.dp).padding(16.dp)) {
        StrokeIcon(icon, c.ct, size = 24.dp)
        Text(value, style = sbStyle(28, FontWeight.SemiBold, c.tx), modifier = Modifier.padding(top = 14.dp), maxLines = 1)
        Text(label, style = sbStyle(13, color = c.mu), modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

// ---- Top rated -----------------------------------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.topRatedTab(
    stats: LibraryStats,
    onOpenSong: (Long) -> Unit,
    albumNames: Map<Long, String>
) {
    item {
        Section("Best rated") {
            if (stats.topRated.isEmpty()) EmptyHint("Rate a song (the stars on the song page) and it will show up here.")
            stats.topRated.forEachIndexed { i, s ->
                RankedSong(i + 1, s, albumNames[s.albumId] ?: "No album", onOpenSong) { RatingTag(s.rating) }
            }
        }
    }
    item {
        val c = Sb.colors
        Section("Ratings") {
            BarChart(stats.ratingBuckets, listOf("1★", "2★", "3★", "4★", "5★"), List(5) { Fill.Main }, highlight = stats.ratingBuckets.indexOfLast { it > 0 })
            Text(
                if (stats.rated == 0) "No rated songs yet." else "${stats.rated} rated · average ${"%.2f".format(stats.avgRating)}",
                style = sbStyle(13, color = c.mu), modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

// ---- Albums --------------------------------------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.albumsTab(shown: List<SongEntity>, albums: List<AlbumEntity>) {
    item {
        val c = Sb.colors
        val rows = remember(shown, albums) {
            val byAlbum = shown.groupBy { it.albumId }
            val named = albums.mapNotNull { a -> byAlbum[a.id]?.let { a.name to it } }
            val loose = byAlbum[null]?.let { listOf("No album" to it) } ?: emptyList()
            (named + loose).sortedByDescending { it.second.size }
        }
        Section("Songs per album") {
            if (rows.isEmpty()) EmptyHint("No songs yet.")
            rows.forEach { (name, list) ->
                val done = list.count { it.stage >= Stage.DONE }
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(name, style = sbStyle(15, FontWeight.SemiBold, c.tx), maxLines = 1, modifier = Modifier.weight(1f))
                        Text("$done / ${list.size}", style = sbStyle(13, color = c.mu))
                    }
                    Row(Modifier.padding(top = 8.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(c.ln)) {
                        if (done > 0) Box(Modifier.weight(done.toFloat()).height(6.dp).background(c.ac))
                        if (list.size - done > 0) Box(Modifier.weight((list.size - done).toFloat()).height(6.dp))
                    }
                }
            }
        }
    }
}

// ---- History -------------------------------------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.historyTab(stats: LibraryStats, onOpenSong: (Long) -> Unit) {
    item {
        Section("Songs added, last six months") {
            val last = stats.perMonth.lastIndex
            BarChart(stats.perMonth.map { it.second }, stats.perMonth.map { it.first }, stats.perMonth.map { if (it.second == 0) Fill.Empty else Fill.Main }, highlight = last)
        }
    }
    item {
        Section("Opened lately") {
            if (stats.recent.isEmpty()) EmptyHint("Songs you open will be listed here.")
            stats.recent.forEachIndexed { i, s -> RankedSong(i + 1, s, songType(s.typeName), onOpenSong) }
        }
    }
    item {
        Section("Most opened") {
            if (stats.mostOpened.isEmpty()) EmptyHint("Nothing opened yet.")
            stats.mostOpened.forEachIndexed { i, s ->
                RankedSong(i + 1, s, songType(s.typeName), onOpenSong) { Text(if (s.opens == 1) "1 time" else "${s.opens} times", style = sbStyle(13, color = Sb.colors.mu)) }
            }
        }
    }
    item {
        Section("Most read") {
            if (stats.mostRead.isEmpty()) EmptyHint("Reading time is counted while a song page is open.")
            stats.mostRead.forEachIndexed { i, s ->
                RankedSong(i + 1, s, songType(s.typeName), onOpenSong) { Text(readTime(s.readSeconds), style = sbStyle(13, color = Sb.colors.mu)) }
            }
        }
    }
}

// ---- Insights ------------------------------------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.insightsTab(stats: LibraryStats) {
    item {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Fact("${stats.words}", "words written", Modifier.weight(1f))
                Fact("${stats.chordsPlaced}", "chords placed", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Fact("${stats.songsWithChords}", "songs with chords", Modifier.weight(1f))
                Fact(if (stats.withBpm == 0) "–" else "${stats.avgBpm}", if (stats.withBpm == 0) "average tempo" else "average BPM · ${stats.withBpm} songs", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Fact("${stats.recordings}", if (stats.recordings == 1) "demo · ${formatDuration(stats.recordedMs)}" else "demos · ${formatDuration(stats.recordedMs)}", Modifier.weight(1f))
                Fact("${stats.opens}", "song page opens", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Fact(readTime(stats.readSeconds), "reading time", Modifier.weight(1f))
                Fact("${stats.albums}", if (stats.groups > 0) "albums · ${stats.groups} groups" else "albums", Modifier.weight(1f))
            }
        }
    }
    item {
        Section("Keys") {
            if (stats.keys.isEmpty()) EmptyHint("Keys are worked out from the chords, or set by hand in the song menu.")
            else Pills(stats.keys)
        }
    }
    item {
        Section("Favorite chords") {
            if (stats.topChords.isEmpty()) EmptyHint("No chords yet.") else Pills(stats.topChords)
        }
    }
}

@Composable
private fun Fact(value: String, label: String, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier.sbCard(24.dp).padding(16.dp)) {
        Text(value, style = sbStyle(28, FontWeight.Normal, c.tx, serif = true), maxLines = 1)
        Text(label, style = sbStyle(13, color = c.mu), modifier = Modifier.padding(top = 4.dp), maxLines = 2)
    }
}

@Composable
private fun Pills(items: List<Pair<String, Int>>) {
    val c = Sb.colors
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (name, n) ->
            Row(
                Modifier.clip(RoundedCornerShape(16.dp)).background(c.track).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(name, style = sbStyle(15, FontWeight.SemiBold, c.ct))
                Text("× $n", style = sbStyle(12, color = c.mu))
            }
        }
    }
}

// ---- shared bits ---------------------------------------------------------------------------

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().sbCard(28.dp).padding(horizontal = 20.dp, vertical = 18.dp)) {
        SectionTitle(title)
        Column(Modifier.padding(top = 6.dp)) { content() }
    }
}

/** One song in a ranked list: number, small cover, title and what is under it, and something on the right. */
@Composable
private fun RankedSong(
    number: Int,
    song: SongEntity,
    subtitle: String,
    onOpen: (Long) -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    val c = Sb.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onOpen(song.id) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("$number", style = sbStyle(14, FontWeight.SemiBold, c.mu), modifier = Modifier.width(18.dp))
        SquareArtwork(song.gradient, 40.dp, 10.dp, image = song.image)
        Column(Modifier.weight(1f)) {
            Text(song.title, style = sbStyle(15, FontWeight.SemiBold, c.tx), maxLines = 1)
            Text(subtitle, style = sbStyle(12, color = c.mu), maxLines = 1)
        }
        trailing()
    }
}

/** "45 s", "12 min", "2 h 5 min". */
private fun readTime(seconds: Long): String = when {
    seconds < 60 -> "$seconds s"
    seconds < 3600 -> "${seconds / 60} min"
    else -> "${seconds / 3600} h ${(seconds % 3600) / 60} min"
}
