package com.songbook.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

// ---- GLASS: floating translucent tab bar + round plus ---------------------------------------

@Composable
fun GlassTabBar(current: String?, onNavigate: (String) -> Unit, onNew: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(modifier.fillMaxWidth()) {
        // list content fades out under the bar instead of running through it
        Box(
            Modifier.matchParentSize()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, c.bg.copy(alpha = 0.96f))))
        )
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp).padding(top = 34.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        Row(
            Modifier
                .weight(1f)
                .height(58.dp)
                .glassSurface(RoundedCornerShape(29.dp), strong = true)
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TopDests.forEach { d ->
                val on = d.route == current
                val tint = if (on) c.ac else c.mu
                Column(
                    Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (on) (if (c.isDark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.06f)) else Color.Transparent)
                        .clickable { onNavigate(d.route) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    StrokeIcon(d.icon, tint, size = 22.dp)
                    Text(d.label, style = sbStyle(9, FontWeight.Medium, tint), maxLines = 1)
                }
            }
        }
        Box(
            Modifier
                .size(58.dp)
                .shadow(12.dp, CircleShape, ambientColor = c.ac.copy(alpha = 0.5f), spotColor = c.ac.copy(alpha = 0.5f))
                .background(c.ac, CircleShape)
                .clip(CircleShape)
                .clickable(onClick = onNew)
                .semantics { contentDescription = "New song" },
            contentAlignment = Alignment.Center
        ) { StrokeIcon(SbIcons.Plus, Color.White, size = 28.dp) }
    }
    }
}

// ---- CORAL: round buttons, a centered title and a coral plus ----------------------------------------

class MenuAction(val label: String, val run: () -> Unit)

/** Round button of the Coral top bar: a white (dark gray in dark mode) circle with a thin line. */
@Composable
fun CoralRoundButton(icon: IconSpec, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier
            .size(44.dp)
            .background(c.cd, CircleShape)
            .border(1.dp, c.ln.copy(alpha = 0.7f), CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, c.tx, size = 20.dp) }
}

/**
 * Top bar of the Coral look: a round button on the left, the page title in the middle and a round "more" button
 * on the right. Without a tab bar, the more menu (or a tap on the title) is how you move between Songs, Albums,
 * Favorites, Statistics and Settings; [extras] adds what the page itself can do (sort, layout...).
 * With [onMore] the button does that instead (the reader opens the song menu).
 */
@Composable
fun CoralTopBar(
    title: String,
    leftIcon: IconSpec,
    leftDescription: String,
    onLeft: () -> Unit,
    modifier: Modifier = Modifier,
    current: String? = null,
    onNavigate: (String) -> Unit = {},
    extras: List<MenuAction> = emptyList(),
    onMore: (() -> Unit)? = null
) {
    val c = Sb.colors
    var open by remember { mutableStateOf(false) }
    Box(modifier.fillMaxWidth().height(64.dp).padding(horizontal = 16.dp)) {
        CoralRoundButton(leftIcon, leftDescription, onLeft, Modifier.align(Alignment.CenterStart))
        Text(
            title,
            style = sbStyle(22, FontWeight.Normal, c.tx, serif = true),
            maxLines = 1,
            modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp))
                .clickable { if (onMore != null) onMore() else open = true }.padding(horizontal = 12.dp, vertical = 6.dp)
        )
        Box(Modifier.align(Alignment.CenterEnd)) {
            CoralRoundButton(SbIcons.More, "More", { if (onMore != null) onMore() else open = true })
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(c.sheet)) {
                val pages = listOf(
                    "library" to "Songs", "albums" to "Albums", "favorites" to "Favorites", "stats" to "Statistics", "settings" to "Settings"
                )
                pages.forEach { (route, label) ->
                    DropdownMenuItem(
                        text = {
                            Text(label, style = sbStyle(14, if (route == current) FontWeight.SemiBold else FontWeight.Normal, if (route == current) c.ct else c.tx))
                        },
                        onClick = { open = false; if (route != current) onNavigate(route) }
                    )
                }
                if (extras.isNotEmpty()) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(c.ln))
                    extras.forEach { a ->
                        DropdownMenuItem(text = { Text(a.label, style = sbStyle(14, color = c.tx)) }, onClick = { open = false; a.run() })
                    }
                }
            }
        }
    }
}

/** Coral plus button for a new song. */
@Composable
fun CoralFab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Box(
        modifier
            .size(60.dp)
            .shadow(8.dp, CircleShape, ambientColor = c.ac.copy(alpha = 0.3f), spotColor = c.ac.copy(alpha = 0.3f))
            .background(c.ac, CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "New song" },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(SbIcons.Plus, c.onAc, size = 28.dp) }
}

/** Round translucent button used by the glass look (back, more, close...). */
@Composable
fun GlassRoundButton(icon: IconSpec, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Sb.colors.tx) {
    Box(
        modifier.size(40.dp).glassSurface(CircleShape).clip(CircleShape).clickable(onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { StrokeIcon(icon, tint, size = 20.dp) }
}

/** Title block of the glass look: big title with a muted line under it. */
@Composable
fun GlassTitle(title: String, subtitle: String?, modifier: Modifier = Modifier) {
    val c = Sb.colors
    Column(modifier) {
        Text(title, style = sbStyle(26, FontWeight.Bold, c.tx))
        if (subtitle != null) Text(subtitle, style = sbStyle(12, color = c.mu), modifier = Modifier.padding(top = 3.dp))
    }
}

/** Small spacer-width helper so call sites read well. */
@Composable
fun HSpace(w: Int) = Box(Modifier.width(w.dp))
