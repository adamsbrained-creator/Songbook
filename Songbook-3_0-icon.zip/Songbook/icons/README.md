# Icon variants

`pink/` and `purple/` each hold the three launcher drawables (`ic_launcher_background.xml`,
`ic_launcher_foreground.xml`, `ic_launcher_monochrome.xml`) plus a PNG preview and a 512 px PNG.

The project uses **pink** (those three files are in `app/src/main/res/drawable/`).

To switch to purple:
1. Copy the three `.xml` files from `icons/purple/` over the ones in `app/src/main/res/drawable/`.
2. In `app/src/main/java/com/songbook/app/ui/components/AppIcon.kt` change `IconInUse = IconPink` to `IconInUse = IconPurple`
   (the copy of the icon inside the app, Settings and the intro).
