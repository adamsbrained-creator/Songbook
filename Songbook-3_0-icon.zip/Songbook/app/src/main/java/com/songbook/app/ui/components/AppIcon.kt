package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The icon colors: the pick's gradient (top-left, bottom-right) and the pale shadow pick behind it. */
private class IconColors(val top: Color, val bottom: Color, val shadow: Color)

private val IconPink = IconColors(Color(0xFFFF6592), Color(0xFFEC2A5E), Color(0xFFFCBED0))
private val IconPurple = IconColors(Color(0xFFB88CE8), Color(0xFF8C5FD0), Color(0xFFDCCBF3))

/** Which icon the app shows inside (Settings, intro). Keep it the same as the files in res/drawable/ic_launcher_*.xml. */
private val IconInUse = IconPink

// The same outlines as res/drawable/ic_launcher_foreground.xml, on the 108 x 108 grid.
private const val ShadowPath =
    "M58.96 86.54 C45.28 78.72 29.05 64.65 26.56 48.89 C24.52 35.99 35.05 26.49 48.9 24.3 C63.71 21.95 75.9 27.85 77.94 40.75 C80.44 56.51 69.16 74.94 58.96 86.54 Z"
private const val PickPath =
    "M54.1 86.52 C41.82 76.66 27.99 60.22 27.99 44.27 C27.99 31.21 39.88 23.48 53.9 23.48 C68.89 23.48 80.01 31.21 80.01 44.27 C80.01 60.22 65.99 76.66 54.1 86.52 Z"
private const val NotePath =
    "M52.45 42.72 Q52.45 41.37 53.81 41.37 L56.37 41.37 Q57.72 41.37 57.72 42.72 C57.72 48.91 68.8 48.62 68.8 57.9 C68.8 59.34 67.63 60.51 66.18 60.51 C64.74 60.51 63.57 59.34 63.57 57.9 C63.57 53.74 61.98 51.33 59.08 49.68 Q57.72 48.91 57.72 51.52 L57.72 60.82 C57.72 63.44 55.72 66.12 52.65 67.6 C49.59 69.07 46.1 69.04 43.83 67.52 C41.56 66 40.98 63.29 42.36 60.69 C43.74 58.08 46.8 56.11 50.09 55.7 Q52.45 55.41 52.45 53.03 L52.45 42.72 Z"

/** In-app copy of the Songbook icon: a white tile with the gradient guitar pick and the white note. */
@Composable
fun AppIconArt(size: Dp, modifier: Modifier = Modifier) {
    val shadowPath = remember { PathParser().parsePathString(ShadowPath).toPath() }
    val pickPath = remember { PathParser().parsePathString(PickPath).toPath() }
    val notePath = remember { PathParser().parsePathString(NotePath).toPath() }
    val shape = RoundedCornerShape(size * 0.225f)
    Canvas(
        modifier.size(size)
            .shadow(if (size > 60.dp) 12.dp else 0.dp, shape)
            .clip(shape)
            .border(1.dp, Color(0x14000000), shape)
    ) {
        val s = this.size.width / 108f
        scale(s, s, pivot = Offset.Zero) {
            drawRect(Color.White, size = Size(108f, 108f))
            // the picture is drawn a little larger than in the launcher icon because the whole tile is visible here
            scale(1.12f, 1.12f, pivot = Offset(54f, 54f)) {
                drawPath(shadowPath, IconInUse.shadow)
                drawPath(
                    pickPath,
                    Brush.linearGradient(
                        listOf(IconInUse.top, IconInUse.bottom),
                        start = Offset(34.1f, 24.4f),
                        end = Offset(76.6f, 84.4f)
                    )
                )
                drawPath(notePath, Color.White)
            }
        }
    }
}
