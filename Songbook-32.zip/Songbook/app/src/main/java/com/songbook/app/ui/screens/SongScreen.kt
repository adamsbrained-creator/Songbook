package com.songbook.app.ui.screens

import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.songbook.app.analysis.ChordTypes
import com.songbook.app.analysis.Instrument
import com.songbook.app.applySystemBars
import com.songbook.app.data.AlbumEntity
import com.songbook.app.data.AppSettings
import com.songbook.app.data.RecordingEntity
import com.songbook.app.data.SectionStyle
import com.songbook.app.data.SongEntity
import com.songbook.app.data.SongLine
import com.songbook.app.data.SongParser
import com.songbook.app.data.SongTheme
import com.songbook.app.data.Stage
import com.songbook.app.data.Transposer
import com.songbook.app.data.UiStyle
import com.songbook.app.data.keyOrAuto
import com.songbook.app.data.serialize
import com.songbook.app.data.replaceLine
import com.songbook.app.data.withChordsAt
import com.songbook.app.data.wordAt
import com.songbook.app.ui.components.BadgePill
import com.songbook.app.ui.components.CapoDialog
import com.songbook.app.ui.components.ConfirmDialog
import com.songbook.app.ui.components.CoralRoundButton
import com.songbook.app.ui.components.ChordDialog
import com.songbook.app.ui.components.ChipPill
import com.songbook.app.ui.components.GlassBackdrop
import com.songbook.app.ui.components.GlassRoundButton
import com.songbook.app.ui.components.HeartButton
import com.songbook.app.ui.components.RatingDialog
import com.songbook.app.ui.components.RatingTag
import com.songbook.app.ui.components.ReadingDialog
import com.songbook.app.ui.components.RecordingsBlock
import com.songbook.app.ui.components.SbIconButton
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.SbSwitch
import com.songbook.app.ui.components.SectionTitle
import com.songbook.app.ui.components.ScrollSpeedDialog
import com.songbook.app.ui.components.SquareArtwork
import com.songbook.app.ui.components.StarRow
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.TextInputDialog
import com.songbook.app.ui.components.formatLongDate
import com.songbook.app.ui.components.glassSurface
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.components.rememberSongPlayer
import com.songbook.app.ui.components.songType
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.SbColors
import com.songbook.app.ui.theme.SongbookTheme
import com.songbook.app.ui.theme.sbStyle
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/** Top half of an ellipse, used for the "Edit" button at the bottom of the classic reader. */
private object DomeShape : Shape {
    override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path().apply {
            moveTo(0f, size.height)
            arcTo(Rect(0f, 0f, size.width, size.height * 2f), 180f, 180f, false)
            close()
        }
        return Outline.Generic(path)
    }
}

class ReaderActions(
    val onClose: () -> Unit,
    val onMenu: () -> Unit,
    val onEdit: () -> Unit,
    val onToggleFavorite: () -> Unit,
    val onCapo: (capo: Int, adjust: Boolean) -> Unit,
    val onShowTabs: (Boolean) -> Unit,
    val onReading: (Int, Int, Float, Int, Int) -> Unit,
    val onLyricsView: (Boolean) -> Unit,
    val onAutoScroll: (Boolean) -> Unit,
    val onScrollSpeed: (Int) -> Unit,
    val onSongTheme: (Int) -> Unit,
    val onRate: (Float) -> Unit,
    /** The whole song text after a chord was typed on a word. */
    val onBody: (String) -> Unit,
    /** Open the key, tempo, comment and "record a demo" dialogs (they live in the root, the song menu uses them too). */
    val onKey: () -> Unit,
    val onBpm: () -> Unit,
    val onComment: () -> Unit,
    val onRecord: () -> Unit,
    val onRenameRecording: (id: Long, title: String) -> Unit,
    val onDeleteRecording: (id: Long) -> Unit,
    /** Open the chord analyzer on one of the song's demos. */
    val onAnalyzeRecording: (RecordingEntity) -> Unit = {},
    /** Statistics: the page was opened / was on screen for this many seconds. */
    val onOpened: () -> Unit,
    val onRead: (seconds: Long) -> Unit
)

/**
 * The song page. Its theme follows the app by default, or is forced dark / light with the
 * "Song page" setting. Three layouts: classic, Coral (round buttons and a black player bar) and Glass (floating bar).
 */
@Composable
fun SongScreen(
    song: SongEntity?,
    album: AlbumEntity?,
    settings: AppSettings,
    appDark: Boolean,
    recordings: List<RecordingEntity>,
    actions: ReaderActions
) {
    // The song was deleted from the menu: go back.
    LaunchedEffect(song == null) { if (song == null) actions.onClose() }
    if (song == null) return

    val songDark = when (settings.songTheme) {
        SongTheme.DARK -> true
        SongTheme.LIGHT -> false
        else -> appDark
    }
    val activity = LocalContext.current as? ComponentActivity
    DisposableEffect(songDark) {
        activity?.applySystemBars(songDark)
        onDispose { activity?.applySystemBars(appDark) }
    }

    SongbookTheme(dark = songDark, accent = settings.accent, accentCustom = settings.accentCustom, style = settings.uiStyle) {
        Box(Modifier.fillMaxSize()) {
            if (settings.uiStyle == UiStyle.GLASS) GlassBackdrop() else Box(Modifier.fillMaxSize().background(Sb.colors.bg))
            SongContent(song, album, settings, recordings, actions)
            com.songbook.app.ui.components.ScrapbookUpdateBanner(song)   // [scrapbook hook 4]
        }
    }
}

@Composable
private fun SongContent(song: SongEntity, album: AlbumEntity?, settings: AppSettings, recordings: List<RecordingEntity>, a: ReaderActions) {
    val c = Sb.colors
    val style = Sb.style
    val lines = remember(song.body) { SongParser.parse(song.body) }
    val hasTabs = remember(song.body) { SongParser.hasTabs(song.body) }
    val shift = if (song.capoAdjust && song.capo > 0) -song.capo else 0
    val tabCapo = if (song.capoAdjust) song.capo else 0
    val songChords = remember(lines) {
        lines.filterIsInstance<SongLine.Lyric>().flatMap { l -> l.chords.map { it.name } }.distinct().take(10)
    }
    val sample = songChords.take(4)
    var readingDialog by remember { mutableStateOf(false) }
    var capoDialog by remember { mutableStateOf(false) }
    var speedDialog by remember { mutableStateOf(false) }
    var rateDialog by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var chordTarget by remember { mutableStateOf<Pair<Int, IntRange>?>(null) }
    val scroll = rememberScrollState()
    val lyricsView = settings.lyricsView
    val player = rememberSongPlayer()
    var renameTarget by remember { mutableStateOf<RecordingEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<RecordingEntity?>(null) }
    val key = remember(song.body, song.songKey) { song.keyOrAuto() }

    // Statistics: one opening, and the time the page stays on screen
    LaunchedEffect(song.id) { a.onOpened() }
    DisposableEffect(song.id) {
        val start = System.currentTimeMillis()
        onDispose {
            val seconds = (System.currentTimeMillis() - start) / 1000L
            if (seconds >= 3L) a.onRead(seconds)
        }
    }

    if (readingDialog) {
        ReadingDialog(
            settings.lyricsSize, settings.chordSize, settings.lineSpacing, settings.chordOffset, settings.sectionSize,
            onCommit = a.onReading, onDismiss = { readingDialog = false },
            songTheme = settings.songTheme, onSongTheme = a.onSongTheme
        )
    }
    if (capoDialog) CapoDialog(song.capo, song.capoAdjust, sample, { cp, adj -> a.onCapo(cp, adj); capoDialog = false }, { capoDialog = false })
    if (speedDialog) ScrollSpeedDialog(settings.scrollSpeed, a.onScrollSpeed, { speedDialog = false })
    if (rateDialog) RatingDialog("Rate song", song.rating, { a.onRate(it); rateDialog = false }, { rateDialog = false })
    renameTarget?.let { r ->
        TextInputDialog("Rename demo", "Name", r.title, "Rename", { a.onRenameRecording(r.id, it); renameTarget = null }, { renameTarget = null })
    }
    deleteTarget?.let { r ->
        ConfirmDialog(
            "Delete demo?", "“${r.title}” will be removed from this song.", "Delete",
            { a.onDeleteRecording(r.id); deleteTarget = null }, { deleteTarget = null }
        )
    }

    // Tap a word: write the chord that is played on it. The chord shows exactly above the first letter of the word.
    chordTarget?.let { (lineIndex, range) ->
        val line = lines.getOrNull(lineIndex) as? SongLine.Lyric
        if (line == null || range.last >= line.text.length) {
            chordTarget = null
        } else {
            val word = line.text.substring(range.first, range.last + 1)
            val here = line.chords.filter { it.offset in range }.map { Transposer.chord(it.name, shift) }
            val save: (String) -> Unit = { typed ->
                // what is typed is the shape that is played; the song keeps the sounding chord
                val names = typed.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { Transposer.chord(it, -shift) }
                val newLine = SongParser.serialize(SongParser.withChordsAt(line, range, names))
                a.onBody(SongParser.replaceLine(song.body, lineIndex, newLine))
                chordTarget = null
            }
            ChordDialog(
                word = word,
                current = here.joinToString(" "),
                suggestions = songChords.map { Transposer.chord(it, shift) },
                note = if (shift != 0) "Capo ${song.capo}: type the shape you play. It is saved as the sounding chord." else null,
                onSave = save,
                onRemove = if (here.isNotEmpty()) ({ save("") }) else null,
                onDismiss = { chordTarget = null }
            )
        }
    }

    // Switching between the Chords and Lyrics pages starts from the top.
    LaunchedEffect(lyricsView) { scroll.scrollTo(0) }

    // Auto scroll: smooth, speed in dp per second, pauses while the finger is on the page, stops at the end.
    val speed by rememberUpdatedState(settings.scrollSpeed)
    // with "BPM scroll" on, a fast song scrolls faster and a slow one slower (100 BPM = normal)
    val bpmFactor by rememberUpdatedState(if (settings.bpmScroll && song.bpm > 0) (song.bpm / 100f).coerceIn(0.6f, 1.6f) else 1f)
    val density = LocalDensity.current
    LaunchedEffect(settings.autoScroll) {
        if (!settings.autoScroll) return@LaunchedEffect
        kotlinx.coroutines.delay(1500)
        var last = withFrameNanos { it }
        var carry = 0f
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            if (scroll.isScrollInProgress) continue
            val dpPerSecond = (4f + (speed - 1) * 6.2f) * bpmFactor
            carry += with(density) { dpPerSecond.dp.toPx() } * dt
            val whole = carry.toInt()
            if (whole >= 1) {
                scroll.scrollBy(whole.toFloat())
                carry -= whole
            }
            if (scroll.maxValue > 0 && scroll.value >= scroll.maxValue) {
                a.onAutoScroll(false)
                break
            }
        }
    }

    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val chips: @Composable () -> Unit = {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChipPill("Aa", active = false, onClick = { readingDialog = true })
            ChipPill("Chords", active = !lyricsView, onClick = { a.onLyricsView(false) })
            ChipPill("Lyrics", active = lyricsView, onClick = { a.onLyricsView(true) })
            if (!lyricsView) {
                ChipPill(
                    if (song.capo == 0) "No capo" else if (song.capoAdjust) "Capo ${song.capo} · shapes" else "Capo ${song.capo}",
                    active = false, onClick = { capoDialog = true }
                )
                ChipPill("Tab", active = settings.showTabs && hasTabs, onClick = { a.onShowTabs(!settings.showTabs) })
            }
            ChipPill(key?.let { "Key $it" } ?: "Key", active = false, onClick = a.onKey)
            ChipPill(if (song.bpm > 0) "${song.bpm} BPM" else "Tempo", active = false, onClick = a.onBpm)
            com.songbook.app.ui.components.IfLinkedToScrapbook(song) { open -> ChipPill("Scrapbook", active = false, onClick = open) }   // [scrapbook hook 4]
        }
    }
    val infoRow: @Composable () -> Unit = {
        Row(
            Modifier.padding(horizontal = 24.dp).padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SquareArtwork(song.gradient, 60.dp, 18.dp, image = song.image)
            Column(Modifier.weight(1f)) {
                Text(song.title, style = sbStyle(22, FontWeight.Bold, c.tx), maxLines = 2)
                Text("${songType(song.typeName)} · ${album?.name ?: "No album"}", style = sbStyle(12, color = c.mu), modifier = Modifier.padding(top = 2.dp))
                Text("Edited ${formatLongDate(song.updatedAt)}", style = sbStyle(12, color = c.mu))
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BadgePill(song.badge, song.badgeColor)
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).clickable { rateDialog = true }.padding(vertical = 2.dp)) {
                        if (song.rating > 0f) StarRow(song.rating, starSize = 13.dp, gap = 2.dp, color = c.tx)
                        else Text("Rate", style = sbStyle(11, FontWeight.Medium, c.mu))
                    }
                }
            }
            HeartButton(song.favorite, a.onToggleFavorite)
        }
    }
    // Where the sections are in the text, which one you are in, and the header that folds away while you read
    val sectionYs = remember(song.id) { mutableStateMapOf<Int, Int>() }
    val sectionIdx = remember(lines) { lines.indices.filter { lines[it] is SongLine.Section } }
    val scope = rememberCoroutineScope()
    var currentSection by remember { mutableStateOf(-1) }
    var headerCollapsed by remember { mutableStateOf(false) }
    var peek by remember { mutableStateOf<String?>(null) }
    val instrument = Instrument.values().getOrElse(settings.anaInstrument) { Instrument.GUITAR }
    LaunchedEffect(scroll, sectionIdx) {
        val line = with(density) { 60.dp.toPx() }
        val up = with(density) { 140.dp.toPx() }
        val down = with(density) { 60.dp.toPx() }
        val minLength = with(density) { 300.dp.toPx() }
        snapshotFlow {
            val v = scroll.value
            var cur = -1
            for (i in sectionIdx) {
                val y = sectionYs[i] ?: continue
                if (y <= v + line) cur = i
            }
            Triple(cur, v, scroll.maxValue)
        }.collect { (cur, v, m) ->
            currentSection = cur
            // folds when you have read a bit and the song is long enough to still scroll after it; opens again near the top
            if (!headerCollapsed && v > up && m > minLength) headerCollapsed = true
            else if (headerCollapsed && v < down) headerCollapsed = false
        }
    }
    val onSectionY: (Int, Int) -> Unit = { i, y -> sectionYs[i] = y }
    val onChord: (String) -> Unit = { name -> if (instrument != Instrument.OFF) peek = name }
    val infoLine = listOfNotNull(
        key?.let { "Key $it" },
        if (song.capo > 0) "Capo ${song.capo}" + (if (song.capoAdjust) " · shapes" else "") else null,
        if (lyricsView) "Lyrics" else "Chords"
    ).joinToString(" · ")
    // the sections as chips: tap one to jump there, the one you are in is lit
    val sectionChips: @Composable () -> Unit = {
        if (sectionIdx.size >= 3) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sectionIdx.forEach { i ->
                    val label = (lines[i] as SongLine.Section).label
                    val on = i == currentSection
                    Box(
                        Modifier.height(30.dp).clip(RoundedCornerShape(15.dp)).background(if (on) c.ac.copy(alpha = 0.18f) else c.track)
                            .clickable {
                                val y = (sectionYs[i] ?: 0) - with(density) { 8.dp.toPx() }.toInt()
                                scope.launch { scroll.animateScrollTo(y.coerceAtLeast(0)) }
                            }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(label.take(14), style = sbStyle(12, FontWeight.Medium, if (on) c.ac else c.mu), maxLines = 1) }
                }
            }
        }
    }
    // tap a chord: how it is played, on the instrument of the chord analyzer (the shape you play when the capo is on)
    peek?.let { name ->
        val parsed = parseChordName(name)
        Dialog(onDismissRequest = { peek = null }) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(c.cd).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(name, style = sbStyle(34, FontWeight.Normal, c.tx, serif = true))
                Text(
                    instrument.label + if (song.capo > 0 && song.capoAdjust) " · the shape, capo ${song.capo}" else "",
                    style = sbStyle(13, color = c.mu), modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                )
                if (parsed != null) ChordShapeView(instrument, parsed.first, parsed.second, Modifier.fillMaxWidth(if (instrument == Instrument.PIANO) 0.9f else 0.6f))
                else Text("No shape for this chord", style = sbStyle(14, color = c.mu))
            }
        }
    }
    val onWord: (Int, IntRange) -> Unit = { lineIndex, range -> chordTarget = lineIndex to range }
    // the black player bar of the Coral page and of the full page
    val playerBar: @Composable () -> Unit = {
        val barShape = RoundedCornerShape(32.dp)
        Row(
            Modifier.fillMaxWidth().height(64.dp).shadow(10.dp, barShape).background(c.pill, barShape).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CoralBarItem("Auto scroll", { a.onAutoScroll(!settings.autoScroll) }) {
                StrokeIcon(if (settings.autoScroll) SbIcons.Pause else SbIcons.Play, c.onPill, size = 22.dp, filled = true)
            }
            CoralBarItem("Speed", { speedDialog = true }) { CoralBarValue("${settings.scrollSpeed}/10") }
            CoralBarItem("Size", { readingDialog = true }) { CoralBarValue("${settings.lyricsSize} pt") }
            CoralBarItem("Capo", { capoDialog = true }) { CoralBarValue(if (song.capo == 0) "–" else "${song.capo}", c.ac) }
            if (settings.showEditButton) CoralBarItem("Edit", a.onEdit) { StrokeIcon(SbIcons.Edit, c.onPill, size = 22.dp) }
        }
    }
    val card: @Composable ColumnScope.(Modifier) -> Unit = { m ->
        Box(m.fillMaxWidth().weight(1f).sbCard(28.dp).clip(RoundedCornerShape(28.dp))) {
            Column(Modifier.fillMaxSize()) {
            Box(Modifier.padding(end = 48.dp)) { sectionChips() }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(horizontal = 20.dp, vertical = 4.dp)) {
                if (lyricsView) PlainLyrics(lines, settings, c, onSectionY, currentSection)
                else Column(Modifier.horizontalScroll(rememberScrollState())) { SongBody(lines, settings, c, shift, tabCapo, onWord, onChord, onSectionY, currentSection) }
                if (song.comment.isNotBlank()) {
                    Column(
                        Modifier.padding(top = 18.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.track)
                            .clickable(onClick = a.onComment).padding(14.dp)
                    ) {
                        SectionTitle("Comment")
                        Text(song.comment, style = sbStyle(14, color = c.tx), modifier = Modifier.padding(top = 6.dp))
                    }
                }
                Column(Modifier.padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (recordings.isNotEmpty()) {
                        RecordingsBlock(recordings, player, a.onRecord, { renameTarget = it }, { deleteTarget = it }, onAnalyze = a.onAnalyzeRecording)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (song.comment.isBlank()) ChipPill("+ Add comment", active = false, inactiveBg = c.track, onClick = a.onComment)
                        if (recordings.isEmpty()) ChipPill("+ Record a demo", active = false, inactiveBg = c.track, onClick = a.onRecord)
                    }
                }
                Box(Modifier.height(24.dp))
            }
            }
            // bigger window: only the lyrics fill the screen
            Box(
                Modifier.align(Alignment.TopEnd).padding(10.dp).size(34.dp).clip(CircleShape).background(c.track)
                    .clickable { expanded = !expanded },
                contentAlignment = Alignment.Center
            ) { StrokeIcon(if (expanded) SbIcons.Collapse else SbIcons.Expand, c.mu, size = 18.dp) }
        }
    }

    if (expanded) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                // how far down the song you are
                Box(
                    Modifier.fillMaxWidth().height(3.dp).background(c.track).drawBehind {
                        val frac = if (scroll.maxValue > 0) scroll.value.toFloat() / scroll.maxValue else 0f
                        drawRect(c.ac, size = androidx.compose.ui.geometry.Size(size.width * frac.coerceIn(0f, 1f), size.height))
                    }
                )
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ToolButton(null, SbIcons.ChevronDown) { a.onClose() }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(song.title, style = sbStyle(17, FontWeight.Medium, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(infoLine, style = sbStyle(12, color = c.mu), maxLines = 1)
                    }
                    ToolButton(null, SbIcons.Collapse) { expanded = false }
                }
                sectionChips()
                // the text sits straight on the page; the section names are the same plain red as in the full screen editor
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(horizontal = 26.dp)) {
                    Box(Modifier.height(8.dp))
                    if (lyricsView) PlainLyrics(lines, settings, c, onSectionY, currentSection)
                    else Column(Modifier.horizontalScroll(rememberScrollState())) { SongBody(lines, settings, c, shift, tabCapo, onWord, onChord, onSectionY, currentSection) }
                    Box(Modifier.height(150.dp + navInset))
                }
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(150.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, c.bg)))
            )
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) { playerBar() }
        }
    } else when (style) {
        // ------------------------------------------------------------------ CORAL: round buttons, black player bar
        UiStyle.CORAL -> Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Box(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 16.dp)) {
                    CoralRoundButton(SbIcons.ChevronDown, "Close", a.onClose, Modifier.align(Alignment.CenterStart))
                    Text(
                        song.title, style = sbStyle(22, FontWeight.Medium, c.tx).copy(letterSpacing = (-0.01).em),
                        maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(horizontal = 64.dp)
                    )
                    CoralRoundButton(SbIcons.More, "More", a.onMenu, Modifier.align(Alignment.CenterEnd))
                }
                Text(
                    if (headerCollapsed) infoLine else "${songType(song.typeName)} · ${album?.name ?: "No album"}", style = sbStyle(14, color = c.mu), maxLines = 1,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(top = 2.dp)
                )
                // stage, stars, badge, key and tempo; folds away while you read
                AnimatedVisibility(visible = !headerCollapsed) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HeartButton(song.favorite, a.onToggleFavorite)
                    CoralInfoChip(Stage.name(song.stage), if (song.stage >= Stage.DONE) SbIcons.Check else null)
                    Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { rateDialog = true }.padding(vertical = 4.dp)) {
                        if (song.rating > 0f) StarRow(song.rating, starSize = 16.dp, gap = 2.dp, color = c.ac)
                        else Text("Rate", style = sbStyle(13, FontWeight.Medium, c.mu))
                    }
                    BadgePill(song.badge, song.badgeColor)
                    CoralInfoChip(key?.let { "Key $it" } ?: "Key", onClick = a.onKey)
                    CoralInfoChip(if (song.bpm > 0) "${song.bpm} BPM" else "Tempo", onClick = a.onBpm)
                    if (song.capo > 0) CoralInfoChip(if (song.capoAdjust) "Capo ${song.capo} · shapes" else "Capo ${song.capo}", onClick = { capoDialog = true })
                    com.songbook.app.ui.components.IfLinkedToScrapbook(song) { open -> CoralInfoChip("Scrapbook", onClick = open) }   // [scrapbook hook 4]
                }
                }
                // Chords, Lyrics, Capo, Tab in one rounded track (the chosen one is filled), Aa beside it
                Row(
                    Modifier.padding(horizontal = 16.dp).padding(top = 14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(28.dp)).background(c.track)
                            .horizontalScroll(rememberScrollState()).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        ChipPill("Chords", active = !lyricsView, inactiveBg = Color.Transparent, onClick = { a.onLyricsView(false) })
                        ChipPill("Lyrics", active = lyricsView, inactiveBg = Color.Transparent, onClick = { a.onLyricsView(true) })
                        if (!lyricsView) {
                            ChipPill(
                                if (song.capo == 0) "No capo" else "Capo ${song.capo}",
                                active = false, inactiveBg = Color.Transparent, onClick = { capoDialog = true }
                            )
                            ChipPill("Tab", active = settings.showTabs && hasTabs, inactiveBg = Color.Transparent, onClick = { a.onShowTabs(!settings.showTabs) })
                        }
                    }
                    Box(
                        Modifier.size(44.dp).background(c.track, CircleShape).clip(CircleShape).clickable { readingDialog = true },
                        contentAlignment = Alignment.Center
                    ) { Text("Aa", style = sbStyle(15, FontWeight.Medium, c.tx)) }
                }
                card(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp + navInset))
            }
            // the black player bar floats over the bottom of the page
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) { playerBar() }
        }

        // ------------------------------------------------------------------ GLASS: floating bar
        UiStyle.GLASS -> Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                GlassRoundButton(SbIcons.ChevronDown, "Close", a.onClose)
                Text("Now Reading", style = sbStyle(15, FontWeight.SemiBold, c.ac))
                GlassRoundButton(SbIcons.More, "More", a.onMenu)
            }
            infoRow()
            chips()
            card(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp))
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp).navigationBarsPadding().fillMaxWidth().height(60.dp)
                    .glassSurface(RoundedCornerShape(30.dp), strong = true).padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
            ) {
                BarItem(if (settings.autoScroll) SbIcons.Pause else SbIcons.Play, "Auto Scroll", settings.autoScroll) { a.onAutoScroll(!settings.autoScroll) }
                BarItem(null, "Speed", false, "${settings.scrollSpeed}/10") { speedDialog = true }
                BarItem(null, "Size", false, "${settings.lyricsSize} pt") { readingDialog = true }
                BarItem(null, "Capo", song.capo > 0, if (song.capo == 0) "–" else "${song.capo}") { capoDialog = true }
                if (settings.showEditButton) BarItem(SbIcons.Edit, "Edit", false) { a.onEdit() }
            }
        }

        // ------------------------------------------------------------------ OLD
        else -> {
            val bottomPad = if (settings.showEditButton) 70.dp + navInset else 16.dp + navInset
            Box(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        SbIconButton(SbIcons.ChevronDown, "Close", a.onClose, size = 24.dp)
                        Text("Now Reading", style = sbStyle(16, FontWeight.SemiBold, c.ac))
                        SbIconButton(SbIcons.More, "More", a.onMenu)
                    }
                    infoRow()
                    chips()
                    // Auto scroll: the switch turns it on; once on, the label opens the speed card.
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(top = 8.dp).height(36.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val on = settings.autoScroll
                        Row(
                            Modifier.clip(RoundedCornerShape(10.dp)).then(if (on) Modifier.clickable { speedDialog = true } else Modifier).padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Auto Scroll", style = sbStyle(13, FontWeight.Medium, if (on) c.ac else c.mu))
                            if (on) {
                                Text("· speed ${settings.scrollSpeed}", style = sbStyle(12, color = c.mu))
                                StrokeIcon(SbIcons.ChevronRight, c.ac, size = 16.dp)
                            }
                        }
                        SbSwitch(on) { a.onAutoScroll(it) }
                    }
                    card(Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = bottomPad))
                }
                if (settings.showEditButton) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).padding(horizontal = 75.dp).fillMaxWidth().height(64.dp + navInset)
                            .clip(DomeShape).background(c.ac).clickable(onClick = a.onEdit).padding(top = 16.dp),
                        contentAlignment = Alignment.TopCenter
                    ) { Text("Edit", style = sbStyle(16, FontWeight.SemiBold, Color.White)) }
                }
            }
        }
    }
}

/** Round button of the full screen reader: a short text or an icon. */
@Composable
private fun ToolButton(text: String?, icon: com.songbook.app.ui.components.IconSpec? = null, onClick: () -> Unit) {
    val c = Sb.colors
    val glass = Sb.style == UiStyle.GLASS
    Box(
        Modifier.size(48.dp).let { if (glass) it.glassSurface(CircleShape, strong = true) else it.background(c.cd, CircleShape) }
            .clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) StrokeIcon(icon, c.tx, size = 22.dp, filled = icon == SbIcons.Play || icon == SbIcons.Pause)
        else Text(text ?: "", style = sbStyle(16, FontWeight.Bold, c.tx))
    }
}

/** Small rounded label of the Coral reader header: stage, key, tempo. Tappable when [onClick] is given. */
@Composable
private fun CoralInfoChip(text: String, icon: com.songbook.app.ui.components.IconSpec? = null, onClick: (() -> Unit)? = null) {
    val c = Sb.colors
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(c.track)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(start = if (icon != null) 9.dp else 12.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        if (icon != null) StrokeIcon(icon, c.ct, size = 15.dp)
        Text(text, style = sbStyle(13, FontWeight.Medium, c.ct), maxLines = 1)
    }
}

/** One cell of the black player bar: an icon or a value on top, a small label under it. */
@Composable
private fun RowScope.CoralBarItem(label: String, onClick: () -> Unit, top: @Composable () -> Unit) {
    val c = Sb.colors
    Column(
        Modifier.weight(1f).height(64.dp).clip(RoundedCornerShape(26.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically)
    ) {
        top()
        Text(label, style = sbStyle(11, color = c.onPill.copy(alpha = 0.65f)), maxLines = 1)
    }
}

@Composable
private fun CoralBarValue(value: String, color: Color = Sb.colors.onPill) {
    Text(value, style = sbStyle(17, FontWeight.SemiBold, color), maxLines = 1)
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.BarItem(
    icon: com.songbook.app.ui.components.IconSpec?,
    label: String,
    on: Boolean,
    value: String? = null,
    onClick: () -> Unit
) {
    val c = Sb.colors
    val tint = if (on) c.ac else c.tx
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (icon != null) StrokeIcon(icon, tint, size = 22.dp, filled = on && label == "Auto Scroll")
        else Text(value ?: "", style = sbStyle(15, FontWeight.Bold, tint))
        Text(label, style = sbStyle(9, FontWeight.Medium, c.mu), maxLines = 1)
    }
}

// ---- section headings ----------------------------------------------------------------------

@Composable
private fun SectionHeading(label: String, style: Int, size: Int, first: Boolean, c: SbColors, dim: Boolean = false) {
    val text = when (style) {
        SectionStyle.LOWER -> label.lowercase()
        SectionStyle.AS_WRITTEN -> label
        else -> label.uppercase()
    }
    val tint = (if (c.style == UiStyle.CORAL) c.ct else c.ac).copy(alpha = if (dim) 0.55f else 1f)
    val textStyle = if (style == SectionStyle.UPPER) {
        sbStyle(size, FontWeight.SemiBold, tint).copy(letterSpacing = 0.14.em)
    } else {
        sbStyle(size, FontWeight.SemiBold, tint).copy(letterSpacing = 0.02.em)
    }
    Text(text, style = textStyle, modifier = Modifier.padding(top = if (first) 14.dp else 18.dp, bottom = 8.dp))
}

// ---- Chords page ---------------------------------------------------------------------------

@Composable
private fun SongBody(
    lines: List<SongLine>,
    settings: AppSettings,
    c: SbColors,
    shift: Int,
    tabCapo: Int,
    onWord: (Int, IntRange) -> Unit,
    onChord: (String) -> Unit,
    onSectionY: (Int, Int) -> Unit,
    currentSection: Int
) {
    var first = true
    lines.forEachIndexed { index, line ->
        when (line) {
            is SongLine.Section -> Box(Modifier.onGloballyPositioned { onSectionY(index, it.positionInParent().y.roundToInt()) }) {
                SectionHeading(line.label, settings.sectionStyle, settings.sectionSize, first, c, dim = currentSection >= 0 && index != currentSection)
            }
            is SongLine.Lyric -> ChordLyricLine(line, settings, c, shift, onChord) { range -> onWord(index, range) }
            is SongLine.Tab -> if (settings.showTabs) {
                Text(Transposer.tabLine(line.text, tabCapo), style = sbStyle(13, FontWeight.Medium, c.tx, mono = true), softWrap = false, modifier = Modifier.padding(bottom = 2.dp))
            }
            SongLine.Blank -> Box(Modifier.height(10.dp))
        }
        first = false
    }
}

/**
 * Lyric line with chords above the exact letter they belong to. The positions come from the chords as they
 * are written, so a capo never moves a chord to another word: only the names change. Tapping a word reports it.
 */
@Composable
private fun ChordLyricLine(line: SongLine.Lyric, settings: AppSettings, c: SbColors, shift: Int, onChord: (String) -> Unit, onTapWord: (IntRange) -> Unit) {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    // extra line height goes below the text, so the lyric sits right under its chords
    val tight = LineHeightStyle(alignment = LineHeightStyle.Alignment.Top, trim = LineHeightStyle.Trim.None)
    val lyricStyle = sbStyle(settings.lyricsSize, FontWeight.Medium, c.tx)
        .copy(lineHeight = (settings.lyricsSize * settings.lineSpacing).sp, lineHeightStyle = tight)
    val chordStyle = sbStyle(settings.chordSize, FontWeight.Medium, if (c.style == UiStyle.CORAL) c.ct else c.ac, mono = true)
        .copy(lineHeight = (settings.chordSize * 1.2f).sp, lineHeightStyle = tight)
    val showChords = settings.showChords && line.chords.isNotEmpty()
    var layoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }

    if (!showChords && line.text.isBlank()) return

    Column(Modifier.padding(bottom = 8.dp)) {
        if (showChords) {
            val placed = remember(line, settings.lyricsSize, settings.chordSize, shift) {
                val layout = measurer.measure(AnnotatedString(line.text), lyricStyle, softWrap = false, maxLines = 1)
                val gap = with(density) { 8.dp.toPx() }
                var minX = 0f
                line.chords.map { m ->
                    val x = layout.getHorizontalPosition(m.offset.coerceIn(0, line.text.length), true)
                    // room is measured with the chord as written, the capo version is drawn at the same spot
                    val w = measurer.measure(AnnotatedString(m.name), chordStyle).size.width
                    val px = maxOf(x, minX)
                    minX = px + w + gap
                    Transposer.chord(m.name, shift) to px
                }
            }
            // "Chord distance" setting: positive pushes the chords away from the lyric, negative pulls them closer.
            val boxHeight = (settings.chordSize * 1.2f + 2f + settings.chordOffset).coerceAtLeast(settings.chordSize * 0.9f)
            Box(Modifier.height(boxHeight.dp)) {
                placed.forEach { (name, px) ->
                    Text(name, style = chordStyle, softWrap = false, maxLines = 1, modifier = Modifier.offset { IntOffset(px.roundToInt(), 0) }.clickable { onChord(name) })
                }
            }
        }
        if (line.text.isNotBlank()) {
            Text(
                line.text, style = lyricStyle, softWrap = false, maxLines = 1,
                onTextLayout = { layoutResult = it },
                modifier = Modifier.pointerInput(line.text) {
                    detectTapGestures { pos ->
                        val lr = layoutResult ?: return@detectTapGestures
                        SongParser.wordAt(line.text, lr.getOffsetForPosition(pos))?.let(onTapWord)
                    }
                }
            )
        } else Box(Modifier.height(4.dp))
    }
}

// ---- Lyrics page (plain text: no chords, no tabs, long lines wrap) -------------------------

@Composable
private fun PlainLyrics(lines: List<SongLine>, settings: AppSettings, c: SbColors, onSectionY: (Int, Int) -> Unit, currentSection: Int) {
    val style = sbStyle(settings.lyricsSize, FontWeight.Medium, c.tx).copy(lineHeight = (settings.lyricsSize * settings.lineSpacing).sp)
    var first = true
    var lastWasBlank = true
    lines.forEachIndexed { index, line ->
        when (line) {
            is SongLine.Section -> {
                Box(Modifier.onGloballyPositioned { onSectionY(index, it.positionInParent().y.roundToInt()) }) {
                    SectionHeading(line.label, settings.sectionStyle, settings.sectionSize, first, c, dim = currentSection >= 0 && index != currentSection)
                }
                lastWasBlank = false
                first = false
            }
            is SongLine.Lyric -> {
                val text = line.text.trim()
                if (text.isNotEmpty()) {
                    Text(text, style = style, modifier = Modifier.padding(bottom = 4.dp))
                    lastWasBlank = false
                    first = false
                }
            }
            is SongLine.Tab -> Unit
            SongLine.Blank -> if (!lastWasBlank) {
                Box(Modifier.height(12.dp))
                lastWasBlank = true
            }
        }
    }
}

private val PeekRx = Regex("""^([A-G])([#b]?)([^/]*)""")

/** "F#m7" -> (6, "m7"): the root note and the type of [ChordTypes], for drawing the chord. */
private fun parseChordName(name: String): Pair<Int, String>? {
    val m = PeekRx.find(name.trim()) ?: return null
    val base = when (m.groupValues[1]) { "C" -> 0; "D" -> 2; "E" -> 4; "F" -> 5; "G" -> 7; "A" -> 9; else -> 11 }
    val accidental = when (m.groupValues[2]) { "#" -> 1; "b" -> -1; else -> 0 }
    return Math.floorMod(base + accidental, 12) to ChordTypes.parse(m.groupValues[3])
}
