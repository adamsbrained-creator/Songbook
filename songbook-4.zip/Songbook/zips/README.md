# zips

Put a Songbook project zip here (or in the main folder): GitHub ▸ **Add file ▸ Upload files**, commit to `main`.
The workflow **Build Songbook (signed APK)** unpacks the newest one, builds and signs it.
Download the APK from the run's Artifacts. See SIGNING.md.
