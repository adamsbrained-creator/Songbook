# Songbook 3.6 - Glassy home layout for Coral (not yet compiled)

## 3.6 changes
- New option Settings > Look > Home Layout (Coral only): Classic (default, unchanged) or Glassy. Glassy gives the Coral look the Glass look's main page: a big greeting with the tagline, the search box always shown, the pinned albums and recent songs as horizontal rows of plain tiles, then the songs. The Coral top bar, bottom bar and menu stay. Stored as `coralHome` (0 or 1); `Blocks.home(Glass)` supplies the default block order, so "Customize this page" works for it too (`CoralLibrary` in `LibraryScreen.kt`)
- Version 3.6

# Songbook 3.5 - Settings pages and empty states

## 3.5 changes (Coral look only)
- Settings is a short list of groups (Look, Library, Profile, Appearance, Layout, Sorting, Pages, Reading, Song Display, Data, About), each opening as its own page; Back or the arrow returns to the list (`SettingsGroup` + `SettingsNav` in `Common.kt`, state in `SettingsScreen.kt`)
- An empty library shows Paperback's empty card with a "New song" button (`CoralEmptyCard`)
- The Workflow page has the same header as the other pages, with "+ Idea" next to its title
- Version 3.5

# Songbook 3.4 - Paperback navigation and gestures

## 3.4 changes (Coral look only)
- Navigation like Paperback: the header's menu button opens a card of pages above a round close button; "More" opens a sheet with this page's actions and every page (`components/NavMenu.kt`, wired in `SongbookRoot.kt`)
- The plus button stays on Songs and Albums; "New song" is also the first row of the menu
- Gestures from Paperback 34 (`components/SwipeHost.kt`): swipe right to go back, swipe left or right on a main page to move between Songs, Albums, Favorites and Settings. Off in the reader and the editors. Two switches in Settings: "Swipe to Go Back", "Swipe Between Pages"
- Long press on a song row opens its menu
- Selected chips use the accent color; search is a big filled pill; "Sort: ..." and "View: ..." pills replace the two icon buttons; Albums and Favorites get the count pill
- Album tiles are a cover with the name under it, no card; album, group and reader pages use the wordmark with a small label under it
- Version 3.4

# Songbook 3.3 - closer to Paperback

## 3.3 changes (Coral look only)
- Paperback's palette: white page with soft gray (#F3F3F3) cards; black page and #161616 cards in dark (`theme/Theme.kt`)
- Bottom bar like Paperback's, with a soft pill on the current page, the plus button above it (`CoralBottomBar` in `Chrome.kt`)
- Header: lighter wordmark, the page name as a 16 sp label with a pill on the right ("24 songs" on the main page), rounded menu with icons
- Settings rows: an icon tile, the label, the value and a chevron, with the line starting under the label (`SettingsRow` in `Common.kt`)
- Main page: the pinned albums are a plain two-column grid, cover with the name and song count under it, no card (`albumsGrid` in `LibraryScreen.kt`)
- Version 3.3

# Songbook 3.2 - Paperback polish

## Build
One workflow now, like Eon: key in the repo (`app/debug.keystore`), builds loose files or a zip, APK in the run's Artifacts. See SIGNING.md.

## 3.2 changes (Coral look only; Old and Glass are untouched)
- Dialogs copy Paperback's PbDialog: big rounded card, serif title, Cancel pill + solid confirm pill (`CoralDialog` in `Dialogs.kt`)
- Text fields are filled and outline-free (`SbField` in `Fields.kt`, drop-in for OutlinedTextField)
- Segmented control is a soft track with a raised white thumb; switch has a lifted thumb on a softer off track
- Cards are flat with no hairline; settings dividers stop short of the card edges; section labels use Paperback's spacing
- Top bar: lighter wordmark, page name is a small label under it, 22dp icons

First `./gradlew assembleDebug` may still show small errors (nothing could be compiled here). Likeliest spots: `Dialogs.kt` imports, `Fields.kt`.

# Songbook 3.1 - new header and icon

The Coral look replaces the old "New" look everywhere (theme, chrome, all screens, reader, settings, statistics, icon).
Old stored "New" choices open as Coral (same stored number).

Written without a compiler in reach, so the first `./gradlew assembleDebug` may show a few small errors
(imports, parameter names). Fix those first. Last version that built: Songbook-2.5.zip.

## Try after it builds
- Settings ▸ Look ▸ Interface: Old / Glass / Coral
- Reader: key, BPM, comment and demos (tap the chips, or the song menu); Settings ▸ Song Display ▸ BPM Auto Scroll
- Coral menu (top-right "more") ▸ Stats; Settings ▸ Library ▸ Statistics
- Record a demo (asks for the microphone), then Settings ▸ backup and restore to check the audio comes along

## 3.1 changes
- Coral top bar now follows the paperback app: menu button (left, opens Songs/Albums/Favorites/Statistics/Settings + page actions), centered bold "songbook", search button (right), page name under the bar.
- Round buttons no longer have an outline. Statistics keeps a back arrow and has no search button.
- New coral icon (icons/coral): dark tile, coral book, white note. In-app copy in AppIcon.kt redrawn to match.
