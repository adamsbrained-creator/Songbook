# Icon variants

`metronome/` is the icon the project uses now (pink-red tile, white metronome, pink pendulum). It holds the three
launcher drawables (`ic_launcher_background.xml`, `ic_launcher_foreground.xml`, `ic_launcher_monochrome.xml`),
a 512 px PNG of the full tile and a PNG preview with the launcher's round mask. Those three files are also in
`app/src/main/res/drawable/`. The in-app copy (Settings and the intro) is `ui/components/AppIcon.kt`.

The metronome is drawn at half the size of the original picture so it fits the launcher's safe zone. To change
its size, edit `android:scaleX` / `android:scaleY` (0.5) on the outer `<group>` in the foreground and monochrome
files (0.6 is a little bigger, 0.4 smaller). The in-app copy uses `scale(0.75f, ...)` in `AppIcon.kt`.

`coral/`, `pink/` and `purple/` are the older icons (book with a note, guitar pick). To go back to one of them,
copy its three `.xml` files over the ones in `app/src/main/res/drawable/` and restore its drawing in `AppIcon.kt`.
