# Building and signing Songbook on GitHub

Same setup as the Eon launcher: the signing key is a file in the repo, so there are no secrets to set up.

* Key: `app/debug.keystore` (password `android`, alias `androiddebugkey`), set in `app/build.gradle.kts`.
  Every build is signed with it, so a new build installs over the previous one and your songs stay.
  The key is public on purpose: this app is for personal sideloading only.
* Workflow: `.github/workflows/build.yml`. It runs on every push to `main` and can be run by hand.
* Version code = 1000 + number of commits, so Android never sees a downgrade.

## Build from loose files
Upload every file of the project to the repo (keep the structure). A build starts on every push.

## Build from a zip (no unpacking)
1. Put `.github/workflows/build.yml` in the repo as a real file (GitHub does not unpack zips to find workflows):
   Add file ▸ Create new file, name it `.github/workflows/build.yml`, paste the contents.
2. Add file ▸ Upload files ▸ drop the project zip (for example `songbook-2.zip`) in the main folder or in `zips/`. Commit.
3. The workflow unpacks the newest zip (by version number), builds and signs it.
   If loose project files are also in the repo, they win; to force a zip use Actions ▸ Run workflow and type its name.

## Install
Actions ▸ the finished run ▸ **Artifacts ▸ songbook-apk** (a zip), unzip it, install the `.apk` over the old app.
The run's summary shows the certificate fingerprint: it must be the same on every build.
No GitHub release is created.

## Coming from builds signed with another key
Android refuses an update signed with a different key. If your installed Songbook came from the old
release-key workflow (the one that used GitHub secrets), do this once: Settings ▸ Backup ▸ save the zip,
uninstall, install the new APK, Settings ▸ Restore. Builds up to 2.5 used this same `debug.keystore`
and update in place.
