package com.songbook.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [AlbumEntity::class, SongEntity::class, GroupEntity::class, RecordingEntity::class],
    version = 5,
    exportSchema = false
)
abstract class SongbookDatabase : RoomDatabase() {
    abstract fun dao(): SongbookDao

    companion object {
        /** 1.0 -> 1.5: images, badges, workflow stage/note, album groups. Keeps all existing data. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE songs ADD COLUMN image TEXT")
                db.execSQL("ALTER TABLE songs ADD COLUMN badge TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE songs ADD COLUMN badgeColor INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN stage INTEGER NOT NULL DEFAULT 4")
                db.execSQL("ALTER TABLE songs ADD COLUMN note TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE albums ADD COLUMN image TEXT")
                db.execSQL("ALTER TABLE albums ADD COLUMN badge TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE albums ADD COLUMN badgeColor INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE albums ADD COLUMN groupId INTEGER")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `album_groups` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`gradient` INTEGER NOT NULL, " +
                        "`image` TEXT, " +
                        "`badge` TEXT NOT NULL, " +
                        "`badgeColor` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
            }
        }

        /** 1.5 -> 2.0: ratings, custom types, songwriting desk, capo-adjusted chords. Keeps all existing data. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE songs ADD COLUMN rating REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN typeName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE songs ADD COLUMN idea TEXT NOT NULL DEFAULT ''")
                // existing songs keep showing their chords exactly as typed
                db.execSQL("ALTER TABLE songs ADD COLUMN capoAdjust INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE albums ADD COLUMN rating REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE albums ADD COLUMN typeName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE album_groups ADD COLUMN rating REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE album_groups ADD COLUMN typeName TEXT NOT NULL DEFAULT ''")
            }
        }

        /** 2.0 -> 2.5: album covers for songs, album sides, manual order. Keeps all existing data. */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE songs ADD COLUMN coverManual INTEGER NOT NULL DEFAULT 0")
                // a song that already has its own picture keeps it until you pick "Use album cover"
                db.execSQL("UPDATE songs SET coverManual = 1 WHERE image IS NOT NULL")
                db.execSQL("ALTER TABLE songs ADD COLUMN side INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN trackNo INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN libPos INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE albums ADD COLUMN sides TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE albums ADD COLUMN position INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE album_groups ADD COLUMN position INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** 2.5 -> 3.0: key, BPM, comment, play statistics and demo recordings. Keeps all existing data. */
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE songs ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE songs SET createdAt = updatedAt")
                db.execSQL("ALTER TABLE songs ADD COLUMN opens INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN lastOpened INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN readSeconds INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN songKey TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE songs ADD COLUMN bpm INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE songs ADD COLUMN comment TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `recordings` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`songId` INTEGER NOT NULL, " +
                        "`file` TEXT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`durationMs` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`songId`) REFERENCES `songs`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_songId` ON `recordings` (`songId`)")
            }
        }

        fun build(context: Context): SongbookDatabase =
            Room.databaseBuilder(context.applicationContext, SongbookDatabase::class.java, "songbook.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .build()
    }
}
