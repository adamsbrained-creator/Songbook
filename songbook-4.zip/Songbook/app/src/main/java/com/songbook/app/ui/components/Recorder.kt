package com.songbook.app.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.songbook.app.data.AudioStore
import com.songbook.app.data.RecordingEntity
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.delay
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** 83000 -> "1:23" */
fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Records from the microphone into an .m4a file in the app's audio folder. */
class AudioRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()

    fun start(): Boolean {
        val f = AudioStore.newFile(context)
        return try {
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            startedAt = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            runCatching { recorder?.release() }
            recorder = null
            f.delete()
            false
        }
    }

    /** Stops the recording. Returns the finished file, or null when nothing usable was recorded. */
    fun stop(): File? {
        val r = recorder ?: return file
        recorder = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: RuntimeException) {
            runCatching { r.release() }
            file?.delete()
            file = null
            null
        }
    }

    /** Throws the take away (stops it first if it is still running). */
    fun cancel() {
        recorder?.let { r ->
            runCatching { r.stop() }
            runCatching { r.release() }
        }
        recorder = null
        file?.delete()
        file = null
    }

    /** The recorded file is kept; the recorder forgets it so [cancel] does not delete it. */
    fun keep(): File? = file.also { file = null }

    fun elapsedMs(): Long = if (recorder != null) System.currentTimeMillis() - startedAt else 0L

    /** Loudness 0..32767 while recording. */
    fun level(): Int = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)

    val isRecording: Boolean get() = recorder != null
}

/** Plays one recording at a time. */
class SongPlayer {
    private var mp: MediaPlayer? = null
    var loadedId by mutableLongStateOf(-1L)
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableIntStateOf(0)
        private set
    var duration by mutableIntStateOf(0)
        private set

    fun toggle(id: Long, file: File) {
        val current = mp
        if (loadedId == id && current != null) {
            if (current.isPlaying) {
                current.pause()
                playing = false
            } else {
                current.start()
                playing = true
            }
            return
        }
        release()
        try {
            val m = MediaPlayer()
            m.setDataSource(file.absolutePath)
            m.prepare()
            m.setOnCompletionListener {
                playing = false
                position = 0
                runCatching { mp?.seekTo(0) }
            }
            duration = m.duration
            position = 0
            m.start()
            mp = m
            loadedId = id
            playing = true
        } catch (e: Exception) {
            release()
        }
    }

    fun seek(ms: Int) {
        mp?.seekTo(ms)
        position = ms
    }

    fun tick() {
        mp?.let { if (it.isPlaying) position = it.currentPosition }
    }

    fun release() {
        runCatching { mp?.release() }
        mp = null
        loadedId = -1L
        playing = false
        position = 0
        duration = 0
    }
}

@Composable
fun rememberSongPlayer(): SongPlayer {
    val player = remember { SongPlayer() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(player.playing) {
        while (player.playing) {
            player.tick()
            delay(150)
        }
    }
    return player
}

/**
 * "Record a demo": Record, Stop, then listen and Save, Record again or Discard. Asks for the microphone
 * the first time. [onSaved] gets the finished file and its length.
 */
@Composable
fun RecorderDialog(onSaved: (File, Long) -> Unit, onDismiss: () -> Unit) {
    val c = Sb.colors
    val context = LocalContext.current
    val recorder = remember { AudioRecorder(context) }
    val player = rememberSongPlayer()
    var phase by remember { mutableIntStateOf(0) }          // 0 ready, 1 recording, 2 listen
    var elapsed by remember { mutableLongStateOf(0L) }
    var level by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    var take by remember { mutableStateOf<File?>(null) }
    var takeMs by remember { mutableLongStateOf(0L) }

    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    fun begin() {
        failed = false
        if (recorder.start()) {
            phase = 1
        } else failed = true
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else denied = true
    }
    fun startRecording() {
        denied = false
        val has = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (has) begin() else permission.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun stopRecording() {
        val f = recorder.stop()
        if (f == null) {
            failed = true
            phase = 0
        } else {
            take = f
            takeMs = AudioStore.durationMs(f).takeIf { it > 0 } ?: elapsed
            phase = 2
        }
    }

    LaunchedEffect(phase) {
        while (phase == 1) {
            elapsed = recorder.elapsedMs()
            level = recorder.level()
            if (elapsed >= 20 * 60 * 1000L) { stopRecording(); break }
            delay(100)
        }
    }

    val confirm: String? = if (phase == 2) "Save" else null
    SbDialog("Record a demo", onDismiss, confirm, {
        val f = recorder.keep()
        if (f != null) onSaved(f, takeMs)
    }, dismissText = if (phase == 2) "Discard" else "Close") {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                when (phase) {
                    1 -> formatDuration(elapsed)
                    2 -> formatDuration(takeMs)
                    else -> "0:00"
                },
                style = sbStyle(36, FontWeight.Bold, if (phase == 1) c.ct else c.tx)
            )
            // big round button: record / stop / play
            val pulse = if (phase == 1) 1f + (level / 32768f).coerceIn(0f, 1f) * 0.45f else 1f
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                if (phase == 1) Box(Modifier.size(84.dp).scale(pulse).background(c.ac.copy(alpha = 0.22f), CircleShape))
                Box(
                    Modifier.size(84.dp).clip(CircleShape).background(c.ac).clickable {
                        when (phase) {
                            0 -> startRecording()
                            1 -> stopRecording()
                            else -> take?.let { player.toggle(1L, it) }
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    when (phase) {
                        1 -> Box(Modifier.size(28.dp).background(c.onAc, RoundedCornerShape(6.dp)))
                        2 -> StrokeIcon(if (player.playing) SbIcons.Pause else SbIcons.Play, c.onAc, size = 36.dp, filled = true)
                        else -> Box(Modifier.size(32.dp).background(c.onAc, CircleShape))
                    }
                }
            }
            Text(
                when {
                    denied -> "The microphone is switched off for Songbook. Allow it in your phone's Settings ▸ Apps ▸ Songbook ▸ Permissions, then try again."
                    failed -> "The recording could not be started. Is another app using the microphone?"
                    phase == 0 -> "Tap the round button to start. Play your song, then tap again to stop."
                    phase == 1 -> "Recording… tap to stop."
                    else -> "Tap to listen. Save keeps it on the song page."
                },
                style = sbStyle(12, color = if (denied || failed) c.ct else c.mu), textAlign = TextAlign.Center
            )
            if (phase == 2) {
                ChipPill("Record again", active = false, inactiveBg = c.track, onClick = {
                    player.release()
                    recorder.cancel()
                    take = null
                    phase = 0
                    startRecording()
                })
            }
        }
    }
}

/** The demos of a song, shown under the lyrics: play, pause, seek, rename and delete, and record another. */
@Composable
fun RecordingsBlock(
    recordings: List<RecordingEntity>,
    player: SongPlayer,
    onRecord: () -> Unit,
    onRename: (RecordingEntity) -> Unit,
    onDelete: (RecordingEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Sb.colors
    val context = LocalContext.current
    val dateFmt = remember { DateTimeFormatter.ofPattern("MMM d") }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle(if (recordings.size == 1) "Demo" else "Demos")
        recordings.forEach { r ->
            var menu by remember { mutableStateOf(false) }
            val active = player.loadedId == r.id
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.track).padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c.ac).clickable { player.toggle(r.id, AudioStore.file(context, r.file)) },
                        contentAlignment = Alignment.Center
                    ) { StrokeIcon(if (active && player.playing) SbIcons.Pause else SbIcons.Play, c.onAc, size = 20.dp, filled = true) }
                    Column(Modifier.weight(1f)) {
                        Text(r.title, style = sbStyle(14, FontWeight.SemiBold, c.tx), maxLines = 1)
                        Text(
                            (if (active) formatDuration(player.position.toLong()) + " / " else "") + formatDuration(r.durationMs) + " · " +
                                Instant.ofEpochMilli(r.createdAt).atZone(ZoneId.systemDefault()).format(dateFmt),
                            style = sbStyle(12, color = c.mu)
                        )
                    }
                    Box {
                        SbIconButton(SbIcons.More, "More", { menu = true }, tint = c.mu, size = 20.dp)
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, modifier = Modifier.background(c.sheet)) {
                            DropdownMenuItem(text = { Text("Rename", style = sbStyle(14, color = c.tx)) }, onClick = { menu = false; onRename(r) })
                            DropdownMenuItem(text = { Text("Delete", style = sbStyle(14, color = c.ct)) }, onClick = { menu = false; onDelete(r) })
                        }
                    }
                }
                if (active && player.duration > 0) {
                    Slider(
                        value = player.position.toFloat().coerceIn(0f, player.duration.toFloat()),
                        onValueChange = { player.seek(it.toInt()) },
                        valueRange = 0f..player.duration.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = c.ac, activeTrackColor = c.ac, inactiveTrackColor = c.ln),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }
        }
        ChipPill("+ Record another", active = false, inactiveBg = c.track, onClick = onRecord)
    }
}
