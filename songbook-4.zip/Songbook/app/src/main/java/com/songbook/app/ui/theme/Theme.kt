package com.songbook.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.songbook.app.R
import com.songbook.app.data.UiStyle

/** Values copied from the mockups: --bg, --tx, --mu, --ac, --cd, --ln, plus a few extras for the new looks. */
@Immutable
class SbColors(
    val bg: Color,
    val tx: Color,
    val mu: Color,
    val ac: Color,
    val cd: Color,
    val ln: Color,
    val isDark: Boolean,
    /** Opaque surface for dialogs and sheets (the glass look keeps [cd] for solid fallbacks only). */
    val sheet: Color = cd,
    /** Track behind segmented controls and inset fields. */
    val track: Color = bg,
    /** [UiStyle.OLD], [UiStyle.CORAL] or [UiStyle.GLASS]. */
    val style: Int = UiStyle.OLD,
    /** Background of the selected chip. The accent in Old and Glass, black (white in dark mode) in Coral. */
    val pill: Color = ac,
    /** Text and icons on the selected chip. */
    val onPill: Color = Color.White,
    /** Text and icons on the accent color: white, or dark when the accent is light (Coral). */
    val onAc: Color = Color.White,
    /** Accent used for small text: stars, chords, section labels. A deeper coral on light backgrounds. */
    val ct: Color = ac
)

/** The Coral look's own first accent color. */
val CoralAccent = Color(0xFFF46C4E)
private val CoralText = Color(0xFFB8391F)

val AccentLight = listOf(Color(0xFFE5173F), Color(0xFF3A63B8), Color(0xFFC2610C))
val AccentDark = listOf(Color(0xFFFF3B62), Color(0xFF6C93F0), Color(0xFFE8812A))

/**
 * Accent for the three presets (index 0..2) or the user's own RGB color (index 3). Custom colors are
 * lifted a little in dark mode and darkened when they are so bright that white text would be unreadable.
 */
fun accentColor(dark: Boolean, accent: Int, custom: Int, style: Int = UiStyle.OLD): Color {
    // in the Coral look the first preset is coral itself
    if (style == UiStyle.CORAL && accent == 0) return CoralAccent
    if (accent in 0..2) return if (dark) AccentDark[accent] else AccentLight[accent]
    var c = Color(custom).copy(alpha = 1f)
    if (dark) c = lerp(c, Color.White, 0.10f)
    repeat(6) { if (c.luminance() > 0.5f) c = lerp(c, Color.Black, 0.12f) }
    return c
}

fun sbColors(dark: Boolean, accent: Int, custom: Int = 0, style: Int = UiStyle.OLD): SbColors {
    val ac = accentColor(dark, accent, custom, style)
    return when (style) {
        UiStyle.CORAL -> {
            val onAc = if (ac.luminance() > 0.28f) Color(0xFF111111) else Color.White
            if (dark) {
                // Paperback's dark tokens: black page, #161616 cards, #1C1C1C menus and dialogs
                SbColors(
                    bg = Color(0xFF000000), tx = Color(0xFFF5F5F5), mu = Color(0xFF9A9A9A), ac = ac,
                    cd = Color(0xFF161616), ln = Color(0xFF2A2A2A), isDark = true,
                    sheet = Color(0xFF1C1C1C), track = Color(0xFF0B0B0B), style = style,
                    pill = Color(0xFFF5F5F5), onPill = Color(0xFF000000), onAc = onAc, ct = ac
                )
            } else {
                // Paperback's light tokens: a white page with soft gray (#F3F3F3) cards
                SbColors(
                    bg = Color.White, tx = Color(0xFF111111), mu = Color(0xFF6B6B6B), ac = ac,
                    cd = Color(0xFFF3F3F3), ln = Color(0xFFE0E0E0), isDark = false,
                    sheet = Color.White, track = Color(0xFFE7E7E7), style = style,
                    pill = Color(0xFF111111), onPill = Color.White, onAc = onAc,
                    ct = if (accent == 0) CoralText else lerp(ac, Color.Black, 0.28f)
                )
            }
        }
        UiStyle.GLASS -> if (dark) {
            SbColors(
                bg = Color(0xFF0A0B0F), tx = Color.White, mu = Color(0xFF9A9EAB), ac = ac,
                cd = Color(0xFF1B1D25), ln = Color(0x29FFFFFF), isDark = true,
                sheet = Color(0xF21E2028), track = Color(0x1AFFFFFF), style = style
            )
        } else {
            SbColors(
                bg = Color(0xFFF2F3F7), tx = Color(0xFF111114), mu = Color(0xFF7D818D), ac = ac,
                cd = Color.White, ln = Color(0x14000000), isDark = false,
                sheet = Color(0xF7FFFFFF), track = Color(0x0F000000), style = style
            )
        }
        else -> if (dark) {
            SbColors(
                bg = Color(0xFF0B0B0D), tx = Color.White, mu = Color(0xFF9A9AA2), ac = ac,
                cd = Color(0xFF1C1C1F), ln = Color(0xFF2A2A2E), isDark = true, style = style
            )
        } else {
            SbColors(
                bg = Color(0xFFF5F5F7), tx = Color(0xFF111114), mu = Color(0xFF6B6B72), ac = ac,
                cd = Color.White, ln = Color(0xFFE8E8ED), isDark = false, style = style
            )
        }
    }
}

val LocalSb = staticCompositionLocalOf { sbColors(false, 0) }

object Sb {
    val colors: SbColors
        @Composable get() = LocalSb.current

    /** [UiStyle.OLD], [UiStyle.CORAL] or [UiStyle.GLASS] */
    val style: Int
        @Composable get() = LocalSb.current.style
}

@Composable
fun SongbookTheme(dark: Boolean, accent: Int, accentCustom: Int, style: Int, content: @Composable () -> Unit) {
    val c = remember(dark, accent, accentCustom, style) { sbColors(dark, accent, accentCustom, style) }
    val scheme = if (dark) {
        darkColorScheme(primary = c.ac, background = c.bg, surface = c.sheet, onSurface = c.tx, onBackground = c.tx)
    } else {
        lightColorScheme(primary = c.ac, background = c.bg, surface = c.sheet, onSurface = c.tx, onBackground = c.tx)
    }
    // text styles are built outside of composition (sbStyle), so the fonts of the look are kept here;
    // this runs before any child of the theme is composed
    SbFonts.sans = if (style == UiStyle.CORAL) Outfit else Poppins
    SbFonts.serif = if (style == UiStyle.CORAL) CoralSerif else null
    CompositionLocalProvider(LocalSb provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

// ---- typography ----------------------------------------------------------------------------

/**
 * Poppins is bundled in res/font. Only Regular, Medium and Bold are included, so the mockup's
 * SemiBold (600) maps to the Bold file. Drop poppins_semibold.ttf into res/font and point the
 * SemiBold line at it for an exact match.
 */
val Poppins = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold)
)

/**
 * Outfit (Coral look): Regular and Bold are bundled, so Medium uses the Regular file and SemiBold the Bold file.
 * The serif is Crimson Pro, a close cousin of the serif in the Coral mockup.
 */
val Outfit = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_regular, FontWeight.Medium),
    Font(R.font.outfit_bold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

val CoralSerif = FontFamily(
    Font(R.font.crimsonpro_regular, FontWeight.Normal),
    Font(R.font.crimsonpro_regular, FontWeight.Medium),
    Font(R.font.crimsonpro_bold, FontWeight.SemiBold),
    Font(R.font.crimsonpro_bold, FontWeight.Bold)
)

/** The fonts of the look that is on screen. */
object SbFonts {
    var sans: FontFamily = Poppins
    var serif: FontFamily? = null
}

/**
 * The text style used all over the app. [serif] asks for the display serif, which only exists in the Coral
 * look (titles, big numbers, lyrics); everywhere else it is ignored and the normal font is used.
 */
fun sbStyle(
    size: Int,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    mono: Boolean = false,
    serif: Boolean = false
): TextStyle {
    val display = if (serif && !mono) SbFonts.serif else null
    return TextStyle(
        fontFamily = if (mono) FontFamily.Monospace else display ?: SbFonts.sans,
        // a serif looks smaller than a sans at the same size
        fontSize = if (display != null) (size * 1.14f).sp else size.sp,
        fontWeight = weight,
        color = color
    )
}

// ---- artwork gradients (135deg, from the mockup) -------------------------------------------

val SongGradients: List<List<Color>> = listOf(
    listOf(Color(0xFFE5173F), Color(0xFFFF7A9A)), // red
    listOf(Color(0xFF0F8BA8), Color(0xFFF0668A)), // teal -> pink
    listOf(Color(0xFF23323F), Color(0xFF9A8CE0)), // navy -> violet
    listOf(Color(0xFFC2610C), Color(0xFF3FA66B))  // orange -> green
)

fun gradientBrush(index: Int): Brush {
    val n = SongGradients.size
    return Brush.linearGradient(SongGradients[((index % n) + n) % n])
}
