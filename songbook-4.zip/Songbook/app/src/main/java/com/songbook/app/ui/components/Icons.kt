package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Stroke icons drawn on a 24x24 grid, 1.8 stroke, round caps, like the mockup's SVGs. */
class IconSpec(
    val paths: List<String> = emptyList(),
    /** x, y, radius */
    val circles: List<Triple<Float, Float, Float>> = emptyList()
)

object SbIcons {
    val Search = IconSpec(listOf("M16 16l4 4"), listOf(Triple(11f, 11f, 6.5f)))
    val Heart = IconSpec(listOf("M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"))
    val More = IconSpec(circles = listOf(Triple(12f, 5f, 1f), Triple(12f, 12f, 1f), Triple(12f, 19f, 1f)))
    val ChevronDown = IconSpec(listOf("M6 9l6 6 6-6"))
    val ChevronRight = IconSpec(listOf("M9 6l6 6-6 6"))
    val Back = IconSpec(listOf("M15 6l-6 6 6 6"))
    val Close = IconSpec(listOf("M6 6l12 12M18 6L6 18"))
    val Plus = IconSpec(listOf("M12 5v14M5 12h14"))
    val Music = IconSpec(listOf("M9 18V5l11-2v13"), listOf(Triple(6f, 18f, 3f), Triple(17f, 16f, 3f)))
    val Albums = IconSpec(
        listOf("M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"),
        listOf(Triple(12f, 12f, 4f), Triple(17.5f, 6.5f, 0.4f))
    )
    val Sliders = IconSpec(
        listOf("M4 8h8M16 8h4M4 16h2M10 16h10"),
        listOf(Triple(14f, 8f, 2f), Triple(8f, 16f, 2f))
    )
    val Expand = IconSpec(listOf("M4 9V4h5", "M20 9V4h-5", "M4 15v5h5", "M20 15v5h-5"))
    val Collapse = IconSpec(listOf("M9 4v5H4", "M15 4v5h5", "M9 20v-5H4", "M15 20v-5h5"))
    val Sort = IconSpec(listOf("M7 4v16", "M3.5 16.5L7 20l3.5-3.5", "M17 20V4", "M13.5 7.5L17 4l3.5 3.5"))
    val Menu = IconSpec(listOf("M4 7h16", "M4 12h10", "M4 17h13"))
    val Drag = IconSpec(listOf("M4 8h16", "M4 12h16", "M4 16h16"))
    val Play = IconSpec(listOf("M7 4.5v15l12-7.5z"))
    val Pause = IconSpec(listOf("M7 5h3.5v14H7z", "M13.5 5H17v14h-3.5z"))
    val Edit = IconSpec(listOf("M4 20h4L19 9l-4-4L4 16z", "M13.5 6.5l4 4"))
    val Star = IconSpec(listOf("M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"))
    val Check = IconSpec(listOf("M5 12.5l4.5 4.5L19 7.5"))
    val Grid = IconSpec(listOf("M4 4h6v6H4z", "M14 4h6v6h-6z", "M4 14h6v6H4z", "M14 14h6v6h-6z"))
    val Rows = IconSpec(
        listOf("M8 6h13M8 12h13M8 18h13"),
        listOf(Triple(3.5f, 6f, 1f), Triple(3.5f, 12f, 1f), Triple(3.5f, 18f, 1f))
    )
    val Stats = IconSpec(listOf("M5 20v-8", "M12 20V4", "M19 20v-5"))
    val Palette = IconSpec(
        listOf("M12 3a9 9 0 1 0 0 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.3A3.7 3.7 0 0 0 21 10.8C21 6.5 17 3 12 3z"),
        listOf(Triple(7.5f, 11f, 1f), Triple(10.5f, 7f, 1f), Triple(15f, 7.5f, 1f))
    )
    val User = IconSpec(listOf("M4 20c0-4 3.6-6 8-6s8 2 8 6"), listOf(Triple(12f, 8f, 4f)))
    val Upload = IconSpec(listOf("M12 16V4", "M7 9l5-5 5 5", "M4 20h16"))
    val Download = IconSpec(listOf("M12 4v12", "M7 11l5 5 5-5", "M4 20h16"))
    val Info = IconSpec(listOf("M12 11v5"), listOf(Triple(12f, 12f, 9f), Triple(12f, 8f, 0.3f)))
    val TextT = IconSpec(listOf("M5 7V5h14v2", "M12 5v14", "M9 19h6"))
    val Image = IconSpec(
        listOf("M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "M21 16l-5-5-9 9"),
        listOf(Triple(8.5f, 8.5f, 1.5f))
    )
}

@Composable
fun StrokeIcon(
    spec: IconSpec,
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    filled: Boolean = false
) {
    val parsed = remember(spec) { spec.paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(modifier.size(size)) {
        val s = this.size.width / 24f
        scale(s, s, pivot = Offset.Zero) {
            val stroke = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            parsed.forEach { p ->
                if (filled) drawPath(p, tint)
                drawPath(p, tint, style = stroke)
            }
            spec.circles.forEach { (x, y, r) ->
                drawCircle(tint, radius = r, center = Offset(x, y), style = stroke)
            }
        }
    }
}
