package com.songbook.app.data

/** Song keys: written by hand, or worked out from the chords a song uses. */
object Keys {
    /** Names as they are shown: major keys, then minor keys, from C. */
    val majors = listOf("C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
    val minors = listOf("Cm", "C#m", "Dm", "Ebm", "Em", "Fm", "F#m", "Gm", "G#m", "Am", "Bbm", "Bm")

    private val natural = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)
    private val chordRx = Regex("""^([A-G])([#b]?)([^/]*)""")

    private class Chord(val root: Int, val minor: Boolean)

    private fun parse(name: String): Chord? {
        val m = chordRx.find(name.trim()) ?: return null
        var root = natural.getValue(m.groupValues[1][0])
        if (m.groupValues[2] == "#") root++ else if (m.groupValues[2] == "b") root--
        val q = m.groupValues[3]
        val minor = (q.startsWith("m") && !q.startsWith("maj")) || q.startsWith("dim")
        return Chord(((root % 12) + 12) % 12, minor)
    }

    /**
     * The most likely key for [chords] (in the order they appear in the song, as written), like "Am" or "G".
     * Every one of the 24 keys is scored by how many chords belong to it; songs usually begin and end on the
     * tonic chord, which counts extra. Null when the song has fewer than two different chords.
     */
    fun detect(chords: List<String>): String? {
        val list = chords.mapNotNull { parse(it) }
        if (list.map { it.root * 2 + if (it.minor) 1 else 0 }.distinct().size < 2) return null
        var best = Double.NEGATIVE_INFINITY
        var bestName = ""
        for (tonic in 0..11) {
            for (minorKey in listOf(false, true)) {
                var score = 0.0
                for (c in list) {
                    val degree = (c.root - tonic + 12) % 12
                    val fits = if (!minorKey) {
                        when (degree) {
                            0, 5, 7 -> !c.minor
                            2, 4, 9, 11 -> c.minor
                            else -> false
                        }
                    } else {
                        when (degree) {
                            0, 5, 2 -> c.minor
                            7 -> true
                            3, 8, 10 -> !c.minor
                            else -> false
                        }
                    }
                    score += if (fits) (if (degree == 0) 1.6 else 1.0) else -0.8
                }
                if (list.first().root == tonic && list.first().minor == minorKey) score += 1.5
                if (list.last().root == tonic && list.last().minor == minorKey) score += 2.0
                if (score > best) {
                    best = score
                    bestName = if (minorKey) minors[tonic] else majors[tonic]
                }
            }
        }
        return bestName
    }

    /** All chords of a song text in order, as written. */
    fun chordsOf(body: String): List<String> =
        SongParser.parse(body).filterIsInstance<SongLine.Lyric>().flatMap { l -> l.chords.map { it.name } }
}

/** The key worked out from the chords, or null. */
fun SongEntity.autoKey(): String? = Keys.detect(Keys.chordsOf(body))

/** The key chosen by hand, or else the one worked out from the chords. */
fun SongEntity.keyOrAuto(): String? = songKey.ifBlank { null } ?: autoKey()
