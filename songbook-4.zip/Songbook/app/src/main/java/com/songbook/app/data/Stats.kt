package com.songbook.app.data

import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

/** Everything the Statistics page shows, worked out from the library. */
class LibraryStats(
    val songs: Int,
    val finished: Int,
    val inProgress: Int,
    val ideas: Int,
    val albums: Int,
    val groups: Int,
    val favorites: Int,
    val rated: Int,
    val avgRating: Float,
    /** Songs rated up to 1, 2, 3, 4 and 5 stars. */
    val ratingBuckets: List<Int>,
    val words: Int,
    val chordsPlaced: Int,
    val songsWithChords: Int,
    val topChords: List<Pair<String, Int>>,
    val keys: List<Pair<String, Int>>,
    val withBpm: Int,
    val avgBpm: Int,
    val recordings: Int,
    val recordedMs: Long,
    val songsWithDemo: Int,
    val opens: Int,
    val readSeconds: Long,
    val mostOpened: List<SongEntity>,
    val mostRead: List<SongEntity>,
    val topRated: List<SongEntity>,
    val recent: List<SongEntity>,
    /** Songs added in each of the last six months, oldest first. */
    val perMonth: List<Pair<String, Int>>
)

object Stats {
    fun compute(
        songs: List<SongEntity>,
        albums: List<AlbumEntity>,
        groups: List<GroupEntity>,
        recordings: List<RecordingEntity>
    ): LibraryStats {
        val rated = songs.filter { it.rating > 0f }
        val buckets = MutableList(5) { 0 }
        rated.forEach { s -> buckets[(Math.ceil(s.rating.toDouble()).toInt().coerceIn(1, 5)) - 1]++ }

        var words = 0
        var placed = 0
        var withChords = 0
        val chordCounts = HashMap<String, Int>()
        val keyCounts = HashMap<String, Int>()
        songs.forEach { s ->
            val lines = SongParser.parse(s.body)
            val chords = lines.filterIsInstance<SongLine.Lyric>().flatMap { it.chords.map { c -> c.name } }
            lines.filterIsInstance<SongLine.Lyric>().forEach { l ->
                words += l.text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
            }
            if (chords.isNotEmpty()) withChords++
            placed += chords.size
            chords.forEach { chordCounts[it] = (chordCounts[it] ?: 0) + 1 }
            (s.songKey.ifBlank { null } ?: Keys.detect(chords))?.let { keyCounts[it] = (keyCounts[it] ?: 0) + 1 }
        }

        val bpms = songs.map { it.bpm }.filter { it > 0 }
        val zone = ZoneId.systemDefault()
        val now = YearMonth.now()
        val months = (5 downTo 0).map { back ->
            val ym = now.minusMonths(back.toLong())
            val n = songs.count { YearMonth.from(Instant.ofEpochMilli(it.createdAt).atZone(zone)) == ym }
            ym.month.getDisplayName(TextStyle.SHORT, Locale.getDefault()) to n
        }
        val songIds = songs.map { it.id }.toSet()
        val demos = recordings.filter { it.songId in songIds }

        return LibraryStats(
            songs = songs.size,
            finished = songs.count { it.stage >= Stage.DONE },
            inProgress = songs.count { it.stage in (Stage.IDEA + 1) until Stage.DONE },
            ideas = songs.count { it.stage == Stage.IDEA },
            albums = albums.size,
            groups = groups.size,
            favorites = songs.count { it.favorite },
            rated = rated.size,
            avgRating = if (rated.isEmpty()) 0f else rated.map { it.rating }.average().toFloat(),
            ratingBuckets = buckets,
            words = words,
            chordsPlaced = placed,
            songsWithChords = withChords,
            topChords = chordCounts.entries.sortedByDescending { it.value }.take(8).map { it.key to it.value },
            keys = keyCounts.entries.sortedByDescending { it.value }.take(6).map { it.key to it.value },
            withBpm = bpms.size,
            avgBpm = if (bpms.isEmpty()) 0 else bpms.average().toInt(),
            recordings = demos.size,
            recordedMs = demos.sumOf { it.durationMs },
            songsWithDemo = demos.map { it.songId }.distinct().size,
            opens = songs.sumOf { it.opens },
            readSeconds = songs.sumOf { it.readSeconds },
            mostOpened = songs.filter { it.opens > 0 }.sortedByDescending { it.opens }.take(5),
            mostRead = songs.filter { it.readSeconds > 0 }.sortedByDescending { it.readSeconds }.take(5),
            topRated = rated.sortedWith(compareByDescending<SongEntity> { it.rating }.thenByDescending { it.opens }).take(5),
            recent = songs.filter { it.lastOpened > 0 }.sortedByDescending { it.lastOpened }.take(5),
            perMonth = months
        )
    }
}
