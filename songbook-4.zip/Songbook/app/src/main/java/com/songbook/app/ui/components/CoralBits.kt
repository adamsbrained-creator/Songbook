package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.songbook.app.ui.theme.sbStyle

/**
 * Ring with a rounded coral arc, used for "Songs finished" on the Settings and Statistics pages.
 * [fraction] is 0..1, [label] is written in the middle ("79%").
 */
@Composable
fun ProgressRing(
    fraction: Float,
    size: Dp,
    stroke: Dp,
    track: Color,
    color: Color,
    label: String,
    labelColor: Color,
    labelSize: Int,
    modifier: Modifier = Modifier
) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val topLeft = Offset(w / 2f, w / 2f)
            val arc = Size(this.size.width - w, this.size.height - w)
            drawArc(track, 0f, 360f, false, topLeft = topLeft, size = arc, style = Stroke(width = w))
            val sweep = 360f * fraction.coerceIn(0f, 1f)
            if (sweep > 0f) drawArc(color, -90f, sweep, false, topLeft = topLeft, size = arc, style = Stroke(width = w, cap = StrokeCap.Round))
        }
        Text(label, style = sbStyle(labelSize, FontWeight.SemiBold, labelColor))
    }
}
