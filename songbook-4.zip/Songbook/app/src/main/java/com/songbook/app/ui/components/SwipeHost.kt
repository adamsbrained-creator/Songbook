package com.songbook.app.ui.components

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Paperback's page swipe (SwipeHost.kt): swipe right for [onSwipeRight] (usually Back), left for [onSwipeLeft].
 * Anything inside that scrolls or drags sideways (sliders, a scrolling row, the rating stars) takes the swipe
 * first, so those keep working; only a free horizontal swipe of about 80 dp counts.
 */
fun Modifier.swipePages(
    enabled: Boolean,
    onSwipeRight: (() -> Unit)?,
    onSwipeLeft: (() -> Unit)?
): Modifier = composed {
    val right by rememberUpdatedState(onSwipeRight)
    val left by rememberUpdatedState(onSwipeLeft)
    pointerInput(enabled) {
        if (!enabled) return@pointerInput
        val threshold = 80.dp.toPx()
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragCancel = { total = 0f },
            onDragEnd = {
                if (total > threshold) right?.invoke() else if (total < -threshold) left?.invoke()
                total = 0f
            },
            onHorizontalDrag = { _, amount -> total += amount }
        )
    }
}
