package com.songbook.app.ui.screens

import com.songbook.app.ui.components.CoralEmptyCard
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.songbook.app.data.AlbumEntity
import com.songbook.app.data.AppSettings
import com.songbook.app.data.SongEntity
import com.songbook.app.data.SongLine
import com.songbook.app.data.SongParser
import com.songbook.app.data.SongSort
import com.songbook.app.data.SongsLayout
import com.songbook.app.data.Stage
import com.songbook.app.data.Transposer
import com.songbook.app.data.UiStyle
import com.songbook.app.data.hasChords
import com.songbook.app.data.hasTabs
import com.songbook.app.data.kindLabel
import com.songbook.app.data.sortedAlbums
import com.songbook.app.data.sortedSongs
import com.songbook.app.ui.components.Artwork
import com.songbook.app.ui.components.BadgePill
import com.songbook.app.ui.components.BlockList
import com.songbook.app.ui.components.Blocks
import com.songbook.app.ui.components.BlocksDialog
import com.songbook.app.ui.components.ChipPill
import com.songbook.app.ui.components.ChoiceDialog
import com.songbook.app.ui.components.CoralTopBar
import com.songbook.app.ui.components.MenuAction
import com.songbook.app.ui.components.CircleArtwork
import com.songbook.app.ui.components.EmptyHint
import com.songbook.app.ui.components.FilterPill
import com.songbook.app.ui.components.GlassRoundButton
import com.songbook.app.ui.components.GlassTitle
import com.songbook.app.ui.components.RatingTag
import com.songbook.app.ui.components.SbIconButton
import com.songbook.app.ui.components.SbIcons
import com.songbook.app.ui.components.SectionTitle
import com.songbook.app.ui.components.SimpleSongRow
import com.songbook.app.ui.components.SongGridCell
import com.songbook.app.ui.components.SongRow
import com.songbook.app.ui.components.SquareArtwork
import com.songbook.app.ui.components.StrokeIcon
import com.songbook.app.ui.components.WorkflowEntry
import com.songbook.app.ui.components.rememberCover
import com.songbook.app.ui.components.sbCard
import com.songbook.app.ui.components.screenBg
import com.songbook.app.ui.components.songType
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.gradientBrush
import com.songbook.app.ui.theme.sbStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LibraryActions(
    val onOpenSong: (Long) -> Unit,
    val onOpenAlbum: (Long) -> Unit,
    val onToggleFavorite: (SongEntity) -> Unit,
    val onMenu: (Long) -> Unit,
    val onOpenWorkflow: () -> Unit,
    val onNew: () -> Unit,
    val onNavigate: (String) -> Unit,
    val onSettings: () -> Unit,
    val onSongSort: (Int) -> Unit,
    val onSongsLayout: (Int) -> Unit,
    val onArrangeSongs: () -> Unit,
    /** Saves the order and visibility of the main page blocks ("" = standard). */
    val onSaveHome: (String) -> Unit
)

/** What the three looks share: the filtered and sorted list, the typed search and the blocks of the page. */
private class Ctx(
    val songs: List<SongEntity>,
    val albums: List<AlbumEntity>,
    val albumNames: Map<Long, String>,
    val settings: AppSettings,
    val filtered: List<SongEntity>,
    val visible: List<SongEntity>,
    val searching: Boolean,
    val showAll: Boolean,
    val filter: Int,
    val query: String,
    val workflowCount: Int,
    val ideaCount: Int,
    val blocks: BlockList,
    val a: LibraryActions,
    val setFilter: (Int) -> Unit,
    val setQuery: (String) -> Unit,
    val toggleShowAll: () -> Unit,
    val openSort: () -> Unit,
    val openLayout: () -> Unit,
    val openBlocks: () -> Unit,
    /** Songs in each album, for the album cards. */
    val albumCounts: Map<Long?, Int>
)

@Composable
fun LibraryScreen(
    songs: List<SongEntity>,
    albums: List<AlbumEntity>,
    settings: AppSettings,
    greeting: String,
    workflowCount: Int,
    ideaCount: Int,
    searchTick: Int,
    actions: LibraryActions
) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var showAll by rememberSaveable { mutableStateOf(false) }
    var dialog by remember { mutableIntStateOf(0) }   // 1 sort, 2 layout, 3 blocks
    val albumNames = remember(albums) { albums.associate { it.id to it.name } }
    val style = Sb.style

    val filtered = remember(songs, filter, query, albumNames, settings.songSort) {
        songs.filter { s ->
            val kindOk = when (filter) {
                0 -> true
                1 -> !s.hasChords() && !s.hasTabs()
                2 -> s.hasChords()
                else -> s.hasTabs()
            }
            val q = query.trim()
            val queryOk = q.isEmpty() ||
                s.title.contains(q, true) || s.tags.contains(q, true) || s.body.contains(q, true) ||
                s.badge.contains(q, true) || s.typeName.contains(q, true) ||
                (albumNames[s.albumId]?.contains(q, true) == true)
            kindOk && queryOk
        }.sortedSongs(settings.songSort, albumNames)
    }
    val sortedAlbums = remember(albums, settings.albumSort) { albums.sortedAlbums(settings.albumSort) }
    val searching = query.isNotBlank() || filter != 0
    val visible = if (showAll || searching) filtered else filtered.take(5)
    // Coral can borrow the Glass look's main page (Settings > Look > Home Layout)
    val glassy = style == UiStyle.CORAL && settings.coralHome == 1
    val blocks = remember(settings.homeLayout, style, glassy) { Blocks.resolve(settings.homeLayout, Blocks.home(if (glassy) UiStyle.GLASS else style)) }

    if (dialog == 1) {
        ChoiceDialog("Sort songs", SongSort.names, settings.songSort, { actions.onSongSort(it); dialog = 0 }, { dialog = 0 })
    }
    if (dialog == 2) {
        ChoiceDialog("Song layout", SongsLayout.names, settings.songsLayout, { actions.onSongsLayout(it); dialog = 0 }, { dialog = 0 })
    }
    if (dialog == 3) {
        BlocksDialog(
            "Main page", blocks,
            onSave = { actions.onSaveHome(Blocks.encode(it)); dialog = 0 },
            onReset = { actions.onSaveHome(""); dialog = 0 },
            onDismiss = { dialog = 0 }
        )
    }

    val ctx = Ctx(
        songs, sortedAlbums, albumNames, settings, filtered, visible, searching, showAll, filter, query,
        workflowCount, ideaCount, blocks, actions, { filter = it }, { query = it }, { showAll = !showAll },
        { dialog = 1 }, { dialog = 2 }, { dialog = 3 }, songs.groupingBy { it.albumId }.eachCount()
    )
    when (style) {
        UiStyle.CORAL -> CoralLibrary(ctx, greeting, searchTick, glassy)
        UiStyle.GLASS -> GlassLibrary(ctx, greeting) { dialog = 3 }
        else -> OldLibrary(ctx, greeting)
    }
}

// ================================================================================================
//  shared pieces
// ================================================================================================

@Composable
private fun SearchField(ctx: Ctx, focus: FocusRequester, modifier: Modifier = Modifier) {
    val c = Sb.colors
    val coral = c.style == UiStyle.CORAL
    // Coral: Paperback's big filled search pill
    Row(
        modifier.fillMaxWidth().height(if (coral) 56.dp else 48.dp).sbCard(if (coral) 28.dp else 16.dp).padding(horizontal = if (coral) 20.dp else 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StrokeIcon(SbIcons.Search, c.mu, size = 20.dp)
        BasicTextField(
            value = ctx.query,
            onValueChange = ctx.setQuery,
            singleLine = true,
            textStyle = sbStyle(14, color = c.tx),
            cursorBrush = SolidColor(c.ac),
            modifier = Modifier.weight(1f).focusRequester(focus),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (ctx.query.isEmpty()) Text("Search songs", style = sbStyle(14, color = c.mu))
                    inner()
                }
            }
        )
    }
}

@Composable
private fun FilterRow(ctx: Ctx, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(if (Sb.style == UiStyle.OLD) 4.dp else 8.dp)) {
        listOf("All", "Lyrics", "Chords", "Tabs").forEachIndexed { i, label ->
            if (Sb.style == UiStyle.OLD) FilterPill(label, ctx.filter == i) { ctx.setFilter(i) }
            else ChipPill(label, ctx.filter == i, { ctx.setFilter(i) }, Modifier.height(if (Sb.style == UiStyle.CORAL) 44.dp else 36.dp))
        }
    }
}

/** Coral: Paperback's "Sort: ..." and "View: ..." pills, which open the same choices as the old icon buttons. */
@Composable
private fun CoralSortRow(ctx: Ctx) {
    val c = Sb.colors
    if (c.style != UiStyle.CORAL) return
    val sort = SongSort.names.getOrElse(ctx.settings.songSort) { "" }.substringBefore(" (")
    val view = SongsLayout.names.getOrElse(ctx.settings.songsLayout) { "" }.substringBefore(",")
    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Sort: $sort" to ctx.openSort, "View: $view" to ctx.openLayout).forEach { (label, go) ->
            Box(
                Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(c.cd).clickable(onClick = go).padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) { Text(label, style = sbStyle(14, FontWeight.SemiBold, c.tx), maxLines = 1) }
        }
    }
}

/** "All Songs" header with See All, Sort and the layout button. */
private fun LazyListScope.songsHeader(ctx: Ctx) {
    item { CoralSortRow(ctx) }
    item {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 14.dp, bottom = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionTitle(if (ctx.searching) "Results" else "All Songs")
            Row(verticalAlignment = Alignment.CenterVertically) {
                val c = Sb.colors
                if (ctx.settings.songSort == SongSort.MANUAL) {
                    Text(
                        "Arrange", style = sbStyle(12, FontWeight.SemiBold, c.ac),
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { ctx.a.onArrangeSongs() }.padding(horizontal = 8.dp, vertical = 8.dp)
                    )
                }
                if (!ctx.searching && ctx.filtered.size > 5) {
                    Text(
                        if (ctx.showAll) "Show Less" else "See All",
                        style = sbStyle(12, color = c.mu),
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { ctx.toggleShowAll() }.padding(horizontal = 8.dp, vertical = 8.dp)
                    )
                }
                if (c.style != UiStyle.CORAL) {
                    SbIconButton(SbIcons.Sort, "Sort songs", ctx.openSort, tint = c.mu, size = 20.dp)
                    SbIconButton(
                        icon = if (SongsLayout.columns(ctx.settings.songsLayout) > 0) SbIcons.Grid else SbIcons.Rows,
                        description = "Song layout",
                        onClick = ctx.openLayout,
                        tint = c.mu,
                        size = 20.dp
                    )
                }
            }
        }
    }
}

/** The song rows (or tiles). Old: plain rows with dividers. Coral and Glass: every row is a card. */
private fun LazyListScope.songsBlock(ctx: Ctx, card: Boolean) {
    if (ctx.visible.isEmpty()) {
        item {
            if (Sb.style == UiStyle.CORAL && ctx.songs.isEmpty()) {
                CoralEmptyCard("Your library is empty", "Write your first song, or bring your songs back from a backup in Settings.", "New song", ctx.a.onNew)
            } else {
                EmptyHint(if (ctx.songs.isEmpty()) "No songs yet. Tap + to write your first one." else "Nothing matches your search.")
            }
        }
    }
    val cols = SongsLayout.columns(ctx.settings.songsLayout)
    if (cols > 0) {
        val rows = ctx.visible.chunked(cols)
        items(rows, key = { row -> row.first().id }) { row ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = if (cols >= 4) 5.dp else 8.dp),
                horizontalArrangement = Arrangement.spacedBy(if (cols >= 4) 8.dp else 12.dp)
            ) {
                row.forEach { s ->
                    SongGridCell(
                        s, ctx.albumNames[s.albumId] ?: "No album", cols,
                        { ctx.a.onOpenSong(s.id) }, { ctx.a.onToggleFavorite(s) }, { ctx.a.onMenu(s.id) },
                        Modifier.weight(1f)
                    )
                }
                repeat(cols - row.size) { Box(Modifier.weight(1f)) }
            }
        }
    } else if (ctx.settings.songsLayout == SongsLayout.SIMPLE) {
        items(ctx.visible, key = { it.id }) { s ->
            SimpleSongRow(
                title = s.title, subtitle = ctx.albumNames[s.albumId] ?: "",
                favorite = s.favorite, rating = s.rating, divider = s.id != ctx.visible.last().id,
                onClick = { ctx.a.onOpenSong(s.id) }, onMore = { ctx.a.onMenu(s.id) }
            )
        }
    } else {
        val compact = ctx.settings.songsLayout == SongsLayout.COMPACT
        items(ctx.visible, key = { it.id }) { s ->
            SongRow(
                title = s.title,
                subtitle = songType(s.typeName) + " · " + (ctx.albumNames[s.albumId] ?: "No album"),
                gradient = s.gradient, favorite = s.favorite,
                onClick = { ctx.a.onOpenSong(s.id) }, onFavorite = { ctx.a.onToggleFavorite(s) }, onMore = { ctx.a.onMenu(s.id) },
                image = s.image, badge = s.badge, badgeColor = s.badgeColor, rating = s.rating,
                divider = s.id != ctx.visible.last().id, card = card, compact = compact
            )
        }
    }
}

/** Horizontal tiles: recently edited songs. */
private fun LazyListScope.recentRow(ctx: Ctx, title: String, tile: Int) {
    if (ctx.songs.isEmpty() || ctx.query.isNotBlank() || ctx.filter != 0) return
    item { SectionTitle(title, Modifier.padding(start = 24.dp, end = 24.dp, top = 18.dp, bottom = 10.dp)) }
    item {
        val c = Sb.colors
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(ctx.songs.take(8), key = { it.id }) { s ->
                Column(Modifier.width(tile.dp).clickable { ctx.a.onOpenSong(s.id) }) {
                    Box {
                        SquareArtwork(s.gradient, tile.dp, if (tile > 100) 20.dp else 18.dp, elevated = true, image = s.image)
                        if (s.badge.isNotBlank()) BadgePill(s.badge, s.badgeColor, Modifier.align(Alignment.TopStart).padding(6.dp), solid = true)
                    }
                    Text(s.title, style = sbStyle(14, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                    Text(s.kindLabel(), style = sbStyle(12, color = c.mu), maxLines = 1)
                    RatingTag(s.rating)
                }
            }
        }
    }
}

/** Top albums as a horizontal row of tiles (Glass and Coral). Hidden when the setting is 0. */
private fun LazyListScope.albumsRow(ctx: Ctx, title: String, tile: Int, plain: Boolean = false) {
    val n = ctx.settings.topAlbums
    if (n <= 0 || ctx.albums.isEmpty() || ctx.query.isNotBlank()) return
    item { SectionTitle(title, Modifier.padding(start = 24.dp, end = 24.dp, top = 18.dp, bottom = 10.dp)) }
    item {
        val c = Sb.colors
        val coral = c.style == UiStyle.CORAL && !plain
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(ctx.albums.take(n), key = { it.id }) { a ->
                val box = if (coral) {
                    Modifier.width((tile + 16).dp).sbCard(16.dp).clip(RoundedCornerShape(16.dp)).clickable { ctx.a.onOpenAlbum(a.id) }.padding(8.dp)
                } else Modifier.width(tile.dp).clickable { ctx.a.onOpenAlbum(a.id) }
                Column(box) {
                    Artwork(a.gradient, RoundedCornerShape(if (coral) 10.dp else 18.dp), Modifier.size(tile.dp), image = a.image) {
                        if (a.badge.isNotBlank()) Box(Modifier.matchParentSize().padding(6.dp), contentAlignment = Alignment.TopStart) { BadgePill(a.badge, a.badgeColor, solid = true) }
                    }
                    Text(a.name, style = sbStyle(12, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                    if (coral) {
                        val count = ctx.albumCounts[a.id] ?: 0
                        Text(if (count == 1) "1 song" else "$count songs", style = sbStyle(11, color = c.mu), maxLines = 1)
                    }
                }
            }
        }
    }
}

/**
 * Coral: the pinned albums as a plain grid, two to a row. The cover, then the name and the song count under it,
 * no card around them. Hidden when the setting is 0.
 */
private fun LazyListScope.albumsGrid(ctx: Ctx, title: String) {
    val n = ctx.settings.topAlbums
    if (n <= 0 || ctx.albums.isEmpty() || ctx.query.isNotBlank()) return
    item { SectionTitle(title, Modifier.padding(start = 24.dp, end = 24.dp, top = 18.dp, bottom = 12.dp)) }
    val rows = ctx.albums.take(n).chunked(2)
    items(rows.size) { r ->
        val c = Sb.colors
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            rows[r].forEach { a ->
                Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable { ctx.a.onOpenAlbum(a.id) }) {
                    Artwork(a.gradient, RoundedCornerShape(18.dp), Modifier.fillMaxWidth().aspectRatio(1f), image = a.image, imagePx = 700) {
                        if (a.badge.isNotBlank()) Box(Modifier.matchParentSize().padding(8.dp), contentAlignment = Alignment.TopStart) { BadgePill(a.badge, a.badgeColor, solid = true) }
                    }
                    Text(a.name, style = sbStyle(15, FontWeight.SemiBold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                    val count = ctx.albumCounts[a.id] ?: 0
                    Text(if (count == 1) "1 song" else "$count songs", style = sbStyle(13, color = c.mu), maxLines = 1)
                }
            }
            if (rows[r].size < 2) Spacer(Modifier.weight(1f))
        }
    }
}

private fun LazyListScope.workflowBlock(ctx: Ctx) {
    if (ctx.query.isBlank() && ctx.filter == 0) {
        item { WorkflowEntry(ctx.workflowCount, ctx.ideaCount, ctx.a.onOpenWorkflow, Modifier.padding(top = 16.dp)) }
    }
}

// ================================================================================================
//  OLD: the classic layout
// ================================================================================================

@Composable
private fun OldLibrary(ctx: Ctx, greeting: String) {
    val c = Sb.colors
    val focus = remember { FocusRequester() }
    LazyColumn(Modifier.fillMaxSize().screenBg().statusBarsPadding(), contentPadding = PaddingValues(bottom = 130.dp)) {
        item {
            Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp)) {
                Text(greeting, style = sbStyle(26, FontWeight.Bold, c.tx))
                Text("Your songs, all in one place.", style = sbStyle(14, color = c.mu), modifier = Modifier.padding(top = 2.dp))
            }
        }
        ctx.blocks.forEach { (id, on) ->
            if (!on) return@forEach
            when (id) {
                "filters" -> item { FilterRow(ctx, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
                "search" -> item { SearchField(ctx, focus, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
                "albums" -> {
                    val n = ctx.settings.topAlbums
                    if (n > 0 && ctx.albums.isNotEmpty() && ctx.query.isBlank()) {
                        item {
                            Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                ctx.albums.take(n).chunked(2).forEach { pair ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        pair.forEach { a ->
                                            val cover = rememberCover(a.image, 400)
                                            Box(
                                                Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(16.dp)).background(gradientBrush(a.gradient))
                                                    .clickable { ctx.a.onOpenAlbum(a.id) }
                                            ) {
                                                if (cover != null) {
                                                    Image(cover, null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                                                    Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.32f)))
                                                }
                                                Text(
                                                    a.name, style = sbStyle(15, FontWeight.SemiBold, Color.White), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.align(Alignment.BottomStart).padding(horizontal = 14.dp, vertical = 9.dp)
                                                )
                                            }
                                        }
                                        if (pair.size == 1) Box(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
                "workflow" -> workflowBlock(ctx)
                "recent" -> recentRow(ctx, "Recently Edited", 112)
                "songs" -> { songsHeader(ctx); songsBlock(ctx, card = false) }
            }
        }
    }
}

// ================================================================================================
//  GLASS
// ================================================================================================

@Composable
private fun GlassLibrary(ctx: Ctx, greeting: String, onCustomize: () -> Unit) {
    val focus = remember { FocusRequester() }
    var menu by remember { mutableStateOf(false) }
    val c = Sb.colors
    LazyColumn(Modifier.fillMaxSize().screenBg().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 24.dp, end = 16.dp, top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                GlassTitle(greeting, "Your songs, all in one place.", Modifier.weight(1f).padding(end = 12.dp))
                Box {
                    GlassRoundButton(SbIcons.More, "More", { menu = true })
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, modifier = Modifier.background(c.sheet)) {
                        DropdownMenuItem(text = { Text("Song layout", style = sbStyle(14, color = c.tx)) }, onClick = { menu = false; ctx.openLayout() })
                        DropdownMenuItem(text = { Text("Sort songs", style = sbStyle(14, color = c.tx)) }, onClick = { menu = false; ctx.openSort() })
                        DropdownMenuItem(text = { Text("Customize this page", style = sbStyle(14, color = c.tx)) }, onClick = { menu = false; onCustomize() })
                        DropdownMenuItem(text = { Text("Workflow", style = sbStyle(14, color = c.tx)) }, onClick = { menu = false; ctx.a.onOpenWorkflow() })
                    }
                }
            }
        }
        ctx.blocks.forEach { (id, on) ->
            if (!on) return@forEach
            when (id) {
                "filters" -> item { FilterRow(ctx, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
                "search" -> item { SearchField(ctx, focus, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
                "albums" -> albumsRow(ctx, "Pinned", 92)
                "workflow" -> workflowBlock(ctx)
                "recent" -> recentRow(ctx, "Recently Edited", 92)
                "songs" -> { songsHeader(ctx); songsBlock(ctx, card = true) }
            }
        }
    }
}

// ================================================================================================
//  CORAL: round-button top bar, big serif greeting, white cards
// ================================================================================================

@Composable
private fun CoralLibrary(ctx: Ctx, greeting: String, searchTick: Int, glassy: Boolean) {
    val c = Sb.colors
    val focus = remember { FocusRequester() }
    var showSearch by remember { mutableStateOf(false) }
    var searchTap by remember { mutableIntStateOf(0) }
    LaunchedEffect(searchTick + searchTap) {
        if (searchTick + searchTap > 0) {
            showSearch = true
            delay(120)
            runCatching { focus.requestFocus() }
        }
    }
    LazyColumn(Modifier.fillMaxSize().screenBg().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
        item {
            CoralTopBar(
                pageTitle = greeting, onSearch = { searchTap++ },
                current = "library", onNavigate = ctx.a.onNavigate,
                chip = if (ctx.songs.size == 1) "1 song" else "${ctx.songs.size} songs",
                showLabel = !glassy,
                extras = listOf(
                    MenuAction("Sort songs") { ctx.openSort() },
                    MenuAction("Song layout") { ctx.openLayout() },
                    MenuAction("Customize this page") { ctx.openBlocks() },
                    MenuAction("Workflow") { ctx.a.onOpenWorkflow() }
                )
            )
        }
        if (glassy) {
            // the Glass look's big greeting
            item {
                Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 6.dp)) {
                    Text(greeting, style = sbStyle(32, FontWeight.Bold, c.tx), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Your songs, all in one place.", style = sbStyle(14, color = c.mu), modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
        // the search button of the top bar opens a box here, unless the Glassy page already shows one
        val searchBlock = glassy && ctx.blocks.any { it.first == "search" && it.second }
        if (!searchBlock && (showSearch || ctx.query.isNotBlank())) {
            item { SearchField(ctx, focus, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
        }
        ctx.blocks.forEach { (id, on) ->
            if (!on) return@forEach
            when (id) {
                "filters" -> item { FilterRow(ctx, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) }
                "search" -> { if (glassy) item { SearchField(ctx, focus, Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp)) } }
                "albums" -> if (glassy) albumsRow(ctx, "Pinned", 92, plain = true) else albumsGrid(ctx, "Pinned")
                "workflow" -> workflowBlock(ctx)
                "recent" -> if (glassy) recentRow(ctx, "Recently Edited", 92) else recentRow(ctx, "Recently edited", 104)
                "songs" -> { songsHeader(ctx); songsBlock(ctx, card = true) }
            }
        }
    }
}
