package com.songbook.app.ui.components

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.songbook.app.data.UiStyle
import com.songbook.app.ui.theme.Sb
import com.songbook.app.ui.theme.sbStyle

/**
 * The app's text field. Drop-in for OutlinedTextField: the Coral look gets Paperback's field (filled, rounded,
 * no outline, cursor in the accent); Old and Glass keep the outlined field.
 */
@Composable
fun SbField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: (@Composable () -> Unit)? = null,
    textStyle: TextStyle = sbStyle(15, color = Sb.colors.tx),
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE
) {
    val c = Sb.colors
    if (c.style != UiStyle.CORAL) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = modifier,
            label = label,
            textStyle = textStyle,
            keyboardOptions = keyboardOptions,
            singleLine = singleLine,
            minLines = minLines,
            maxLines = maxLines
        )
        return
    }
    // Paperback's field: filled with the card color, so it reads on a white dialog
    val fill = c.cd
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        label = label,
        textStyle = textStyle,
        keyboardOptions = keyboardOptions,
        singleLine = singleLine,
        minLines = minLines,
        maxLines = maxLines,
        shape = RoundedCornerShape(if (singleLine) 28.dp else 22.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = fill,
            unfocusedContainerColor = fill,
            disabledContainerColor = fill,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = c.ac,
            focusedTextColor = c.tx,
            unfocusedTextColor = c.tx,
            focusedLabelColor = c.mu,
            unfocusedLabelColor = c.mu
        )
    )
}
