package com.songbook.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// The metronome icon: a pink-red tile, a white metronome and a pink pendulum with its faint swing shadow.
// Same shapes and colors as res/drawable/ic_launcher_*.xml, on a 1080 grid.
private val IconTop = Color(0xFFFD628C)
private val IconBottom = Color(0xFFEA2157)
private val IconInk = Color(0xFFF63E70)
private val IconGhost = Color(0xFFFCBCCD)

private const val BodyPath =
    "M425,172 L650,172 Q676,172 684,198 L878,886 Q886,930 845,930 L232,930 Q190,930 197,886 L391,198 Q399,172 425,172 Z"

/** In-app copy of the Songbook icon. */
@Composable
fun AppIconArt(size: Dp, modifier: Modifier = Modifier) {
    val body = remember { PathParser().parsePathString(BodyPath).toPath() }
    val shape = RoundedCornerShape(size * 0.225f)
    Canvas(
        modifier.size(size)
            .shadow(if (size > 60.dp) 12.dp else 0.dp, shape)
            .clip(shape)
            .border(1.dp, Color(0x14FFFFFF), shape)
    ) {
        val s = this.size.width / 1080f
        scale(s, s, pivot = Offset.Zero) {
            drawRect(
                Brush.linearGradient(listOf(IconTop, IconBottom), start = Offset(300f, 0f), end = Offset(780f, 1080f)),
                size = Size(1080f, 1080f)
            )
            // the launcher shows about two thirds of its canvas, this tile shows all of it: 0.75 here looks like 0.5 there
            scale(0.75f, 0.75f, pivot = Offset(540f, 540f)) {
                drawPath(body, Color.White)
                drawLine(IconGhost, Offset(428f, 368f), Offset(535f, 752f), strokeWidth = 40f, cap = StrokeCap.Round)
                drawLine(IconInk, Offset(647f, 365f), Offset(540f, 800f), strokeWidth = 40f, cap = StrokeCap.Round)
                drawCircle(IconInk, radius = 45f, center = Offset(537f, 805f))
                rotate(14f, pivot = Offset(627f, 437f)) {
                    drawRoundRect(IconInk, topLeft = Offset(563f, 398f), size = Size(128f, 78f), cornerRadius = CornerRadius(22f))
                }
            }
        }
    }
}
